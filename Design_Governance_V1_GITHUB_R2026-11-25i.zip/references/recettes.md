# Recettes de procédé

Des procédés déjà résolus pour des difficultés de code où un rendu perd du temps ou se trompe. Chaque recette règle un comportement ou un procédé, jamais une apparence : police, couleur, taille, rythme et aspect d’une matière restent à la direction. `python3 scripts/parcours.py recette NOM` affiche une recette ; `python3 scripts/parcours.py recette` les liste. Une technique sans recette se cherche avec `SAVOIR/TECH`, « Chercher une méthode ».

Une recette n’entre ici que si plusieurs rendus ont achoppé sur la même difficulté. Si deux rendus en sortent avec la même apparence, elle impose un style : elle se réécrit ou se retire.

## graphique

**Problème.** Un graphique lisible au bureau devient illisible ou chevauché à 390 px : le texte d’un SVG mis à l’échelle rapetisse avec lui, et les étiquettes se recouvrent.

**Quand.** Une série de valeurs à comparer (barres, volume par semaine, évolution). **Pas quand** la donnée tient en une phrase ou en un seul chiffre.

**Procédé.** Les marques se dessinent à l’échelle, le texte reste en HTML à sa taille. Les étiquettes s’éclaircissent sous une largeur donnée ; la valeur mise en avant et les extrêmes restent écrits.

```html
<figure class="graph" aria-label="Kilomètres par semaine">
  <ol class="barres">
    <li style="--v:.70"><span class="val">21</span><span class="lab">S1</span></li>
    <li style="--v:.77"><span class="val">23</span><span class="lab">S2</span></li>
    <li style="--v:.83"><span class="val">25</span><span class="lab">S3</span></li>
    <li style="--v:1" class="cle"><span class="val">30</span><span class="lab">S4</span></li>
    <li style="--v:.53"><span class="val">16</span><span class="lab">S5</span></li>
  </ol>
</figure>
<style>
.graph { container-type: inline-size; margin: 0 }
.barres { list-style: none; margin: 0; padding: 0; display: grid; grid-auto-flow: column; grid-auto-columns: 1fr;
  gap: clamp(2px, 1.5cqi, 12px); align-items: end; height: 220px; border-bottom: 1px solid currentColor }
.barres li { display: flex; flex-direction: column; justify-content: flex-end; height: 100%; position: relative }
.barres li::before { content: ""; order: 2; height: calc(var(--v) * 80%); background: var(--marque, #888) }
.barres .cle::before { background: var(--accent, #111) }
.val { order: 1; font-variant-numeric: tabular-nums; font-size: .8rem; text-align: center }
.lab { position: absolute; top: 100%; left: 0; right: 0; text-align: center; font-size: .75rem; padding-top: 4px }
@container (max-width: 420px) {
  .barres li:not(.cle):not(:first-child):not(:last-child) .val { visibility: hidden }
  .barres li:nth-child(even):not(.cle) .lab { visibility: hidden }
}
</style>
```

**La direction décide.** Couleurs des marques et de la valeur clé, hauteur, épaisseur des barres, police des chiffres, axe ou non.

**Vérifier sur capture.** À 390 px : aucune étiquette recouverte, la valeur clé et les extrêmes lisibles à au moins 12 px, chiffres alignés.

## grand-chiffre

**Problème.** Un grand chiffre qui change (saisie, recalcul, compteur) saute en largeur, déborde de son cadre ou écrase le champ voisin, et son contraste se perd quand il sort de son fond.

**Quand.** Un montant, un temps, un score mis en scène en grand. **Pas quand** le chiffre est secondaire.

**Procédé.** Figures tabulaires, largeur réservée en `ch` selon le nombre de caractères, taille bornée par la largeur du conteneur, recalcul sans animation sous mouvement réduit.

```html
<div class="montant">
  <label for="m">Vous envoyez</label>
  <input id="m" inputmode="decimal" value="200" autocomplete="off">
  <output for="m" id="r" aria-live="polite">131 191</output>
</div>
<style>
.montant { container-type: inline-size; display: grid; gap: .25rem; overflow: hidden }
.montant input, .montant output { font: inherit; font-variant-numeric: tabular-nums; white-space: nowrap;
  font-size: min(8rem, 18cqi); line-height: .95; border: 0; background: none; color: inherit; padding: 0 }
.montant input { width: calc(var(--n, 3) * 1ch + .1ch); min-width: 2ch; border-bottom: 2px solid currentColor }
</style>
<script>
const m = document.getElementById('m'), r = document.getElementById('r');
const fmt = new Intl.NumberFormat('fr-FR', {maximumFractionDigits: 0});
function maj() {
  m.style.setProperty('--n', Math.max(2, m.value.length));
  const v = parseFloat(m.value.replace(',', '.')) || 0;
  r.textContent = fmt.format(v * 2);  // le calcul vient du produit
}
m.addEventListener('input', maj); maj();
</script>
```

**La direction décide.** Police et graisse du chiffre, unité et sa place, couleur et fond, le calcul lui-même.

**Vérifier sur capture.** Avec 1, 4 et 7 chiffres saisis : rien ne déborde du cadre, le voisin ne bouge pas, le contraste du chiffre se mesure sur son propre fond (`check_render`).

## moment-orchestre

**Problème.** Les entrées animées se posent sur chaque bloc (fondu-glissé partout), retardent l’action ou ignorent le mouvement réduit ; sans script, le contenu peut rester caché.

**Quand.** Une page faite pour se montrer, avec un objet de preuve qui gagne à apparaître. **Pas quand** la page est un outil ou une lecture.

**Procédé.** Un seul moment, sur l’objet de preuve et au plus deux éléments liés, défini seulement sous `prefers-reduced-motion: no-preference` : sans préférence ou sans animation, tout est visible et à sa place.

```html
<div class="scene"><h1>Titre</h1><div class="preuve">Objet de preuve</div><a class="action" href="#">Agir</a></div>
<style>
@media (prefers-reduced-motion: no-preference) {
  .preuve { animation: pose .7s cubic-bezier(.2, .7, .2, 1) .15s both }
  .preuve > * { animation: monte .5s ease-out .5s both }
}
@keyframes pose { from { opacity: 0; transform: translateY(18px) rotate(-1.5deg) } }
@keyframes monte { from { opacity: 0; transform: translateY(8px) } }
</style>
```

**La direction décide.** Ce qui bouge, la trajectoire, la durée (au plus une seconde au total), la courbe.

**Vérifier sur la planche de mouvement** (`parcours.py mouvement`) : une seule entrée, l’action visible dès la première image, rien sous mouvement réduit.

## focus

**Problème.** Le contour de focus disparaît sur un fond de sa couleur, ou se mesure sous 3:1 quand la page mêle fonds clairs et sombres.

**Quand.** Toute page, dès que les fonds varient. **Pas quand** un design system impose déjà son focus.

**Procédé.** Un double contour : un trait clair contre l’élément, un trait sombre au-delà. L’un des deux contraste toujours avec le fond.

```html
<a href="#" class="exemple">Lien</a> <button>Bouton</button>
<style>
:focus-visible { outline: 3px solid var(--focus-sombre, #111); outline-offset: 2px;
  box-shadow: 0 0 0 2px var(--focus-clair, #fff) }
</style>
```

**La direction décide.** Les deux couleurs, l’épaisseur et le décalage.

**Vérifier.** Contraste du focus relevé par `check_render` sur chaque fond ; parcours au clavier complet (`parcours.py verifier`, ordre de tabulation).

## controles

**Problème.** Groupes segmentés, onglets, champs et boutons recodés à la main perdent le clavier, le nom accessible ou l’état : boutons radio hors de Tab, onglet sans flèches, erreur non annoncée, bouton qui change de nom pendant le chargement.

**Quand.** Tout contrôle ordinaire. **Pas quand** un design system ou une bibliothèque du projet fournit déjà le composant.

**Procédé.** L’élément natif d’abord, avec son comportement ; la direction habille, sans changer le comportement.

```html
<fieldset class="seg"><legend>Distance</legend>
  <label><input type="radio" name="d" value="5" checked><span>5 km</span></label>
  <label><input type="radio" name="d" value="10"><span>10 km</span></label>
</fieldset>
<div class="champ">
  <label for="e">Adresse e-mail</label>
  <input id="e" type="email" required aria-describedby="e-err">
  <p id="e-err" class="err" hidden>Écrivez une adresse complète, comme nom@exemple.fr.</p>
</div>
<button class="envoi" type="button"><span>Envoyer</span><i class="roue" aria-hidden="true"></i></button>
<div role="tablist" aria-label="Vues">
  <button role="tab" id="t1" aria-selected="true" aria-controls="p1">Semaine</button>
  <button role="tab" id="t2" aria-selected="false" aria-controls="p2" tabindex="-1">Mois</button>
</div>
<div role="tabpanel" id="p1" aria-labelledby="t1">…</div><div role="tabpanel" id="p2" aria-labelledby="t2" hidden>…</div>
<style>
.seg { border: 0; padding: 0; display: inline-flex }
.seg input { position: absolute; opacity: 0; width: 1px; height: 1px }
.seg input:checked + span { font-weight: 700; text-decoration: underline }
.seg input:focus-visible + span { outline: 3px solid #111; outline-offset: 2px }
.roue { display: none } .envoi[aria-busy="true"] .roue { display: inline-block }
</style>
<script>
const e = document.getElementById('e'), err = document.getElementById('e-err');
e.addEventListener('blur', () => { const ko = !e.checkValidity(); e.setAttribute('aria-invalid', ko); err.hidden = !ko; });
const b = document.querySelector('.envoi');
b.addEventListener('click', () => { b.setAttribute('aria-busy', 'true'); b.setAttribute('aria-disabled', 'true'); });
const tabs = [...document.querySelectorAll('[role=tab]')];
tabs.forEach((t, i) => t.addEventListener('keydown', ev => {
  const d = {ArrowRight: 1, ArrowLeft: -1}[ev.key]; if (!d) return;
  const n = tabs[(i + d + tabs.length) % tabs.length]; n.click(); n.focus(); }));
tabs.forEach(t => t.addEventListener('click', () => tabs.forEach(x => {
  const on = x === t; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1;
  document.getElementById(x.getAttribute('aria-controls')).hidden = !on; })));
</script>
```

**La direction décide.** L’habillage de chaque contrôle : voix typographique, bord, couleur par rôle, alignement sur la grille (`BIBLIOTHEQUE/COMPONENTS`, « Parties ordinaires »). Un menu de sélection reste un `<select>` natif, habillé.

**Vérifier.** Ordre de tabulation et noms accessibles (`parcours.py verifier`) ; flèches dans le groupe et dans les onglets ; l’erreur annoncée et liée au champ ; le bouton garde son libellé pendant le chargement.

## matiere

**Problème.** Une matière codée de mémoire (émail, papier, bois, verre, métal) paraît dessinée : un dégradé unique et lisse, un reflet blanc plaqué en haut à gauche, un grain qui grossit avec l’élément ou dont la tuile se voit, un filtre posé sur tout l’élément qui ralentit la page et floute le texte.

**Quand.** La direction déclare une matière que le sujet possède. **Pas quand** la planéité est choisie, ou quand une vraie photo de la matière est disponible : elle l’emporte.

**Procédé.** D’abord regarder : deux photos réelles de la matière (`parcours.py references --polyhaven "texture: …"` ou `--commons "…"`), et trois observations écrites (où la couleur s’accumule, comment finit le bord, d’où vient la lumière). Puis coder en couches, de la plus lente à la plus fine : la couleur de base ; deux ou trois variations lentes, irrégulières, placées où la photo les montre ; un grain fin en image de fond tuilée, à taille fixe en pixels, jamais en `filter` sur l’élément ; l’accident observé (coulure, fibre, bulle, rayure) en dernier, une seule fois.

```html
<div class="matiere" role="img" aria-label="Matière du sujet"><span class="accident"></span></div>
<style>
.matiere { position: relative; aspect-ratio: 4 / 3; overflow: hidden; isolation: isolate;
  background:
    radial-gradient(55% 40% at var(--lumiere, 70% 20%), rgb(255 255 255 / var(--eclat, .22)), transparent 70%),
    radial-gradient(70% 55% at 25% 85%, rgb(0 0 0 / var(--creux, .18)), transparent 75%),
    var(--base, #8a8f86) }
.matiere::after { content: ""; position: absolute; inset: 0; pointer-events: none; opacity: var(--grain, .35); mix-blend-mode: multiply;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 .6 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23g)'/%3E%3C/svg%3E");
  background-size: 180px 180px }
.accident { position: absolute; inset: var(--accident-place, 0 0 45% 0); background: var(--accident, transparent);
  clip-path: var(--accident-forme, none) }
</style>
```

**La direction décide.** La matière, sa couleur, la place de la lumière et des creux, la force du grain, la forme et la place de l’accident : tout vient des photos regardées, pas de cette recette.

**Vérifier.** Une page de deux images à la même échelle, la photo et un carré de la matière codée, capturée (`parcours.py captures`) : paraît-elle observée ou dessinée ? Dessinée, elle se reprend d’après la photo, ou part au test de retrait. Grain de même taille à 390 et à 1440 px ; texte posé dessus mesuré sur le fond réel (`regard.py`).

## police-variable

**Problème.** Une graisse animée ou pilotée par un curseur ne bouge pas (fichier non variable, plage absente de `@font-face`), fait sauter la mise en page en s’élargissant, déborde à 390 px dans sa graisse la plus forte, tourne sans fin sous mouvement réduit, ou se règle avec un curseur sans nom ni valeur lisible.

**Quand.** Un spécimen, un titre ou un objet de preuve dont la graisse est l’idée. **Pas quand** la police n’est pas variable : on montre alors les graisses existantes côte à côte.

**Procédé.** La plage déclarée dans `@font-face` ; la graisse pilotée par une variable ; la taille calée une fois sur la graisse la plus forte, pour que rien ne déborde ni ne bouge quand elle change ; un curseur natif, nommé, qui annonce la graisse en mots ; le balayage seulement sans préférence de mouvement réduit, et arrêté dès que la personne prend la main.

```html
<div class="specimen">
  <p class="echantillon balaye" id="ech">Échantillon</p>
  <label for="gr">Graisse</label>
  <input id="gr" type="range" min="200" max="900" step="1" value="400">
  <output for="gr" id="grv">400</output>
</div>
<style>
@font-face { font-family: "Variable"; src: url("police-variable.woff2") format("woff2"); font-weight: 100 900; font-display: swap }
.specimen { container-type: inline-size }
.echantillon { font-family: "Variable", Georgia, serif; font-weight: var(--wght, 400); font-size: min(9rem, 15cqi);
  line-height: 1.1; margin: 0; white-space: nowrap; overflow: hidden }
@media (prefers-reduced-motion: no-preference) {
  .echantillon.balaye { animation: balaye 5s ease-in-out infinite alternate }
}
@keyframes balaye { from { font-weight: 200 } to { font-weight: 900 } }
</style>
<script>
{
  const g = document.getElementById('gr'), e = document.getElementById('ech'), v = document.getElementById('grv');
  const noms = [[300, 'légère'], [500, 'normale'], [650, 'demi-grasse'], [800, 'grasse'], [1000, 'noire']];
  function caler() {
    const balaye = e.classList.contains('balaye'); e.classList.remove('balaye'); e.style.fontSize = '';
    e.style.setProperty('--wght', 900); let t = parseFloat(getComputedStyle(e).fontSize);
    while (e.scrollWidth > e.clientWidth && t > 12) { t -= 2; e.style.fontSize = t + 'px'; }
    e.style.setProperty('--wght', g.value); if (balaye) e.classList.add('balaye');
  }
  function maj() {
    e.classList.remove('balaye'); e.style.setProperty('--wght', g.value); v.textContent = g.value;
    g.setAttribute('aria-valuetext', g.value + ', ' + noms.find(([s]) => g.value < s)[1]);
  }
  g.addEventListener('input', maj); addEventListener('resize', caler);
  document.fonts.ready.then(caler); caler();
  g.setAttribute('aria-valuetext', g.value + ', normale');
}
</script>
```

**La direction décide.** La police, le mot ou la phrase, la plage et la courbe du balayage, la place et l’habillage du curseur.

**Vérifier.** À 390 px dans la graisse la plus forte, rien ne déborde ; au clavier, les flèches changent la graisse et sa valeur annoncée ; sous mouvement réduit, rien ne bouge (`parcours.py mouvement`).

## reponse-courriel

**Problème.** Un formulaire de réponse sans serveur perd la réponse : `<form action="mailto:">` mal pris en charge, accents et retours à la ligne mal encodés, aucune issue quand aucune messagerie ne s’ouvre, et un « Merci, c’est envoyé » qui ment.

**Quand.** Une invitation, une inscription, une demande sans serveur derrière. **Pas quand** un service de formulaire existe : il l’emporte.

**Procédé.** Un vrai formulaire, validé avant l’envoi, l’erreur annoncée et liée au champ. À l’envoi, le message se compose (`encodeURIComponent`, retours `\r\n`) et la messagerie s’ouvre ; la page dit ce qui reste à faire, montre l’adresse en clair et le message prêt à copier, au cas où rien ne s’ouvre.

```html
<form class="reponse" id="rep" novalidate>
  <label for="rn">Votre nom</label>
  <input id="rn" name="nom" required autocomplete="name" aria-describedby="rn-err">
  <p id="rn-err" class="err" hidden>Écrivez votre nom.</p>
  <fieldset><legend>Vous venez ?</legend>
    <label><input type="radio" name="vient" value="oui" checked> Oui</label>
    <label><input type="radio" name="vient" value="non"> Non</label>
  </fieldset>
  <label for="rp">Combien serez-vous ?</label>
  <input id="rp" name="nombre" type="number" min="1" max="6" value="1" inputmode="numeric">
  <button type="submit">Préparer ma réponse</button>
  <div id="rep-ok" role="status" hidden>
    <p>Votre messagerie s’ouvre avec la réponse prête : il reste à l’envoyer. Rien ne s’ouvre ? Écrivez à
      <a id="rep-lien" href="mailto:reponse@exemple.fr">reponse@exemple.fr</a> ce message :</p>
    <textarea id="rep-texte" readonly rows="4" aria-label="Votre message"></textarea>
  </div>
</form>
<script>
{
  const f = document.getElementById('rep'), ADRESSE = 'reponse@exemple.fr';
  f.addEventListener('submit', ev => {
    ev.preventDefault();
    const nom = f.nom.value.trim(), err = document.getElementById('rn-err');
    f.nom.setAttribute('aria-invalid', String(!nom)); err.hidden = !!nom;
    if (!nom) { f.nom.focus(); return; }
    const corps = [`Nom : ${nom}`, `Je viens : ${f.vient.value}`, `Nombre : ${f.nombre.value}`].join('\r\n');
    const url = `mailto:${ADRESSE}?subject=${encodeURIComponent('Réponse : ' + nom)}&body=${encodeURIComponent(corps)}`;
    document.getElementById('rep-lien').href = url;
    document.getElementById('rep-texte').value = corps;
    document.getElementById('rep-ok').hidden = false;
    location.href = url;
  });
}
</script>
```

**La direction décide.** Les questions posées, leur ton, l’habillage des champs (recette `controles`), la place du formulaire dans la page.

**Vérifier.** Envoi sans nom : l’erreur s’affiche et le focus revient au champ. Avec un nom accentué : le lien composé le garde, la confirmation dit ce qui reste à faire, jamais « envoyé ».

## agenda

**Problème.** Un fichier d’agenda écrit à la main est refusé ou décalé : retours à la ligne sans `\r`, heure sans fuseau (l’invité d’un autre fuseau voit la mauvaise heure), virgules et points-virgules non échappés, `UID` ou `DTSTAMP` absents, lignes de plus de 75 octets non pliées.

**Quand.** Un événement daté que la personne doit retrouver : vernissage, rendez-vous, lancement. **Pas quand** la date n’est pas encore fixée.

**Procédé.** L’heure écrite avec son décalage (`+01:00`), convertie en UTC ; le texte échappé ; chaque ligne pliée à 75 octets ; le fichier produit dans la page et téléchargé par un lien nommé.

```html
<a class="agenda" id="ics" href="#" download="evenement.ics">Ajouter à mon agenda</a>
<script>
{
  const EV = { titre: 'Vernissage, atelier du Pont', lieu: '12 rue des Potiers, Nantes',
    debut: '2026-12-04T18:30:00+01:00', fin: '2026-12-04T21:00:00+01:00',
    texte: 'Pièces nouvelles; entrée libre, sur réponse.', uid: 'evenement-2026-12-04@exemple.fr' };
  const utc = d => new Date(d).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const esc = s => s.replace(/\\/g, '\\\\').replace(/([,;])/g, '\\$1').replace(/\n/g, '\\n');
  const octets = s => new TextEncoder().encode(s).length;
  function plier(l) {
    const out = []; let cur = '';
    for (const c of l) { if (octets(cur + c) > (out.length ? 74 : 75)) { out.push(cur); cur = ''; } cur += c; }
    out.push(cur); return out.join('\r\n ');
  }
  function ics(e) {
    return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//exemple//agenda//FR', 'CALSCALE:GREGORIAN', 'BEGIN:VEVENT',
      'UID:' + e.uid, 'DTSTAMP:' + utc(Date.now()), 'DTSTART:' + utc(e.debut), 'DTEND:' + utc(e.fin),
      'SUMMARY:' + esc(e.titre), 'LOCATION:' + esc(e.lieu), 'DESCRIPTION:' + esc(e.texte),
      'END:VEVENT', 'END:VCALENDAR'].map(plier).join('\r\n') + '\r\n';
  }
  document.getElementById('ics').href = URL.createObjectURL(new Blob([ics(EV)], { type: 'text/calendar;charset=utf-8' }));
}
</script>
```

**La direction décide.** Le libellé, la place et l’habillage du lien ; le nom du fichier.

**Vérifier.** Le fichier téléchargé : `DTSTART` en UTC, aucune ligne de plus de 75 octets, retours `\r\n`, virgules et points-virgules échappés ; ouvert dans un agenda, l’heure est la bonne.

## objet-en-scene

**Problème.** Un objet posé sur la page (photo de produit, pièce, spécimen) paraît collé : une seule ombre grise et floue qui le fait flotter, un recadrage qui coupe au hasard à 390 px, une image sans dimensions qui pousse le texte au chargement.

**Quand.** Un objet réel qui porte la preuve ou l’idée. **Pas quand** l’image est un fond d’atmosphère (`SAVOIR/SOURCE`, « Construire une atmosphère »).

**Procédé.** Un cadre au rapport fixé, qui réserve sa place ; l’image recadrée sur son point d’intérêt, choisi pour chaque largeur ; deux ombres, une courte et sombre au contact, une longue et douce au-delà, teintées de la couleur du fond, jamais noires. Un objet détouré prend les mêmes deux ombres en `filter: drop-shadow`, qui suit sa forme.

```html
<figure class="scene-objet">
  <div class="cadre"><img src="objet.jpg" width="1200" height="1500" alt="Décrire l’objet, sa matière et son angle de vue"></div>
  <figcaption>Légende de l’objet</figcaption>
</figure>
<style>
.scene-objet { margin: 0; container-type: inline-size }
.cadre { aspect-ratio: var(--rapport, 4 / 5); overflow: hidden; background: var(--fond, #e8e4dd);
  box-shadow: 0 1px 2px rgb(var(--ombre, 45 35 25) / .28), 0 22px 44px -14px rgb(var(--ombre, 45 35 25) / .32) }
.cadre img { display: block; width: 100%; height: 100%; object-fit: cover; object-position: var(--point, 50% 40%) }
@container (max-width: 420px) {
  .cadre { aspect-ratio: var(--rapport-mobile, 1) }
  .cadre img { object-position: var(--point-mobile, var(--point, 50% 40%)) }
}
</style>
```

**La direction décide.** Le rapport du cadre, le point d’intérêt, la couleur du fond et des ombres, la lumière ; l’objet lui-même.

**Vérifier.** À 1440 et 390 px, l’objet garde son point d’intérêt dans le cadre ; rien ne bouge au chargement ; l’ombre se lit comme un contact, pas comme un flottement, sur capture agrandie.

## emplacement-photo

**Problème.** Sans photo réelle du lieu, du produit ou des personnes, la page remplace l’image par un objet codé (étiquette, tableau, dessin) qui la déguise, ou laisse un rectangle gris qui fait gabarit. Un vrai studio fait l’inverse : il compose la page pour ses photos à venir.

**Quand.** La catégorie vend par l’image (commerce, lieu, service, portfolio, restaurant) et les photos manquent. **Pas quand** les photos sont fournies, ou quand la page n’a pas besoin d’image.

**Procédé.** Un cadre au ratio du futur cliché, à la place et à l’échelle qu’aura la photo ; un fond du ton dominant attendu, pris dans la palette ; une légende de prise de vue (sujet, cadrage, lumière) ; une mention discrète « photo à fournir ». Le cadre est décrit comme l’image attendue, pour la lecture d’écran. Aucune fausse photo, aucune icône d’appareil, aucun objet codé à la place.

```html
<figure class="emplacement-photo" style="--ratio: 4 / 5; --ratio-mobile: 1; --ton: #8a7b6a">
  <div class="cadre" role="img" aria-label="Photo à fournir : l’établi de l’atelier, lumière du matin, un vélo sur le pied"></div>
  <figcaption><span class="consigne">Photo à fournir</span> L’établi, lumière du matin, cadrage serré sur les mains et l’outil.</figcaption>
</figure>
<style>
.emplacement-photo { margin: 0; container-type: inline-size }
.emplacement-photo .cadre { aspect-ratio: var(--ratio); background: var(--ton);
  background-image: linear-gradient(160deg, rgb(255 255 255 / .10), transparent 60%);
  box-shadow: inset 0 0 0 1px rgb(0 0 0 / .08) }
.emplacement-photo figcaption { font-size: .8rem; margin-top: .5rem; opacity: .75 }
.emplacement-photo .consigne { font-weight: 600; margin-right: .4em }
@container (max-width: 420px) { .emplacement-photo .cadre { aspect-ratio: var(--ratio-mobile, var(--ratio)) } }
</style>
```

**La direction décide.** Le ratio, la place et l’échelle de chaque photo, le ton attendu, la consigne de prise de vue ; la mise en page reste celle qu’aura la page avec ses photos.

**Vérifier.** À 1440 et 390 px, le cadre garde son ratio et sa place ; il est décrit pour la lecture d’écran ; la page ne contient aucune image qui se donne pour une vraie photo du client.

Pour l’ensemble des références de la skill, revenir à leur [index](README.md).
