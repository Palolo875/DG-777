#!/usr/bin/env python3
"""Cas connus de `scripts/parcours.py` : chaque sous-commande retrouve la réponse attendue.

Sans navigateur : lecture des graisses, plus grand rectangle vide, coupe des détails, seuils des signaux, feuille de
polices écrite à partir de fichiers simulés (aucun accès réseau), et présence de chaque geste nommé par un signal
dans `SAVOIR/STATE`. Avec navigateur : une page piège déclenche chaque signal, une page propre n'en déclenche aucun,
les faux positifs connus restent muets (chiffres en chasse fixe ou en SVG, marge étroite), l'habillage de gabarit est
relevé, la planche de mouvement distingue un moment orchestré d'un effet répété (fondu sur chaque bloc, survol sur
chaque carte, boucle sans fin, mouvement réduit ignoré, texte jamais révélé), les captures existent à la bonne
échelle et `verifier` écrit sa fiche et rend le bon code. Sans navigateur aussi : `trace` accepte l'exemple de la skill
et nomme chaque défaut de forme de la trace légère.

Pages pièges écrites dans un dossier temporaire ; aucune ressource externe. Il faut Playwright, Chromium, NumPy,
SciPy et Pillow : s'il en manque un, les cas navigateur sont NOT-VERIFIED, jamais réussis ; `--require-browser`
en fait un échec. Ce fichier ne valide aucun rendu : il vérifie que l'outil dit vrai sur des cas connus.
"""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True
import argparse
import contextlib
import importlib.util
import io
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

SALE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Piège</title>
<style>body{margin:0;background:#eee;font-family:Arial,sans-serif}
.carte{position:absolute;left:120px;top:80px;width:1100px;height:700px;background:#fff;display:grid;grid-template-columns:1fr 1fr;
 border-radius:14px;box-shadow:0 2px 4px rgba(0,0,0,.2)}
.g{padding:30px}.d{background:#fafafa;padding:30px}
.b1{border-radius:4px;background:#ddd;width:80px;height:40px;box-shadow:0 8px 20px rgba(0,0,0,.3)}
.b2{border-radius:9px;background:#ccc;width:80px;height:40px;margin-top:8px;box-shadow:0 1px 1px #000}
h1{font-size:44px;width:520px;margin:0 0 10px;font-family:Georgia,serif}
.mono{font-family:"Courier New",monospace;font-size:15px}
.mini{font-size:9px}.vert{color:#0a0}.rouge{color:#d00}.bleu{color:#00c}
.prix{width:200px}.prix div{text-align:right;font-size:18px}
.s1{font-size:12px}.s2{font-size:13px}.s3{font-size:14px}.s4{font-size:15px}.s5{font-size:16px}</style>
<div class="carte"><div class="g">
<h1 id="titre">Un&nbsp;titre&nbsp;piège&nbsp;finit vraiment</h1>
<p class="mono">Un paragraphe courant composé en chasse fixe, assez long pour fatiguer la lecture sur plusieurs lignes de texte.</p>
<p class="mini">Mention minuscule illisible</p><p class="vert">vert</p><p class="rouge">rouge</p><p class="bleu">bleu</p>
<div class="b1"></div><div class="b2"></div>
<div class="prix"><div>1 240</div><div>87</div><div>19 990</div></div>
<p class="s1">a b</p><p class="s2">a b</p><p class="s3">a b</p><p class="s4">a b</p><p class="s5">a b</p>
</div><div class="d"><p>Seulement ceci en haut ; le reste de la colonne est vide.</p></div></div>
<button id="action" style="position:absolute;top:1400px;left:40px">Agir</button>
</html>"""

PROPRE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Propre</title>
<style>body{margin:0;background:#f4f4f2;font-family:Arial,sans-serif;color:#222}
main{max-width:900px;margin:60px auto;padding:0 24px}
h1{font-size:40px;margin:0 0 16px;text-wrap:balance}p{font-size:16px;line-height:1.5}
.carte{border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,.15);padding:16px;margin:12px 0;background:#fff}
.prix div{text-align:right;font-variant-numeric:tabular-nums;width:160px}
a.cta{display:inline-block;border-radius:8px;background:#1b4dd8;color:#fff;padding:12px 18px;text-decoration:none}</style>
<main><h1>Un titre court</h1><p>Un paragraphe sobre, sur une seule échelle.</p>
<div class="carte"><p>Première carte.</p></div><div class="carte"><p>Seconde carte.</p></div>
<div class="prix"><div>1 240</div><div>87</div><div>19 990</div></div>
<a class="cta" id="action" href="#">Commencer</a></main></html>"""

MUET = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Muet</title>
<style>body{margin:0;background:#fff;font-family:Arial,sans-serif}
.m div{font-family:"Courier New",monospace;text-align:right;width:160px}
.panneau{position:absolute;left:100px;top:100px;width:900px;height:500px;background:#fff;display:flex}
.panneau .rempli{flex:1;background:repeating-linear-gradient(45deg,#ccc 0 6px,#888 6px 12px)}
.panneau .marge{width:64px;background:#fff}</style>
<div class="m"><div>1 240</div><div>87</div><div>19 990</div></div>
<svg width="200" height="120"><text x="150" y="20" text-anchor="end">1 240</text><text x="150" y="60" text-anchor="end">87</text>
<text x="150" y="100" text-anchor="end">19 990</text></svg>
<div class="panneau"><div class="rempli"></div><div class="marge"></div></div></html>"""

GRAIN = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='g'%3E%3CfeTurbulence baseFrequency='.9'/%3E%3C/filter%3E%3Crect width='120' height='120' filter='url(%23g)' opacity='.08'/%3E%3C/svg%3E\")"

BANDES = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Bandes</title>
<style>body{margin:0;font-family:Arial,sans-serif}
.fond{position:fixed;inset:0;display:flex;flex-direction:column}.fond i{flex:1}
.fond i:nth-child(1){background:#d9c27a}.fond i:nth-child(2){background:#c79a5b}.fond i:nth-child(3){background:#a8703f}
.fond i:nth-child(4){background:#7b4a28}.fond i:nth-child(5){background:#4f2c17}.fond i:nth-child(6){background:#2e190c}
.grain{position:fixed;inset:0;background:GRAIN}
h1{position:relative;margin:24px 20px 8px;font-size:44px}p{position:relative;margin:0 20px;font-size:16px}
button{position:absolute;left:20px;right:20px;bottom:40px;height:56px}
.bulles{position:absolute;top:140px;left:20px;width:350px;height:600px}
.bulles b{position:absolute;width:18px;height:18px;border-radius:50%;background:#f4ead8}</style>
<div class="fond"><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="grain"></div>
<h1>Titre en haut</h1><p>Un chapô court sous le titre, sur deux lignes au plus.</p>BULLES<button>Commander</button></html>"""

GENERIQUE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Gabarit</title>
<style>body{margin:0;font:16px/1.5 Arial,sans-serif}section{min-height:600px;padding:80px}
.reveal{opacity:0;transform:translateY(24px);transition:opacity .6s,transform .6s}.reveal.vu{opacity:1;transform:none}
.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:12px}
.cartes{display:flex;gap:16px}.carte{width:220px;height:160px;background:#f3f3f3;transition:transform .3s}.carte:hover{transform:translateY(-4px)}
.btn{display:inline-block;padding:14px 22px;background:#111;color:#fff}</style>
<section><p class="eyebrow">Notre studio</p><h1>Un titre de <span style="color:#c33">démonstration</span></h1><p>Design · Code · Stratégie</p><a class="btn" id="cta" href="#">Commencer →</a></section>
<section class="reveal"><p class="eyebrow">Services</p><h2>Ce que nous faisons</h2><div class="cartes"><div class="carte">01</div><div class="carte">02</div><div class="carte">03</div></div><a class="btn" href="#">Voir plus →</a></section>
<section class="reveal"><p class="eyebrow">Méthode</p><h2>Comment</h2><p>Écoute · Esquisse · Livraison</p></section>
<section class="reveal"><h2>Contact</h2><p>Écrivez-nous pour parler de votre projet.</p></section>
<script>const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('vu')}));document.querySelectorAll('.reveal').forEach(x=>io.observe(x));</script></html>"""

ORCHESTRE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Orchestré</title>
<style>body{margin:0;font:18px Georgia,serif;background:#f6f6f2}.hero{height:900px;position:relative;overflow:hidden}
.bande{position:absolute;left:0;top:300px;height:200px;width:100%;background:#c33;transform-origin:left;animation:tire 1.2s both}
h1{position:absolute;left:80px;top:340px;margin:0;font-size:96px;color:#fff;animation:monte .8s .6s both}
@keyframes tire{from{transform:scaleX(0)}to{transform:none}}@keyframes monte{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:none}}
#cta{position:absolute;left:80px;top:560px;padding:14px 20px;background:#111;color:#fff;transition:background .2s}#cta:hover{background:#c33}
@media (prefers-reduced-motion: reduce){.bande,h1{animation:none}}</style>
<div class="hero"><div class="bande"></div><h1>La ligne rouge</h1><a id="cta" href="#">Réserver une place</a></div></html>"""

BOUCLE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Boucle</title>
<style>body{margin:0}.flotte{width:200px;height:200px;margin:200px;background:#36c;animation:flotte 3s infinite}
@keyframes flotte{50%{transform:translateY(-20px)}}.cache{opacity:0}</style>
<div class="flotte"></div><p class="cache" style="margin:80px;height:1200px">Un texte qui attend une révélation jamais déclenchée.</p></html>"""

GESTES_ATTENDUS = ["Cohérence de rayon", "Surface", "Texte secondaire", "Masse visuelle", "Accent",
                   "Alignement optique", "Chiffres", "Gestion du vide", "Partie ordinaire", "Mouvement", "Habillage de gabarit", "Typographie fine"]


def manquants() -> list[str]:
    absents = [m for m in ("numpy", "scipy", "PIL", "playwright") if importlib.util.find_spec(m) is None]
    if not absents:
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                p.chromium.launch().close()
        except Exception as exc:
            absents.append(f"Chromium ({type(exc).__name__})")
    return absents


def statiques(parcours, attendre) -> None:
    import numpy as np
    rng = np.random.default_rng(1)
    attendre(parcours.plat(128 + rng.normal(0, 2.5, (16, 16))), "vide : le grain d'une matière s'efface au lissage")
    attendre(parcours.plat(np.vstack([np.full((8, 16), 200.0), np.full((8, 16), 90.0)])),
             "vide : la limite nette entre deux bandes de fond reste plate")
    detail = "1440 px : intersection verticale 520.5 px sur 520.5, horizontale 392 px sur 392; 390 px : intersection verticale 0 px sur 446"
    r = parcours.recomposition([{"check": "Objet de preuve au premier écran (.planche)", "detail": detail}])
    attendre(r is not None and r["largeur"] == 390 and r["source"] == "BIBLIOTHEQUE/SEQUENCE",
             "recomposition : preuve vue au bureau, absente en mobile, signal renvoyé à BIBLIOTHEQUE/SEQUENCE")
    attendre(parcours.recomposition([{"check": "Objet de preuve au premier écran (.p)", "detail": detail.replace("0 px sur 446", "12 px sur 446")}]) is None
             and parcours.recomposition([]) is None, "recomposition : preuve présente aux deux largeurs ou absente de la recette, aucun signal")
    damier = np.indices((16, 16)).sum(axis=0) // 4 % 2 * 200.0
    attendre(not parcours.plat(damier), "vide : une forme dessinée n'est pas plate")
    attendre(parcours.analyser_spec("Bodoni Moda:400,700i") == ("Bodoni Moda", [(400, "normal"), (700, "italic")]),
             "polices : « Famille:400,700i » donne deux styles, l'italique compris")
    attendre(parcours.analyser_spec("Inter") == ("Inter", [(400, "normal")]), "polices : sans graisse, 400 normal")
    grille = [[1, 1, 0, 0], [1, 1, 1, 1], [1, 1, 1, 1], [0, 1, 1, 1]]
    attendre(parcours.plus_grand_rectangle(grille)[0] == 9, "vide : plus grand rectangle de cases vides (3 × 3)")
    detail = "premier ; deuxième ; " + "x" * 80
    court = parcours.abreger(detail, 40)
    attendre(court.startswith("premier ; deuxième") and "recette.json" in court and "xxxx" not in court,
             "fiche : un détail long est coupé à la dernière clause entière et renvoie à recette.json")
    G = parcours.gestes()
    absents = [g for g in GESTES_ATTENDUS if g not in G]
    attendre(not absents, f"gestes : chaque geste nommé par un signal se lit dans SAVOIR/STATE (absents : {absents or 'aucun'})")
    attendre(all(t.endswith((".", "?", "!")) for t in G.values()), "gestes : la première phrase de chaque geste finit par un point")
    vide = {"rayons": {}, "ombres": {}, "familles": {"Arial": 10}, "tailles": {"16": 1}, "teintes": {},
            "mono_long": [], "veuves": [], "petits": [], "chiffres": []}
    attendre(parcours.signaux(vide, 1440, G) == [], "signaux : une mesure calme ne pose aucune question")
    une = dict(vide, gabarit={"medians": ["A · B"], "surtitres": [], "fleches": ["Voir →"], "numeros": [], "tirets": []})
    attendre(parcours.signaux(une, 1440, G) == [], "gabarit : une marque isolée, décidée, ne pose pas de question")
    m0 = {"largeur": 1440, "entree": [], "revelations": [], "defile": 0, "script": False, "cartes": [], "reduit": [], "invisibles": [], "action_ms": None}
    attendre([s["mesure"].startswith("rien ne bouge") for s in parcours.mouvement_signaux(m0, G)] == [True],
             "mouvement : rien ne bouge, une seule question, qui laisse la page d'outil sans justification")
    deux = [{"id": "1", "cible": "div.bande", "props": ["transform"], "infinie": False}, {"id": "2", "cible": "h1", "props": ["opacity", "transform"], "infinie": False}]
    attendre(parcours.mouvement_signaux(dict(m0, entree=deux), G) == [], "mouvement : un moment orchestré sur deux éléments ne pose aucune question")
    pistes, dim = parcours.tirage()
    divergence = parcours.lire_route("DIRECTION/DIVERGENCE")
    attendre(len(set(pistes)) == 2 and "costume de l’objet" in divergence and not any("objet imprimé" in p for p in pistes)
             and dim in ("Composition", "Matière et rendu", "Représentation", "Époque et culture", "Densité et énergie", "Interaction et temps", "Voix et comportement"),
             f"tirage : deux pistes distinctes et une dimension de la taxonomie, lues à leur lieu ({pistes}, {dim})")
    (grille, g_def), (profil, p_def) = parcours.tirage_structure()
    attendre(f"`{grille}`" in parcours.lire_route("BIBLIOTHEQUE/GRID") and f"`{profil}`" in parcours.lire_route("SAVOIR/STYLE") and g_def and p_def,
             f"tirage : une grille et un profil existants, lus à leur lieu ({grille}, {profil})")
    try:
        r = parcours.leviers("tension, Précision")
    except RuntimeError as exc:
        r = {"poles": [], "ordre": "", "expressif": str(exc)}
    attendre([x[0] for x in r["poles"]] == ["Tension", "Précision"] and all(x[1] and x[2] for x in r["poles"])
             and "foyer → masse → rythme" in r["ordre"] and r["expressif"].startswith("La beauté perçue"),
             "leviers : leviers et piège de chaque pôle, ordre de composition et « Classique et expressif », lus à leur lieu")
    refus = []
    for demande in ("calme,tension", "joli", "calme,précision,rupture", ""):
        try:
            parcours.leviers(demande)
        except ValueError:
            refus.append(demande)
        except RuntimeError:
            pass
    attendre(len(refus) == 4, f"leviers : même paire, pôle inconnu, plus de deux pôles et demande vide refusés ({refus})")
    from PIL import Image as _Im
    def _png(w, h, couleur):
        tampon = io.BytesIO(); _Im.new("RGB", (w, h), couleur).save(tampon, "PNG"); return tampon.getvalue()
    with tempfile.TemporaryDirectory() as tmp:
        vues = [(1440, _png(144, 90, "white")), (390, _png(39, 84, "white"))]
        seule = _Im.open(parcours.planche_version(vues, Path(tmp) / "a.png")).size
        double = _Im.open(parcours.planche_version(vues, Path(tmp) / "b.png", [(1440, _png(144, 90, "black")), (390, _png(39, 84, "black"))])).size
        haut_gauche = _Im.open(Path(tmp) / "b.png").convert("RGB").getpixel((30, 50))
    attendre(double == (seule[0], 2 * seule[1]) and haut_gauche == (0, 0, 0),
             f"planche de version contre l'esquisse : l'esquisse en première rangée, la version dessous ({seule} → {double})")
    with tempfile.TemporaryDirectory() as tmp:
        page = Path(tmp) / "p.html"
        page.write_text("<!doctype html><title>x</title>", encoding="utf-8")
        args = argparse.Namespace(foyer=None, action=None, refs=None, mobile=False)
        deux = parcours.rediger(page, Path(tmp), [1440, 390], 0, 0, [], [], None, args)
        une = parcours.rediger(page, Path(tmp), [1440], 0, 0, [], [], None, args)
    dabord = next((l for l in deux.splitlines() if "D'abord, seule" in l), "")
    attendre("sans-texte-390.png" in dabord and "survit-elle à la recomposition" in dabord and "survit-elle" not in une,
             "verifier : la lecture sans le texte se fait aussi au premier écran mobile, dans la même consigne")
    diag = parcours.convergence("Plan, schéma ou diagramme")
    attendre(diag is not None and "CFT-04a" in diag[1] and "sans légende" in diag[1],
             "convergence : le diagramme comme objet principal est un signal de SELECT, avec sa question de reprise")
    with tempfile.TemporaryDirectory() as tmp:
        page = Path(tmp) / "p.html"
        page.write_text("<!doctype html><title>x</title>", encoding="utf-8")
        args = argparse.Namespace(foyer=".plan", action=None, refs=None, mobile=False)
        avec = parcours.rediger(page, Path(tmp), [1440], 0, 0, [], [], None, args)
        args.foyer = None
        sans = parcours.rediger(page, Path(tmp), [1440], 0, 0, [], [], None, args)
    attendre("objet de preuve `.plan`" in avec and "CFT-04a" in avec and "CFT-04a" not in sans,
             "verifier : la fiche sert la question du diagramme quand un objet de preuve est nommé, et seulement alors")
    divergence = parcours.lire_route("DIRECTION/DIVERGENCE")
    attendre("ne s’estime pas : c’est ta première idée astucieuse" in divergence
             and "jamais une preuve de rareté" in divergence,
             "divergence : la modale au second degré s'observe (première idée) ; la probabilité ne prouve pas la rareté")
    pistes_toutes = parcours.re.search(r"piste différente du sujet : (.+?)\.\s*(?:-\s*)?Chacune passe", divergence, parcours.re.S)
    attendre(bool(pistes_toutes) and "son deuxième attribut qui le signe" in pistes_toutes.group(1),
             "tirage : la piste d'attribut tirée au sort part du deuxième attribut")
    attendre("La page ne commente pas son design" in parcours.lire_route("SAVOIR/CRAFT/CFT-06"),
             "écriture : signal « la page ne commente pas son design » dans CFT-06")
    noyau = (HERE.parent / "SKILL.md").read_text(encoding="utf-8")
    # Lot 11c : la ligne d'invariant tient la règle au noyau ; la phrase complète reste servie par sa route.
    attendre("d’une décision visuelle ouverte, regarde en image" in noyau
             and "Sur une surface dont la décision visuelle est ouverte, ouvre et regarde" in parcours.lire_route("DIRECTION/STANDARD"),
             "calibration : références réelles regardées dès que la décision visuelle est ouverte, pas seulement en DIRECTION")
    attendre("polices --catalogue" in parcours.lire_route("SAVOIR/TYPE-VOIX"),
             "voix typographique : le catalogue de Fontshare est servi là où la voix se cherche")
    with tempfile.TemporaryDirectory() as tmp:
        racine = Path(tmp)
        (racine / "livrable").mkdir()
        page = racine / "livrable" / "p.html"
        page.write_text("<!doctype html><title>x</title>", encoding="utf-8")
        (racine / "work" / "references").mkdir(parents=True)
        (racine / "work" / "references" / "refs.md").write_text(
            "- [1] A. Change : … ; ne se transfère pas : … ; usage : regarder.\n"
            f"- [2] B. Change : la trame ; ne se transfère pas : le logo.\n", encoding="utf-8")
        skill = racine / ".claude" / "skills" / "x"
        skill.mkdir(parents=True)
        (skill / "refs.md").write_text(parcours.JUGEMENT_VIDE * 5, encoding="utf-8")
        n, fichiers = parcours.references_sans_jugement(page, None)
        args = argparse.Namespace(foyer=None, action=None, refs=None, mobile=False)
        fiche = parcours.rediger(page, racine / "sortie", [1440], 0, 0, [], [], None, args)
        attendre(n == 1 and len(fichiers) == 1 and "Références sans jugement" in fiche and "1 ligne(s)" in fiche,
                 "références : une ligne de jugement restée au gabarit est signalée, une ligne remplie ne l'est pas, la skill est ignorée")
    attendre("au niveau visé (ligne `NIVEAU`)" in noyau
             and "un site d’information du sujet calibre le contenu, pas le niveau" in parcours.lire_route("SAVOIR/TOOLS/MOYENS"),
             "calibration : le niveau renvoie à la ligne NIVEAU ; une référence de niveau vient d'une source éditée")
    fiche_a = "# P\n## 1. Défauts bloquants\n- **Contraste** : 2,1\n\n## 3. Signaux et questions\n- 1440 px · Rayons\n## 4. Images\n- img"
    fiche_b = "# P\n## 1. Défauts bloquants\n- Aucun.\n\n## 3. Signaux et questions\n- 1440 px · Rayons\n- 390 px · Accent\n## 4. Images\n- img"
    apparus, disparus, restants = parcours.ecart_fiche(parcours.lignes_signal(fiche_a), parcours.lignes_signal(fiche_b))
    attendre(apparus == ["- 390 px · Accent"] and disparus == ["- **Contraste** : 2,1"] and restants == ["- 1440 px · Rayons"],
             "verifier : d'un appel au suivant, apparus, disparus et toujours présents ; « Aucun. » et les images ne comptent pas")
    with tempfile.TemporaryDirectory() as tmp:
        resume, detail = parcours.chantier(Path(tmp) / "projet", "tension,précision")
        projet = Path(tmp) / "projet"
        trace_ch = (projet / "travail" / "trace.md").read_text(encoding="utf-8")
        echecs, _ = parcours.controle_trace(trace_ch)
        contenus = [l.split(":", 1)[1].strip() for l in trace_ch.splitlines() if ":" in l]
        attendre(all((projet / x).is_dir() for x in ("travail", "livrable", "references")) and not echecs
                 and all(c.startswith("[") and c.endswith("]") for c in contenus) and len(resume) <= parcours.CHANTIER_MAX
                 and "Tension" in detail.read_text(encoding="utf-8"),
                 "chantier : dossiers, gabarit de trace conforme et vide de décision, leviers servis, sortie courte")
        texte_ch = detail.read_text(encoding="utf-8")
        attendre("--etape ESQUISSES" in texte_ch and "--etape CONSTRUCTION" in texte_ch and "--etape ESQUISSES" in resume
                 and "Grille tirée : GRID/" in texte_ch and "Profil tiré : STYLE/" in texte_ch,
                 "chantier : les deux étapes de lecture annoncées, une grille et un profil tirés")
    import read_route as _rr
    morceaux, _total = _rr.tronc_text("DIRECTION")
    somm = "\n".join(_rr.sommaire_tronc(morceaux))
    attendre(all(loc in somm for loc, _ in morceaux) and len(somm) <= _rr.SOMMAIRE_TRONC_MAX
             and all(len(l.split(" : ", 1)[1]) >= 30 for l in somm.splitlines() if l.startswith("- ")),
             f"tronc : sommaire de chaque route, phrase porteuse, sous {_rr.SOMMAIRE_TRONC_MAX} caractères ({len(somm)})")
    attendre("relance `verifier` seulement après un changement qui peut modifier un défaut" in (HERE.parent / "SKILL.md").read_text(encoding="utf-8"),
             "noyau : consignes de sobriété dans la boucle")
    atelier = parcours.lire_route("ACTION/ATELIER-EDITION")
    attendre("un relevé vide ne prouve pas la réussite" in atelier,
             "passe de finition : un relevé vide de verifier n'est pas déclaré réussite")
    t, n = parcours.typo_fr("Prix : 12 €, vraiment ? Oui! « bien »...")
    attendre(t == "Prix : 12 €, vraiment ? Oui ! « bien »…" and n > 0,
             "typographie : insécable avant les deux-points et dans les guillemets, fine avant ? !, points de suspension")
    attendre(parcours.typo_fr("À 15:30, voir http://a.b/c ; déjà ; prêt :")[0] == "À 15:30, voir http://a.b/c ; déjà ; prêt :",
             "typographie : heures et adresses intactes, espaces déjà justes non doublées")
    with tempfile.TemporaryDirectory() as tmp:
        f = Path(tmp) / "fr.html"
        f.write_text('<html lang="fr"><title>A : b</title><p title="x : y">Oui!</p><p>A &amp; B&nbsp;; C</p><p>Déjà inscrit&#8239;? Oui</p><span>?</span><script>a ? b : c</script><code>x!</code></html>', encoding="utf-8")
        n = parcours.typo_page(f, True)
        out = f.read_text(encoding="utf-8")
        attendre(n == 3 and "Oui !" in out and "A : b" in out and 'title="x : y"' in out and "a ? b : c" in out and "<code>x!</code>" in out and "A &amp; B" in out and "inscrit&#8239;? Oui" in out and "<span>?</span>" in out and "\u202f\u202f" not in out,
                 "typographie --corriger : texte visible corrigé ; attributs, script et code intacts")
    import tarfile as _tar
    tampon = io.BytesIO()
    with _tar.open(fileobj=tampon, mode="w:gz") as tz:
        for nom, data in (("package/icons/check.svg", b"<svg/>"), ("package/LICENSE", b"ISC")):
            ti = _tar.TarInfo(nom); ti.size = len(data); tz.addfile(ti, io.BytesIO(data))
    orig_lire = parcours._lire
    parcours._lire = lambda url, accept=None: (b'{"version": "9.9.9", "license": "ISC", "dist": {"tarball": "x"}}' if "registry" in url else tampon.getvalue())
    try:
        with tempfile.TemporaryDirectory() as tmp:
            notes = parcours.icones(["check", "absente"], Path(tmp))
            attendre((Path(tmp) / "icones" / "check.svg").is_file() and (Path(tmp) / "icones" / "LICENCE.txt").is_file()
                     and "introuvable" in notes[1] and "ISC" in notes[-1], "icônes : fichier et licence écrits, nom inconnu signalé, rien de deviné")
    finally:
        parcours._lire = orig_lire
    serre = dict(vide, tailles={str(t): 1 for t in (12, 13, 14, 15, 16)})
    attendre([s["geste"] for s in parcours.signaux(serre, 1440, G)] == ["Masse visuelle"],
             "signaux : quatre paires de tailles voisines suffisent, sous le seuil du nombre de tailles")

    faux = {(400, "normal", "latin"): b"wOF2-faux"}
    orig = parcours.polices_fontsource, parcours.polices_google, parcours.polices_fontshare
    try:
        parcours.polices_fontsource = lambda nom, styles, sous: (faux, "OFL-1.1 (simulé)") if nom == "Connue" else None
        parcours.polices_google = lambda nom, styles, sous: None
        parcours.polices_fontshare = lambda nom, styles, sous: None
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            css, notes = parcours.polices(["Connue:400"], d / "a", False, False)
            attendre(css is not None and "url(fonts/connue-latin-400-normal.woff2)" in css.read_text()
                     and (d / "a" / "fonts" / "connue-latin-400-normal.woff2").is_file() and "OFL-1.1" in notes[0],
                     "polices : fichier écrit, règle @font-face qui le cite, licence rapportée")
            css, _ = parcours.polices(["Connue:400"], d / "b", True, False)
            attendre(css is not None and "data:font/woff2;base64," in css.read_text() and not (d / "b" / "fonts").exists(),
                     "polices --integrer : données dans la feuille, aucun fichier à part")
            css, notes = parcours.polices(["Inconnue:400"], d / "c", False, False)
            attendre(css is None and not (d / "c").exists() and "introuvable" in notes[0],
                     "polices : famille introuvable, aucune feuille écrite, rien de deviné")
    finally:
        parcours.polices_fontsource, parcours.polices_google, parcours.polices_fontshare = orig
    # Repli Google Fonts : à un outil qui dit son nom, une feuille TrueType sans sous-ensembles (forme observée).
    vus = []
    feuille = ("@font-face {\n  font-family: 'Nette';\n  font-style: normal;\n  font-weight: 400;\n"
               "  src: url(https://fonts.gstatic.example/s/nette/v1/a.ttf) format('truetype');\n}\n")

    def faux_lire(url, accept=None):
        vus.append(url)
        return feuille.encode() if "css2" in url else b"\x00\x01\x00\x00faux-ttf"
    orig_lire, orig_fs = parcours._lire, parcours.polices_fontsource
    try:
        parcours._lire, parcours.polices_fontsource = faux_lire, (lambda nom, styles, sous: None)
        trouve = parcours.polices_google("Nette", [(400, "normal")], ["latin"])
        attendre(trouve is not None and list(trouve[0]) == [(400, "normal", "complet")],
                 "polices : repli Google Fonts lu sous l'identité de l'outil (TrueType complet)")
        with tempfile.TemporaryDirectory() as tmp:
            css, notes = parcours.polices(["Nette:400"], Path(tmp), True, False)
            texte = css.read_text()
            attendre("format('truetype')" in texte and "unicode-range" not in texte and "data:font/ttf;base64," in texte
                     and "TrueType" in notes[0], "polices : un TrueType est déclaré comme tel, et son poids est signalé")
        attendre("Chrome" not in parcours.AGENT_POLICES and "DesignGovernance" in parcours.AGENT_POLICES,
                 "polices : l'outil s'annonce par son nom, jamais comme un navigateur")
    finally:
        parcours._lire, parcours.polices_fontsource = orig_lire, orig_fs
    # Fontshare : l'italique se demande par la graisse + 1 ; WOFF2 complets ; licence lue dans le catalogue.
    vus_fs = []
    feuille_fs = ("@font-face {\n  font-family: 'Gambetta';\n  src: url('//cdn.fontshare.example/wf/a.woff2') format('woff2');\n"
                  "  font-weight: 400;\n  font-style: normal;\n}\n@font-face {\n  font-family: 'Gambetta';\n"
                  "  src: url('//cdn.fontshare.example/wf/b.woff2') format('woff2');\n  font-weight: 400;\n  font-style: italic;\n}\n")
    catalogue = b'{"fonts": [{"name": "Gambetta", "slug": "gambetta", "category": "Serif", "license_type": "itf_ffl"}, {"name": "Epilogue", "slug": "epilogue", "category": "Sans", "license_type": "sil_ofl"}]}'

    def faux_fs(url, accept=None):
        vus_fs.append(url)
        if url.endswith("/fonts"):
            return catalogue
        return feuille_fs.encode() if "/css?" in url else b"wOF2-faux-fs"
    orig_lire = parcours._lire
    try:
        parcours._lire = faux_fs
        trouve = parcours.polices_fontshare("Gambetta", [(400, "normal"), (400, "italic")], ["latin"])
        attendre(trouve is not None and sorted(trouve[0]) == [(400, "italic", "complet"), (400, "normal", "complet")]
                 and any("gambetta@400,401" in u for u in vus_fs) and all(u.startswith("https:") for u in vus_fs)
                 and "ni sous-ensemble" in trouve[1],
                 "polices : Fontshare, italique demandé par graisse + 1, adresses en https, licence FFL et ses limites rapportées")
        cat = parcours.catalogue_fontshare()
        attendre([(f["nom"], f["categorie"], f["licence"]) for f in cat] == [("Gambetta", "Serif", "itf_ffl"), ("Epilogue", "Sans", "sil_ofl")],
                 "polices --catalogue : familles de Fontshare avec catégorie et licence")
        vus_fs.clear()
        orig_src = parcours.polices_fontsource, parcours.polices_google
        parcours.polices_fontsource = parcours.polices_google = (lambda nom, styles, sous: None)
        with tempfile.TemporaryDirectory() as tmp:
            css, notes = parcours.polices(["Gambetta:400"], Path(tmp), True, False)
            attendre(css is not None and "Fontshare" in notes[0] and "unicode-range" not in css.read_text(),
                     "polices : Fontshare essayé en dernier recours quand Fontsource et Google Fonts n'ont pas la famille")
            vus_fs.clear()
            css, notes = parcours.polices(["Gambetta:400"], Path(tmp) / "b", True, False, "fontshare")
            attendre(css is not None and vus_fs and all("fontshare" in u for u in vus_fs), "polices --source fontshare : Fontshare seulement")
        parcours.polices_fontsource, parcours.polices_google = orig_src
    finally:
        parcours._lire = orig_lire


COMMONS = {"query": {"pages": {"12": {"index": 2, "title": "File:Atelier B.jpg", "imageinfo": [{"descriptionurl": "https://commons.example/B",
            "thumburl": "https://upload.example/b.jpg", "extmetadata": {"Artist": {"value": "<a href='x'>Ama &amp; Co</a>"},
            "LicenseShortName": {"value": "CC BY-SA 4.0"}, "DateTimeOriginal": {"value": "2019"}}}]},
            "11": {"index": 1, "title": "File:Atelier A.jpg", "imageinfo": [{"descriptionurl": "https://commons.example/A",
            "thumburl": "https://upload.example/a.jpg", "extmetadata": {"LicenseShortName": {"value": "Public domain"}}}]}}}}
OPENVERSE = {"results": [{"title": "Coupe", "foreign_landing_url": "https://flickr.example/1", "thumbnail": "https://ov.example/t1",
              "url": "https://flickr.example/1.jpg", "creator": "Bayo", "license": "by", "license_version": "2.0", "source": "flickr"}]}


AIC = {"data": [{"id": 28560, "title": "The Bedroom", "artist_display": "Vincent van Gogh", "image_id": "abc", "is_public_domain": True, "date_display": "1889"},
                {"id": 1, "title": "Sans image", "image_id": None, "is_public_domain": True}]}
PH_TEXTURES = {"linen_01": {"name": "Linen 01", "categories": ["fabric"], "tags": ["linen", "cloth"], "authors": {"Rob": "All"}},
               "asphalt": {"name": "Asphalt", "categories": ["road"], "tags": ["grey"], "authors": {"Rob": "All"}}}
PH_HDRIS = {"night_room": {"name": "Night Room", "categories": ["indoor", "night"], "tags": ["room"], "authors": {"Greg": "All"}}}
PEXELS = {"photos": [{"id": 9, "url": "https://pexels.example/photo/9", "alt": "Sleep", "photographer": "Lina", "src": {"large2x": "https://img.example/9.jpg"}}]}
UNSPLASH = {"results": [{"id": "u1", "alt_description": "bed", "links": {"html": "https://unsplash.example/u1", "download_location": "https://api.unsplash.com/photos/u1/download"},
                         "urls": {"regular": "https://img.example/u1.jpg"}, "user": {"name": "Ana"}}]}


def statiques_references(parcours, attendre) -> None:
    import json as _json
    import urllib.error
    from PIL import Image
    tampon = io.BytesIO()
    Image.new("RGB", (64, 40), (120, 60, 30)).save(tampon, "PNG")
    png = tampon.getvalue()
    appels = []
    entetes_vus = []

    def faux(url, entetes=None):
        appels.append(url)
        if "api.artic.edu" in url:
            return _json.dumps(AIC).encode()
        if url.startswith("https://api.polyhaven.com/assets?t=textures"):
            return _json.dumps(PH_TEXTURES).encode()
        if url.startswith("https://api.polyhaven.com/assets?t=hdris"):
            return _json.dumps(PH_HDRIS).encode()
        if url == "https://api.polyhaven.com/files/linen_01":
            return _json.dumps({"Diffuse": {"1k": {"jpg": {"url": "https://dl.example/linen_1k.jpg"}}}}).encode()
        if url == "https://api.polyhaven.com/files/night_room":
            return _json.dumps({"tonemapped": {"url": "https://dl.example/night_room.jpg"}}).encode()
        if "api.pexels.com" in url:
            entetes_vus.append(entetes)
            return _json.dumps(PEXELS).encode()
        if "api.unsplash.com" in url:
            return _json.dumps(UNSPLASH).encode()
        if "commons.wikimedia.org" in url:
            return _json.dumps(COMMONS).encode()
        if "api.openverse.org" in url:
            return _json.dumps(OPENVERSE).encode()
        if url == "https://ov.example/t1":
            raise urllib.error.HTTPError(url, 424, "x", {}, None)
        if url == "https://upload.example/b.jpg":
            raise urllib.error.HTTPError(url, 429, "x", {}, None)
        return png
    orig = parcours._lire_ua
    parcours._lire_ua = faux
    try:
        c = parcours.chercher_commons("tailleur Douala", 2)
        attendre([e["titre"] for e in c] == ["Atelier A.jpg", "Atelier B.jpg"] and c[1]["auteur"] == "Ama & Co"
                 and c[1]["licence"] == "CC BY-SA 4.0" and c[0]["licence"] == "Public domain",
                 "références : Commons dans l'ordre de pertinence, auteur sans balises, licence lue")
        attendre([parcours.integrable(x) for x in ("CC BY-SA 4.0", "BY-NC-ND 2.0", "Public domain", "CC BY-ND 4.0", "")] == [True, False, True, False, False],
                 "références : licence intégrable seulement sans NC ni ND, et lue")
        o = parcours.chercher_openverse("tailor", 3)
        attendre(o[0]["licence"] == "BY 2.0" and o[0]["source"] == "Openverse (flickr)", "références : Openverse, licence et source relevées")
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            with contextlib.redirect_stdout(io.StringIO()):
                code = parcours.main(["references", "--commons", "tailleur Douala", "--openverse", "tailor", "--nombre", "2", "--sortie", str(d)])
            refs = _json.loads((d / "refs.json").read_text(encoding="utf-8"))
            statuts = [e["statut"] for e in refs]
            attendre(code == 0 and statuts == ["ok", "1 image(s) refusé (HTTP 429)", "ok"], f"références : refus noté en une ligne par requête, non relancé ({statuts})")
            attendre("https://flickr.example/1.jpg" in appels, "références : vignette refusée, l'image elle-même à l'adresse de la collection")
            attendre(all(e["consulte"] and e["usage"] == "regarder" and e["change"] == "" for e in refs),
                     "références : date de consultation, usage « regarder » par défaut, jugement laissé à l'agent")
            fiches = (d / "refs.md").read_text(encoding="utf-8")
            attendre("jamais une consigne" in fiches and "Change : …" in fiches and "masquant l'identité" in fiches
                     and "canal officiel" in fiches,
                     "références : fiches prêtes pour la trace, page lue tenue pour une donnée")
            attendre(any("iiurlwidth=2560" in u for u in appels) and "nette jusqu'à 32 px de large affichés" in fiches,
                     "références : Commons demandé à 2560 px ; largeur utile de chaque image écrite (moitié de sa largeur)")
            attendre((d / "refs-planche.png").is_file() and sorted(x.name for x in d.glob("[0-9]-*")) == ["1-image.png", "3-image.png"],
                     "références : planche et fichiers numérotés comme les fiches")
            ecran = d / "ecran.png"
            Image.new("RGB", (1440, 900), (240, 240, 240)).save(ecran)
            planche = parcours.contre_references(ecran, d, d / "x") if (d / "x").mkdir() is None else None
            attendre(planche is not None and Image.open(planche).size[0] < 1440 * 520 // 900 + 3 * (64 * 520 // 40) + 200,
                     "contre-références : la planche des références n'y est pas reprise comme une référence")
        a = parcours.chercher_aic("night bedroom", 3)
        attendre(len(a) == 1 and a[0]["licence"].startswith("CC0") and a[0]["fichier_url"].endswith("/full/1686,/0/default.jpg")
                 and a[0]["secours_url"].endswith("/full/843,/0/default.jpg"),
                 "références : Art Institute of Chicago, domaine public seul, image IIIF")
        ph = parcours.chercher_polyhaven("linen night", 3)
        attendre([e["titre"] for e in ph] == ["Linen 01", "Night Room"] and ph[0]["fichier_url"].endswith("linen_1k.jpg")
                 and ph[1]["fichier_url"].endswith("night_room.jpg") and ph[1]["source"] == "Poly Haven (panorama de lumière)"
                 and all(e["licence"] == "CC0" for e in ph), "références : Poly Haven, textures et panoramas par mots, CC0, fichier direct")
        ph2 = parcours.chercher_polyhaven("hdri:night", 3)
        attendre([e["titre"] for e in ph2] == ["Night Room"], "références : Poly Haven, « hdri: » restreint aux panoramas")
        anciennes = {k: parcours.os.environ.pop(v, None) for k, v in parcours.CLES.items()}
        try:
            with tempfile.TemporaryDirectory() as tmp:
                with contextlib.redirect_stdout(io.StringIO()):
                    code = parcours.main(["references", "--pexels", "sleep", "--sortie", tmp])
                refs = _json.loads((Path(tmp) / "refs.json").read_text(encoding="utf-8"))
                attendre(code == 1 and refs[0]["statut"] == "non atteinte : clé absente (PEXELS_API_KEY)" and not any("pexels" in u for u in appels),
                         "références : banque à clé sans clé, déclarée non atteinte, aucun appel")
            parcours.os.environ["PEXELS_API_KEY"] = "k-test"
            parcours.os.environ["UNSPLASH_ACCESS_KEY"] = "u-test"
            with tempfile.TemporaryDirectory() as tmp:
                with contextlib.redirect_stdout(io.StringIO()):
                    code = parcours.main(["references", "--pexels", "sleep", "--unsplash", "bed", "--nombre", "1", "--sortie", tmp])
                refs = _json.loads((Path(tmp) / "refs.json").read_text(encoding="utf-8"))
                attendre(code == 0 and [e["source"] for e in refs] == ["Pexels", "Unsplash"] and entetes_vus[-1] == {"Authorization": "k-test"}
                         and refs[0]["auteur"] == "Lina" and "crédit" in refs[1]["licence"],
                         "références : Pexels et Unsplash avec clé, auteur et licence relevés")
                attendre("https://api.unsplash.com/photos/u1/download" in appels and "signal_entetes" not in refs[1],
                         "références : téléchargement Unsplash signalé à la source, clé absente des fiches")
            with tempfile.TemporaryDirectory() as tmp:
                with contextlib.redirect_stdout(io.StringIO()):
                    code = parcours.main(["references", "--fichier", "https://cdn.example/p.jpg?w=2000", "https://banque.example/photo/1", "Licence X", "--sortie", tmp])
                refs = _json.loads((Path(tmp) / "refs.json").read_text(encoding="utf-8"))
                attendre(code == 0 and refs[0]["page"] == "https://banque.example/photo/1" and refs[0]["licence"] == "Licence X (lue sur la page)"
                         and refs[0]["titre"] == "p.jpg", "références : fichier trouvé ailleurs, page de licence et licence relevées")
        finally:
            for k, v in parcours.CLES.items():
                parcours.os.environ.pop(v, None)
                if anciennes[k] is not None:
                    parcours.os.environ[v] = anciennes[k]
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["references"]) == 2, "références : sans adresse ni requête, code 2")
    finally:
        parcours._lire_ua = orig


def statiques_attente(parcours, attendre) -> None:
    """Refus 429 : une seule attente du délai indiqué (au plus une minute), puis le refus remonte."""
    import urllib.error
    from email.message import Message

    def erreur(code, delai=None):
        h = Message()
        if delai is not None:
            h["Retry-After"] = delai
        return urllib.error.HTTPError("https://x.example", code, "x", h, None)

    class Rep:
        def __init__(self, data): self.data = data
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def read(self): return self.data

    def scenario(reponses):
        appels, attentes = [], []
        def urlopen(req, timeout=30):
            appels.append(req.full_url)
            r = reponses[len(appels) - 1]
            if isinstance(r, Exception):
                raise r
            return Rep(r)
        orig_open, orig_att = parcours.urllib.request.urlopen, parcours._attendre
        parcours.urllib.request.urlopen, parcours._attendre = urlopen, attentes.append
        try:
            try:
                res = parcours._lire_ua("https://x.example")
            except urllib.error.HTTPError as exc:
                res = exc.code
        finally:
            parcours.urllib.request.urlopen, parcours._attendre = orig_open, orig_att
        return res, len(appels), attentes

    res, n, att = scenario([erreur(429, "5"), b"ok"])
    attendre(res == b"ok" and n == 2 and att == [5], "attente : 429 avec délai court, une attente puis réussite")
    res, n, att = scenario([erreur(429, "5"), erreur(429, "5")])
    attendre(res == 429 and n == 2 and att == [5], "attente : 429 qui persiste, une seule attente puis refus déclaré")
    res, n, att = scenario([erreur(429, "3600")])
    attendre(res == 429 and n == 1 and att == [], "attente : délai au-delà d'une minute, refus déclaré sans attendre")
    res, n, att = scenario([erreur(429)])
    attendre(res == 429 and n == 1 and att == [], "attente : 429 sans délai indiqué, refus déclaré sans relance")
    res, n, att = scenario([erreur(403, "5")])
    attendre(res == 403 and n == 1 and att == [], "attente : refus 403, jamais relancé")


def statiques_mesures(parcours, attendre) -> None:
    """Densité d'image, découpe en sections : sans navigateur."""
    from PIL import Image
    G = {"Image intégrée": "Pour une image floue…"}
    s = parcours.densite_signaux([{"nom": "héro", "densite": 1.2, "l": 1440}, {"nom": "vignette", "densite": 2.4, "l": 300}], 1440, G)
    attendre(len(s) == 1 and s[0]["geste"] == "Image intégrée" and "1 image(s)" in s[0]["mesure"] and "héro" in s[0]["mesure"],
             "densité : seule l'image sous 2× est relevée, avec le geste « Image intégrée »")
    attendre(parcours.densite_signaux([{"nom": "x", "densite": 2.0, "l": 800}], 1440, G) == [], "densité : 2× tout juste, aucun signal")
    im = Image.new("RGB", (1440, 3000), (200, 200, 200))
    tampon = io.BytesIO(); im.save(tampon, "PNG")
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        secs = parcours.decouper_sections(tampon.getvalue(), [{"nom": "a", "y": 0, "haut": 900}, {"nom": "b", "y": 900, "haut": 40},
                                                                {"nom": "c", "y": 940, "haut": 1200}], d, 7)
        attendre([x["nom"] for x in secs] == ["a", "c"] and (d / "7-section-1.png").is_file() and (d / "7-site-sections.png").is_file()
                 and Image.open(d / "7-section-1.png").width == 720,
                 "sections : une image par section à 720 px, les bandes trop fines écartées, planche des sections")


SIGNES = {  # signes pièges de l'épreuve d'identité, et un signe propre (une couleur, forme intérieure évidée)
    "propre": '<path fill-rule="evenodd" fill="#2b1d14" d="M50 4a46 46 0 1 0 0.01 0ZM30 30H70V70H30Z"/>',
    "fin": '<g fill="none" stroke="#1d1d1b" stroke-width="1.2"><circle cx="50" cy="50" r="44"/><circle cx="50" cy="50" r="36"/>'
           '<path d="M20 50h60M50 20v60M28 28l44 44M72 28L28 72"/></g>',
    "lumi": '<rect x="5" y="5" width="90" height="90" fill="#d9442b"/><circle cx="50" cy="50" r="28" fill="#2f8f4e"/>',
    "degrade": '<defs><linearGradient id="g"><stop offset="0" stop-color="#ff5f6d"/><stop offset="1" stop-color="#2a5bd7"/>'
               '</linearGradient></defs><circle cx="50" cy="50" r="45" fill="url(#g)"/>',
}


def signe_svg(nom: str, vue: str = "0 0 100 100") -> str:
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vue}">{SIGNES[nom]}</svg>'


def statiques_identite(parcours, attendre) -> None:
    """Mesures et signaux de l'épreuve d'identité, sur des signes dessinés sans navigateur."""
    from PIL import Image, ImageDraw
    def signe(dessin, taille: int = 256):
        im = Image.new("RGBA", (taille, taille), (0, 0, 0, 0))
        dessin(ImageDraw.Draw(im), taille / 256)
        return im
    def petit(im):
        return im.resize((16, 16), Image.LANCZOS)
    def mesurer(dessin):
        im = signe(dessin)
        return parcours.mesures_signe(im, petit(im))
    def noms(mes, vectoriel=True):
        return {s["geste"] for s in parcours.identite_signaux(mes, vectoriel)}
    propre = mesurer(lambda d, k: (d.ellipse((10, 10, 246, 246), fill=(43, 29, 20, 255)),
                                   d.rectangle((80, 80, 176, 176), fill=(0, 0, 0, 0))))
    attendre(noms(propre) == set(), f"identité : signe propre (une couleur, forme évidée), aucun signal ({propre.get('fin'):.3f})")
    attendre(noms(propre, vectoriel=False) == {"Vectoriel maître"}, "identité : un signe qui n'est pas un SVG demande le vectoriel maître")
    fin = mesurer(lambda d, k: [d.line((20, y, 236, y), fill=(29, 29, 27, 255), width=3) for y in range(30, 230, 24)])
    attendre({"Trait ou vide trop fin", "Détail perdu en petit"} <= noms(fin), "identité : traits de 3 px à 256 (sous 1 px à 32), signalés")
    def troue(d, k):
        d.rectangle((4, 4, 252, 252), fill=(20, 20, 20, 255))
        for i in range(6):
            for j in range(6):
                d.rectangle((24 + i * 38, 24 + j * 38, 29 + i * 38, 29 + j * 38), fill=(0, 0, 0, 0))
    attendre("Contreforme bouchée" in noms(mesurer(troue)), "identité : contreformes de 6 px à 256, bouchées à 32, signalées")
    lumi = mesurer(lambda d, k: (d.rectangle((10, 10, 246, 246), fill=(217, 68, 43, 255)),
                                 d.ellipse((60, 60, 196, 196), fill=(47, 143, 78, 255))))
    attendre({"La couleur porte la forme", "Silhouette en une couleur"} <= noms(lumi),
             "identité : deux couleurs de même luminosité, et une forme peinte dans la silhouette, signalées")
    large = mesurer(lambda d, k: d.rectangle((0, 103, 255, 153), fill=(32, 58, 92, 255)))
    attendre("Trop large pour un carré" in noms(large) and large["ratio"] > 4.5, "identité : signe cinq fois plus large que haut, signalé")
    def degrade(d, k):
        for x in range(10, 246):
            d.line((x, 10, x, 246), fill=(255 - x // 2, 95, 109 + x // 3, 255))
    attendre(noms(mesurer(degrade)) == {"Dégradé ou matière"}, "identité : dégradé relevé seul, sans compter ses teintes comme des couleurs")
    quatre = mesurer(lambda d, k: [d.rectangle((x, y, x + 127, y + 127), fill=c) for x, y, c in
                                   ((0, 0, (27, 42, 73, 255)), (128, 0, (228, 87, 46, 255)), (0, 128, (243, 193, 58, 255)),
                                    (128, 128, (118, 176, 65, 255)))])
    attendre("Couleurs nombreuses" in noms(quatre) and len(quatre["couleurs"]) == 4, "identité : quatre couleurs pleines comptées et signalées")
    attendre(noms(parcours.mesures_signe(signe(lambda d, k: None), signe(lambda d, k: None, 16))) == {"Signe vide"},
             "identité : un signe sans encre est déclaré vide")


def statiques_poids(parcours, attendre) -> None:
    """Poids de la page : un signal par repère dépassé, aucun pour une page légère ; image à côté de la page comptée."""
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d / "legere.html").write_text("<!doctype html><title>x</title><p>Texte.</p>", encoding="utf-8")
        (d / "photo.jpg").write_bytes(b"0" * 3_000_000)
        (d / "lourde.html").write_text('<!doctype html><title>x</title><img src="photo.jpg" alt="">', encoding="utf-8")
        legere = parcours.poids_signaux(parcours.poids(d / "legere.html"), 1440)
        lourde = parcours.poids_signaux(parcours.poids(d / "lourde.html"), 1440)
    attendre(legere == [], "poids : page légère, aucun signal")
    mesures = [s["mesure"] for s in lourde]
    attendre(len(lourde) == 2 and any(m.startswith("page") for m in mesures) and any(m.startswith("plus lourde image") for m in mesures)
             and all("[À ADAPTER]" in m and s["question"] for m, s in zip(mesures, lourde)) and all(s["source"] == "SAVOIR/CONTEXT" for s in lourde),
             "poids : page de 3 Mo et image de 3 Mo signalées, chacune avec sa question et son repère à adapter")


def statiques_trace(parcours, attendre) -> None:
    """Forme de la trace légère (`trace`) : l'exemple de la skill passe ; chaque défaut de forme est nommé."""
    import re as _re
    exemple = (HERE.parent / "references" / "examples.md").read_text(encoding="utf-8")
    bloc = next(b for b in _re.findall(r"```text\n(.*?)```", exemple, _re.S) if b.startswith("RUN:"))
    lignes = bloc.rstrip("\n").splitlines()

    def lancer(texte: str | None, nom: str = "trace.md"):
        with tempfile.TemporaryDirectory() as tmp:
            chemin = Path(tmp) / nom
            if texte is not None:
                chemin.write_text(texte, encoding="utf-8")
            sortie, erreur = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(sortie), contextlib.redirect_stderr(erreur):
                code = parcours.main(["trace", str(chemin)])
            return code, sortie.getvalue() + erreur.getvalue()

    code, out = lancer(bloc)
    attendre(code == 0 and "Conforme" in out and "Signaux" not in out, "trace : l'exemple de la skill est conforme, sans signal")
    autres = [lancer(b)[0] for b in _re.findall(r"```text\n(.*?)```", exemple, _re.S) if b.startswith("RUN:")]
    attendre(len(autres) == 3 and set(autres) == {0}, "trace : les trois traces légères des exemples sont conformes")
    guide = (HERE.parent / "guides" / "3-maitriser.md").read_text(encoding="utf-8")
    exemples_guide = [b for b in _re.findall(r"```text\n(.*?)```", guide, _re.S) if b.startswith("RUN:")]
    code, out = lancer(exemples_guide[0] if exemples_guide else "")
    attendre(len(exemples_guide) == 1 and code == 0 and "Conforme" in out, "trace : l'exemple du guide 3 est une trace légère conforme")
    sans_choix = [l.split(" ; choisi par")[0] if l.startswith("MODAL") else l for l in lignes]
    code, out = lancer("\n".join(sans_choix))
    attendre(code == 0 and "ne dit pas qui a choisi" in out and "B3" in out,
             "trace : ligne modal sans « choisi par » signalée, sans échec")
    sans_rang = [l.replace(" ; idée : fait de rang 2 de l’inventaire, contre la modale défendue", "") if l.startswith("MODAL") else l for l in lignes]
    code, out = lancer("\n".join(sans_rang))
    attendre(sans_rang != lignes and code == 0 and "ne dit pas de quel rang" in out,
             "trace : ligne modal sans rang de l'inventaire signalée, sans échec ; présent, rien (exemple de la skill)")
    sans_structure = [l.replace(" ; structure `GRID/HIERARCHICAL`, profil `STYLE/EDITORIAL_PRECISION`", "") if l.startswith("MODAL") else l for l in lignes]
    code, out = lancer("\n".join(sans_structure))
    hors = [l.replace("RUN: DIRECTION", "RUN: STANDARD") if l.startswith("RUN") else l for l in sans_structure]
    code_h, out_h = lancer("\n".join(hors))
    attendre(sans_structure != lignes and code == 0 and "ne nomme pas la structure" in out and "ne nomme pas la structure" not in out_h,
             "trace : en DIRECTION, ligne modal sans structure ni profil signalée, sans échec ; hors DIRECTION, rien")
    sans_expression = [l.replace(" ; expression : [sobre, affirmée ou expressive]", "") if l.startswith("DIRECTION") else l for l in lignes]
    code, out = lancer("\n".join(sans_expression))
    code_a, out_a = lancer("\n".join(l.replace("[sobre, affirmée ou expressive]", "affirmée") for l in lignes))
    attendre(sans_expression != lignes and code == 0 and "ne dit pas l'expression attendue" in out
             and code_a == 0 and "expression attendue" not in out_a,
             "trace : ligne de direction sans expression (sobre, affirmée, expressive) signalée, sans échec ; présente, rien")
    code, out = lancer("\n".join(l for l in lignes if not l.startswith("MODAL")))
    attendre(code == 1 and "ligne manquante : MODAL, TRAME ET PARTI:" in out, "trace : ligne manquante, échec nommé")
    inverse = lignes[:]
    inverse[1], inverse[2] = inverse[2], inverse[1]
    code, out = lancer("\n".join(inverse))
    attendre(code == 1 and "ordre : DIRECTION DÉCLARÉE ET THÈSE:" in out, "trace : ordre inversé, échec nommé")
    longue = lignes[:]
    longue[3] = longue[3] + " ; détail" * 40
    code, out = lancer("<!--\n" + "\n".join(longue) + "\n-->\n<!doctype html><title>x</title>", "page.html")
    attendre(code == 0 and "PLAFOND, ESSAIS ET CONTENUS MARQUÉS: (ligne 5) fait" in out and "[À ADAPTER]" in out,
             "trace : en-tête du fichier livré lu ; ligne trop longue signalée, sans échec")
    envisage = lignes[:]
    envisage[4] = "DÉFAUT DOMINANT RESTANT: premier écran encore générique ; geste envisagé : resserrer la grille, pas encore appliqué"
    code, out = lancer("\n".join(envisage))
    attendre(code == 0 and "geste envisagé, pas appliqué" in out, "trace : geste seulement envisagé signalé, sans échec")
    code, out = lancer(None)
    attendre(code == 2 and "trace introuvable" in out, "trace : fichier introuvable, code 2")
    with tempfile.TemporaryDirectory() as tmp:
        page = Path(tmp) / "index.html"
        page.write_text("<!doctype html><title>x</title>", encoding="utf-8")
        sans = parcours.traces_voisines(page)
        (Path(tmp) / "trace.md").write_text(bloc, encoding="utf-8")
        attendre(sans == [] and parcours.traces_voisines(page) == [Path(tmp) / "trace.md"],
                 "trace : verifier la propose seulement quand une trace se trouve à côté de la page")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Cas connus du parcours par défaut.")
    ap.add_argument("--require-browser", action="store_true")
    ap.add_argument("--skip-browser", action="store_true")
    a = ap.parse_args(argv)
    sys.path.insert(0, str(HERE))
    import parcours  # noqa: E402

    echecs: list[str] = []
    n = 0

    def attendre(cond: bool, msg: str) -> None:
        nonlocal n
        n += 1
        print(f"  [{'ok' if cond else 'ÉCHEC'}] P{n:02d} {msg}")
        if not cond:
            echecs.append(msg)

    statiques(parcours, attendre)
    statiques_references(parcours, attendre)
    statiques_attente(parcours, attendre)
    statiques_mesures(parcours, attendre)
    statiques_identite(parcours, attendre)
    statiques_trace(parcours, attendre)
    statiques_poids(parcours, attendre)
    if a.skip_browser:
        print(f"PARCOURS TESTS {'FAILED' if echecs else 'NOT-VERIFIED'} — {n} cas statiques ; navigateur écarté (--skip-browser)")
        return 1 if echecs else 0
    absents = manquants()
    if absents:
        print(f"PARCOURS TESTS {'FAILED' if echecs else 'NOT-VERIFIED'} — {n} cas statiques ; absents : " + ", ".join(absents))
        return 1 if echecs or a.require_browser else 0

    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        for nom, html in (("sale", SALE), ("propre", PROPRE), ("muet", MUET)):
            (d / f"{nom}.html").write_text(html, encoding="utf-8")

        sig = parcours.finition(d / "sale.html", [1440])
        gestes = {s["geste"] for s in sig}
        mesures = " ".join(s["mesure"] for s in sig)
        for g in ("Cohérence de rayon", "Surface", "Accent", "Masse visuelle", "Alignement optique", "Chiffres", "Gestion du vide"):
            attendre(g in gestes, f"finition (page piège) : signal « {g} »")
        attendre("chasse fixe" in mesures, "finition (page piège) : texte courant en chasse fixe")
        attendre("9 px" in mesures, "finition (page piège) : texte sous 11 px")
        attendre("div.d" in mesures, "finition (page piège) : le vide est trouvé dans la colonne qui le porte")
        attendre(all(s["geste_texte"] and "introuvable" not in s["geste_texte"] for s in sig),
                 "finition : chaque signal porte son geste lu dans SAVOIR/STATE")

        from PIL import Image as _Im
        _Im.new("RGB", (400, 300), (90, 120, 160)).save(d / "petite.png")
        _Im.new("RGB", (1600, 1200), (90, 120, 160)).save(d / "grande.png")
        (d / "images.html").write_text('<!doctype html><html lang="fr"><body style="margin:0">'
                                        '<img src="petite.png" alt="molle" style="width:800px;height:600px;display:block">'
                                        '<img src="grande.png" alt="nette" style="width:800px;height:600px;display:block"></body></html>', encoding="utf-8")
        (d / "signe.svg").write_text('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100"/></svg>', encoding="utf-8")
        (d / "images.html").write_text((d / "images.html").read_text(encoding="utf-8").replace(
            "</body>", '<img src="signe.svg" alt="vectoriel" style="width:600px;height:600px;display:block"></body>'), encoding="utf-8")
        sig = [s for s in parcours.finition(d / "images.html", [1440]) if s["geste"] == "Image intégrée"]
        attendre(len(sig) == 1 and "vectoriel" not in sig[0]["mesure"],
                 "densité : une image vectorielle agrandie n'est pas relevée comme floue")
        attendre(len(sig) == 1 and "molle" in sig[0]["mesure"] and "nette" not in sig[0]["mesure"],
                 "densité (page piège) : l'image à 0,5× est relevée, celle à 2× ne l'est pas")

        sig = parcours.finition(d / "propre.html", [1440, 390])
        attendre(sig == [], f"finition (page propre) : aucun signal ({[s['geste'] for s in sig]})")
        sig = parcours.finition(d / "muet.html", [1440])
        attendre(not any(s["geste"] in ("Chiffres", "Gestion du vide") for s in sig),
                 "finition : chiffres en chasse fixe ou en SVG et marge étroite restent muets")

        bulles = "<div class='bulles'>" + "".join(f"<b style='left:{(k * 53) % 330}px;top:{(k * 37) % 580}px'></b>" for k in range(70)) + "</div>"
        for nom, contenu in (("bandes", ""), ("bulles", bulles)):
            (d / f"{nom}.html").write_text(BANDES.replace("GRAIN", GRAIN).replace("BULLES", contenu), encoding="utf-8")
        sig = parcours.finition(d / "bandes.html", [390])
        attendre(any(s["geste"] == "Gestion du vide" and "premier écran" in s["mesure"] for s in sig),
                 "finition (390 px) : bande sans contenu sous des bandes de fond et un grain")
        sig = parcours.finition(d / "bulles.html", [390])
        attendre(not any(s["geste"] == "Gestion du vide" for s in sig), "finition (390 px) : un dessin fait de formes n'est pas un vide")
        (d / "champs.html").write_text("""<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#eee;font:16px Arial}
form{position:absolute;left:300px;top:120px;width:640px;height:410px;background:#fff;padding:32px;box-sizing:border-box}
input{display:block;width:100%;height:120px;margin:0 0 24px;border:0;background:#fff;font-size:18px}</style>
<form><label>Nom</label><input><label>Adresse</label><input><button>Envoyer</button></form>""", encoding="utf-8")
        (d / "cadre.html").write_text("""<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#e8e8e6;font:16px Arial}
.cadre{position:absolute;left:120px;top:120px;width:1200px;height:420px;background:#17181a;overflow:hidden}
.cadre svg{position:absolute;inset:0}.cadre p{position:absolute;left:0;right:0;bottom:24px;text-align:center;color:#fff;font-size:28px;margin:0}</style>
<div class="cadre"><svg aria-hidden="true" width="100%" height="100%"><filter id="g"><feTurbulence baseFrequency=".9"/></filter>
<rect width="100%" height="100%" filter="url(#g)" opacity=".06"/></svg><p>Un sous-titre en bas du cadre</p></div>""", encoding="utf-8")
        sig = parcours.finition(d / "cadre.html", [1440])
        attendre(any(s["geste"] == "Gestion du vide" and "div.cadre" in s["mesure"] for s in sig),
                 "finition : un cadre vide sous un calque de grain en SVG reste un vide")
        sig = parcours.finition(d / "champs.html", [1440])
        attendre(not any(s["geste"] == "Gestion du vide" for s in sig), "finition : un champ de saisie uni n'est pas un vide")

        for nom, html in (("generique", GENERIQUE), ("orchestre", ORCHESTRE), ("boucle", BOUCLE)):
            (d / f"{nom}.html").write_text(html, encoding="utf-8")
        G = parcours.gestes()
        (d / "typo.html").write_text("""<!doctype html><html lang="fr"><meta charset="utf-8"><title>T</title><body style="font:16px Arial;margin:40px">
<p>Chargement en cours...</p><p>Prix : 12 €, vraiment ? Oui!</p><p>Il dit "bonjour" à tous.</p><code>a: b...</code>
<p>Heure 15:30, et une espace ; juste : ici.</p></body></html>""", encoding="utf-8")
        t = " ".join(s["mesure"] for s in parcours.finition(d / "typo.html", [1440]) if s["geste"] == "Typographie fine")
        attendre("1 × trois points" in t and "ponctuation haute" in t and "guillemets droits" in t,
                 f"typographie fine : points de suspension, ponctuation haute et guillemets droits relevés, code ignoré ({t})")
        sig = parcours.finition(d / "generique.html", [1440])
        gab = " ".join(s["mesure"] for s in sig if s["geste"] == "Habillage de gabarit")
        attendre(all(x in gab for x in ("points médians", "sur-titres", "flèches", "numéros", "mis en couleur dans un titre")),
                 "gabarit : points médians, sur-titres en capitales, flèches et numéros relevés, révélations masquées comprises")
        (d / "demo.html").write_text("""<!doctype html><html lang="fr"><meta charset="utf-8"><title>D</title><body style="font:16px Arial;margin:40px">
<p style="font-family:monospace">Fiche d'atelier</p><p style="font-family:'Courier New',monospace">Talon client à garder</p>
<div style="width:300px;height:160px;background:#d9b98a;transform:rotate(-3deg)"><p>Étiquette suspendue</p></div></body></html>""", encoding="utf-8")
        (d / "donnees.html").write_text("""<!doctype html><html lang="fr"><meta charset="utf-8"><title>P</title><body style="font:16px Arial;margin:40px">
<p style="font-family:monospace">15 €</p><p style="font-family:monospace">12:30</p><code>npm install</code>
<div style="width:300px;height:160px;background:#eee"><p>Carte droite</p></div></body></html>""", encoding="utf-8")
        dem = " ".join(s["mesure"] for s in parcours.finition(d / "demo.html", [1440]) if s["geste"] == "Habillage de gabarit")
        don = " ".join(s["mesure"] for s in parcours.finition(d / "donnees.html", [1440]) if s["geste"] == "Habillage de gabarit")
        attendre("chasse fixe" in dem and "incliné" in dem and "chasse fixe" not in don and "incliné" not in don,
                 f"marques de démonstration : libellés décoratifs en chasse fixe et bloc incliné relevés ; prix, heure et code en chasse fixe, rien ({dem} | {don})")
        mv = parcours.mouvement(d / "generique.html", 1440, d, "#cta")
        q = " ".join(s["mesure"] for s in parcours.mouvement_signaux(mv, G))
        attendre("fondu-glissé sur 3" in q and "survol sur 3 cartes" in q, f"mouvement (gabarit) : fondu sur chaque section et survol sur chaque carte ({q})")
        attendre(Path(mv["planche"]).is_file() and (d / "mouvement.json").is_file(), "mouvement : planche et relevé écrits")
        mv = parcours.mouvement(d / "orchestre.html", 1440, d / "o" if (d / "o").mkdir() is None else d, "#cta")
        attendre(parcours.mouvement_signaux(mv, G) == [] and mv["duree"] == 1400 and mv["reduit"] == [],
                 "mouvement (orchestré) : une entrée de 1,4 s, mouvement réduit respecté, aucune question")
        attendre(mv["action_ms"] == 0, "mouvement : l'action visible dès la première image")
        attendre(mv["survol"] == [{"cible": "action", "change": True}], "mouvement : le survol de l'action est capturé dans le même cadre, et son changement se voit")
        from PIL import Image as _Im
        attendre(_Im.open(mv["planche"]).size[0] > 5 * 360, "mouvement : cinq images d'entrée sur la planche")
        mv = parcours.mouvement(d / "boucle.html", 1440, d / "b" if (d / "b").mkdir() is None else d)
        q = " ".join(s["mesure"] for s in parcours.mouvement_signaux(mv, G))
        attendre("sans fin" in q and "mouvement réduit" in q and "invisible" in q,
                 f"mouvement : boucle sans fin, mouvement réduit ignoré, texte jamais révélé ({q})")
        (d / "acces.html").write_text("""<!doctype html><html lang="fr"><meta charset="utf-8"><title>Accès</title><body>
<button id="icone"><svg width="16" height="16"><rect width="16" height="16"/></svg></button>
<input id="piege" aria-label="Piège" onkeydown="if(event.key==='Tab')event.preventDefault()"><button>Suivant</button>
<input type="date" aria-label="Date"></body></html>""", encoding="utf-8")
        m = parcours.acces(d / "acces.html")
        attendre(m["sans_nom"] == ["button"] and any("Suivant" in x for x in m["non_atteints"]),
                 f"accès : bouton sans nom calculé et contrôle jamais atteint au clavier ({m['sans_nom']}, {m['non_atteints']})")
        m = parcours.acces(d / "propre.html")
        attendre(m["sans_nom"] == [] and m["non_atteints"] == [], "accès : page propre, aucun signal")
        sec = '<section style="height:600px;padding:60px"><h2 style="font-size:48px;margin:0">Titre {i}</h2><p style="width:40%">Un paragraphe.</p></section>'
        (d / "monotone.html").write_text("<!doctype html><body style='margin:0;font:16px Arial'>" + "".join(sec.format(i=i) for i in range(3)) + "</body>", encoding="utf-8")
        _, groupes = parcours.silhouette(d / "monotone.html", d)
        attendre(len(groupes) == 1 and len(groupes[0]) == 3 and (d / "silhouette-1440.png").is_file(),
                 f"silhouette : trois sections de même silhouette, page réduite écrite ({groupes})")
        varie = ('<section style="height:700px"><h1 style="font-size:96px;margin:0">Grand</h1></section>'
                 '<section style="height:500px;display:flex;justify-content:flex-end"><div style="width:30%"><h2 style="font-size:32px">Calme</h2><p>Texte.</p></div></section>')
        (d / "varie.html").write_text("<!doctype html><body style='margin:0;font:16px Arial'>" + varie + "</body>", encoding="utf-8")
        attendre(parcours.silhouette(d / "varie.html", d)[1] == [], "silhouette : sections d'échelle et de place différentes, aucun signal")
        # Recettes : chaque code tourne dans le navigateur, sans erreur, et fait ce que la recette promet.
        from playwright.sync_api import sync_playwright
        R = parcours.recettes()
        attendre(set(R) == {"graphique", "grand-chiffre", "moment-orchestre", "focus", "controles", "matiere", "police-variable",
                            "reponse-courriel", "agenda", "objet-en-scene", "emplacement-photo"} and all(parcours.code_recette(t) for t in R.values()),
                 "recettes : onze recettes, chacune avec son code")
        # Pages d'essai : une image réelle pour l'objet, un mot long pour la graisse, un texte long pour l'agenda (pliage).
        IMG = ("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1200' height='1500'%3E%3Crect width='1200' height='1500' fill='%23cb9'/%3E"
               "%3Ccircle cx='600' cy='600' r='300' fill='%23345'/%3E%3C/svg%3E")
        essais = {"objet-en-scene": ('src="objet.jpg"', f'src="{IMG}"'),
                  "police-variable": (">Échantillon<", ">Échantillonnage typographique<"),
                  "agenda": ("texte: 'Pièces nouvelles; entrée libre, sur réponse.'", "texte: 'Pièces nouvelles; entrée libre, sur réponse. ' + 'Cuisson au bois, émaux de cendre, longue table. '.repeat(3)")}
        for nom, t in R.items():
            code = parcours.code_recette(t)
            if nom in essais:
                code = code.replace(*essais[nom])
            (d / f"r-{nom}.html").write_text('<!doctype html><html lang="fr"><meta charset="utf-8"><title>' + nom + '</title><body style="font:16px Arial;margin:16px">'
                                             + code + "</body></html>", encoding="utf-8")
        with sync_playwright() as p:
            nav = p.chromium.launch()
            erreurs = []

            def ouvrir(nom, L=1440, **k):
                ctx = nav.new_context(viewport={"width": L, "height": 900}, **k)
                pg = ctx.new_page(); pg.on("pageerror", lambda e: erreurs.append(f"{nom} : {e}"))
                pg.goto((d / f"r-{nom}.html").as_uri()); pg.wait_for_timeout(150)
                return pg
            pg = ouvrir("graphique", 390)
            boites = pg.evaluate("""() => [...document.querySelectorAll('.lab,.val')].filter(e => getComputedStyle(e).visibility === 'visible')
                .map(e => { const r = e.getBoundingClientRect(); return [r.left, r.right, r.top, r.bottom]; })""")
            chev = any(a[0] < b[1] - 1 and b[0] < a[1] - 1 and a[2] < b[3] - 1 and b[2] < a[3] - 1 for i, a in enumerate(boites) for b in boites[i + 1:])
            attendre(not chev and pg.evaluate("() => getComputedStyle(document.querySelector('.cle .val')).visibility") == "visible",
                     "recette graphique : à 390 px, aucune étiquette recouverte, la valeur clé reste écrite")
            pg = ouvrir("grand-chiffre", 390)
            pg.fill("#m", "1234567"); pg.wait_for_timeout(50)
            attendre(pg.evaluate("() => { const c = document.querySelector('.montant'); return c.scrollWidth <= c.clientWidth + 1; }")
                     and pg.evaluate("() => document.getElementById('r').textContent").replace("\u202f", " ").startswith("2 469"),
                     "recette grand-chiffre : sept chiffres saisis à 390 px, rien ne déborde, le résultat suit")
            n_libre = ouvrir("moment-orchestre").evaluate("() => document.getAnimations().length")
            n_reduit = ouvrir("moment-orchestre", reduced_motion="reduce").evaluate("() => document.getAnimations().length")
            attendre(n_libre >= 1 and n_reduit == 0, f"recette moment-orchestre : une entrée, rien sous mouvement réduit ({n_libre}, {n_reduit})")
            pg = ouvrir("focus"); pg.keyboard.press("Tab")
            attendre(pg.evaluate("() => { const cs = getComputedStyle(document.activeElement); return cs.outlineWidth === '3px' && cs.boxShadow.includes('2px'); }"),
                     "recette focus : double contour au focus clavier")
            pg = ouvrir("controles"); pg.keyboard.press("Tab"); pg.keyboard.press("ArrowRight")
            radio = pg.evaluate("() => document.querySelector('input[name=d]:checked').value")
            pg.click("#e"); pg.fill("#e", "pas-une-adresse"); pg.keyboard.press("Tab")
            erreur = pg.evaluate("() => document.getElementById('e').getAttribute('aria-invalid') === 'true' && !document.getElementById('e-err').hidden")
            pg.click(".envoi")
            occupe = pg.evaluate("() => { const b = document.querySelector('.envoi'); return b.getAttribute('aria-busy') === 'true' && b.innerText.trim() === 'Envoyer'; }")
            pg.focus("#t1"); pg.keyboard.press("ArrowRight")
            onglet = pg.evaluate("() => document.getElementById('t2').getAttribute('aria-selected') === 'true' && !document.getElementById('p2').hidden && document.activeElement.id === 't2'")
            attendre(radio == "10" and erreur and occupe and onglet,
                     f"recette controles : flèches dans le groupe et les onglets, erreur annoncée, libellé gardé au chargement ({radio}, {erreur}, {occupe}, {onglet})")
            grains = []
            for L in (1440, 390):
                pg = ouvrir("matiere", L)
                grains.append(pg.evaluate("""() => { const m = document.querySelector('.matiere'), a = getComputedStyle(m, '::after');
                    return [a.backgroundSize, getComputedStyle(m).filter, a.backgroundImage.includes('feTurbulence')]; }"""))
            pg.locator(".matiere").screenshot(path=str(d / "r-matiere.png"))
            from PIL import Image as _Img, ImageStat
            ecart = ImageStat.Stat(_Img.open(d / "r-matiere.png").convert("L")).stddev[0]
            attendre(grains[0] == grains[1] == ["180px 180px", "none", True] and ecart > 3,
                     f"recette matiere : grain en image de fond, même taille en pixels à 1440 et 390 px, aucun filtre sur l'élément, surface non plate ({grains}, {ecart:.1f})")
            for L in (1440, 390):
                pg = ouvrir("police-variable", L)
                anime = pg.evaluate("() => document.getAnimations().length")
                pg.focus("#gr"); pg.keyboard.press("End")
                g = pg.evaluate("""() => { const e = document.getElementById('ech');
                    return [getComputedStyle(e).fontWeight, document.getElementById('grv').textContent, document.getElementById('gr').getAttribute('aria-valuetext'),
                            e.scrollWidth <= e.clientWidth + 1, document.getAnimations().length]; }""")
                attendre(anime == 1 and g == ["900", "900", "900, noire", True, 0],
                         f"recette police-variable à {L} px : balayage, puis la main au clavier, la graisse la plus forte sans débordement ({anime}, {g})")
            attendre(ouvrir("police-variable", reduced_motion="reduce").evaluate("() => document.getAnimations().length") == 0,
                     "recette police-variable : rien ne bouge sous mouvement réduit")
            pg = ouvrir("reponse-courriel", 390)
            pg.click("button[type=submit]")
            vide = pg.evaluate("() => !document.getElementById('rn-err').hidden && document.activeElement.id === 'rn' && document.getElementById('rep-ok').hidden")
            pg.fill("#rn", "Élise Noël"); pg.check("input[value=non]"); pg.click("button[type=submit]"); pg.wait_for_timeout(100)
            lien, ok = pg.evaluate("() => [document.getElementById('rep-lien').href, !document.getElementById('rep-ok').hidden]")
            from urllib.parse import unquote
            attendre(vide and ok and unquote(lien).endswith("Nom : Élise Noël\r\nJe viens : non\r\nNombre : 1")
                     and "envoyé" not in pg.evaluate("() => document.getElementById('rep-ok').textContent"),
                     f"recette reponse-courriel : erreur et focus sans nom ; lien composé, accents et retours gardés, rien ne dit « envoyé » ({vide}, {ok}, {lien[:60]})")
            pg = ouvrir("agenda", accept_downloads=True)
            with pg.expect_download() as tele:
                pg.click("#ics")
            ics = Path(tele.value.path()).read_bytes()
            lignes = ics.split(b"\r\n")
            attendre(tele.value.suggested_filename.endswith(".ics") and b"DTSTART:20261204T173000Z" in ics and b"SUMMARY:Vernissage\\, atelier" in ics
                     and max(map(len, lignes)) <= 75 and any(x.startswith(b" ") for x in lignes) and b"\n" not in ics.replace(b"\r\n", b"")
                     and b"UID:" in ics and b"DTSTAMP:" in ics,
                     f"recette agenda : fichier .ics en UTC, échappé, plié à 75 octets, retours CRLF ({tele.value.suggested_filename}, {max(map(len, lignes))})")
            cadres = []
            for L in (1440, 390):
                cadres.append(ouvrir("objet-en-scene", L).evaluate("""() => { const c = document.querySelector('.cadre'), i = c.querySelector('img'),
                    r = c.getBoundingClientRect(), q = i.getBoundingClientRect();
                    return [Math.round(r.width / r.height * 100) / 100, (getComputedStyle(c).boxShadow.match(/rgb/g) || []).length,
                            q.width === r.width && q.height === r.height, i.hasAttribute('width') && i.hasAttribute('height') && i.alt.length > 0]; }"""))
            attendre(cadres == [[0.8, 2, True, True], [1.0, 2, True, True]],
                     f"recette objet-en-scene : cadre au rapport fixé, recadré à 390 px, deux ombres, image dimensionnée et décrite ({cadres})")
            places = []
            for L in (1440, 390):
                places.append(ouvrir("emplacement-photo", L).evaluate("""() => { const c = document.querySelector('.emplacement-photo .cadre'), r = c.getBoundingClientRect();
                    return [Math.round(r.width / r.height * 100) / 100, c.getAttribute('role') === 'img' && (c.getAttribute('aria-label') || '').length > 20,
                            !!document.querySelector('.emplacement-photo figcaption .consigne'), document.querySelectorAll('img').length]; }"""))
            attendre(places == [[0.8, True, True, 0], [1.0, True, True, 0]],
                     f"recette emplacement-photo : ratio tenu, recadré à 390 px, décrit pour la lecture d'écran, consigne présente, aucune image ({places})")
            nav.close()
        for nom in ("controles", "police-variable", "reponse-courriel", "agenda"):
            m = parcours.acces(d / f"r-{nom}.html")
            attendre(m["sans_nom"] == [] and m["non_atteints"] == [] and not m.get("inertes"),
                     f"recette {nom} : aucun contrôle sans nom, hors du clavier ou inerte ({m})")
        attendre(not erreurs, f"recettes : aucune erreur de script ({erreurs})")
        vites = parcours.captures(d / "propre.html", [1440, 390], None, d / "boucle", "v2")
        from PIL import Image
        taille = Image.open(d / "boucle" / "v2.png").size if (d / "boucle" / "v2.png").exists() else None
        attendre([x.name for x in vites] == ["v2.png"] and taille == (1440 + 390 + 3 * 24, parcours.hauteur(1440) + 36 + 24),
                 f"captures --version : une seule image par version, les premiers écrans côte à côte à 1x ({taille})")
        contre = parcours.captures(d / "propre.html", [1440, 390], None, d / "boucle-c", "v2", contre=d / "sale.html")
        taille_c = Image.open(d / "boucle-c" / "v2.png").size if (d / "boucle-c" / "v2.png").exists() else None
        attendre([x.name for x in contre] == ["v2.png"] and taille is not None and taille_c == (taille[0], 2 * taille[1]),
                 f"captures --version --contre : l'esquisse retenue en première rangée, la version dessous, une seule image ({taille_c})")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["captures", str(d / "propre.html"), "--contre", str(d / "sale.html")]) == 2
                     and parcours.main(["captures", str(d / "propre.html"), "--version", "v3", "--contre", str(d / "absente.html")]) == 2,
                     "captures --contre : refusé sans --version, ou si l'esquisse est introuvable")
        piege14c = ("<!doctype html><html lang=fr><meta charset=utf-8><title>p</title><style>body{margin:0;font:16px sans-serif;background:#fff;color:#111}"
                    "#bord{position:absolute;left:2px;top:40px}#anim{animation:clair 1s linear both;font-size:20px;margin:120px 40px}"
                    "@keyframes clair{from{color:#fafafa}to{color:#111}}input{border:1px solid #f2f2f2;background:#fff;margin:40px}</style>"
                    "<p id=bord>Collé au bord</p><p id=anim>Titre qui apparaît</p>"
                    "<svg role=img aria-label=courbe width=200 height=60><path d='M0 50 L200 10' stroke='#e6e6e6' stroke-width=2 fill=none /></svg>"
                    "<label>Nom <input></label><div role=slider tabindex=0 aria-label=Graisse aria-valuenow=300 aria-valuemin=200 aria-valuemax=900>300</div></html>")
        propre14c = ("<!doctype html><html lang=fr><meta charset=utf-8><title>p</title><style>body{margin:0;padding:24px;font:16px sans-serif;background:#fff;color:#111}"
                     "input{border:1px solid #666}</style><p>Texte posé avec sa marge</p>"
                     "<svg role=img aria-label=courbe width=200 height=60><path d='M0 50 L200 10' stroke='#333' stroke-width=2 fill=none /></svg>"
                     "<label>Nom <input></label><input type=range aria-label=Graisse min=200 max=900 value=300></html>")
        (d / "piege14c.html").write_text(piege14c, encoding="utf-8")
        (d / "propre14c.html").write_text(propre14c, encoding="utf-8")
        f_piege = parcours.finition(d / "piege14c.html", [1440])
        f_propre = parcours.finition(d / "propre14c.html", [1440])
        attendre(any(s["geste"] == "Gestion du vide" and "bord de la fenêtre" in s["mesure"] for s in f_piege)
                 and not any("bord de la fenêtre" in s["mesure"] for s in f_propre),
                 "finition : texte collé au bord de la fenêtre signalé ; marge respectée, rien")
        attendre(any(s["geste"] == "Contraste non textuel" and "graphique path" in s["mesure"] and "bord de input" in s["mesure"] for s in f_piege)
                 and not any(s["geste"] == "Contraste non textuel" for s in f_propre),
                 "finition : courbe et bord de champ sous 3:1 signalés ; contrastés, rien")
        a_piege, a_propre = parcours.acces(d / "piege14c.html"), parcours.acces(d / "propre14c.html")
        attendre(any("slider" in x for x in a_piege["inertes"]) and a_propre["inertes"] == []
                 and any(s["geste"] == "Commande au clavier" for s in parcours.acces_signaux(a_piege, 1440)),
                 f"accès : curseur personnalisé sans effet des flèches signalé ; curseur natif, rien ({a_piege['inertes']}, {a_propre['inertes']})")
        (d / "mvt14c").mkdir(exist_ok=True)
        m_piege = parcours.mouvement(d / "piege14c.html", 1440, d / "mvt14c")
        attendre(any("Titre qui apparaît" in " ".join(x) for _, x in m_piege["contraste_entree"])
                 and any("pendant l'entrée" in s["mesure"] for s in parcours.mouvement_signaux(m_piege, parcours.gestes())),
                 f"mouvement : texte illisible pendant l'entrée, lisible à la fin, signalé ({m_piege['contraste_entree']})")
        separees = parcours.captures(d / "propre.html", [1440, 390], None, d / "boucle-s", "v2", False, True)
        attendre(sorted(x.name for x in separees) == ["v2-1440.png", "v2-390.png"]
                 and Image.open(d / "boucle-s" / "v2-390.png").size == (390, 844),
                 "captures --version --separees : une image par largeur, à 1x")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["captures", str(d / "propre.html"), "--version", "a b"]) == 2, "captures --version : nom refusé s'il contient une espace")
        livre = parcours.captures(d / "sale.html", [1440], None, d / "livre", "pricing", True)
        attendre([x.name for x in livre] == ["pricing-1440.png"] and Image.open(livre[0]).size[1] > 900,
                 "captures --version --pleine : page entière sous le nom demandé")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["captures", str(d / "propre.html"), "--pleine"]) == 2, "captures --pleine sans --version : refusé")

        caps = parcours.captures(d / "propre.html", [1440], "main", d / "caps")
        noms = {c.name for c in caps}
        attendre({"ecran-1440.png", "page-1440.png", "ecran-1440@2x.png", "foyer-1440@2x.png"} <= noms,
                 "captures : premier écran, page entière, @2x et foyer agrandi")
        attendre(Image.open(d / "caps" / "ecran-1440@2x.png").size == (2880, 1800), "captures : @2x à deux fois la fenêtre")
        tel = parcours.captures(d / "propre.html", [390], None, d / "tel")
        attendre("ecran-390-telephone.png" in {c.name for c in tel} and Image.open(d / "tel" / "ecran-390-telephone.png").size[0] == 1170,
                 "captures : sous 768 px, premier écran sur téléphone émulé à densité 3×")
        attendre(not any("telephone" in c.name for c in caps), "captures : pas de téléphone émulé au bureau")

        refs = d / "refs"
        refs.mkdir()
        Image.new("RGB", (800, 600), (200, 30, 30)).save(refs / "r1.png")
        Image.new("RGB", (600, 900), (30, 30, 200)).save(refs / "r2.jpg")
        planche = parcours.contre_references(d / "caps" / "ecran-1440.png", refs, d / "caps")
        attendre(planche is not None and Image.open(planche).size[1] == 520 + 72, "contre-références : trois tuiles à la même hauteur")

        with contextlib.redirect_stdout(io.StringIO()):
            code_ok = parcours.main(["verifier", str(d / "propre.html"), "--action", "#action", "--foyer", "main",
                                     "--refs", str(refs), "--sortie", str(d / "v1")])
            code_ko = parcours.main(["verifier", str(d / "sale.html"), "--action", "#action", "--sortie", str(d / "v2")])
        sortie_courte = io.StringIO()
        (d / "v3").mkdir(exist_ok=True)
        (d / "v3" / ".appels").write_text("2")
        with contextlib.redirect_stdout(sortie_courte):
            parcours.main(["verifier", str(d / "propre.html"), "--action", "#action", "--sortie", str(d / "v3")])
        ecran = sortie_courte.getvalue()
        attendre("Appel 3 de verifier" in ecran and "captures" in ecran.split("\n")[0], "verifier : au troisième appel pour une page, le compte des appels est affiché")
        attendre("## 3." in ecran and "## 5." not in ecran and "Fiche complète" in ecran and "D'abord, seule" in ecran,
                 "verifier : à l'écran, défauts, réserves, signaux et première image ; le reste dans la fiche")
        premier, second = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(premier):
            parcours.main(["verifier", str(d / "propre.html"), "--action", "#action", "--sortie", str(d / "v6")])
        with contextlib.redirect_stdout(second):
            parcours.main(["verifier", str(d / "propre.html"), "--action", "#action", "--sortie", str(d / "v6")])
        attendre("Rien n'a changé" in second.getvalue() and "Toujours présents" in second.getvalue()
                 and len(second.getvalue()) * 3 <= len(premier.getvalue()),
                 f"verifier : au deuxième appel sur une page inchangée, seulement ce qui a changé ({len(premier.getvalue())} → {len(second.getvalue())} car.)")
        fiche = (d / "v1" / "parcours.md").read_text(encoding="utf-8")
        attendre(code_ok == 0 and all(f"## {i}." in fiche for i in range(1, 7)), "verifier : fiche en six sections, code 0")
        attendre("largeurs 1440, 768, 390 px" in fiche, "verifier : la recette voit aussi la largeur intermédiaire, 768 px")
        attendre("tous nommés" in fiche and "nom accessible calculé non vérifié" not in fiche,
                 "verifier : noms accessibles calculés par le navigateur, réserve de la recette levée")
        attendre("- Poids : fichier" in fiche and "un signal [À ADAPTER]" in fiche, "verifier : poids de la page donné, avec ses repères à adapter")
        attendre("**Partie ordinaire**" in fiche and "non mesuré" in fiche, "verifier : rappel des parties ordinaires, déclaré non mesuré")
        attendre(fiche.index("sans-texte-1440.png") < fiche.index("ecran-1440@2x.png") and "Avant d'ouvrir une autre capture" in fiche,
                 "verifier : l'image sans le texte vient d'abord, avant de relire la direction")
        attendre("planche.py atelier.png" in fiche and "retiree.html" in fiche, "verifier : garder un signal renvoie à l'atelier, commande donnée")
        attendre("contre-references.png" in fiche and "parcours.py verifier" in fiche,
                 "verifier : planche citée et prochaine commande écrite")
        attendre("mouvement-1440.png" in fiche and "- Mouvement :" in fiche.split("## 6.")[1],
                 "verifier : planche de mouvement citée et ligne de trace du mouvement")
        fiche = (d / "v2" / "parcours.md").read_text(encoding="utf-8")
        attendre(code_ko == 1 and "--in-frame" in fiche.split("## 2.")[0],
                 "verifier : action hors du premier écran, défaut bloquant et code 1")
        attendre("Sans référence fournie" in fiche, "verifier : sans --refs, la fiche demande de regarder des références")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["verifier", str(d / "absente.html")]) == 2, "verifier : page introuvable, code 2")
        (d / "tablette.html").write_text("""<!doctype html><html lang="fr"><meta charset="utf-8"><title>Tablette</title>
<style>body{margin:0;font:16px Arial}.large{width:780px;height:60px;background:#ccc}
@media (max-width:700px){.large{width:300px}}</style><main><h1>Titre</h1><div class="large"></div>
<a id="action" href="#">Agir</a></main></html>""", encoding="utf-8")
        with contextlib.redirect_stdout(io.StringIO()):
            code = parcours.main(["verifier", str(d / "tablette.html"), "--action", "#action", "--sortie", str(d / "v4")])
        fiche = (d / "v4" / "parcours.md").read_text(encoding="utf-8")
        attendre(code == 1 and "Débordement horizontal" in fiche.split("## 2.")[0],
                 "verifier : un débordement présent seulement à 768 px est un défaut bloquant")
        refs_mes = d / "refs-mesurees"
        refs_mes.mkdir()
        (refs_mes / "refs.json").write_text('[{"n": 1, "source": "réf", "mesures": {"hauteur": 4000, "part_media": 60, "sections": 9, "echelle": 3}}]',
                                            encoding="utf-8")
        texte, _ = parcours.mesures_contre_refs(d / "propre.html", refs_mes, 1440, "main")
        attendre("matière codée non comptée" in texte and "construit en code" in texte and "Routes par rôle" not in texte,
                 "contre-références : part d'image nommée honnêtement ; objet de preuve codé, écart d'image qui peut être voulu")
        texte, _ = parcours.mesures_contre_refs(d / "propre.html", refs_mes, 1440)
        attendre("« Routes par rôle »" in texte, "contre-références : sans objet de preuve déclaré, renvoi aux routes de matière par rôle")
        import check_render
        attendre(parcours.hauteur(720) == check_render.hauteur_fenetre(720) == 844 and parcours.hauteur(768) == 900,
                 "fenêtre : même hauteur pour la recette et le parcours, seuil à 768 px")
        with contextlib.redirect_stdout(io.StringIO()):
            code = parcours.main(["critique", str(d / "propre.html"), "--brief", "Une page propre", "--refs", str(refs), "--sortie", str(d / "crit")])
        noms = sorted(x.name for x in (d / "crit" / "images").iterdir())
        consigne = (d / "crit" / "consigne.md").read_text(encoding="utf-8")
        attendre(code == 0 and noms == ["1-sans-texte-1440.png", "2-reduite-1440.png", "3-ecran-1440.png", "4-ecran-390.png",
                                        "5-mouvement.png", "6-contre-references.png"],
                 "critique : images seules, dans l'ordre de lecture, planches de mouvement et contre références comprises")
        attendre("« Une page propre »" in consigne and "ni l'intention" in consigne and not (d / "crit" / ".travail").exists(),
                 "critique : consigne avec la demande, sans direction ni trace ; dossier de travail retiré")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["critique", str(d / "absente.html"), "--brief", "x"]) == 2, "critique : page introuvable, code 2")
        import functools, http.server, threading
        class Silencieux(http.server.SimpleHTTPRequestHandler):
            def log_message(self, *args):  # pas de requêtes de test dans le journal de préparation
                pass
        serveur = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Silencieux, directory=str(d)))
        threading.Thread(target=serveur.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{serveur.server_address[1]}"
        try:
            (d / "bandeau.html").write_text("""<!doctype html><html lang="fr"><meta charset="utf-8"><title>Bandeau</title>
<body style="margin:0;height:3000px"><div style="position:fixed;left:0;right:0;bottom:0;height:260px;background:#222;color:#fff">
Nous utilisons des cookies. <button>Tout accepter</button> <button>Refuser</button></div></body></html>""", encoding="utf-8")
            sites = parcours.capturer_sites([f"{base}/propre.html", f"{base}/absente.html", f"{base}/bandeau.html"], d, 1)
        finally:
            serveur.shutdown()
        attendre(any("page courte" in x for x in sites[0].get("a_regarder", [])) and any("bandeau" in x for x in sites[2].get("a_regarder", []))
                 and not any("page courte" in x for x in sites[2].get("a_regarder", [])),
                 "références : page courte et bandeau de consentement signalés, à regarder avant de s'en servir")
        sites = sites[:2]
        attendre([s["statut"] for s in sites] == ["ok", "refusé (HTTP 404)"] and sites[0]["titre"] == "Propre" and (d / "1-site.png").is_file(),
                 "références : site capturé au premier écran avec son titre ; page refusée notée, sans capture")
        m = sites[0].get("mesures", {})
        attendre((d / "1-site-page.png").is_file() and {"hauteur", "part_media", "sections", "echelle"} <= set(m)
                 and "mesures" not in sites[1],
                 f"références : page entière capturée et mesurée ; rien pour la page refusée ({m})")

    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        for nom in SIGNES:
            (d / f"{nom}.svg").write_text(signe_svg(nom), encoding="utf-8")
        resultats = {}
        for nom in SIGNES:
            with contextlib.redirect_stdout(io.StringIO()):
                code = parcours.main(["identite", str(d / f"{nom}.svg"), "--sortie", str(d / nom)])
            fiche = (d / nom / "identite.md").read_text(encoding="utf-8")
            resultats[nom] = (code, fiche, (d / nom / "planche-identite.png").is_file())
        code, fiche, planche = resultats["propre"]
        attendre(code == 0 and planche and "Aucun signal mesurable" in fiche and "SAVOIR/IDENTITY" in fiche,
                 "identite (navigateur) : signe propre, planche écrite, aucun signal, route citée")
        attendre("**Trait ou vide trop fin**" in resultats["fin"][1] and "**Détail perdu en petit**" in resultats["fin"][1],
                 "identite (navigateur) : traits fins et détail perdu relevés sur le rendu du SVG")
        attendre("**La couleur porte la forme**" in resultats["lumi"][1], "identite (navigateur) : deux couleurs de même luminosité relevées")
        attendre("**Dégradé ou matière**" in resultats["degrade"][1] and "Couleurs nombreuses" not in resultats["degrade"][1],
                 "identite (navigateur) : dégradé SVG relevé comme tel")
        from PIL import Image as _Im
        attendre(_Im.open(d / "propre" / "planche-identite.png").width == 1200 and "NOT-VERIFIED" in fiche,
                 "identite (navigateur) : planche à taille réelle ; reproduction et droits déclarés non vérifiés")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["identite", str(d / "absent.svg")]) == 2, "identite : signe introuvable, code 2")

    # Planches de principes : le générateur (distribution GitHub seulement) réécrit les six planches au format.
    if (HERE / "principes.py").is_file():
        import principes
        with tempfile.TemporaryDirectory() as tmp:
            with contextlib.redirect_stdout(io.StringIO()):
                code = principes.main(["--sortie", tmp])
            from PIL import Image as _Im
            tailles = {p.name: _Im.open(p).size for p in Path(tmp).glob("*.png")}
        attendre(code == 0 and len(tailles) == 6 and set(tailles.values()) == {(1600, 900)}
                 and set(tailles) == {f"{n}.png" for n in principes.PLANCHES},
                 "principes : le générateur réécrit les six planches à 1600 × 900")

    print(f"PARCOURS TESTS {'PASSED' if not echecs else 'FAILED'} — {n} cas")
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main())
