# Design Governance V1.6.1 — art direction and proof for design agents

**Design Governance** is a skill for AI agents (and the people who work with them) that design web pages, screens and visual identities. It asks the agent to choose a real direction before building, to build a complete first proposal, then to look at the actual render, fix the main defect and look again. When work has to be delivered or audited, it keeps track of what was checked — and of what was not.

The full documentation is in French; this page is a short English overview.

> **Status:** V1.6.1, experimental, published on 26 November 2026. Its effect on output quality has **not** been measured yet (`NOT-VERIFIED`); an evaluation on real renders is planned.

## Who it is for

- **Agents** that build user interfaces in code (Claude Code, Codex, Cursor, Gemini CLI, GitHub Copilot…), loaded as a skill.
- **Designers and developers** who pilot such agents and want directed, credible first proposals instead of generic templates.
- Proven on the Web (pages, screens, flows, components, desktop to mobile). Brand identity has its own method but is less proven.

## Install

```bash
npx skills add Palolo875/DESIGN-GOVERNANCE1 --skill design-governance-practice
```

Or clone the package into your agent's skills folder, for example `.claude/skills/design-governance-practice`. Python 3.10+ is enough to read the rules; render checks also need Playwright with Chromium, Pillow, numpy and SciPy. Details: [installation, in French](README.md#installer-la-skill-dans-un-agent).

## How the agent reads

- **The core** (`SKILL.md`, about 32 KB) holds the rules that apply to every request, one line per obligation, and an index of all 85 sections: which signal calls which section.
- **The trunk**: the agent classifies the request, then reads once, in full, the sections its mode always needs.
- **The rest** is read when its signal appears, by its code: `python3 scripts/read_route.py CODE`.
- **The tools** (`scripts/`) capture, measure and compare renders. They never decide for the agent.
- **Without code execution**, the agent reads the files directly; anything that needs a capture or a script is declared not verified, never passed.

A visual summary: [How the agent reads](supports/lecture.md) (in French).

## Limits

- Attractive is not proven, compliant is not successful: the system asks the agent to show that gap and fix the main defect.
- The level depends on the means at hand: figurative subjects (product, place, person) need your images, an open source or a generated image you allow.
- It does not replace creative judgment, user testing or project responsibility.

## License

Code under the [MIT License](LICENSE); texts, cards and images under [CC BY 4.0](LICENSE-CC-BY-4.0.txt); the Manrope font under the SIL Open Font License. To cite: [`CITATION.cff`](CITATION.cff). Changes: [`CHANGELOG.md`](CHANGELOG.md) (in French).
