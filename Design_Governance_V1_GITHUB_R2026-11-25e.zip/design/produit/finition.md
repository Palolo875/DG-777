# Produit — finition

Le craft jugé sur le rendu réel, et ce qui sépare un produit fini d’un rendu générique.

## ACTION/GATE-C — craft sur rendu réel

Gate C évalue la présence de décisions perceptibles et la qualité de leur résolution. En trace complète, il est obligatoire en `DIRECTION`, ciblé au risque craft en `STANDARD`, limité à la zone touchée en `ITER` et `N/A-JUSTIFIED` en `LITE` lorsque le craft n’est pas concerné ; en trace légère, il sert sans verdict, dans la boucle d’édition (fin de cette route).

Une capture réelle est nécessaire pour un jugement C. Sans runtime ou capture, le craft reste `NOT-VERIFIED`.

Gate C décide sur le rendu à partir des observations de la revue créative et, si elle est déclenchée, de la paire B1b (`ACTION/GATE-B — B1b`) pour la décision mise à l’épreuve ; il ne refait pas une seconde revue, ni une seconde procédure de comparaison.

Chaque verdict C précise le périmètre : viewport, état, scène, contenu et élément observé. Pour une finesse insuffisante, utilise les gestes conditionnels de `SAVOIR/STATE`, puis compare les versions au même scope ; une cohérence déclarée ou un geste seulement prévu ne prouve pas la résolution. Lorsque la structure est ouverte, applique sur la même capture les tests perceptifs de `BIBLIOTHEQUE/GATE` (non-généricité, silhouette, grille) ; ils nourrissent C3 et C4 sans verdict propre.

| Critère | Présent si… | Retour ou réserve si… | Geste si absent (route à charger) |
|---|---|---|---|
| **C1 — Stratégie de surface** | Photo, donnée, lumière, illustration, surface, trame d’impression, profondeur ou planéité choisie découle du produit. | Traitement par défaut sans relation observable ; sur une surface `DIRECTION`, aplat gardé sans essai de matière. | Choisis la surface d’après ce que le produit montre (carte des moyens : `SAVOIR/TOOLS/MOYENS`) ; un traitement justifié par la thèse pour les assets moyens ; retire le traitement sans rôle. |
| **C2 — Typographie choisie** | Famille, système existant ou alternative est justifié ; rôles, échelle et fallback servent le contexte. | Choix par défaut non interrogé ou non calibré. | Choisis la famille pour la voix et la donnée à porter (`SAVOIR/TYPE`) ; fixe deux ou trois rôles et une échelle contrastée ; vérifie le fallback au rendu. |
| **C3 — Composition intentionnelle** | Structure de lecture identifiable sert l’action et le rythme. | Empilement uniforme sans décision spatiale. | Recompose dans l’ordre intention → foyer → masse → rythme (`SAVOIR/FRAME/COMPOSITION`) ; nomme le foyer et l’ordre de lecture ; romps la trame modale si elle ne sert pas la tâche (test de trame : `BIBLIOTHEQUE/SELECT`). |
| **C4 — Densité optique** | Espace, masses et regroupements suivent la priorité et l’usage. | Espacement uniforme qui masque les relations. | Regroupe par proximité ; redistribue masses et vides selon la priorité (`SAVOIR/STATE` : masse visuelle, gestion du vide) ; contrôle la silhouette à faible détail. |
| **C5 — Stratégie de profondeur applicable** | Profondeur, lumière ou planéité est cohérente avec le registre et lisible au rendu. | Ombres, bordures ou flous par défaut sans logique. `N/A-JUSTIFIED` si la planéité est intentionnelle et suffisante. | Tiens une seule logique, lumière, élévation ou planéité, sur toute la surface ; retire ombres, bordures et flous sans rôle (`SAVOIR/STATE` : surface). |
| **C6 — Résolution située** | Une difficulté réelle est résolue par microcopie, état, donnée, interaction, asset ou transition pertinente. | Assemblage de composants sans adaptation au cas. | Trouve la difficulté réelle du cas (attente, erreur, donnée, choix) et résous-la par microcopie, état, donnée ou interaction (`SAVOIR/CRAFT/CFT-01` : forme située) ; une erreur se résout jusqu’à la reprise (`SAVOIR/STATE`). |

Chaque verdict C cite l’élément concret observé. Un critère bloquant absent, ou plusieurs signaux faibles convergeant sur le même risque, déclenchent un retour. La correction revient à la direction, à la spec ou au build ; elle n’ajoute pas un effet décoratif terminal.

En trace légère, Gate C sert de contrôle de craft sur la capture, dans la boucle d’édition : un critère absent déclenche son geste, puis une nouvelle capture ; aucun verdict n’est écrit.

---

## ACTION/ANTI-SLOP — conséquence de gate

La matrice canonique motivation/construction appartient à `SAVOIR/CRAFT/CFT-01`. ACTION ne la reproduit pas : il vérifie sa conséquence sur l’artefact. Lorsqu’un motif manque de motivation, de construction ou des deux, la trace nomme l’élément observé, la relation produit/lecture manquante et la sortie : correction, retrait, réserve ou `RETURN`.

Une couleur de marque, une contrainte de contenu ou une construction technique soignée n’immunisent pas un choix contre les autres gates. Les watchlists et tendances restent des aides de jugement dans `SAVOIR/CRAFT` ou la veille ; elles ne deviennent pas des interdits universels.

---

## ACTION/ATELIER-EDITION — opération observable

<!-- noyau:début BOUCLE-ATELIER-LIGNE -->
**Atelier sur capture.** Sur une surface `DIRECTION`, ou dès que la décision visuelle est ouverte, quel que soit le mode, après la première capture, au moins un tour, même en trace légère : lecture sans le texte, au bureau et au premier écran mobile ; test de retrait et d’intensification, où l’élément qui porte l’idée ne part pas, comparés à la version sur une planche ; défaut dominant corrigé et recapturé ; chaque version jugée contre l’esquisse retenue (`captures --version vN --contre ESQUISSE.html`), où l’idée doit se lire aussi vite. Il est requis dans le scope de B1b. Avant de livrer, la passe de finition, par lots, jusqu’à ce que `verifier` ne laisse aucun signal sans correction ni raison. Détail : `ACTION/ATELIER-EDITION`.
<!-- noyau:fin BOUCLE-ATELIER-LIGNE -->

<!-- différé:début BOUCLE-ATELIER -->
**Atelier sur capture (`ACTION/ATELIER-EDITION`).** Sur une surface `DIRECTION`, ou dès que la décision visuelle est ouverte, quel que soit le mode, après la première capture, fais au moins un tour d’atelier, même en trace légère : lecture sans le texte, test de retrait, défaut dominant corrigé et recapturé ; la paire n’est pas exigée en trace. Dans le scope de B1b (surface `DIRECTION` qui accepte avec l’axe V (caractère visuel, `ACTION/STATUS`) positif, en trace complète : `ACTION/GATE-B/B1b`), cet atelier est requis, sauf deux motifs `N/A-JUSTIFIED` : aucune décision principale éditable, ou une paire équivalente encore valide qui couvre la même décision.

Après la première capture, avant de relire la direction déclarée, fais une lecture légère sur l’image sans le texte, au bureau puis au premier écran sur téléphone (`regard.py` la produit à chaque largeur) : nomme en une phrase la catégorie, la marque et le niveau de preuve que la surface semble raconter, puis l’idée qui s’y lit en une seconde. Compare ensuite ce nom à la direction déclarée ; s’ils ne concordent pas, c’est l’idée qui se reprend, pas le nom. Sur téléphone, l’idée doit survivre à la recomposition ; sinon, c’est la version mobile qui se reprend. Si l’idée a besoin d’une consigne ou d’une légende pour se comprendre, c’est un diagramme : la décision à éprouver est celle-là. Fais ensuite le **test de retrait**, en une seule variante au même niveau de finition : retire ensemble les accessoires, tout ce qui n’est pas l’idée (grain, ombre, motif, ornement, marqueur), et compare à la vue ; ce qui ne manque pas part, **sauf l’élément qui porte l’idée** (le « grâce à quoi » de la ligne `VISION`) : il ne se retire pas, et s’il manque à la lecture sans le texte, il revient. Puis corrige le défaut dominant par un geste de `SAVOIR/STATE` et recapture. Chaque version se juge contre l’esquisse retenue, sur la même planche (`parcours.py captures PAGE --version vN --contre ESQUISSE.html`) : si l’idée s’y lit moins vite qu’à l’esquisse, ce qui la portait revient. Fais aussi, toujours, la variante qui **intensifie** l’élément qui porte l’idée, au même niveau de finition : échelle, contraste, position, fond perdu, matière ou cadrage, poussés d’un cran net. Compare les trois sur une planche (`planche.py`) : la version actuelle, le retrait, l’intensification. Garde la plus forte à la vue, et dis pourquoi ; garder l’actuelle reste un résultat valide. L’intensification ne gagne pas parce qu’elle est plus forte, mais parce que l’idée s’y lit mieux, au niveau d’expression déclaré (ligne `NIVEAU`), sans que la tâche y perde.

**Matière observée.** Si la direction déclare une matière du sujet (émail, papier, bois, verre, métal), regarde avant de la coder deux photos réelles (`parcours.py references --polyhaven "texture: …"` ou `--commons`) et suis la recette `matiere` (`parcours.py recette matiere`). À l’atelier, pose la photo et un carré de la matière codée côte à côte, à la même échelle, et réponds : paraît-elle observée ou dessinée ? Dessinée, elle se reprend d’après la photo, ou part au test de retrait.

La trace dit ce que le test de retrait et la correction ont confirmé, modifié ou retiré ; garder l’original quand il résout mieux la décision est un résultat valide.

**Garder se décide à l’atelier.** Un signal ou un marqueur relevé au premier écran (`parcours.py`, `regard.py`) qui n’est pas corrigé se garde par comparaison, pas par une phrase : il passe le test de retrait, comparé à la vue. Les signaux gardés passent ensemble dans la même variante ; dès deux marqueurs gardés, palette et typographie s’éprouvent comme un ensemble. Pour un marqueur typographique, la variante essaie une autre voix qui a du caractère, pas une voix neutre facile à battre.

**Regard séparé.** Si l’environnement permet un second agent, fais critiquer la version gardée sur images seules par un agent qui ne lit ni la direction ni la trace : `python3 scripts/parcours.py critique page.html --brief "…"` prépare les images et la consigne. Juge la critique sur capture : applique ce qu’elle confirme, écarte avec sa raison ce qu’elle contredit. Facultatif : sans second agent, la revue sur capture (`SAVOIR/CRAFT/CFT-00`) en tient lieu.

**Passe de finition.** Sur une surface `DIRECTION`, ou dès que la décision visuelle est ouverte, avant de livrer la version gardée, fais une passe sur le premier écran, l’objet de preuve, puis chaque section suivante, même sans symptôme : parcours les gestes de finition de `SAVOIR/STATE` (rayons emboîtés, gris hiérarchisés, un accent par rôle, chiffres alignés, états vrais, alignement optique, icônes d’une seule famille, recadrage, texte final, parties ordinaires : une propriété de la direction, pas un motif) et corrige ce que la capture agrandie montre, par lots, du plus visible au plus fin : premier écran à la vue, mobile, états et contraste, détail ; `captures --version` entre deux lots. Un défaut connu dont la correction ne change pas la direction se corrige, il ne se déclare pas. La passe finit quand `verifier` ne laisse aucun signal sans correction ni raison gardée ; un relevé vide ne prouve pas la réussite : présence, caractère et choix se jugent sur capture. Elle n’ajoute aucune décision.
<!-- différé:fin BOUCLE-ATELIER -->
