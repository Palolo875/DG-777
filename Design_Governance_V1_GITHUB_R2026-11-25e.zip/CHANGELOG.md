# Journal des changements

Les changements visibles de Design Governance, par version publique. Le détail de ce que contient la version en cours est dans [la fiche de version](maintenance/versions.md) ; ce qui est vérifié, et ce qui ne l’est pas, aussi.

## V1.3.0 — 25 novembre 2026

Révision interne `R2026-11-25e`. Cette version vise des idées plus propres au sujet et une exécution moins tâtonnante. Aucune mesure sur des rendus ne l'accompagne encore.

### Ajouté

- **Cinq recettes de procédé**, tirées de ce que les rendus ont dû coder de mémoire : matière, police variable animée, réponse par courriel, ajout à l'agenda, objet mis en scène (`parcours.py recette`). Chacune règle un comportement ou un procédé, jamais une apparence.
- **La matière observée.** Avant de coder une matière, l'agent en regarde deux photos réelles ; à l'atelier, il les compare au rendu, à la même échelle : paraît-elle observée ou dessinée ?
- **L'idée tirée d'un fait de deuxième rang.** L'inventaire du sujet se classe du plus évident au moins évident ; les esquisses viennent d'un fait de deuxième rang ou au-delà, sauf si le premier gagne sur la planche. La trace dit de quel rang vient l'idée gardée ; `parcours.py trace` le relève.
- **La modale défendue.** Avant d'être écartée, la modale est défendue en une ligne (ce qu'elle ferait de mieux pour ce sujet) et esquissée sous cet angle.

### Changé

- Les probabilités des directions restent un ordre de grandeur pour diversifier ; ce qui se vérifie, c'est le rang du fait.

## V1.2.0 — 25 novembre 2026

Révision interne `R2026-11-25c`. Cette version vise des rendus plus affirmés : l'agent est aidé à **voir** son travail et à **oser** l'idée, sans rien retirer du plancher. Aucune mesure sur des rendus ne l'accompagne encore.

### Ajouté

- **Voir.** Chaque version se compare à l'esquisse retenue, sur une même planche (`parcours.py captures --version vN --contre ESQUISSE.html`) : l'idée doit s'y lire aussi vite. La lecture sans le texte se fait aussi au premier écran sur téléphone. Au test de retrait, l'élément qui porte l'idée ne part pas.
- **Oser.** L'atelier fait toujours deux variantes, l'une qui retire, l'autre qui intensifie l'élément porteur, comparées à la version sur une planche. La direction déclare l'expression attendue : sobre, affirmée ou expressive. Au noyau : « Le plancher protège ; il ne suffit pas. Le geste qui porte l'idée se pousse jusqu'au bout. »
- **Quatre signaux de finition** : texte collé au bord de la fenêtre ; élément graphique ou bord de champ sous 3:1 ; texte illisible pendant le mouvement d'entrée ; commande personnalisée sans effet au clavier.
- **Une préparation deux fois plus rapide** pour qui maintient le système (environ 8 minutes au lieu de 15), et un mode rapide d'environ 90 secondes pendant le travail (`validate_all.py --rapide`).

### Changé

- Le noyau peut atteindre 33 000 octets (31 500 auparavant) pour accueillir ces règles.

## V1.1.1 — 25 novembre 2026

Révision interne `R2026-11-15y`. Correctif issu d’une première évaluation sur deux rendus jugés à l’aveugle.

### Corrigé

- **L’atelier sur capture vaut dans tous les modes** dès que la décision visuelle est ouverte : lecture sans le texte, test de retrait, défaut dominant corrigé, puis passe de finition. Depuis la V1.1.0, il n’était dit que pour le mode direction ; un rendu en mode standard s’en est passé et en est sorti trop dense.

### Mesuré

- Sur deux objets refaits avec la V1.1.0 et comparés à la révision précédente : environ 29 % de tours et 32 % de lecture en moins. Qualité : une paire gagnée, une perdue ; rien n’est conclu sur ce point.

## V1.1.0 — 22 novembre 2026

Révision interne `R2026-11-15x`. Aucune mesure comparative de qualité n’accompagne cette version : l’évaluation sur des rendus reste à faire.

### Ajouté

- **Un noyau-index.** La skill porte les règles de chaque demande, une ligne pour chaque obligation, et l’index de toutes les sections (85) : tel signal, telle section à lire. Le détail des procédures reste servi par sa section, lue au moment utile.
- **Un passage « Sans outils ».** Sans exécution de code, l’agent lit les fichiers directement ; ce qui demande une capture ou un script est déclaré non vérifié, jamais réussi. Le guide de niveau 1 le dit aussi aux personnes.
- **Des outils plus sobres** : une image par version pendant la boucle (`parcours.py captures --version`), une vérification qui ne répète que ce qui a changé, un démarrage en une commande (`parcours.py chantier`), un sommaire en tête du tronc d’un mode.
- **Une référence générée** depuis les sources : toutes les commandes et leurs options, toutes les sections et leur sujet ([`guides/reference.md`](guides/reference.md)).
- **Une quatrième carte**, « Comment l’agent lit » ([`supports/lecture.md`](supports/lecture.md)).
- **Les fichiers du projet** : licences, ce journal, citation, guide de contribution, présentation en anglais.

### Changé

- Le noyau passe de 45 876 à 31 057 octets ; un run en mode direction lit d’office environ 16 % de texte en moins.
- Les pages d’entrée parlent en mots, sans codes internes, et toute page est à trois clics au plus du README.

### Contrôles ajoutés

- Chaque obligation reste visible au noyau, en bloc ou en ligne qui nomme sa section ; l’index cite chaque section ; aucune consigne du noyau ne suppose un second agent.
- La référence générée reste identique à ses sources ; aucune ligne des cartes ne déborde de son encadré.
- Aucun nom tiré des essais du système (brief, lieu, titre) n’entre dans le paquet.

## V1.0.0

Première version publiée. Son contenu est décrit dans [la fiche de version](maintenance/versions.md) ; les révisions internes qui l’ont suivie sont reprises dans la V1.1.0.
