#!/usr/bin/env python3
"""Orchestre les contrôles de cohérence, de projection et de distribution."""
from __future__ import annotations

import argparse
import hashlib
import os
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True  # les imports entre outils n’écrivent rien dans le paquet
sys.path.insert(0, str(ROOT / "gouvernance" / "outils"))
from validate_run_card import FIXTURE_TABLE  # noqa: E402  une seule liste des fiches et de leur motif
# Posée pour le second build seulement : il ne sert qu’à comparer les archives, les contrôles ont déjà passé sur le même contenu.
REPRODUCTIBILITE = "DG_BUILD_REPRODUCTIBILITE"

def run(command: list[str]) -> None:
    print("+", " ".join(command))
    subprocess.run(command, cwd=ROOT, check=True)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def expect_failure(command: list[str], label: str, expected_message: str) -> None:
    """Vérifie qu’un scénario d’entrée invalide échoue réellement, et pour le motif attendu."""
    target = next((Path(part) for part in command if part.endswith(".json")), None)
    if target is not None and not target.is_absolute():
        target = ROOT / target  # chemins résolus depuis ROOT, jamais depuis le dossier courant
    if target is not None and not target.is_file() and label not in {"fichier absent", "JSON malformé"}:
        raise SystemExit(f"CLI REGRESSION FAILED — {label} : fixture absente : {target}")
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    if result.returncode == 0:
        output = (result.stdout + result.stderr).strip()
        raise SystemExit(f"CLI REGRESSION FAILED — {label} a réussi à tort : {output}")
    output = result.stdout + result.stderr
    if "Traceback (most recent call last)" in output:
        raise SystemExit(f"CLI REGRESSION FAILED — {label} a échoué par exception non gouvernée")
    if expected_message not in output:
        raise SystemExit(f"CLI REGRESSION FAILED — {label} a échoué pour un autre motif : attendu {expected_message!r}")
    print(f"+ expected failure ({label})")

def check_craft_regressions() -> None:
    """Exerce les défauts réellement corrigés, sans modifier les sources livrées.

    Ces mutations contrôlent l'activation et ses garde-fous documentaires ;
    elles ne mesurent ni le goût ni l'effet perceptuel d'un geste.
    """
    sys.path.insert(0, str(ROOT / "scripts"))
    import validate_reading_map as reading_map

    baseline = reading_map.load_texts()
    if not reading_map.lcf_46(baseline):
        raise SystemExit("CRAFT REGRESSION FAILED — LCF-46 baseline invalide")
    for line in (
        "Le détourage porte un halo clair sur le fond réel.",
        "Comparer la séparation du bord sans halo.",
    ):
        case = dict(baseline)
        case["S"] += "\n" + line
        if not reading_map.lcf_46(case):
            raise SystemExit("CRAFT REGRESSION FAILED — défaut de production confondu avec une vague")
    for line in ("Ajouter des halos décoratifs à la scène.", "Des halos lumineux entourent les cartes.",
                 "Un halo violet derrière le titre."):
        case = dict(baseline)
        case["S"] += "\n" + line + "\n"
        if reading_map.lcf_46(case):
            raise SystemExit("CRAFT REGRESSION FAILED — marqueur de vague non daté accepté : " + line)

    with tempfile.TemporaryDirectory(prefix="design-governance-craft-") as temp_dir:
        for name, change, expected in (
            (
                "wrong_owner",
                # Tous les renvois de CFT-00 vers SAVOIR/STATE passent au mauvais propriétaire.
                lambda s: s.replace("vocabulaire perceptuel de `SAVOIR/STATE`",
                                    "vocabulaire perceptuel de `SAVOIR/CRAFT`", 1)
                           .replace("le jugement visuel situé (`SAVOIR/STATE`)", "le jugement visuel situé (`SAVOIR/CRAFT`)", 1),
                "renvoi SAVOIR/CRAFT/CFT-00 → FIN-01",
            ),
            (
                "closed_gestures",
                lambda s: s.replace("Les gestes proposés sont des points de départ, pas une liste fermée",
                                    "Le geste retenu est l’un de ses diffs", 1),
                "vocabulaire retiré",
            ),
            (
                "missing_activation",
                lambda s: s.replace("<!-- concept:FIN-01 -->", "", 1),
                "FIN-01",
            ),
        ):
            case_root = Path(temp_dir) / name
            shutil.copytree(ROOT, case_root, ignore=shutil.ignore_patterns(
                ".git", ".build", "dist", "__pycache__", "*.zip"))
            # Le texte visé est cherché dans les fichiers de règles, où qu'il soit rangé.
            for candidate in reading_map.rr.regles():
                source = case_root / candidate.relative_to(ROOT)
                before = source.read_text(encoding="utf-8")
                after = change(before)
                if before != after:
                    break
            else:
                raise SystemExit(f"CRAFT REGRESSION FAILED — mutation {name} non exercée")
            source.write_text(after, encoding="utf-8")
            subprocess.run([sys.executable, "scripts/build_core.py"], cwd=case_root,
                           check=True, capture_output=True, text=True)
            result = subprocess.run([sys.executable, "scripts/validate_structure.py"],
                                    cwd=case_root, capture_output=True, text=True)
            output = result.stdout + result.stderr
            if result.returncode == 0 or expected not in output or "Traceback" in output:
                raise SystemExit(f"CRAFT REGRESSION FAILED — mutation {name} non détectée pour le motif attendu")
    print("CRAFT REGRESSIONS PASSED — 2 cas de halo de production admis, 3 marqueurs de vague non datés et 3 mutations d’activation rejetés")

def check_move_regression() -> None:
    """Déplacer une section revient à déplacer son texte : aucun registre à tenir.

    Sur une copie, la route SAVOIR/TYPE (avec un bloc du noyau) part dans un nouveau fichier, ajouté au seul inventaire
    des fichiers livrés. Sans rien d'autre : le lecteur la sert depuis son nouveau fichier, la skill compilée reste
    identique et la validation de structure reste verte ; seuls les liens des textes humains qui visaient l'ancien
    fichier sont signalés, chacun nommé. Ces liens suivis, tout est vert. Deux témoins doivent échouer : le même code
    porté par deux titres, et une section déplacée sans son code.
    """
    sys.path.insert(0, str(ROOT / "scripts"))
    import read_route as rr
    import build_core as bc
    current = rr.resolve("SAVOIR/TYPE")[0]  # le fichier qui porte aujourd'hui la route, où qu'il soit
    rel = current.relative_to(ROOT).as_posix()
    skill_rel = bc.SKILL.relative_to(ROOT)
    layout = "github" if (ROOT / "scripts/build_distributions.sh").is_file() else "local"  # export Local : sans les outils de préparation
    target = "design/savoir/typographie-essai.md"
    with tempfile.TemporaryDirectory(prefix="design-governance-move-") as temp_dir:
        for case_name in ("deplacement", "liens-suivis", "doublon", "sans-code"):
            case = Path(temp_dir) / case_name
            shutil.copytree(ROOT, case, ignore=shutil.ignore_patterns(".git", ".build", "dist", "__pycache__", "*.zip"))
            text = (case / rel).read_text(encoding="utf-8")
            text = "\n" + text if not text.startswith("\n") else text
            start = text.find("\n# SAVOIR/TYPE")
            following = text.find("\n# ", start + 1)
            end = following if following >= 0 else len(text) - 1
            if start < 0:
                raise SystemExit("MOVE REGRESSION FAILED — section SAVOIR/TYPE introuvable")
            moved = "# Savoir — typographie (essai)\n\nLa typographie, rangée dans un autre fichier.\n\n" + text[start + 1:end + 1]
            if case_name == "sans-code":  # la section perd son code : elle n'est plus une route
                moved = moved.replace("# SAVOIR/TYPE — ", "# ", 1)
            (case / target).write_text(moved, encoding="utf-8")
            # Comme le dit la procédure (« Manifeste »), le fichier neuf entre aussi dans le README de son dossier (garde DOC-02).
            index = case / Path(target).parent / "README.md"
            index.write_text(index.read_text(encoding="utf-8").rstrip("\n") + f"\n\n- [`{Path(target).name}`]({Path(target).name})\n", encoding="utf-8")
            remaining = text[:start + 1] + text[end + 1:]
            if case_name == "doublon":  # le même code porté par deux titres doit être refusé
                remaining += "\n# SAVOIR/TYPE — doublon\n\nTexte.\n"
            (case / rel).write_text(remaining.lstrip("\n"), encoding="utf-8")
            if case_name == "liens-suivis":  # les liens vers les titres déplacés suivent la section
                moved_lines = moved.splitlines()
                anchors = {rr.ancre(moved_lines, i) for i, _, _ in rr.headings(moved_lines)}
                old_name, new_name = Path(rel).name, Path(target).name
                for doc in case.rglob("*.md"):
                    body = doc.read_text(encoding="utf-8")
                    fixed = body
                    for anchor in anchors:
                        fixed = fixed.replace(f"{old_name}#{anchor})", f"{new_name}#{anchor})")
                    if fixed != body:
                        doc.write_text(fixed, encoding="utf-8")
            manifest = case / "scripts/package_manifest.json"
            data = json.loads(manifest.read_text(encoding="utf-8"))
            data[layout].append(target)
            manifest.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            skill_before = (ROOT / skill_rel).read_bytes()
            steps = [[sys.executable, "scripts/build_core.py", "--check"],
                     [sys.executable, "scripts/validate_structure.py"],
                     [sys.executable, "scripts/validate_reading_map.py"],
                     [sys.executable, "scripts/validate_design_governance.py"],
                     [sys.executable, "scripts/read_route.py", "SAVOIR/TYPE"]]
            results = [subprocess.run(s, cwd=case, capture_output=True, text=True) for s in steps]
            failed = [" ".join(s[1:]) for s, r in zip(steps, results) if r.returncode != 0 or "Traceback" in r.stdout + r.stderr]
            if any("Traceback" in r.stdout + r.stderr for r in results):
                raise SystemExit(f"MOVE REGRESSION FAILED — exception non gouvernée ({case_name})")
            if case_name == "doublon":
                if "scripts/validate_reading_map.py" not in failed or "scripts/read_route.py SAVOIR/TYPE" not in failed:
                    raise SystemExit("MOVE REGRESSION FAILED — un code porté par deux titres n'est pas refusé")
            elif case_name == "sans-code":
                if not failed:
                    raise SystemExit("MOVE REGRESSION FAILED — une section déplacée sans son code passe inaperçue")
            elif case_name == "deplacement":
                kept = {"scripts/build_core.py --check", "scripts/validate_structure.py", "scripts/read_route.py SAVOIR/TYPE"}
                if kept & set(failed):
                    raise SystemExit(f"MOVE REGRESSION FAILED — le déplacement seul casse : {', '.join(sorted(kept & set(failed)))}")
                if f"OWNER: {target}" not in results[-1].stdout:
                    raise SystemExit("MOVE REGRESSION FAILED — SAVOIR/TYPE n'est pas servie depuis son nouveau fichier")
                reports = [line for s, r in zip(steps, results) if " ".join(s[1:]) in failed
                           for line in (r.stdout + r.stderr).splitlines() if line.startswith("- ")]
                if not reports or not all(Path(rel).name in line for line in reports):
                    raise SystemExit("MOVE REGRESSION FAILED — après déplacement, un écart autre qu'un lien vers l'ancien fichier : "
                                     + " | ".join(reports[:3]))
            else:
                if failed:
                    detail = " | ".join((r.stdout + r.stderr).strip().splitlines()[-1][:200] for s, r in zip(steps, results)
                                        if " ".join(s[1:]) in failed)
                    raise SystemExit(f"MOVE REGRESSION FAILED — après déplacement : {', '.join(failed)} ({detail})")
                if f"OWNER: {target}" not in results[-1].stdout:
                    raise SystemExit("MOVE REGRESSION FAILED — SAVOIR/TYPE n'est pas servie depuis son nouveau fichier")
                if (case / skill_rel).read_bytes() != skill_before:
                    raise SystemExit("MOVE REGRESSION FAILED — la skill a changé")
    print("MOVE REGRESSION PASSED — route déplacée avec son bloc de noyau, sans registre : lecteur, noyau et structure la "
          "retrouvent, les liens vers l'ancien fichier sont nommés, puis tout est vert quand ils suivent ; un code porté par "
          "deux titres et une section sans son code sont refusés")


def check_supports_render(browser: list[str]) -> None:
    """Les trois cartes du système passent la recette de rendu du paquet : le système tient sa propre règle."""
    pages = [ROOT / "supports" / f"{nom}.html" for nom in ("index", "parcours", "boucle")]
    if "--skip-browser" in browser:
        print("SUPPORTS RENDER NOT-VERIFIED — navigateur écarté (--skip-browser)")
        return
    try:
        import playwright  # noqa: F401
    except ImportError:
        if "--require-browser" in browser:
            raise SystemExit("SUPPORTS RENDER FAILED — navigateur exigé, Playwright absent")
        print("SUPPORTS RENDER NOT-VERIFIED — Playwright absent")
        return
    for page in pages:
        result = subprocess.run([sys.executable, "scripts/check_render.py", str(page)], cwd=ROOT, capture_output=True, text=True)
        if result.returncode != 0 or "[RETURN" in result.stdout:
            defauts = [l.strip() for l in result.stdout.splitlines() if l.startswith("[RETURN")]
            raise SystemExit(f"SUPPORTS RENDER FAILED — {page.name} : " + (" ; ".join(defauts) or result.stderr.strip()[-300:]))
    print("SUPPORTS RENDER PASSED — trois cartes sans défaut bloquant à 390, 768 et 1440 px")


def build_outputs() -> dict[str, tuple[int, int]]:
    """Empreinte (date, taille) des sorties du build : dist/, .build/ et archives à la racine."""
    paths = [p for d in ("dist", ".build") for p in (ROOT / d).rglob("*") if p.is_file()]
    paths += sorted(ROOT.glob("Design_Governance_V1_*.zip"))
    return {p.relative_to(ROOT).as_posix(): (p.stat().st_mtime_ns, p.stat().st_size) for p in paths}

def main() -> int:
    parser = argparse.ArgumentParser(description="Contrôler le package et ses distributions ; les tests navigateur restent explicitement non vérifiés s’ils sont indisponibles.")
    parser.add_argument("--require-browser", action="store_true", help="exiger l’exécution des tests navigateur, sinon échouer")
    parser.add_argument("--skip-browser", action="store_true", help="ne pas lancer les tests navigateur (déclarés NOT-VERIFIED) ; sert à la validation de l’export Local pendant le build, dont le code a déjà été testé dans le navigateur")
    parser.add_argument("--lecture-seule", action="store_true", help="tout contrôler sans construire : ni dist/ ni archives ne sont écrits ; build et reproductibilité restent non vérifiés")
    args = parser.parse_args()
    if args.skip_browser and args.require_browser:
        parser.error("--skip-browser et --require-browser sont incompatibles")
    browser = ["--require-browser"] if args.require_browser else ["--skip-browser"] if args.skip_browser else []
    before = build_outputs() if args.lecture_seule else None
    scripts = sorted(p.relative_to(ROOT).as_posix() for d in ("scripts", "gouvernance/outils") for p in (ROOT / d).glob("*.py"))
    run([sys.executable, "-m", "py_compile", *scripts])
    run([sys.executable, "scripts/build_core.py", "--check"])
    run([sys.executable, "scripts/validate_design_governance.py"])
    run([sys.executable, "gouvernance/outils/validate_run_card.py"])
    run([sys.executable, "gouvernance/outils/validate_contracts.py"])
    run([sys.executable, "scripts/validate_reading_map.py"])
    run([sys.executable, "scripts/validate_structure.py"])
    run([sys.executable, "scripts/validate_supports.py"])
    check_craft_regressions()
    check_move_regression()
    run([sys.executable, "scripts/test_core_budget.py"])
    run([sys.executable, "scripts/test_read_route.py"])
    run([sys.executable, "scripts/test_journal_mobilisation.py"])
    run([sys.executable, "scripts/test_audit_regressions.py"])
    if (ROOT / "scripts/test_preparer_livraison.py").is_file():
        run([sys.executable, "scripts/test_preparer_livraison.py"])
    run([sys.executable, "scripts/test_check_render.py", *browser])
    run([sys.executable, "scripts/test_regard.py", *browser])
    run([sys.executable, "scripts/test_parcours.py", *browser])
    check_supports_render(browser)
    run([sys.executable, "scripts/read_route.py", "DIRECTION/START"])
    found = subprocess.run([sys.executable, "scripts/read_route.py", "--trouver", "Cohérence de rayon"], cwd=ROOT, capture_output=True, text=True)
    if found.returncode != 0 or "SAVOIR/STATE" not in found.stdout:
        raise SystemExit("FINDABILITY FAILED — « Cohérence de rayon » ne mène plus à SAVOIR/STATE")
    print("FINDABILITY PASSED — read_route --trouver relie un terme à sa route")
    expect_failure(
        [sys.executable, "scripts/read_route.py", "DIRECTION/UNKNOWN"],
        "locator inconnu",
        "locator inconnu : DIRECTION/UNKNOWN",
    )
    run([sys.executable, "gouvernance/outils/validate_contracts.py", "gouvernance/schemas/examples/domain_frame.example.json"])
    run([sys.executable, "gouvernance/outils/validate_run_card.py", "gouvernance/schemas/run_card.example.json"])
    for fixture, motif in sorted(FIXTURE_TABLE.items()):  # chaque fiche par la ligne de commande, depuis la table du validateur
        command = [sys.executable, "gouvernance/outils/validate_run_card.py", f"gouvernance/schemas/fixtures/{fixture}"]
        if motif is None:
            run(command)
        else:
            expect_failure(command, fixture, motif)
    print(f"CLI FIXTURES PASSED — {len(FIXTURE_TABLE)} fiches : {sum(m is None for m in FIXTURE_TABLE.values())} valides acceptées, "
          f"{sum(m is not None for m in FIXTURE_TABLE.values())} invalides refusées pour leur motif")
    with tempfile.TemporaryDirectory(prefix="design-governance-cli-") as temp_dir:
        temp = Path(temp_dir)
        strict_card = temp / "strict_card.json"
        strict_card.write_text((ROOT / "gouvernance/schemas/run_card.example.json").read_text(encoding="utf-8").replace("chemin-ou-url-local", (ROOT / "gouvernance/schemas/run_card.example.json").as_posix()).replace("ticket-ou-chemin-de-run", (ROOT / "gouvernance/schemas/run_card.example.json").as_posix()), encoding="utf-8")
        (temp / "captures").mkdir()
        (temp / "captures/premiere-scene-v1.png").write_bytes(b"")
        expect_failure(
            [sys.executable, "gouvernance/outils/validate_run_card.py", "--strict", str(strict_card)],
            "strict capture B1b absente",
            "strict : capture B1b après local absent",
        )
        (temp / "captures/premiere-scene-v1-sans-objet.png").write_bytes(b"")
        run([sys.executable, "gouvernance/outils/validate_run_card.py", "--strict", str(strict_card)])
        expect_failure(
            [sys.executable, "gouvernance/outils/validate_run_card.py", "--strict", "gouvernance/schemas/run_card.example.json"],
            "strict placeholder",
            "strict : placeholder",
        )
        malformed = temp / "malformed.json"
        malformed.write_text('{"run_card":', encoding="utf-8")
        expect_failure(
            [sys.executable, "gouvernance/outils/validate_run_card.py", str(malformed)],
            "JSON malformé",
            "lecture JSON impossible",
        )
        expect_failure(
            [sys.executable, "gouvernance/outils/validate_run_card.py", str(temp / "missing.json")],
            "fichier absent",
            "lecture JSON impossible",
        )
    if args.lecture_seule:
        if build_outputs() != before:
            raise SystemExit("READ-ONLY FAILED — un contrôle a écrit dans dist/, .build/ ou les archives")
        print("READ-ONLY VALIDATION PASSED — contrôles exécutés sans écrire ; build et reproductibilité NOT-VERIFIED (relancer sans --lecture-seule)")
        return 0
    build_script = ROOT / "scripts/build_distributions.sh"
    if not build_script.is_file():
        print("LOCAL VALIDATION PASSED — contrôles documentaires, RUN_CARD et CLI ; build et reproductibilité hors périmètre de l’export Local")
        return 0
    run(["bash", "scripts/build_distributions.sh"])
    github = ROOT / "Design_Governance_V1_GITHUB.zip"
    local = ROOT / "Design_Governance_V1_LOCAL.zip"
    first = (sha256(github), sha256(local))
    print(f"+ {REPRODUCTIBILITE}=1 bash scripts/build_distributions.sh   (second build : comparaison des archives seulement)")
    subprocess.run(["bash", "scripts/build_distributions.sh"], cwd=ROOT, check=True, env={**os.environ, REPRODUCTIBILITE: "1"})
    second = (sha256(github), sha256(local))
    if first != second:
        raise SystemExit("REPRODUCIBILITY FAILED — les archives diffèrent entre deux builds")
    print("FULL VALIDATION PASSED — package, RUN_CARD, build et reproductibilité")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
