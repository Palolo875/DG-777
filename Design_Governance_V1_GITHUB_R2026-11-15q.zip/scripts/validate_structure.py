#!/usr/bin/env python3
"""Validateur de structure : gardes de propriété « une chose, un lieu ».

Gardes :
  1. CONCEPTS — un concept protégé est repéré par une balise invisible `<!-- concept:ID -->` placée juste
     avant sa définition. La balise existe une seule fois, dans une route de sa famille propriétaire (le code de la
     route qui la contient), suivie d'un bloc non vide (au moins 12 mots) ; toute balise hors registre est refusée.
  2. RENVOIS — une route qui dépend d'un concept cite un locator dont le bloc servi contient ce concept
     (atteignabilité en un saut).
  3. VOCABULAIRE RETIRÉ — un terme remplacé par décision n'apparaît plus dans le paquet (l'historique vit hors du paquet).
  4. FIDÉLITÉ DES RÉSUMÉS — tout lieu qui résume une règle en garde la condition canonique.
  5. GLOSSAIRE — chaque terme du vocabulaire de fabrication a sa ligne dans le glossaire (`guides/glossaire.md`).
  6. LIGNES DE TABLE UNIQUES — dans un même fichier, deux lignes de table d'au moins 8 mots ne sont pas identiques.
  7. REGISTRE — les textes pour les personnes (guides, README) vouvoient : tout pronom de la deuxième personne
     du singulier (« tu », « toi », « tes », « t’ ») est refusé hors code (garde générale, VOU-01). Le guide
     opérateur garde en plus une liste close de tutoiements impératifs, que le pronom ne révèle pas.
  8. NOYAU — les blocs `<!-- noyau:début ID -->` / `<!-- noyau:fin ID -->` (compilés) et `<!-- différé:… -->` (servis par
     leur route) sont appariés, uniques et placés dans une route ; la balise suit le registre de `scripts/build_core.py` ;
     la section compilée de la skill est identique à sa compilation.
  9. CHARGEMENT — une seule table de chargement par mode (`DIRECTION/CHARGE`, sa ligne servie à la demande) ;
     les façades y renvoient ; la ligne `DIRECTION` garde le build et l'ordre cible → premier objet ;
     Gate B n'y est chargée qu'en trace complète.
     Les tables qui associent un signal à une route ne sont pas couvertes par cette garde.
 10. ORDRE — le rôle ouvre le noyau compilé et la posture le suit ; leurs blocs vivent dans une route DIRECTION (ORD-01).
 11. CHOIX CONTEXTUELS (garde bornée) — refuse le retour des formulations universelles retirées et les impératifs
     universels explicites (« toujours », « à tous les »…) sur un traitement ou une famille unique ; accepte un choix situé.
 12. LOCATORS DU VALIDATEUR — un message de `validate_run_card.py` cite un lieu nommé, jamais un numéro de ligne.
 13. ENTRÉE HUMAINE — une seule entrée balisée (niveau 1 des guides, lié depuis le README), quatre questions,
     aucun mode demandé, vouvoiement ; une seule constitution minimale (ENT-01, CST-01).
 14. CARTES — une seule section « Combinaisons par résultat recherché », au niveau 2 des guides (MAP-01).
 15. (retirée avec le préambule de BIBLIOTHEQUE.)
 16. EN-TÊTE DE LA SKILL — métadonnées `name` et `description` lisibles en YAML : valeur citée dès qu'elle porte « : » ou serait lue comme nul, booléen, nombre ou date (SKL-01).
 17. DÉCLENCHEUR UI/UX — `CHARGE` appelle `ACTION/UI-UX-REALITY` en STANDARD et DIRECTION avant fabrication, pas en LITE (UIX-01).
 18. FAÇADES — trace légère et proposition dans les guides, glossaire et carte ; exemple hors domaine de référence ; liens vers « Commencer » (FAC-01).
 19. SERVICE PAR UNE ROUTE — toute ligne d'un fichier de règles est servie par une route ou compilée dans le noyau, sauf
     l'en-tête du fichier et les zones `orientation:` destinées aux personnes (ATT-01). Les sections de maintenance
     (`maintenance/`) se lisent par leur fichier. Servie ne veut pas dire chargée par un mode ni lue : la lecture
     effective n'est pas contrôlée ici (elle s'observe par le journal de mobilisation).
 20. PLANCHERS — chaque obligation étiquetée `[REQUIS PAR LE MODULE — scope]` d'une source normative a un plancher
     inscrit au registre `PLANCHERS` : un bloc compilé dans le noyau, ou une route présente dans le tronc des modes visés.
     Seules les obligations étiquetées sont couvertes ; une obligation non étiquetée n'a pas de plancher garanti.
     Une obligation absente du registre, un plancher perdu ou une entrée sans obligation font échouer (REQ-01).
 21. TABLE DE SIGNAUX — une seule table signal → route, celle du noyau dans `DIRECTION/CHARGE` : toute autre table dont
     l'en-tête associe un signal, une situation, une question ou un déclencheur à une route est refusée ; une table de
     renvoi local (colonne « route à charger », « route approfondie », « savoir à approfondir ») doit être déclarée,
     avec sa raison, dans `RENVOIS_LOCAUX` (SIG-01).
 22. ACCORD — `DIRECTION/ASSET-ROUTE` dit que toute génération, ancre comprise, attend l'accord de la personne (ACC-01).
 23. REGISTRE — chaque dimension du registre nommée au noyau a sa ligne dans la taxonomie de `SAVOIR/STYLE`, reliée à des
     axes existants de `SAVOIR/CRAFT/CFT-02` (REG-01).
 24. LISIBILITÉ — dans les textes pour les personnes, une cellule de table tient en 500 signes visibles et un paragraphe
     en 900, seuils `[À ADAPTER]` (LIS-01).
 25. LANGUE — dans ces mêmes textes, aucun mot de la liste close des mots anglais remplacés ; chaque mot anglais gardé
     (run, skill, brief, build, craft) a sa ligne au glossaire (LAN-01).

Les gardes 1 à 18 protègent des propriétés et des formulations connues : ce sont des listes closes, sauf le pronom de
la garde 7, général. Les gardes 19 à 21 vérifient qu'une règle est servie par une route ou compilée dans le noyau,
qu'une obligation étiquetée a son plancher (noyau ou tronc) et qu'un signal a une seule table ; aucune ne contrôle
la lecture effective.

Une reformulation qui garde la formulation protégée ne casse pas ces gardes ; une suppression, une copie, un retour du
vocabulaire retiré ou une reformulation qui perd la formulation protégée les cassent. Un déplacement d'une section avec
son titre les garde, sans rien mettre à jour : le lecteur la retrouve par son code. `scripts/read_route.py` retire les
balises à la lecture.

Usage : python3 scripts/validate_structure.py
"""
from __future__ import annotations

import json
import re
import sys
sys.dont_write_bytecode = True  # les imports entre outils n’écrivent rien dans le paquet
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import read_route as rr  # noqa: E402
import build_core as bc  # noqa: E402

SKILL_DIR = ROOT  # le paquet est la skill : SKILL.md à la racine, références dans references/
MARKER = re.compile(r"^\s*<!-- concept:([A-Z0-9][A-Z0-9\-]*) -->\s*$")
LOCATOR = re.compile(r"`((?:DIRECTION|ACTION|SAVOIR|BIBLIOTHEQUE)/[A-Z0-9_\-]+(?:/[A-Z0-9_\-]+)?)`")
MIN_WORDS = 12

# 1. Registre des concepts protégés : identifiant, famille propriétaire, propriété.
CONCEPTS: list[tuple[str, str, str]] = [
    ("HON-01", "DIRECTION", "vérité de scène : exemples marqués, divulgation en langage produit"),
    ("HON-02", "SAVOIR", "aucun faux asset présenté comme authentique"),
    ("HON-03", "DIRECTION", "plafond déclaré quand une capacité manque (FABRICATION)"),
    ("HON-04", "ACTION", "frontière de validation : ce que la machine atteste et n'atteste pas"),
    ("HON-05", "ACTION", "agent seul : preuve dégradée et conclusions interdites"),
    ("HON-06", "ACTION", "NOT-VERIFIED plutôt qu'un PASS sans preuve"),
    ("HON-07", "ACTION", "une capture prouve un rendu, pas une tâche"),
    ("HON-08", "ACTION", "droit inconnu : ACCEPTED interdit"),
    ("ANT-01", "SAVOIR", "marqueurs de vague datés, pour nommer MODAL"),
    ("MOY-01", "SAVOIR", "carte des moyens par couche"),
    ("SOR-01", "ACTION", "réponse visible en langage produit, trace sur demande"),
    ("TRA-01", "ACTION", "trace légère par défaut ; trace complète si persistant, partagé, audité ou acceptation demandée"),
    ("CHK-01", "ACTION", "la première proposition vaut checkpoint, sauf action irréversible ou coûteuse"),
    ("CNT-01", "DIRECTION", "destination réelle sans contenu : exemple marqué plutôt qu'emplacements vides"),
    ("TRM-01", "BIBLIOTHEQUE", "test de trame : nommer la trame modale du brief, la rompre ou la justifier"),
    ("GTA-01", "ACTION", "Gate A par profil de surface : contrôles d'office et contrôles selon le contenu"),
    ("ROL-01", "DIRECTION", "rôle de directeur·rice artistique senior, défini une seule fois, en tête de DIRECTION"),
    ("PRC-01", "BIBLIOTHEQUE", "tests perceptifs de structure (non-généricité, silhouette, grille), atteignables depuis Gate C"),
    ("EXD-01", "DIRECTION", "données d'exemple cohérentes entre elles ; aucun chiffre sans référence"),
    ("TIT-01", "SAVOIR", "équilibre d'un titre : coupe par le sens, lignes équilibrées, écart d'échelle net"),
    ("TXI-01", "SAVOIR", "texte sur image : zone calme, recadrage ou voile, contraste au point le plus défavorable"),
    ("RCV-01", "SAVOIR", "récupération après erreur : message, saisie conservée, focus, reprise observée par interaction"),
    ("ANC-01", "DIRECTION", "ancre graduée : explorer sans ancre (limite déclarée), accepter avec ancre, observée ou fournie pour un produit réel"),
    ("VAL-01", "ACTION", "promesse du validateur : ce qu'atteste et n'atteste pas une RUN_CARD validée, texte unique"),
    ("ALT-01", "DIRECTION", "alternative située : déclenchement en un seul lieu ; leviers SAVOIR ; matérialisation, trace et comparaison ACTION"),
    ("FIN-01", "SAVOIR", "activation du craft : signal, savoir, geste conditionné, réinspection et décision"),
]

# 2. Renvois : la route cite un locator dont le bloc contient le concept.
REFERENCES: list[tuple[str, str]] = [
    ("DIRECTION/CREATIVE-BOOT", "ANT-01"),
    ("DIRECTION/ASSET-ROUTE", "MOY-01"),
    ("ACTION/GATE-C", "PRC-01"),
    ("ACTION/GATE-C", "RCV-01"),
    ("SAVOIR/CRAFT/CFT-00", "FIN-01"),
    ("DIRECTION/CHARGE", "FIN-01"),
    ("DIRECTION/DOUBLE-LOOP", "FIN-01"),
    ("ACTION/HANDOFF", "FIN-01"),
    ("ACTION/GATE-C", "FIN-01"),
]

# 3. Vocabulaire retiré : motif, remplacement, fichiers exemptés (historique).
RETIRED: list[tuple[str, str, set[str]]] = [
    (r"vocabulaire perceptuel ci-dessous|le geste retenu est l’un de ses diffs",
     "renvoi stable à SAVOIR/STATE et gestes conditionnels non fermés", set()),
    (r"Il est accepté uniquement si la version après", "validité de la comparaison distincte de la version retenue", set()),
    (r"Sinon, reconsidère-les", "si rien ne les justifie, reconsidère-les", set()),
    (r"dérive cinq artefacts de preuve", "cinq responsabilités de preuve, regroupables", set()),
    (r"Établissez le mode", "classer d'abord avec DIRECTION/START, par l'opérateur ou l'agent", set()),
    (r"Forme courte LITE non persistante", "forme courte LITE : trace complète d'un LITE clôturé, distincte de la trace légère", set()),
    (r"`CLOSED` uniquement si la direction est tenue", "CLOSED décrit la persistance ; le résultat se déclare à part (ACTION/STATUS)", set()),
    (r"anti-directions?", "MODAL / PARTI", set()),
    (r"La suite de la page se construit dans la direction gardée\.", "la suite se construit comme une séquence (BIBLIOTHEQUE/SEQUENCE)", set()),
    (r"dessine le sujet \(`CODE-NATIVE`\)", "route suivante du rôle (SAVOIR/SOURCE, « Routes par rôle »)", set()),
    (r"pour une démonstration, elle est permise et marquée", "accord de la personne avant toute génération ou outil branché sur son compte, même en démonstration (MOY-PLAFOND)", set()),
    (r"collection qui refuse (?:se remplace|remplacée) par une autre|ne se relance pas sous une autre adresse",
     "une source qui refuse se remplace par un canal officiel ou une autre source (SAVOIR/SOURCE)", set()),
    (r"[Rr]egistres? fermés?|registres canoniques", "listes closes (gouvernance/statuts)", set()),
    (r"MODE — DECISION — CHANGE — PROOF", "réponse visible en langage produit (ACTION/HANDOFF)", set()),
    (r"déclenche un (?:nouveau )?checkpoint", "la première proposition vaut checkpoint (ACTION/PIPELINE-DIRECTION)", set()),
    (r"checkpoint humain intervient avant le build|demande une validation avant le build",
     "la première proposition vaut checkpoint (ACTION/PIPELINE-DIRECTION)", set()),
    (r"\*\*Ce qu’atteste une `RUN_CARD` validée :\*\*", "renvoi à la frontière de validation d'ACTION/RUN_CARD (VAL-01)",
     {"ACTION"}),
    # Boucle d'édition : une seule description (DIRECTION/DOUBLE-LOOP, copiée dans le noyau). Aucune exemption.
    (r"→ isoler|observer, isoler", "boucle d'édition de DIRECTION/DOUBLE-LOOP (noyau)",
     {"DIRECTION", "SKILL.md"}),
    (r"Distingue trois niveaux", "un seul modèle de niveaux : Correction, Précision, Intention", set()),
    # L'agent lit le noyau et CHARGE ; READING_MAP est une vue pour les personnes.
    (r"seul document canonique de cadrage chargé au démarrage", "noyau compilé et DIRECTION/CHARGE", set()),
    (r"utilisez `READING_MAP\.md` comme vue dérivée", "READING_MAP pour une personne ; l'agent charge par DIRECTION/CHARGE",
     set()),
    # One-shot : une seule définition (branche one-shot d'ACTION/PIPELINE-DIRECTION).
    (r"Le `one-shot` est une stratégie de préparation", "branche one-shot d'ACTION/PIPELINE-DIRECTION", set()),
    (r"cette vue reste interne", "la prise de brief reste dans la trace", set()),
    (r"Mandat de fonctionnement|Adopte le niveau d’exigence", "rôle unique (ROL-01)", set()),
    (r"`VISUAL_TARGET` la spécifie", "chaîne de lecture interne unique (DIRECTION)", set()),
    (r"`DAILY`", "DIRECTION/CHARGE", set()),
    (r"ancre fraîche et inspectable|\bancre inspectable\b|Ne dessine jamais une surface identitaire uniquement de mémoire|"
     r"établis une ancre fraîche|bloque la livraison validée, sauf `FAIL-ASSUMED`",
     "ancre graduée (ANC-01, absolu 2 de DIRECTION) ; FAIL-ASSUMED n'accepte jamais", set()),
    # Formulations inexactes ou périmées.
    (r"Forme seule, dans la trace|la machine ne le vérifie pas",
     "contrôle machine nommé par mode (CLOSE-PACKAGE, VAL-01)", set()),
    (r"la triade d’`ACTION/STATUS` s’applique|sinon la triade d’|porte la triade de `ACTION/STATUS`|\(triade d’`ACTION/STATUS`\)",
     "triade = changée, confirmée, abandonnée ; sinon valeurs de repli", set()),
    (r"est définie une seule fois, par `ACTION/CLOSE-PACKAGE`", "paquet défini par CLOSE-PACKAGE, précisé par les routes",
     set()),
    (r"Un risque critique exclut `LITE` et `ITER` \(", "exclusion conditionnelle de DIRECTION/START", set()),
    (r"Une ancre `transformed` est compatible avec tout verdict", "exigence limitée à DIRECTION", set()),
    (r"`decision_change` \(`outcome`, `reason`\)|`direction\.calibration` : `real_constraint`|est abandonnée au profit d|"
     r"abandonnée jusqu’à correction|vérifie le titre exact du propriétaire|sinon la direction est traitée d’abord",
     "références alignées sur le schéma et les propriétaires", set()),
    # Une ancre absente reste NOT-VERIFIED ; FAIL-ASSUMED exige un échec connu (ACTION/OVERRIDE).
    # Seul le raccourci « ancre absente → FAIL-ASSUMED » est retiré ; une diffusion limitée
    # d'un échec connu qui « passe par FAIL-ASSUMED » reste une phrase légitime.
    (r"(?:sans (?:l’)?ancre|ancre (?:absente|manquante))[^.]{0,200}(?:passe par|possible par) `FAIL-ASSUMED`|"
     r"`FAIL-ASSUMED` ne permet qu’une diffusion limitée",
     "sans ancre : EXPLORATORY ; FAIL-ASSUMED seulement pour un échec connu", set()),
    # Une seule entrée humaine ; plus de démarrages concurrents ; une seule constitution minimale.
    (r"Démarrage en 90 secondes|démarrage en 90 secondes|Démarrage express|Le chemin en trente secondes|"
     r"Le parcours complet en cinq minutes|Commencer en deux minutes|\| Si vous avez… \|",
     "entrée humaine unique (« Commencer », README du paquet) ; parcours commun du guide opérateur", set()),
    (r"dessinée uniquement de mémoire|coordination du réel et du beau",
     "constitution minimale unique, exacte (README du paquet, bloc « constitution »)", set()),
    # Copies du handoff, instrumentation de lecture, copies du déclenchement de l'alternative.
    (r"conserve au minimum `MODE`|Conservez aussi `MODE`", "renvoi au handoff canonique (ACTION/HANDOFF)", set()),
    (r"Charges de lecture à ne pas confondre|Déclare dans la trace la nature de chaque lecture",
     "catégories de lecture de DIRECTION, pour un run instrumenté ou audité", set()),
    (r"considère une proposition crédible répondant à un public|Matérialise-la seulement au niveau nécessaire pour comparer|"
     r"sa trace avant le build",
     "alternative située : déclenchement DIRECTION (ALT-01), leviers SAVOIR, matérialisation et trace ACTION", set()),
    # Reprise ITER depuis une trace légère ; trace de l'alternative graduée ; ordre de chargement.
    (r"retrouvables dans la session, la `RUN_CARD` ou le manifeste local|retrouvables dans la `RUN_CARD`, le manifeste ou le projet",
     "reprise ITER : la trace légère (ligne de thèse) compte parmi les lieux retrouvables", set()),
    (r"Pour chaque alternative, préciser dans la trace existante",
     "trace de l'alternative graduée : trace complète, sinon alternative écartée nommée dans la proposition", set()),
    (r"`DIRECTION/CREATIVE-BOOT`, `DIRECTION/EXTERNAL-START` si le brief est vague",
     "prise de brief avant le boot : EXTERNAL-START puis CREATIVE-BOOT", set()),
    # Grille de travail, nom de la case RUN, marquage d'une démonstration, nom du paquet.
    (r"contrôle des huit dimensions", "revue sur capture en quatre questions ; contrat du premier objet en trace complète", set()),
    (r"\[preuve suivante\]|preuve minimale et (?:la )?condition d’arrêt", "prochaine preuve (case de la ligne RUN)", set()),
    (r"porte près de l’objet le marquage", "TRUTH/* dans la trace ; à l’écran, une mention en langage produit", set()),
    (r"\b(?:du|le|au|ce) package\b(?!-)", "paquet (un package logiciel garde son nom)", set()),
]

# 11. Choix contextuels — garde BORNÉE. Elle ne juge pas le sens d'une phrase quelconque ; elle détecte
#     seulement (a) le retour des formulations universelles retirées, et (b) les impératifs universels explicites
#     (« toujours », « à tous les », « dans tous les cas »…) portant sur un traitement ou une famille unique, sauf négation.
#     Un choix situé (« pour cette série, un seul traitement a été retenu ») est accepté ; la revue juge le reste.
RETIRED_UNIVERSAL = re.compile(r"applique un traitement unique et cohérent|reçoit un traitement unique et justifié|"
                               r"un seul traitement pour les assets moyens|un seul traitement cohérent|Icônes : une seule famille",
                               re.I)
UNIVERSAL = re.compile(r"traitement unique|un seul traitement|une seule famille", re.I)
ALWAYS = re.compile(r"\btoujours\b|systématiquement|dans tous les cas|en toutes circonstances|quel que soit|"
                    r"à tou(?:s|tes) les|pour tou(?:s|tes) les", re.I)
NEGATION = re.compile(r"\bjamais\b|\bne\b|\bn[’']", re.I)


def check_universal(corpus: dict[Path, list[str]], errors: list[str]) -> None:
    for path, lines in corpus.items():
        for para in paragraphs(lines):
            for sentence in re.split(r"(?<=[.!?])\s+", para):
                if RETIRED_UNIVERSAL.search(sentence) or (UNIVERSAL.search(sentence) and ALWAYS.search(sentence)
                                                          and not NEGATION.search(sentence)):
                    errors.append(f"[UNI-01] choix présenté comme universel ({rr.nom(path)}) : « {sentence[:90]}… »")


# 10. Ordre : le rôle ouvre le noyau compilé, la posture le suit ; leur texte vit dans une route DIRECTION.
ORDER: tuple[str, ...] = ("ROLE", "POSTURE")

# 4. Fidélité des résumés : tout paragraphe qui contient le déclencheur contient la condition canonique.
FIDELITY: list[tuple[str, str, str]] = [
    ("prise de brief", r"au plus trois", "destination si elle est incertaine"),
    ("checkpoint", r"checkpoint[^.]{0,60}avant (?:le )?build|avant (?:le )?build[^.]{0,60}checkpoint", "irréversible ou coûteuse"),
    ("question de convergence", r"Question de convergence", "police de titre"),
    ("carte des moyens", r"\*\*Carte des moyens par couche\*\*", "chaque ressource retenue"),
    ("relecture de l'ensemble", r"la correction a affaibli", "l’ensemble"),
    ("titre : composition voulue", r"\*\*Équilibre d’un titre\.\*\*", "on le garde si"),
    ("récupération : focus selon le moment", r"\*\*Récupération après erreur\.\*\*", "sans déplacer le focus"),
    # Cohérence ciblée
    ("promesse du validateur par mode", r"Ce qu’elle n’atteste pas", "invariants communs"),
    ("arrêt one-shot et B1b",
     r"branche `one-shot` est une exécution raccourcie|`one-shot` est une branche raccourcie|rendu one-shot peut être clôturé", "B1b"),
    ("protection de niveau", r"Un risque critique que le changement touche", "strictement local"),
    ("scopes de la direction et de l'artefact", r"Direction qualifiée", "distinct d’`artifact.scope`"),
    ("B1b et decision_change", r"`confirmed`, `modified` ou `abandoned`", "`CHANGED`"),
    ("COMPONENTS en SYSTÈME", r"`ACTION/RUN-SYSTEM` \+ `BIBLIOTHEQUE/COMPONENTS`", "si un composant change"),
    ("zéro contrat", r"Zéro contrat est valide", "`production_contracts`"),
    ("champ voisin", r"jamais glissé dans un champ voisin", "non prévu par cette table"),
    # Répétitions retirées
    ("lecture instrumentée : ouverture", r"distingue dans la trace :", "run instrumenté ou audité"),
    ("lecture instrumentée : déclaration", r"déclare dans la trace la catégorie de lecture", "run instrumenté ou audité"),
    ("trace de l'alternative graduée", r"la raison de son niveau de matérialisation", "En trace légère"),
    ("signal de matière (PRINT_FIELD)", r"Trois cartes égales sous un titre centré", "`MODIFIER/PRINT_FIELD`"),
    # Parcours
    ("checkpoint : valider n'est pas accepter", r"la personne valide, réoriente ou arrête", "pas une acceptation"),
    ("entrée humaine : valider ou retenir", r"\*\*4\. Comment poursuivre \?\*\*", "vrai produit"),
    ("prise de brief : construire dans le même tour", r"\*\*Prise de brief\.\*\*", "dans le même tour"),
    ("sortie des routes en trace légère", r"\*\*Sortie\.\*\* Paquet `(?:LITE|ITER|STANDARD|SYSTÈME)`", "Trace légère : la proposition"),
    ("réponse visible : alternative écartée", r"Pourquoi : la thèse", "l’alternative écartée"),
    # Une route RUN-* ne prescrit DECIDED puis CLOSED qu'en trace complète (TRA-01)
    ("clôture des routes en trace complète", r"\*\*Clôture\.\*\*[^.]{0,40}`DECIDED`", "En trace complète"),
    # Une valeur inconnue ne retire pas l'action principale ; elle reste fonctionnelle et marquée
    ("contenu marqué : action principale", r"\*\*Destination réelle sans contenu\.\*\*", "action principale"),
    # Ancre, trace complète, règle CTA, lecture de l'agent, veille
    ("ancre absente : pas de FAIL-ASSUMED, pipeline", r"Sans ancre utile et spec exploitable", "échec connu"),
    ("preuve indisponible : pas de FAIL-ASSUMED", r"Si une preuve est indisponible, le mode ne baisse pas", "échec connu"),
    ("trace persistante en trace complète", r"conserve(?:nt)? une trace persistante", "trace complète"),
    ("FAST-PATH : clôture en trace complète", r"clôture avec (?:la forme courte LITE|le paquet de son mode)", "trace complète"),
    ("sélection structurelle persistée en trace complète", r"sélection structurelle[^.?]{0,40}persisté", "trace complète"),
    ("flux : fermer en trace complète", r"[Dd]écider et fermer", "trace complète"),
    ("exemples : niveau de trace", r"Les champs affichés respectent les contrats d’ACTION", "trace complète"),
    ("règle CTA : valeur d'exemple marquée", r"Un CTA doit soit déclencher", "CNT-01"),
    ("flux : READING_MAP pour une personne", r"la section « Combinaisons par résultat recherché » de `READING_MAP", "si une personne le demande"),
    ("veille : signaux à confirmer", r"\*\*Marqueurs de vague\*\*", "Signaux à confirmer"),
    # Une seule liste de chargement, plancher SAVOIR dans le noyau, lieu de la trace légère
    ("table des signaux : détail final conditionnel, par CHARGE", r"\| Détail final susceptible", "DIRECTION/CHARGE"),
    ("ACTION/ROUTING : renvoi à CHARGE", r"DIRECTION déclenche la classification générale", "DIRECTION/CHARGE"),
    ("SAVOIR/READ : plancher dans le noyau", r"\*\*Chemin minimal\.\*\* Décide d’abord", "noyau"),
    ("trace légère : lieu", r"\*\*Trace légère par défaut\.\*\*", "à côté de l’artefact"),
    # Ancre et FAIL-ASSUMED
    ("ancre et FAIL-ASSUMED", r"sans (?:l’)?ancre[^.]{0,200}`FAIL-ASSUMED`|ancre (?:absente|manquante)[^.]{0,200}`FAIL-ASSUMED`|"
     r"`FAIL-ASSUMED`[^.]{0,120}ancre (?:absente|manquante)", "échec connu"),
    # Procédure et fabrication
    ("RUN-DIRECTION : CLOSED distinct du résultat", r"puis `CLOSED` lorsque l’artefact et la trace sont persistés", "ACTION/STATUS"),
    ("FAST-PATH : paquet du mode, ITER vers ITER", r"Pour `LITE` et les petits `ITER`", "paquet `ITER` pour un `ITER`"),
    ("niveau requis : preuve manquante distincte du N/A", r"Obligation spécialisée\. \|", "NOT-VERIFIED"),
    ("recherche : confirmation distincte du N/A", r"Une recherche de domaine et une recherche de calibration visuelle", "confirmation"),
    ("module sans effet : confirmation distincte du N/A", r"Quelle décision concrète a changé grâce à ce module", "confirmation"),
    ("QUICKSTART, fermeture : preuve manquante distincte du N/A", r"la preuve attendue est obtenue ou déclarée", "ne vaut que si la preuve ne s’applique pas"),
    ("règle d'or 8 : réserve structurée recevable", r"ne compense jamais un axe bloquant par une moyenne", "ACCEPTED-WITH-RESERVATION"),
    ("contenu marqué : fonctions d'un produit fictif", r"\*\*Destination réelle sans contenu\.\*\*", "fonctions, intégrations et conformités affirmées"),
    # Façades dérivées des contrats stabilisés
    ("QUICKSTART : suite par défaut, la proposition", r"choisissez une seule suite", "trace complète"),
    ("QUICKSTART : niveau de trace distinct du mode", r"Une sortie de run a deux formes : la \*\*réponse visible\*\*", "trace légère"),
    ("QUICKSTART : sortie one-shot selon la trace", r"la sortie one-shot peut être une décision directement clôturée", "trace complète"),
    ("QUICKSTART : l'agent lit le noyau et CHARGE", r"L’agent localise le paquet réellement fourni", "DIRECTION/CHARGE"),
    ("QUICKSTART : la ligne de run suit le classement", r"Pour piloter un run, commencez ici", "DIRECTION/START"),
    ("README : parcours, proposer ou fermer", r"Le parcours complet d’un run est", "trace légère"),
    ("flux : la proposition vaut checkpoint", r"présenter la proposition \(trace légère", "checkpoint"),
    ("HANDOFF : forme courte LITE distincte de la trace légère", r"\*\*Forme courte LITE", "distincte de la trace légère"),
    ("exemples : la sortie par défaut porte sa trace légère", r"montre la sortie par défaut", "trace légère"),
    # Raccords de chargement et de précision
    ("SAVOIR/STYLE : FRAME conditionnel comme dans CHARGE", r"Le parcours est : `DIRECTION/START → SAVOIR/FRAME", "si le cadrage est à éclaircir"),
    ("contrat de composant : delta local qualifié", r"S’applique à un pattern réutilisable, à un composant critique ou à un composant partagé", "reclasser"),
    ("avant/après : version retenue, l'original possible", r"La comparaison est valide si elle isole la décision", "l’original"),
    ("test de masquage : dépendance porteuse recevable", r"Si texte, données et images sont masqués", "dépendance est recevable"),
    ("connexion C05 : réemploi lu dans REUSE", r"`SAVOIR/SYSTEM` selon le choix repris", "`DIRECTION/REUSE`"),
    ("génération : accord à la route de production", r"Toute génération d’image, asset ou ancre", "accord de la personne"),
]

# 13. Entrée humaine : une seule entrée, balisée dans le niveau 1 des guides (guides/1-utiliser.md), vers lequel
#     renvoient le README du paquet ; quatre questions ; aucun mode interne demandé ; vouvoiement.
#     Une seule constitution minimale, balisée dans le README du paquet.
ENTRY = re.compile(r"<!-- entree:début -->(.*?)<!-- entree:fin -->", re.S)
CONSTITUTION = re.compile(r"<!-- constitution:début -->(.*?)<!-- constitution:fin -->", re.S)
QUESTIONS = ("**1. Que demander ?**", "**2. Que fournir ?**", "**3. Que recevoir ?**", "**4. Comment poursuivre ?**")
MODE_ASKED = re.compile(r"`(?:LITE|ITER|STANDARD|DIRECTION|SYSTÈME)`|MODE —")
CONSTITUTION_SIGNATURE = "le réel et le beau sont cadrés ensemble"


def check_entry(corpus: dict[Path, list[str]], errors: list[str]) -> None:
    readme, guide = ROOT / "README.md", ROOT / "guides" / "1-utiliser.md"
    if not readme.is_file():
        errors.append("[ENT-01] README.md absent à la racine du package")
        return
    text = readme.read_text(encoding="utf-8")
    entries = ENTRY.findall(guide.read_text(encoding="utf-8")) if guide.is_file() else []
    if len(entries) != 1:
        errors.append(f"[ENT-01] entrée humaine balisée {len(entries)} fois dans guides/1-utiliser.md (attendu : 1)")
    else:
        block = entries[0]
        for question in QUESTIONS:
            if question not in block:
                errors.append(f"[ENT-01] question absente de l'entrée humaine : {question}")
        asked = MODE_ASKED.search(block)
        if asked:
            errors.append(f"[ENT-01] l'entrée humaine demande un mode interne : « {asked.group(0)} »")
        familiar = re.search(TUTOIEMENT.pattern, block, re.I)  # insensible à la casse (début de phrase)
        if familiar:
            errors.append(f"[ENT-01] registre : tutoiement « {familiar.group(0)} » dans l'entrée humaine")
        if block.count("retenir cette direction pour") > 1:  # une seule mention, à la question 4
            errors.append("[ENT-01] redite : « retenir cette direction pour » plus d'une fois dans l'entrée humaine")
    constitutions = CONSTITUTION.findall(text)
    if len(constitutions) != 1 or CONSTITUTION_SIGNATURE not in constitutions[0]:
        errors.append("[CST-01] constitution minimale absente, multiple ou inexacte dans README.md (bloc « constitution »)")
    for path, lines in corpus.items():
        if path.resolve() == readme.resolve():
            continue
        if any(CONSTITUTION_SIGNATURE in line for line in lines):
            errors.append(f"[CST-01] copie de la constitution minimale hors du README : {rr.nom(path)}")


# 14. Cartes réunies : les combinaisons par résultat vivent au niveau 2 des guides.
def check_maps(errors: list[str]) -> None:
    found = [rr.nom(p) for p in rr.fichiers_officiels() + [ROOT / "README.md"]
             if p.is_file() and p.read_text(encoding="utf-8").count("## Combinaisons par résultat recherché")]
    if found != ["guides/2-comprendre.md"]:
        errors.append("[MAP-01] une seule section « Combinaisons par résultat recherché », au niveau 2 des guides "
                      f"(trouvée : {', '.join(found) or 'aucune'})")


# 12. Locators numériques : un message du validateur cite un lieu nommé, jamais un numéro de ligne.
NUMERIC_LOCATOR = re.compile(r"\((?:[^()]*, )?(?:DIRECTION|ACTION|SAVOIR|BIBLIOTHEQUE) \d+\)")


def check_numeric_locators(errors: list[str]) -> None:
    path = ROOT / "gouvernance" / "outils" / "validate_run_card.py"
    if not path.is_file():
        return
    for i, line in enumerate(path.read_text(encoding="utf-8").splitlines()):
        if "ValidationError(" in line and NUMERIC_LOCATOR.search(line):
            errors.append(f"[LOC-01] locator numérique dans un message du validateur : validate_run_card.py:{i + 1}")

# 5. Termes du vocabulaire de fabrication présents dans le glossaire (première cellule d'une ligne de table).
GLOSSARY_TERMS = ["Thèse", "Ancre", "Creative Boot", "MODAL", "PARTI", "FABRICATION", "Plafond",
                  "Objet de preuve", "Défaut dominant", "Vérité de scène", "Slop",
                  "Trace légère", "Trace complète", "Première proposition", "Trame modale", "Profil de surface"]

# 7. Registre des façades humaines : formes de tutoiement impératif refusées.
REGISTER_FILES = ["guides/3-maitriser.md"]
# Garde générale : tout pronom de la 2e personne du singulier, hors code (VOU-01).
PRONOM_TU = re.compile(r"(?<![\w’'-])(?:tu|toi|tes)(?![\w’'-])|(?<![\w’'-])t[’'](?=\w)", re.I)
# Liste close : les impératifs de tutoiement déjà rencontrés, que le pronom ne révèle pas.
TUTOIEMENT = re.compile(r"\b(?:ne confonds|utilise le|Charge `|active `|Augmente la|ajoute le|garde en tête|reste sur)\b")


# 8. Noyau : les blocs vivent dans une route d'une famille normative.
NOYAU_MARK = re.compile(r"^<!-- (?:noyau|différé):(début|fin) ([A-Z0-9\-]+) -->$")

# 9. Chargement : en-têtes d'une table de chargement ; lignes de façade qui doivent renvoyer à DIRECTION/CHARGE.
LOAD_HEADERS = re.compile(r"^\|\s*Mode\s*\|\s*(Charger d’abord|Démarrage minimal|Chargement)")  # « Chargement » inclus
LOAD_POINTERS = [("guides/3-maitriser.md", "| Une direction visuelle ouverte |"),
                 ("guides/2-comprendre.md", "| **Direction forte et spécifique** |")]


def lire(path: Path) -> str:
    """Texte d'un fichier où chaque lien vers une section de règle devient son code : les contrôles lisent les mêmes
    codes, que le texte cite la section par un lien ou par son code."""
    return rr.liens_en_codes(path.read_text(encoding="utf-8"), path)


def texte(name: str) -> str:
    """Famille (`DIRECTION`, `ACTION`, `SAVOIR`, `BIBLIOTHEQUE`) construite à partir de ses routes, ou fichier relatif
    à la racine (`guides/glossaire.md`)."""
    return rr.famille(name) if name in rr.FAMILLES else lire(ROOT / name)


def lignes(name: str) -> list[str]:
    return texte(name).splitlines()


def texts() -> dict[Path, list[str]]:
    files = rr.fichiers_officiels() + [SKILL_DIR / "SKILL.md", *sorted((SKILL_DIR / "references").glob("*.md"))]
    readme = ROOT / "README.md"
    if readme.is_file():
        files.append(readme)
    return {p: lire(p).splitlines() for p in files}


def paragraphs(lines: list[str]) -> list[str]:
    out, buf = [], []
    for line in lines:
        if not line.strip():
            if buf:
                out.append(" ".join(buf))
            buf = []
        else:
            buf.append(line)
    if buf:
        out.append(" ".join(buf))
    return out


def check_concepts(corpus: dict[Path, list[str]], errors: list[str]) -> None:
    found: dict[str, list[tuple[Path, int]]] = {}
    for path, lines in corpus.items():
        for i, line in enumerate(lines):
            m = MARKER.match(line)
            if m:
                found.setdefault(m.group(1), []).append((path, i))
    known = {cid for cid, _, _ in CONCEPTS}
    for cid in sorted(set(found) - known):
        errors.append(f"balise hors registre : {cid}")
    for cid, owner, prop in CONCEPTS:
        places = found.get(cid, [])
        if not places:
            errors.append(f"{cid} absent ({prop})")
            continue
        if len(places) > 1:
            where = ", ".join(f"{rr.nom(p)}:{i + 1}" for p, i in places)
            errors.append(f"{cid} défini {len(places)} fois : {where}")
            continue
        path, i = places[0]
        if rr.famille_de(path, i) != owner:
            errors.append(f"{cid} hors d'une route de sa famille propriétaire ({owner}) : {rr.nom(path)}:{i + 1}")
            continue
        block = []
        for line in corpus[path][i + 1:]:
            if not line.strip():
                break
            block.append(line)
        if len(" ".join(block).split()) < MIN_WORDS:
            errors.append(f"{cid} : bloc vide ou trop court après la balise ({owner}:{i + 1})")


def raw_block(locator: str) -> list[str]:
    path, lines, index = rr.resolve(locator)
    return lines[index:rr.block_end(lines, rr.headings(lines), index)]


def check_references(errors: list[str]) -> None:
    for route, cid in REFERENCES:
        try:
            path, lines, index = rr.resolve(route)
        except rr.RouteError as exc:
            errors.append(f"renvoi {route} → {cid} : route introuvable ({exc})")
            continue
        served = "\n".join(rr.extract(lines, index))
        hit = False
        for loc in sorted(set(LOCATOR.findall(served))):
            try:
                block = raw_block(loc)
            except rr.RouteError:
                continue
            if any(MARKER.match(l) and MARKER.match(l).group(1) == cid for l in block):
                hit = True
                break
        if not hit:
            errors.append(f"renvoi {route} → {cid} : aucun locator cité par la route ne mène au concept")


def check_retired(corpus: dict[Path, list[str]], errors: list[str]) -> None:
    for pattern, repl, exempt in RETIRED:
        rx = re.compile(pattern, re.I)
        for path, lines in corpus.items():
            if path.name in exempt:
                continue
            for i, line in enumerate(lines):
                if rx.search(line) and rr.famille_de(path, i) not in exempt:
                    errors.append(f"vocabulaire retiré « {pattern} » ({repl}) : {rr.nom(path)}:{i + 1}")


def check_fidelity(corpus: dict[Path, list[str]], errors: list[str]) -> None:
    for name, trigger, needle in FIDELITY:
        rx = re.compile(trigger, re.I)
        for path, lines in corpus.items():
            for para in paragraphs(lines):
                if rx.search(para) and needle not in para:
                    errors.append(f"résumé infidèle ({name}) : {rr.nom(path)} « {para[:70]}… » sans « {needle} »")


def cell(text: str) -> str:
    return re.sub(r"[`*]", "", text).strip()


def check_glossary(errors: list[str]) -> None:
    heads = set()
    for line in lignes("guides/glossaire.md"):
        if line.lstrip().startswith("|"):
            parts = line.split("|")
            if len(parts) > 2:
                heads.add(cell(parts[1]))
    for term in GLOSSARY_TERMS:
        if term not in heads:
            errors.append(f"glossaire : terme absent « {term} »")
    check_codes_glossed(errors)


CODE_CAPITALES = re.compile(r"`([A-Z][A-Z0-9_]{2,}(?:-[A-Z0-9_]+)*)`")


def check_codes_glossed(errors: list[str], files: list[Path] | None = None) -> None:
    """[GLO-02] Tout code en capitales cité hors bloc de code dans un texte pour les personnes a sa ligne au glossaire."""
    glossaire = (ROOT / "guides" / "glossaire.md").read_text(encoding="utf-8")
    files = [p for p in textes_personnes() if p.name != "glossaire.md"] if files is None else files
    for path in files:
        for i, line in enumerate(sans_code_bloc(path.read_text(encoding="utf-8")), 1):
            for code in CODE_CAPITALES.findall(line):
                if f"`{code}`" not in glossaire and f"**{code}**" not in glossaire:
                    errors.append(f"[GLO-02] code « {code} » sans ligne au glossaire : {rr.nom(path)}:{i} "
                                  "(un code en capitales que lit une personne se définit dans guides/glossaire.md)")


def sans_code_bloc(text: str) -> list[str]:
    """Lignes d'un texte, blocs de code vidés (les segments en ligne restent : ils portent les codes)."""
    out, fence = [], False
    for line in text.splitlines():
        if line.lstrip().startswith("```"):
            fence = not fence
            out.append("")
            continue
        out.append("" if fence else line)
    return out


def check_unique_rows(corpus: dict[Path, list[str]], errors: list[str]) -> None:
    for path, lines in corpus.items():
        seen: dict[str, int] = {}
        for i, line in enumerate(lines):
            if not line.lstrip().startswith("|") or re.match(r"^\s*\|[\s\-:|]+\|\s*$", line):
                continue
            key = re.sub(r"[`*\s|]+", " ", line).strip().lower()
            if len(key.split()) < 8:
                continue
            if key in seen:
                errors.append(f"ligne de table en double : {rr.nom(path)}:{seen[key] + 1} et {i + 1}")
            else:
                seen[key] = i


def sans_code(text: str) -> list[str]:
    """Lignes d'un texte, blocs et segments de code vidés (numérotation conservée)."""
    out, fence = [], False
    for line in text.splitlines():
        if line.lstrip().startswith("```"):
            fence = not fence
            out.append("")
            continue
        out.append("" if fence else re.sub(r"`[^`]*`", "", line))
    return out


def textes_personnes() -> list[Path]:
    return sorted((ROOT / "guides").glob("*.md")) + [ROOT / "README.md"]


def textes_lecture() -> list[Path]:
    """Textes lus par les personnes, au sens large : guides, README, notes de version et README des dossiers."""
    extra = [ROOT / "RELEASE_NOTES.md", ROOT / "maintenance" / "versions.md"] + sorted(ROOT.glob("*/README.md"))
    return textes_personnes() + [p for p in extra if p.is_file()]


def visible(text: str) -> str:
    """Texte lu : commentaires HTML et cibles de liens retirés."""
    text = re.sub(r"<!--.*?-->", "", text)
    return re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", text).strip()


# [LIS-01] Seuils de lecture [À ADAPTER] : une cellule et un paragraphe se lisent d'un coup d'œil.
CELLULE_MAX, PARAGRAPHE_MAX = 500, 900


def check_readability(errors: list[str], files: list[Path] | None = None) -> None:
    """[LIS-01] Cellule de table au plus CELLULE_MAX signes visibles, paragraphe au plus PARAGRAPHE_MAX."""
    for path in textes_lecture() if files is None else files:
        for i, line in enumerate(sans_code_bloc(path.read_text(encoding="utf-8")), 1):
            if line.startswith("|"):
                for c in line.strip("|").split(" | "):
                    if len(visible(c)) > CELLULE_MAX:
                        errors.append(f"[LIS-01] cellule de {len(visible(c))} signes > {CELLULE_MAX} : {rr.nom(path)}:{i} "
                                      "(découper la ligne ou renvoyer le détail à sa route)")
            elif line and not line.startswith(("#", "<!--", ">")) and len(visible(line)) > PARAGRAPHE_MAX:
                errors.append(f"[LIS-01] paragraphe de {len(visible(line))} signes > {PARAGRAPHE_MAX} : {rr.nom(path)}:{i} "
                              "(découper en paragraphes ou en liste)")


# [LAN-01] Langue des textes pour les personnes. Deux listes closes : les mots anglais gardés (chacun défini au
# glossaire) et les mots anglais remplacés par leur équivalent français. Le code, les liens et les en-têtes du
# glossaire, qui donnent le terme anglais entre parenthèses, sont hors garde ; « Gate A », « Gate B », « Gate C » sont des noms.
ANGLAIS_GARDES = ["Run", "Skill", "Brief", "Build", "Craft"]
ANGLAIS_REMPLACES = {
    "owner": "responsable", "scope": "périmètre", "polish": "finition", "checkpoint": "point de contrôle",
    "gate": "contrôle (ou le nom Gate A, B, C)", "token": "jeton de design", "rollback": "retour arrière",
    "fix": "correctif", "pattern": "motif", "review": "revue", "blast radius": "portée du changement",
    "workflow": "déroulé",
}
ANGLAIS_RX = re.compile(r"(?<![\w-])(" + "|".join(re.escape(w) for w in ANGLAIS_REMPLACES) + r")s?(?![\w-])(?!\.\w)", re.I)  # owner.txt est un nom de fichier


def check_language(errors: list[str], files: list[Path] | None = None, glossaire: str | None = None) -> None:
    """[LAN-01] Aucun mot de la liste close des remplacés ; chaque mot gardé a sa ligne au glossaire."""
    for path in textes_lecture() if files is None else files:
        for i, line in enumerate(sans_code(path.read_text(encoding="utf-8")), 1):
            if path.name == "glossaire.md" and line.startswith("|"):
                line = "|".join(line.split("|")[2:])
            texte = visible(line)
            for m in ANGLAIS_RX.finditer(texte):
                mot = m.group(1).lower()
                if mot == "gate" and re.match(r"\s+[ABC]\b", texte[m.end():]):
                    continue  # nom propre d'une famille de vérifications
                errors.append(f"[LAN-01] mot anglais « {m.group(0)} » dans {rr.nom(path)}:{i} : écrire « "
                              f"{ANGLAIS_REMPLACES[mot]} » (liste close des mots remplacés)")
    texte = (ROOT / "guides" / "glossaire.md").read_text(encoding="utf-8") if glossaire is None else glossaire
    tetes = {cell(l.split("|")[1]).split(" (")[0] for l in texte.splitlines() if l.startswith("|") and l.count("|") > 2}
    for mot in ANGLAIS_GARDES:
        if mot not in tetes:
            errors.append(f"[LAN-01] mot anglais gardé « {mot} » sans ligne au glossaire (liste close des mots gardés)")


def check_register(errors: list[str], files: list[Path] | None = None) -> None:
    for path in textes_personnes() if files is None else files:
        for i, line in enumerate(sans_code(path.read_text(encoding="utf-8"))):
            m = PRONOM_TU.search(line)
            if m:
                errors.append(f"[VOU-01] registre : pronom de la deuxième personne du singulier « {m.group(0)} » "
                              f"dans {rr.nom(path)}:{i + 1} (les textes pour les personnes vouvoient)")
    for name in REGISTER_FILES:
        for i, line in enumerate(lignes(name)):
            m = TUTOIEMENT.search(line)
            if m:
                errors.append(f"registre (liste close) : tutoiement « {m.group(0)} » dans {name}:{i + 1}")


def check_noyau(corpus: dict[Path, list[str]], errors: list[str]) -> None:
    seen: dict[str, str] = {}
    for path, lines in corpus.items():
        open_id = None
        for i, line in enumerate(lines):
            m = NOYAU_MARK.match(line.strip())
            if not m:
                continue
            if rr.famille_de(path, i) not in rr.FAMILLES:
                errors.append(f"noyau : balise hors d'une route ({rr.nom(path)}:{i + 1})")
                continue
            kind, bid = m.groups()
            if kind == "début":
                if open_id:
                    errors.append(f"noyau : {bid} ouvert dans {open_id} ({rr.nom(path)}:{i + 1})")
                if bid in seen:
                    errors.append(f"noyau : bloc {bid} défini deux fois ({seen[bid]} et {rr.nom(path)})")
                seen[bid] = rr.nom(path)
                open_id = bid
            else:
                if bid != open_id:
                    errors.append(f"noyau : fin {bid} sans début ({rr.nom(path)}:{i + 1})")
                open_id = None
        if open_id:
            errors.append(f"noyau : bloc {open_id} non fermé ({rr.nom(path)})")
    try:
        raw = bc.SKILL.read_bytes()
        bc.check_budget(raw)
        skill = raw.decode("utf-8")
        if bc.render(skill, bc.compile_core()) != skill:
            errors.append("[NOY-02] noyau : la skill diffère de sa compilation (scripts/build_core.py)")
    except (bc.CoreError, OSError, UnicodeError) as exc:
        errors.append(f"noyau : {exc}")


def load_row(lines: list[str], mode: str) -> str:
    rows = [l for l in lines if l.startswith(f"| **{mode}** |")]
    return rows[0] if len(rows) == 1 else ""


def check_load(corpus: dict[Path, list[str]], errors: list[str]) -> None:
    for path, lines in corpus.items():
        for i, line in enumerate(lines):
            if LOAD_HEADERS.match(line) and path.name != "SKILL.md" and rr.famille_de(path, i) != "DIRECTION":
                errors.append(f"[CHG-05] chargement : table de chargement hors DIRECTION/CHARGE ({rr.nom(path)}:{i + 1})")
    for name, prefix in LOAD_POINTERS:
        rows = [l for l in lignes(name) if l.startswith(prefix)]
        if rows and not all("`DIRECTION/CHARGE`" in r for r in rows):
            errors.append(f"[CHG-06] chargement : {name} redéfinit la liste « {prefix.strip('| *')} » au lieu de renvoyer à DIRECTION/CHARGE")
    try:
        path, lines, index = rr.resolve("DIRECTION/CHARGE")
    except rr.RouteError as exc:
        errors.append(f"chargement : DIRECTION/CHARGE introuvable ({exc})")
        return
    served = rr.extract(lines, index)
    body = "\n".join(served)

    def cells(mode: str) -> list[str]:
        r = load_row(served, mode)
        return [c.strip() for c in r.strip().strip("|").split("|")] if r else []
    d = cells("DIRECTION")
    first = d[1] if len(d) > 1 else ""
    vt, fo = first.find("`DIRECTION/VISUAL_TARGET`"), first.find("`DIRECTION/FIRST-OBJECT`")
    if "`ACTION/RUN-DIRECTION`" not in first or "`ACTION/FIRST-RENDER`" not in first or "`SAVOIR/TYPE`" not in first \
            or not (0 <= vt < fo):
        errors.append("[CHG-07] chargement : la ligne DIRECTION de DIRECTION/CHARGE doit charger RUN-DIRECTION, FIRST-RENDER "
                      "et SAVOIR/TYPE (U5), et placer VISUAL_TARGET avant FIRST-OBJECT")
    gb, tc = first.find("`ACTION/GATE-B`"), first.find("trace complète")
    if gb >= 0 and not (0 <= tc < gb):
        errors.append("[CHG-08] chargement : en DIRECTION, Gate B n'est chargée qu'en trace complète (ACTION/HANDOFF)")
    for mode in ("LITE", "ITER", "STANDARD", "DIRECTION", "SYSTÈME"):
        try:
            absentes = rr.bloquantes_hors_tronc(mode)
            _, total = rr.tronc_text(mode)
        except rr.RouteError as exc:
            errors.append(f"[CHG-09] chargement : tronc {mode} illisible ({exc})")
            continue
        if absentes:
            errors.append(f"[CHG-09] chargement : en {mode}, route bloquante hors du tronc ({', '.join(absentes)}) ; "
                          "le budget se règle sur l'explicatif, jamais sur une contrainte bloquante")
        if total > rr.TRONC_BUDGET:
            errors.append(f"[CHG-10] chargement : tronc {mode} à {total} caractères, au-delà du budget de {rr.TRONC_BUDGET}")
    if "`ACTION/CLOSE-PACKAGE`" not in body or any("Clôture" in l for l in served if l.startswith("| Mode |")):
        errors.append("[CHG-01] chargement : la clôture de chaque mode renvoie à ACTION/CLOSE-PACKAGE, sans colonne de clôture")
    lite = cells("LITE")
    if len(lite) < 3 or "`ITER`" not in lite[2]:
        errors.append("[CHG-02] chargement : depuis LITE, la reclassification inclut ITER")
    sysm = cells("SYSTÈME")
    if len(sysm) < 2 or "`BIBLIOTHEQUE/COMPONENTS` si un composant change" not in sysm[1]:
        errors.append("[CHG-03] chargement : en SYSTÈME, BIBLIOTHEQUE/COMPONENTS seulement si un composant change")
    for mode in ("LITE", "ITER"):
        c = cells(mode)
        if len(c) < 2 or "`ACTION/GATE-A" not in c[1] or "ACTION/GATE-B" not in c[1]:  # sous-routes admises
            errors.append(f"[CHG-04] chargement : en {mode}, Gate A applicable et Gate B du risque sont chargés d'abord")


def check_order(errors: list[str]) -> None:
    first = [bid for _, items in bc.NOYAU for bid in items][:len(ORDER)]
    if tuple(first) != ORDER:
        errors.append(f"[ORD-01] ordre du noyau : {', '.join(ORDER)} doivent l’ouvrir (trouvé : {', '.join(first)})")
    for path in rr.regles():
        lines = path.read_text(encoding="utf-8").splitlines()
        for i, line in enumerate(lines):
            m = NOYAU_MARK.match(line.strip())
            if m and m.group(1) == "début" and m.group(2) in ORDER and rr.famille_de(path, i) != "DIRECTION":
                errors.append(f"[ORD-01] bloc {m.group(2)} hors d’une route DIRECTION ({rr.nom(path)}:{i + 1})")


# Ce que la section compilée de la skill doit porter
CORE_FLOOR = [("python3 scripts/read_route.py --mode MODE", "activation de la ligne propriétaire de DIRECTION/CHARGE"),
              ("`SAVOIR/TOOLS/CONVERGENCE`", "activation conditionnelle des observations datées"),
              ("`SAVOIR/TOOLS/MOYENS`", "activation conditionnelle des ressources par rôle"),
              ("python3 scripts/read_route.py --trouver", "recherche conditionnelle de savoir dans CHARGE"),
              ("sans conclure à l’absence du savoir", "limite de la recherche littérale dans CHARGE"),
              ("Conçois une palette par rôles", "plancher couleur de SAVOIR/CRAFT/CFT-05"),
              ("Choisis une typographie pour ses langues", "plancher typographique de SAVOIR/TYPE"),
              ("`ACTION/ATELIER-EDITION`", "activation de l'atelier d'édition dans son scope"),
              ("fonctions, intégrations et conformités affirmées", "fonctions d'un produit fictif marquées"),
              ("sauf avec `--allow-external`", "recette check_render et son blocage externe par défaut"),
              ("où va l’œil en premier", "revue sur capture en quatre questions, grille de travail en trace légère"),
              ("ouvre Gate C (`ACTION/GATE-C`)", "activation de Gate C par la revue sur capture"),
              ("aussi à 390 px pour un produit d’abord mobile", "esquisses comparées aussi en mobile pour un produit d’abord mobile"),
              ("`python3 scripts/parcours.py trace FICHIER`", "contrôle de la forme de la trace légère")]


def check_core_floor(errors: list[str]) -> None:
    text = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
    core = text[text.find("<!-- noyau:compilé début -->"):text.find("<!-- noyau:compilé fin -->")]
    for needle, label in CORE_FLOOR:
        if needle not in core:
            errors.append(f"[CORE-01] noyau : {label} absent de la section compilée")


# 16. En-tête de la skill () : métadonnées YAML lisibles par un hôte, sans dépendance tierce.
# Sous-ensemble contrôlé : une paire « clé: valeur » par ligne ; une valeur non citée ne porte ni « : », ni « # »
# précédé d'une espace, ni indicateur initial ; une valeur citée est décodée (doubles : échappements JSON ; simples : '').
SKILL_KEYS = ("name", "description")
# Format ouvert Agent Skills (agentskills.io/specification) : champs connus et contraintes de longueur et de nom.
SKILL_ALLOWED_KEYS = {"name", "description", "license", "compatibility", "allowed-tools", "metadata"}
SKILL_LIMITS = {"name": 64, "description": 1024, "compatibility": 500}
PLAIN_FORBIDDEN_START = tuple("[]{}#&*!|>'\"%@`,") + ("- ", "? ", ": ")
# Scalaires non cités qu'un parseur YAML (1.1 ou 1.2) ne lit pas comme une chaîne : nul, booléen, nombre, date.
PLAIN_NON_STRING = re.compile(
    r"(?:~|null|Null|NULL|true|True|TRUE|false|False|FALSE|yes|Yes|YES|no|No|NO|on|On|ON|off|Off|OFF"
    r"|[-+]?(?:\d[\d_]*)?\.?\d+(?:[eE][-+]?\d+)?|0x[0-9a-fA-F]+|0o[0-7]+|[-+]?\.(?:inf|Inf|INF)|\.(?:nan|NaN|NAN)"
    r"|[-+]?\d+(?::[0-5]?\d)+(?:\.\d*)?|\d{4}-\d\d?-\d\d?(?:[Tt ].*)?)")


def _scalar(key: str, raw: str, problems: list[str]) -> str | None:
    """Valeur scalaire textuelle du sous-ensemble YAML contrôlé ; None si refusée (problème noté)."""
    if raw.startswith('"'):
        try:
            value = json.loads(raw)
        except json.JSONDecodeError:
            problems.append(f"{key} : chaîne entre guillemets doubles mal formée")
            return None
        if not isinstance(value, str):
            problems.append(f"{key} : chaîne entre guillemets doubles mal formée")
            return None
        return value
    if raw.startswith("'"):
        if len(raw) < 2 or not raw.endswith("'") or "'" in raw[1:-1].replace("''", ""):
            problems.append(f"{key} : chaîne entre guillemets simples mal formée")
            return None
        return raw[1:-1].replace("''", "'")
    if raw.startswith(PLAIN_FORBIDDEN_START) or ": " in raw or " #" in raw or raw.endswith(":"):
        problems.append(f"{key} : valeur non citée contenant « : », « # » ou un indicateur YAML (citer la valeur)")
        return None
    if PLAIN_NON_STRING.fullmatch(raw):
        problems.append(f"{key} : valeur non citée lue en YAML comme nul, booléen, nombre ou date, pas comme texte (citer la valeur)")
        return None
    return raw


def skill_header(text: str) -> tuple[dict[str, str], list[str]]:
    """Champs de l'en-tête. `metadata` (table de textes, format Agent Skills) est admis en style bloc
    (clés indentées) ou en ligne (`{clé: valeur, …}`) ; ses entrées textuelles sont vérifiées."""
    lines = text.splitlines()
    if not lines or lines[0] != "---" or "---" not in lines[1:]:
        return {}, ["en-tête YAML absent (--- en première ligne, puis ---)"]
    values: dict[str, str] = {}
    problems: list[str] = []
    metadata: dict[str, str] | None = None  # table en cours de lecture (style bloc)
    for number, line in enumerate(lines[1:lines.index("---", 1)], start=2):
        if line.startswith("  ") and metadata is not None:
            key, sep, raw = line.strip().partition(":")
            if not sep or not re.fullmatch(r"[A-Za-z0-9_.-]+", key) or not raw.startswith(" "):
                problems.append(f"ligne {number} : entrée « clé: valeur » attendue dans metadata")
                continue
            value = _scalar(f"metadata.{key}", raw[1:].rstrip(), problems)
            if value is not None:
                metadata[key] = value
            continue
        metadata = None
        key, sep, raw = line.partition(":")
        if not sep or not re.fullmatch(r"[a-z][a-z0-9_-]*", key) or not (raw.startswith(" ") or (key == "metadata" and not raw)):
            problems.append(f"ligne {number} : paire « clé: valeur » attendue")
            continue
        raw = raw[1:].rstrip() if raw else ""
        if key in values:
            problems.append(f"{key} : clé répétée")
        if key == "metadata":
            entries: dict[str, str] = {}
            if not raw:
                metadata = entries
            elif raw.startswith("{") and raw.endswith("}"):
                for item in filter(None, (part.strip() for part in raw[1:-1].split(","))):
                    name, sep, val = item.partition(":")
                    if not sep or not re.fullmatch(r"[A-Za-z0-9_.-]+", name.strip()) or not val.startswith(" "):
                        problems.append(f"metadata : entrée « clé: valeur » attendue ({item})")
                        continue
                    value = _scalar(f"metadata.{name.strip()}", val[1:].strip(), problems)
                    if value is not None:
                        entries[name.strip()] = value
            else:
                problems.append("metadata : table de textes attendue (clés indentées ou {clé: valeur})")
            values[key] = "table"
            continue
        value = _scalar(key, raw, problems)
        if value is not None:
            values[key] = value
    return values, problems


def check_skill_header(errors: list[str]) -> None:
    path = SKILL_DIR / "SKILL.md"
    if not path.is_file():
        errors.append("[SKL-01] SKILL.md absent")
        return
    values, problems = skill_header(path.read_text(encoding="utf-8"))
    for problem in problems:
        errors.append(f"[SKL-01] en-tête de la skill : {problem}")
    for key in SKILL_KEYS:
        if not values.get(key, "").strip() and not any(problem.startswith(f"{key} :") for problem in problems):
            errors.append(f"[SKL-01] en-tête de la skill : champ {key} absent ou vide")
    if values.get("name") and values["name"] != "design-governance-practice":
        errors.append(f"[SKL-01] en-tête de la skill : name « {values['name']} » ≠ design-governance-practice")
    if values.get("name") and not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", values["name"]):
        errors.append("[SKL-01] en-tête de la skill : name hors du format Agent Skills (minuscules, chiffres, tirets simples)")
    for key in sorted(set(values) - SKILL_ALLOWED_KEYS):
        errors.append(f"[SKL-01] en-tête de la skill : champ {key} inconnu du format Agent Skills")
    for key, limit in SKILL_LIMITS.items():
        if key in values and len(values[key]) > limit:
            errors.append(f"[SKL-01] en-tête de la skill : {key} dépasse {limit} caractères ({len(values[key])})")


# 17. Déclencheur UI/UX () : dans DIRECTION/CHARGE, la colonne « Charger d'abord » des lignes
# STANDARD et DIRECTION appelle ACTION/UI-UX-REALITY pour une surface UI/UX nouvelle ou substantiellement modifiée ;
# la ligne LITE ne l'appelle pas (un delta local n'est pas une surface nouvelle).
UI_TRIGGER = "`ACTION/UI-UX-REALITY` si la surface UI/UX est nouvelle ou substantiellement modifiée"


def check_ui_trigger(errors: list[str]) -> None:
    source = texte("DIRECTION")
    start = source.find("## DIRECTION/CHARGE")
    skill = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
    core = skill[skill.find("<!-- noyau:compilé début -->"):skill.find("<!-- noyau:compilé fin -->")]
    if "python3 scripts/read_route.py --mode MODE" not in core:
        errors.append("[UIX-01] noyau compilé : la ligne propriétaire du mode n'est pas activée")
    places = [("CHARGE", source[start:source.find("\n## ", start + 1)] if start >= 0 else "")]
    for place, section in places:
        rows = {line.split("|")[1].strip(): line.split("|") for line in section.splitlines() if line.startswith("| **")}
        for mode in ("**STANDARD**", "**DIRECTION**"):
            cells = rows.get(mode)
            if not cells or UI_TRIGGER not in cells[2]:
                errors.append(f"[UIX-01] {place} : la ligne {mode.strip('*')} ne charge pas ACTION/UI-UX-REALITY avant fabrication")
        if "UI-UX-REALITY" in "|".join(rows.get("**LITE**", [])):
            errors.append(f"[UIX-01] {place} : la ligne LITE appelle ACTION/UI-UX-REALITY (delta local)")


# 18. Façades  : lignes de table, sections et liens que les façades doivent porter.
ROW_NEEDLES = [  # (fichier, début de ligne, mot attendu, raison)
    ("guides/glossaire.md", "| **Mode** |", "se choisit à part", "le mode se choisit sans être demandé"),
    ("guides/glossaire.md", "| **Run** |", "proposition", "un run livre une proposition"),
    ("guides/glossaire.md", "| **Trace légère** |", "plafond atteint, essais par couche et contenus marqués", "forme de la trace légère"),
    ("guides/glossaire.md", "| **Plafond** |", "après avoir essayé", "un plafond se déclare après essai"),
    ("guides/glossaire.md", "| **Livraison** |", "point de contrôle", "une livraison est un point de contrôle"),
    ("guides/2-comprendre.md", "| **Agent contrôlé** |", "trace complète", "un agent contrôlé tient une trace complète"),
    ("DIRECTION", "| Décision suffisamment établie |", "trace légère", "une décision établie se trace en trace légère"),
    ("DIRECTION", "| **STANDARD** |", "DIRECTION/DOMAIN-FRAME", "cadre de domaine chargé par ce mode"),
    ("DIRECTION", "| **DIRECTION** |", "DIRECTION/DOMAIN-FRAME", "cadre de domaine chargé par ce mode"),
    ("DIRECTION", "| Détail final susceptible", "selon la question ouverte", "chargement selon la question ouverte"),
    ("DIRECTION", "| Token, composant partagé, theming ou blast radius |", "si un composant change", "chargement seulement si un composant change"),
]
EXAMPLE_SECTION = "## DIRECTION — fabrication depuis un brief flou"
COMMENCER = re.compile(r"\]\((?:\.\./)*(?:guides/)?1-utiliser\.md#commencer\)")


def check_facades(errors: list[str]) -> None:
    for name, prefix, needle, origin in ROW_NEEDLES:
        try:
            rows = [line for line in lignes(name) if line.startswith(prefix)]
        except FileNotFoundError:
            rows = []
        if len(rows) != 1 or needle not in rows[0]:
            errors.append(f"[FAC-01] {name} : ligne « {prefix} » absente, multiple ou sans « {needle} » ({origin})")
    examples = SKILL_DIR / "references" / "examples.md"
    text = examples.read_text(encoding="utf-8") if examples.is_file() else ""
    start = text.find(EXAMPLE_SECTION)
    section = text[start:text.find("\n## ", start + 1)] if start >= 0 else ""
    if not section or "Trace (trace légère" not in section or "PROCHAINE PREUVE" not in section:
        errors.append("[FAC-01] examples.md : la fabrication depuis un brief flou ne montre pas sa trace légère")
    if re.search(r"boulangerie", section, re.I):
        errors.append("[FAC-01] examples.md : exemple dans le domaine du brief de référence")
    for name in ("README.md", "guides/3-maitriser.md"):
        if (ROOT / name).is_file() and not COMMENCER.search(texte(name)):
            errors.append(f"[FAC-01] {name} : la section « Commencer » du niveau 1 des guides n'est pas liée")
    guide = ROOT / "guides" / "1-utiliser.md"
    if not guide.is_file() or "## Commencer" not in guide.read_text(encoding="utf-8"):
        errors.append("[FAC-01] niveau 1 des guides : titre « Commencer » absent, cible des liens")
    notes = ROOT / "RELEASE_NOTES.md"
    if notes.is_file():
        body = notes.read_text(encoding="utf-8")
        if "lire README et QUICKSTART" in body:
            errors.append("[FAC-01] RELEASE_NOTES : ancien parcours d'agent présenté comme courant")
        # Les notes de version déclarent l'efficacité non vérifiée, l'absence de mesure comparative et la
        # frontière de ce que le validateur atteste.
        for needle in ("**Efficacité : `NOT-VERIFIED`.**", "Aucune mesure comparative", "## Ce que le validateur atteste"):
            if needle not in body:
                errors.append(f"[FAC-01] RELEASE_NOTES : « {needle} » absent")


# 19. Atteignabilité : une règle qu'aucune route ne sert et que le noyau ne porte pas n'atteint jamais l'agent.
ZONE = re.compile(r"^<!-- orientation:(début|fin) -->$")
# Les sections de maintenance (`maintenance/`) se lisent par leur fichier ; leurs routes restent servies par le lecteur.
LUS_PAR_FICHIER = ("maintenance/",)


def unreachable_lines(path: Path) -> list[int]:
    """Numéros (base 1) des lignes d'un fichier de règles qu'aucune route ne sert et qu'aucun bloc compilé ne porte,
    hors de l'en-tête (titre et introduction, jusqu'au premier titre suivant) et des zones `orientation:`."""
    lines = path.read_text(encoding="utf-8").splitlines()
    heads = rr.headings(lines)
    served = set()
    for start, end, _ in rr.blocs_de_route(lines, heads):
        served.update(range(start, end))
    header_end = next((i for i, _, _ in heads if i > 0), len(lines))
    out, zone, block = [], False, None
    for i, line in enumerate(lines):
        s = line.strip()
        z = ZONE.match(s)
        if z:
            zone = z[1] == "début"
            continue
        n = NOYAU_MARK.match(s)
        if n:
            block = n[2] if n[1] == "début" else None
            continue
        if (i < header_end or not s or s == "---" or s.startswith(("#", "<!--")) or zone
                or i in served or (block and (block in bc.COMMUN or block in bc.DETAILS))):
            continue
        out.append(i + 1)
    return out


def check_reachability(errors: list[str]) -> None:
    for path in rr.regles():
        if rr.nom(path).startswith(LUS_PAR_FICHIER):
            continue
        found = unreachable_lines(path)
        if not found:
            continue
        ranges, start = [], found[0]
        for a, b in zip(found, found[1:] + [None]):
            if b != a + 1:
                ranges.append(f"{start}" if start == a else f"{start}-{a}")
                start = b
        errors.append(f"[ATT-01] lignes de règle servies par aucune route ni par le noyau : {rr.nom(path)}:{', '.join(ranges)}")


# Garde 20 : plancher de chaque obligation [REQUIS], repérée par son scope.
# ("noyau", bloc) : le bloc est compilé à chaque run ; ("tronc", route, modes) : la route est lue à chaque run de ces modes.
PLANCHERS: dict[str, tuple] = {
    "surface identitaire, hiérarchie complexe ou revue perceptuelle": ("noyau", "COMP-CONTROLES"),
    "couleur, thème, statut ou surface identitaire": ("noyau", "COMP-COULEUR"),
    "lecture, ton, données, hiérarchie ou surface identitaire": ("noyau", "COMP-TYPO"),
    "surface `DIRECTION`": ("noyau", "ANCRE"),
    "claim qui influence une décision, un seuil, une route, une tendance ou un livrable": ("noyau", "CHARGE-DETAILS"),
    "toute tâche de surface ; une ligne compacte peut suffire en LITE uniquement si le changement est réellement local":
        ("noyau", "FND-CADRAGE"),
    "composant, état, surface `DIRECTION` ou Gate C": ("noyau", "STATE-PLANCHER"),
    "premier écran, identité ou scène d’une surface `DIRECTION` dont la décision visuelle est ouverte ; pas pour un correctif local":
        ("noyau", "DIR-LEVIERS"),
    "surface `DIRECTION`, ou surface `STANDARD` ou `ITER` dont la décision visuelle est ouverte": ("noyau", "DIR-DECLARATION"),
    "avant verdict `DIRECTION` ou lorsqu’une règle risque d’être satisfaite dans la forme": ("noyau", "INTEG-RECITATION"),
    "capacité incertaine, direction ambiguë, asset critique ou besoin de second regard": ("noyau", "INTEG-LIMITES"),
    "blast radius partagé, token ou primitive": ("tronc", "SAVOIR/SYSTEM", ("SYSTÈME",)),
    "contrôle applicable dans ACTION": ("tronc", "ACTION/GATE-A/CONTROLES", ("LITE", "ITER", "STANDARD", "DIRECTION", "SYSTÈME")),
}
# Les légendes citent le tag entre accents graves (`[REQUIS PAR LE MODULE — scope]`) : elles ne sont pas des obligations.
REQUIS = re.compile(r"(?<!`)\[REQUIS PAR LE MODULE — ([^\]]+)\]")


def obligations() -> dict[str, list[str]]:
    """Scope → lieux (fichier:ligne) des obligations [REQUIS] des sources normatives, hors blocs de code."""
    found: dict[str, list[str]] = {}
    for path in rr.sources_normatives():
        if not path.is_file():
            continue
        for i, line in rr.non_code_lines(path.read_text(encoding="utf-8").split("\n")):
            for m in REQUIS.finditer(line):
                found.setdefault(m.group(1), []).append(f"{rr.nom(path)}:{i + 1}")
    return found


def check_floors(errors: list[str], planchers: dict[str, tuple] | None = None) -> None:
    planchers = PLANCHERS if planchers is None else planchers
    found = obligations()
    for scope, places in sorted(found.items()):
        if scope not in planchers:
            errors.append(f"[REQ-01] obligation sans plancher inscrit : [REQUIS PAR LE MODULE — {scope}] ({', '.join(places)})")
    for scope, floor in planchers.items():
        if scope not in found:
            errors.append(f"[REQ-01] plancher inscrit pour une obligation introuvable : « {scope} »")
            continue
        if floor[0] == "noyau":
            if floor[1] not in bc.COMMUN:
                errors.append(f"[REQ-01] plancher de « {scope} » : le bloc {floor[1]} n'est pas compilé dans le noyau")
        else:
            for mode in floor[2]:
                try:
                    tronc = rr.tronc_routes(mode)
                except rr.RouteError as exc:
                    errors.append(f"[REQ-01] plancher de « {scope} » : {exc}")
                    continue
                if floor[1] not in tronc:
                    errors.append(f"[REQ-01] plancher de « {scope} » : {floor[1]} absent du tronc {mode}")


# Garde 22 : l'accord avant une génération est dit là où se choisit la route de production (ACC-01).
def check_consent(errors: list[str]) -> None:
    try:
        _, lines, index = rr.resolve("DIRECTION/ASSET-ROUTE")
    except rr.RouteError as exc:
        errors.append(f"[ACC-01] DIRECTION/ASSET-ROUTE introuvable ({exc})")
        return
    served = " ".join(rr.extract(lines, index))
    if "accord de la personne" not in served or "ANCHOR-GENERATED" not in served:
        errors.append("[ACC-01] DIRECTION/ASSET-ROUTE ne dit pas que toute génération, ancre comprise, attend l’accord de la personne")


# Garde 23 : dimensions du registre reliées aux axes de CFT-02 (REG-01).
REGISTRE_NOYAU = re.compile(r"au moins deux dimensions du registre \(([^)]+)\)")


def table_rows(lines: list[str], header: str) -> list[list[str]]:
    start = next((i for i, l in enumerate(lines) if l.startswith(header)), None)
    if start is None:
        return []
    out = []
    for line in lines[start + 2:]:
        if not line.startswith("|"):
            break
        out.append([c.strip() for c in line.strip().strip("|").split("|")])
    return out


def check_register_axes(errors: list[str]) -> None:
    skill = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
    m = REGISTRE_NOYAU.search(skill)
    if not m:
        errors.append("[REG-01] noyau : liste des dimensions du registre introuvable (« au moins deux dimensions du registre (…) »)")
        return
    named = [d.strip() for d in m.group(1).split(",")]
    _, slines, sindex = rr.resolve("SAVOIR/STYLE")
    _, clines, cindex = rr.resolve("SAVOIR/CRAFT/CFT-02")
    styles = table_rows(rr.extract(slines, sindex), "| Dimension | Exemples | Question de décision | Axes de `CFT-02` |")
    axes = {r[0].split(", dont")[0] for r in table_rows(rr.extract(clines, cindex), "| Axe | Pôles possibles | Question utile |")}
    if not styles:
        errors.append("[REG-01] SAVOIR/STYLE : taxonomie sans colonne « Axes de `CFT-02` »")
        return
    for dim in named:
        if not any(r[0].lower().startswith(dim.lower()) for r in styles):
            errors.append(f"[REG-01] dimension du registre « {dim} » (noyau) absente de la taxonomie de SAVOIR/STYLE")
    for row in styles:
        cited = [a.strip() for a in row[3].split(",")] if len(row) > 3 else []
        unknown = [a for a in cited if a not in axes]
        if not cited or unknown:
            errors.append(f"[REG-01] SAVOIR/STYLE, « {row[0]} » : axes de CFT-02 absents ou inconnus ({', '.join(unknown) or 'vide'})")


# Garde 21 : une seule table signal → route. Seules `DIRECTION/CHARGE` et la table des signaux du noyau disent quoi
# charger au départ d'un run. Une table qui, dans une route, renvoie d'un critère à son propriétaire est un renvoi local :
# elle est reconnue à sa colonne (route à charger, route approfondie, savoir à approfondir) et doit être déclarée ici.
SIGNAL_HEADER = re.compile(r"^\|\s*(?:Signal|Situation|Question|Déclencheur)s?\s*\|\s*Routes?\b")
RENVOI_HEADER = re.compile(r"^\|.*\|\s*[^|]*(?:route à charger|[Rr]oute approfondie|savoir à approfondir)[^|]*\|", re.I)
RENVOIS_LOCAUX = {
    "ACTION/GATE-C": "chaque critère de craft renvoie au geste et à la route qui le traite, lus pendant Gate C",
    "SAVOIR/STATE": "chaque terme du vocabulaire perceptuel renvoie au savoir à approfondir, lu pendant la route",
    "SAVOIR/DESIGN-ATLAS": "chaque famille de design renvoie à sa route approfondie, lue pendant l'atlas",
}


def route_de(path: Path, index: int) -> str | None:
    """Code de la route la plus précise qui sert la ligne `index` du fichier."""
    around = [(len(ind), loc) for p, ind, loc in rr.route_blocks(strict=False)
              if p.resolve() == path.resolve() and index in ind]
    return min(around)[1] if around else None


def renvoi_tables() -> tuple[list[str], set[str]]:
    """(lieux non déclarés, routes déclarées trouvées) des tables de renvoi local."""
    undeclared, found = [], set()
    for source in rr.sources_normatives():
        for i, line in rr.non_code_lines(source.read_text(encoding="utf-8").split("\n")):
            if RENVOI_HEADER.match(line):
                route = route_de(source, i)
                if route in RENVOIS_LOCAUX:
                    found.add(route)
                else:
                    undeclared.append(f"{rr.nom(source)}:{i + 1} ({route or 'hors route'})")
    return undeclared, found


def signal_tables() -> list[str]:
    """Lieux (fichier:ligne) des en-têtes de table signal → route hors de DIRECTION/CHARGE."""
    path, lines, index = rr.resolve("DIRECTION/CHARGE")
    allowed = {(path.resolve(), i) for i, _ in rr.served_lines(lines, index)}
    found = []
    for source in rr.sources_normatives():
        if not source.is_file():
            continue
        for i, line in rr.non_code_lines(source.read_text(encoding="utf-8").split("\n")):
            if SIGNAL_HEADER.match(line) and (source.resolve(), i) not in allowed:
                found.append(f"{rr.nom(source)}:{i + 1}")
    return found


def check_signal_tables(errors: list[str]) -> None:
    for place in signal_tables():
        errors.append(f"[SIG-01] table signal → route hors de DIRECTION/CHARGE ({place}) : la table des signaux du noyau est la seule")
    undeclared, found = renvoi_tables()
    for place in undeclared:
        errors.append(f"[SIG-01] table de renvoi vers des routes non déclarée ({place}) : la retirer, ou la déclarer dans RENVOIS_LOCAUX avec sa raison")
    for route in sorted(set(RENVOIS_LOCAUX) - found):
        errors.append(f"[SIG-01] renvoi local déclaré pour {route}, mais aucune table de renvoi n'y est trouvée")


# [PRO-01] Matériau d'essai : aucun nom tiré des runs (brief, lieu, titre, citation) n'entre dans le paquet. La liste vit
# hors du paquet, dans le suivi du mainteneur ; la préparation la passe par la variable DG_NOMS_INTERDITS. Sans elle,
# le contrôle ne tourne pas, et le dit.
TEXTES_PRO = (".md", ".py", ".json", ".txt", ".sh", ".yml")


def noms_de_runs(textes: dict[str, str], noms: list[str]) -> list[str]:
    """Occurrences, en mots entiers, des noms tirés des runs dans les textes du paquet."""
    erreurs = []
    for nom in noms:
        motif = re.compile(r"(?<![\w-])" + re.escape(nom) + r"(?![\w-])", re.IGNORECASE)
        for chemin, texte in textes.items():
            m = motif.search(texte)
            if m:
                ligne = texte.count("\n", 0, m.start()) + 1
                erreurs.append(f"[PRO-01] nom tiré d'un run « {nom} » dans {chemin}:{ligne} : matériau d'essai, à remplacer par un exemple neutre")
    return erreurs


def check_noms_de_runs(errors: list[str]) -> None:
    import os
    source = os.environ.get("DG_NOMS_INTERDITS")
    if not source or not Path(source).is_file():
        return
    noms = [l.strip() for l in Path(source).read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
    manifeste = json.loads((ROOT / "scripts" / "package_manifest.json").read_text(encoding="utf-8"))
    liste = manifeste["local"] if not (ROOT / "scripts" / "build_distributions.sh").is_file() else manifeste["github"]
    textes = {f: (ROOT / f).read_text(encoding="utf-8", errors="replace") for f in liste
              if f.endswith(TEXTES_PRO) and (ROOT / f).is_file()}
    errors.extend(noms_de_runs(textes, noms))


def check() -> list[str]:
    errors: list[str] = []
    corpus = texts()
    check_concepts(corpus, errors)
    check_references(errors)
    check_retired(corpus, errors)
    check_fidelity(corpus, errors)
    check_glossary(errors)
    check_unique_rows(corpus, errors)
    check_register(errors)
    check_readability(errors)
    check_language(errors)
    check_noyau(corpus, errors)
    check_load(corpus, errors)
    check_order(errors)
    check_universal(corpus, errors)
    check_numeric_locators(errors)
    check_entry(corpus, errors)
    check_noms_de_runs(errors)
    check_maps(errors)
    check_core_floor(errors)
    check_skill_header(errors)
    check_ui_trigger(errors)
    check_facades(errors)
    check_reachability(errors)
    check_floors(errors)
    check_signal_tables(errors)
    check_consent(errors)
    check_register_axes(errors)
    return errors


def main() -> int:
    bad = rr.non_utf8(ROOT)  # encodage nommé avant toute lecture (arrêt, pas contrôle complet)
    if bad:
        print(f"STRUCTURE VALIDATION FAILED — Markdown non UTF-8 : {', '.join(bad)}")
        return 1
    errors = check()
    if errors:
        print("STRUCTURE VALIDATION FAILED — gardes de propriété")
        for e in errors:
            print(f"- {e}")
        return 1
    for mode in ("LITE", "ITER", "STANDARD", "DIRECTION", "SYSTÈME"):
        _, total = rr.tronc_text(mode)
        if total > rr.TRONC_BUDGET * 0.9:  # pour le mainteneur seulement ; le lecteur ne l'affiche plus à l'agent
            print(f"MARGE FAIBLE — tronc {mode} : {total} / {rr.TRONC_BUDGET} caractères ; un ajout s'y compense par un "
                  "allègement du même tronc, pas par une hausse du budget.")
    print(f"STRUCTURE VALIDATION PASSED — {len(CONCEPTS)} concepts, {len(REFERENCES)} renvois, "
          f"listes closes ({len(RETIRED)} vocabulaire(s) retiré(s), {len(FIDELITY)} résumé(s) fidèle(s)), "
          f"{len(GLOSSARY_TERMS)} termes de glossaire, lignes de table uniques, vouvoiement, lisibilité et langue des textes pour les personnes, "
          f"noyau compilé, chargement unique, règles servies par une route, {len(PLANCHERS)} obligations étiquetées "
          f"avec leur plancher (noyau ou tronc), une table de signaux "
          f"et {len(RENVOIS_LOCAUX)} renvois locaux déclarés ; la lecture effective n’est pas contrôlée")
    return 0


if __name__ == "__main__":
    sys.exit(main())
