#!/usr/bin/env python3
"""Témoins de régression : navigation réelle, références opérationnelles, façades, atteignabilité des règles,
planchers d'obligation et profil de capacités cohérent.

Ces tests n'établissent ni une compréhension utilisateur ni un gain esthétique.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import re
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import validate_design_governance as package
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "gouvernance" / "outils"))
import validate_run_card as cards
import validate_reading_map as reading_map
import validate_structure as structure
import read_route as routes

ROOT = Path(__file__).resolve().parents[1]


class MobilisationFacadeTests(unittest.TestCase):
    def setUp(self):
        self.texts = reading_map.load_texts()

    def assert_rejected(self, key, old, new, expected):
        texts = dict(self.texts)
        self.assertIn(old, texts[key], f"mutation impossible dans {key} : {old}")
        texts[key] = texts[key].replace(old, new, 1)
        errors = []
        with patch.object(reading_map, "load_texts", return_value=texts):
            reading_map.check_facades(errors)
        self.assertTrue(any(expected in error for error in errors), errors)

    def test_inheritance_cannot_become_non_applicability(self):
        self.assert_rejected("B", "conserve-la par héritage ou comme cas documentaire, avec sa source et sa justification.",
                             "conserve-la et justifie `N/A-JUSTIFIED`.", "LCF-51")

    def test_run_card_cannot_be_required_by_mode_alone(self):
        self.assert_rejected("G", "Son exigence dépend du niveau de trace et du mode ; une proposition en trace légère ne produit pas de RUN_CARD.",
                             "Elle est toujours exigée en STANDARD et DIRECTION.", "LCF-52")

    def test_domain_template_cannot_omit_risk_coverage(self):
        self.assert_rejected("D", "`required_controls`, `risk_coverage`, `depth_rules`", "`required_controls`, `depth_rules`", "LCF-53")

    def test_activation_cannot_disappear_from_compiled_core(self):
        self.assert_rejected("SK", "python3 scripts/read_route.py --connexions", "commande retirée", "LCF-54")

    def test_iter_cannot_capture_local_fix(self):
        self.assert_rejected('D','au-delà d’un fix ou delta local qui la conserve','y compris tout fix local','LCF-55')

    def test_tree_must_keep_iter_discriminant(self):
        self.assert_rejected('D','au-delà d’un fix ou delta local qui la conserve','quel que soit le delta','LCF-55')

    def test_persistence_cannot_erase_short_lite_exception(self):
        self.assert_rejected('A','sauf la forme courte LITE définie ci-dessus','sans exception','LCF-56')

    def test_glossary_cannot_make_complete_trace_always_structured(self):
        self.assert_rejected('G','La forme courte LITE définie par `ACTION/HANDOFF` est complète sans RUN_CARD','Toute trace complète exige une RUN_CARD','LCF-56')

    def test_compiled_trace_keeps_short_lite_exception(self):
        self.assert_rejected('SK','La forme courte LITE conserve une trace complète sans RUN_CARD','Toute clôture exige une RUN_CARD','LCF-56')

    def test_owner_and_scope_stay_due_in_full_trace(self):
        # A11 : la ligne RUN suffit en trace légère ; OWNER et SCOPE restent dus en trace complète.
        self.assert_rejected('D', 'En trace complète, `OWNER` et `SCOPE` ne sont jamais omis', '`OWNER` et `SCOPE` sont facultatifs', 'LCF-08')

    def test_brief_rule_stays_protected_when_loaded_by_reference(self):
        self.assert_rejected('D', 'Au plus trois demandes', 'Questionnaire sans limite', 'LCF-44')

    def test_first_object_rule_stays_protected_when_loaded_by_reference(self):
        self.assert_rejected('D', 'de préférence **codé**', 'décoratif par défaut', 'LCF-47')

    def test_missing_brief_relay_cannot_pass_as_a_shorter_skill(self):
        # Le bloc BRIEF est compilé (L2-09) : sans lui ni renvoi, la skill ne porte plus la règle.
        texts = dict(self.texts)
        for key in ('D', 'SK'):
            texts[key] = texts[key].replace('`DIRECTION/EXTERNAL-START`', 'renvoi retiré')
        self.assertTrue(reading_map.lcf_44(texts))
        texts['SK'] = texts['SK'].replace('Au plus trois demandes', 'Des demandes')
        self.assertFalse(reading_map.lcf_44(texts))

    def test_signal_table_keeps_gate_consequence_of_generic_motif(self):
        self.assert_rejected('D', 'conséquence de gate : `ACTION/ANTI-SLOP`', 'conséquence de gate : aucune', 'LCF-17')

    def test_signal_table_does_not_classify(self):
        self.assert_rejected('D', '| Structure ouverte | `BIBLIOTHEQUE/READ`', '| Structure ouverte | `ACTION/RUN-STANDARD`, `BIBLIOTHEQUE/READ`', 'LCF-06')

    def test_asset_treatment_rule_stays_at_its_current_owner(self):
        self.assert_rejected('S', '**Traitement des assets moyens.**', '**Règle supprimée.**', 'LCF-49')


class NavigationTests(unittest.TestCase):
    def check(self, text: str, extra: dict[str, str] | None = None) -> list[str]:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "README.md").write_text(text, encoding="utf-8")
            for name, content in (extra or {}).items():
                (root / name).write_text(content, encoding="utf-8")
            with patch.object(package, "ROOT", root):
                errors: list[str] = []
                package.check_links(errors)
                return errors

    def test_same_document_missing_section_refused(self):
        self.assertTrue(any("fragment Markdown introuvable" in e for e in self.check("# Entrée\n[aide](#absente)\n")))

    def test_invented_anchor_in_other_file_refused(self):
        """Une ancre inventée vers un fichier existant est refusée, la vraie est admise."""
        guide = "# Guide\n## Classer avant d’agir\n"
        self.assertTrue(any("fragment Markdown introuvable" in e
                            for e in self.check("# Entrée\n[voir](guide.md#classer-puis-agir)\n", {"guide.md": guide})))
        self.assertEqual(self.check("# Entrée\n[voir](guide.md#classer-avant-dagir)\n", {"guide.md": guide}), [])

    def test_same_document_existing_section_admitted(self):
        self.assertEqual(self.check("# Entrée\n[aide](#entrée)\n"), [])

    def test_code_example_is_not_a_destination(self):
        text = "# Entrée\n```md\n## Section fictive\n```\n[aide](guide.md#section-fictive)\n"
        self.assertTrue(any("fragment Markdown introuvable" in e for e in self.check(text, {"guide.md": text})))

    def test_nested_code_example_is_not_a_destination(self):
        text='# Entrée\n````md\n```\n## Faux\n```\n````\n[aide](#faux)\n'
        self.assertTrue(any('fragment Markdown introuvable' in e for e in self.check(text)))

    def test_formatted_heading_uses_visible_text(self):
        self.assertEqual(self.check("# `État` : _d’abord_ !\n[aide](#état--dabord-)\n"), [])

    def test_duplicate_heading_suffix_admitted(self):
        self.assertEqual(self.check("# Entrée\n## Aide\n## Aide\n[deuxième](#aide-1)\n"), [])

    def test_duplicate_suffix_without_heading_refused(self):
        self.assertTrue(any("fragment Markdown introuvable" in e for e in self.check("# Aide\n[absente](#aide-1)\n")))

    def test_custom_html_anchor_admitted(self):
        self.assertEqual(self.check('# Entrée\n<a name="reprise"></a>\n[aide](#reprise)\n'), [])

    def test_encoded_fragment_admitted(self):
        self.assertEqual(self.check("# Entrée\n[aide](#entr%C3%A9e)\n"), [])

    def test_external_link_is_not_fetched(self):
        self.assertEqual(self.check("# Entrée\n[externe](https://example.invalid/#absente)\n"), [])

    def test_missing_file_still_refused(self):
        self.assertTrue(any("lien relatif cassé" in e for e in self.check("# Entrée\n[aide](absent.md#aide)\n")))


class OperationalReferenceTests(unittest.TestCase):
    def check(self, text, extra=None):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            files = {"README.md": text, **(extra or {})}
            for name, content in files.items():
                target = root / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding="utf-8")
            errors = []
            with patch.multiple(package, ROOT=root, EXPECTED=list(files)):
                package.check_inline_references(errors)
            return errors

    def test_deleted_changelog_reference_is_rejected(self):
        self.assertTrue(any("CHANGELOG.md" in e for e in self.check("Lire `CHANGELOG.md`.")))

    def test_retired_names_without_extension_are_rejected(self):
        for name in ("QUICKSTART", "GLOSSAIRE", "ORCHESTRATION_MAP"):
            with self.subTest(name=name):
                self.assertTrue(any(name in e for e in self.check(f"Lire `{name}`.")))
                self.assertTrue(any(name in e for e in self.check(f"Lire `{name}#section`.")))

    def test_supported_changelog_alias_and_symbolic_names_are_admitted(self):
        self.assertEqual(self.check("`CHANGELOG` ; `ACTION` ; `DIRECTION` ; `PASS` ; `CI`."), [])

    def test_common_extensions_missing_and_existing_files(self):
        for suffix in ("sh", "bash", "yml", "yaml", "html", "htm", "css", "js", "mjs", "cjs", "ts", "tsx", "jsx", "toml", "txt", "markdown"):
            with self.subTest(suffix=suffix):
                name = f"outils/controle.{suffix}"
                self.assertTrue(any(name in e for e in self.check(f"Lire `{name}`.")))
                self.assertEqual(self.check(f"Lire `{name}`.", {name: ""}), [])

    def test_declared_extensionless_file_is_checked(self):
        self.assertEqual(self.check("Lire `LICENSE`.", {"LICENSE": "Licence"}), [])
        with patch.multiple(package, EXPECTED=["README.md", "LICENSE"]):
            # Tester le manifeste sans créer le fichier déclaré.
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                (root / "README.md").write_text("Lire `LICENSE`.")
                errors = []
                with patch.object(package, "ROOT", root):
                    package.check_inline_references(errors)
                self.assertTrue(any("LICENSE" in e for e in errors))

    def test_shell_commands_check_scripts_and_ignore_user_arguments(self):
        for command in ("bash", "sh", "bash -n", "bash -eux", "bash --"):
            with self.subTest(command=command):
                text = f"Lancer `{command} scripts/test.sh chemin/saisie.json`."
                self.assertTrue(any("scripts/test.sh" in e for e in self.check(text)))
                self.assertEqual(self.check(text, {"scripts/test.sh": ""}), [])

    def test_python_flags_keep_script_and_route_checks(self):
        self.assertTrue(any("SAVOIR/FAUX" in e for e in self.check("`python3 -u ./scripts/read_route.py SAVOIR/FAUX`.",
                                                                 {"scripts/read_route.py": ""})))

    def test_modules_inline_code_and_complex_options_are_not_script_paths(self):
        for command in ("python3 -m http.server 4173", "python3 -c 'print(1)'", "bash -c 'echo scripts/absent.sh'", "bash -s argument-utilisateur", "bash --rcfile configuration.sh"):
            with self.subTest(command=command):
                self.assertEqual(self.check(f"`{command}`."), [])

    def test_new_reference_families_keep_example_and_fence_exemptions(self):
        self.assertEqual(self.check("`exemple: QUICKSTART` ; `exemple: scripts/absent.sh`\n```sh\nbash scripts/absent.sh\n```"), [])

    def test_shell_scope_uses_other_distribution_manifest(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"github": ["scripts/github.sh"], "local": []}):
            self.assertEqual(self.check("`bash scripts/github.sh` <!-- références:github -->"), [])
            self.assertTrue(self.check("`bash scripts/absent.sh` <!-- références:github -->"))

    def test_yaml_and_shell_file_scopes_remain_checked_in_local_export(self):
        for name in (".github/workflows/validate.yml", "scripts/build_distributions.sh"):
            with self.subTest(name=name), patch.multiple(package, IS_LOCAL=True, LISTS={"github": [name], "local": []}):
                self.assertEqual(self.check(f"GitHub : `{name}` <!-- références:github -->"), [])
                self.assertTrue(self.check(f"Lire `{name}`."))
                missing = str(Path(name).with_name("absent" + Path(name).suffix))
                self.assertTrue(self.check(f"`{missing}` <!-- références:github -->"))

    def test_moved_document_is_resolved_at_current_path(self):
        self.assertEqual(self.check("Lire `maintenance/versions.md`.", {"maintenance/versions.md": "# Versions"}), [])

    def test_relative_reference_and_unique_basename_are_supported(self):
        self.assertEqual(self.check("Lire `guides/3-maitriser.md` et `3-maitriser.md`.", {"guides/3-maitriser.md": "# Équipe"}), [])

    def test_ambiguous_basename_is_rejected(self):
        self.assertTrue(self.check("Lire `aide.md`.", {"guides/aide.md": "# A", "design/aide.md": "# B"}))

    def test_nonexistent_fragment_is_rejected(self):
        self.assertTrue(any("fragment opérationnel" in e for e in self.check("Lire `README.md#absent`.")))

    def test_existing_fragment_is_accepted(self):
        self.assertEqual(self.check("# Entrée\nLire `README.md#entrée`."), [])

    def test_operational_command_checks_its_script(self):
        self.assertTrue(any("scripts/absent.py" in e for e in self.check("Lancer `python3 scripts/absent.py chemin/run.json`.")))

    def test_user_argument_is_not_a_package_dependency(self):
        self.assertEqual(self.check("Lancer `python3 scripts/test.py chemin/run.json`.", {"scripts/test.py": ""}), [])

    def test_bad_readable_address_is_rejected(self):
        self.assertTrue(any("adresse lisible retirée" in e for e in self.check("Lire `savoir/section-absente`.")))

    def test_bad_route_in_command_is_rejected(self):
        self.assertTrue(any("DIRECTION/ABSENT" in e for e in self.check("Lancer `python3 scripts/read_route.py DIRECTION/ABSENT`.",
                                                                         {"scripts/read_route.py": ""})))

    def test_explicit_examples_fences_and_provenance_are_not_dependencies(self):
        self.assertEqual(self.check("`exemple: chemin/fiche.md`\n<!-- origine:CHANGELOG.md -->\n"
                                    "````md\n```\n`absent.md`\n```\n````\n"), [])

    def test_existing_directory_is_not_a_route(self):
        self.assertEqual(self.check("Les fichiers sont dans `gouvernance/schemas`.",
                                    {"gouvernance/schemas/a.json": "{}"}), [])

    def test_explicit_other_distribution_uses_its_manifest(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"github": ["scripts/github.py"], "local": []}):
            self.assertEqual(self.check("Dans GitHub : `python3 scripts/github.py`. <!-- références:github -->"), [])

    def test_scope_cannot_hide_an_undeclared_reference(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"github": [], "local": []}):
            self.assertTrue(self.check("`scripts/absent.py` <!-- références:github -->"))

    def test_unscoped_github_instruction_is_rejected_in_local_export(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"github": ["scripts/github.py"], "local": []}):
            self.assertTrue(self.check("Lancer `python3 scripts/github.py`."))

    def test_missing_scope_manifest_is_rejected_without_exception(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"local": []}):
            self.assertTrue(any("manifeste de la portée" in e for e in self.check("`scripts/github.py` <!-- références:github -->")))

    def test_reference_outside_package_is_rejected(self):
        self.assertTrue(self.check("Lire `../README.md`."))


class SourceLocationTests(unittest.TestCase):
    """Sans registre : chaque famille a des routes, et aucun reste du rangement par registre ne revient."""

    def check(self, marker=None, sections=False, family=True):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            body = "".join(f"## {p}/TEST — essai\nTexte.\n\n" for p in routes.FAMILLES if family or p != "SAVOIR")
            document = root / "design" / "source.md"
            document.parent.mkdir(parents=True)
            document.write_text((marker + "\n" if marker else "") + "# Source\n\nIntroduction.\n\n" + body, encoding="utf-8")
            if sections:
                (root / "sections").mkdir()
            errors = []
            with patch.multiple(package, ROOT=root, EXPECTED=["design/source.md"]), patch.multiple(routes, ROOT=root):
                package.check_source_locations(errors)
            return errors

    def test_clean_package_is_accepted(self):
        self.assertEqual(self.check(), [])

    def test_provenance_marker_is_rejected(self):
        for marker in ("<!-- origine:SAVOIR.md -->", "<!-- lieux:début -->"):
            with self.subTest(marker=marker):
                self.assertTrue(any("marqueur de rangement retiré" in e for e in self.check(marker=marker)))

    def test_sections_folder_is_rejected(self):
        self.assertTrue(any("dossier sections/" in e for e in self.check(sections=True)))

    def test_family_without_route_is_rejected(self):
        self.assertTrue(any("famille sans route : SAVOIR" in e for e in self.check(family=False)))


class GovernancePresentationTests(unittest.TestCase):
    def test_contextual_governance_is_allowed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "README.md").write_text("Une règle fait foi dans sa section propriétaire, qui porte un code stable. "
                                            "La gouvernance n’est pas toujours obligatoire ; elle s’adapte au contexte.")
            errors = []
            with patch.object(package, "ROOT", root):
                package.check_canonicity_language(errors)
            self.assertEqual(errors, [])

    def test_unconditional_exemption_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "design").mkdir()
            (root / "design/README.md").write_text("Le module de gouvernance peut s’ajouter ; il n’est jamais requis.")
            errors = []
            with patch.object(package, "ROOT", root):
                package.check_canonicity_language(errors)
            self.assertTrue(any("sans adaptation au contexte" in e for e in errors), errors)

    def test_unconditional_obligation_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "README.md").write_text("La gouvernance est toujours obligatoire.")
            errors = []
            with patch.object(package, "ROOT", root):
                package.check_canonicity_language(errors)
            self.assertTrue(any("sans adaptation au contexte" in e for e in errors), errors)


class CapabilityTests(unittest.TestCase):
    def setUp(self):
        self.document = cards.load_json(ROOT / "gouvernance/schemas/fixtures/valid_direction_exploratory_untransformed.json")
        self.schema = cards.load_json(ROOT / "gouvernance/schemas/run_card.schema.json")
        self.profile = {"available": ["inspection vectorielle"], "unavailable": ["navigateur/capture"],
                        "not_required": ["connexion bancaire"], "basis": [
                            {"capability": "inspection vectorielle", "kind": "tool_result", "detail": "Rasterisation du SVG et inspection du rendu."}]}

    def validate(self, profile):
        document = copy.deepcopy(self.document)
        document["run_card"]["capability_profile"] = profile
        cards.validate_card(document, self.schema)

    def test_disjoint_categories_admitted(self):
        self.validate(self.profile)

    def test_available_and_unavailable_refused(self):
        self.profile["unavailable"].append("inspection vectorielle")
        with self.assertRaisesRegex(cards.ValidationError, "plusieurs catégories"):
            self.validate(self.profile)

    def test_available_and_not_required_refused(self):
        self.profile["not_required"].append("inspection vectorielle")
        with self.assertRaisesRegex(cards.ValidationError, "plusieurs catégories"):
            self.validate(self.profile)

    def test_unavailable_and_not_required_refused(self):
        self.profile["not_required"].append("navigateur/capture")
        with self.assertRaisesRegex(cards.ValidationError, "plusieurs catégories"):
            self.validate(self.profile)

    def test_surrounding_spaces_do_not_hide_conflict(self):
        self.profile["unavailable"].append(" inspection vectorielle ")
        with self.assertRaisesRegex(cards.ValidationError, "plusieurs catégories"):
            self.validate(self.profile)

    def test_empty_availability_is_not_success_or_failure(self):
        self.validate({"available": [], "unavailable": ["navigateur/capture"], "not_required": [], "basis": []})


class StrictHostTests(unittest.TestCase):
    def test_demo_families_for_artifact_and_trace_without_network(self):
        schema = cards.load_json(ROOT / 'gouvernance/schemas/run_card.schema.json')
        baseline = cards.load_json(ROOT / 'gouvernance/schemas/run_card.example.json')
        baseline['run_card']['artifact']['locator'] = 'https://production.audit-project.test/page'
        baseline['run_card']['proof']['provenance']['artifact_locator'] = baseline['run_card']['artifact']['locator']
        baseline['run_card']['trace_locator'] = 'trace-audit-42'
        pair = baseline['run_card']['closure']['b1b']['pair']  # captures non locales : hors contrôle d'existence (C47)
        pair['before_locator'], pair['after_locator'] = ('https://production.audit-project.test/v1.png',
                                                         'https://production.audit-project.test/v1b.png')
        cards.validate_card(baseline, schema, strict=True)
        for field in ('artifact', 'trace'):
            for host, rejected in [('example.com', True), ('EXAMPLE.COM', True), ('www.example.com', True),
                                   ('example.com.', True), ('demo.example.invalid', True), ('other.invalid.', True),
                                   ('x.example.org.', True), ('www.example.net', True),
                                   ('example.org.evil.test', False), ('myexample.com', False),
                                   ('production.audit-project.test', False)]:
                with self.subTest(field=field, host=host):
                    document = copy.deepcopy(baseline)
                    locator = 'https://' + host + '/page'
                    if field == 'artifact':
                        document['run_card']['artifact']['locator'] = locator
                        document['run_card']['proof']['provenance']['artifact_locator'] = locator
                    else:
                        document['run_card']['trace_locator'] = locator
                    if rejected:
                        with self.assertRaisesRegex(cards.ValidationError, 'URL de démonstration interdite'):
                            cards.validate_card(document, schema, strict=True)
                    else:
                        cards.validate_card(document, schema, strict=True)


class CoreResourceActivationTests(unittest.TestCase):
    def test_compiled_resource_relays_cannot_disappear(self):
        skill = structure.SKILL_DIR / 'SKILL.md'
        original = skill.read_text()
        for locator in ('SAVOIR/TOOLS/CONVERGENCE', 'SAVOIR/TOOLS/MOYENS'):
            with self.subTest(locator=locator), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); (root / 'SKILL.md').write_text(original.replace('`' + locator + '`', 'relai retiré'))
                errors = []
                with patch.object(structure, 'SKILL_DIR', root):
                    structure.check_core_floor(errors)
                self.assertEqual(len(errors), 1, errors)
                self.assertIn('activation conditionnelle', errors[0])

    def test_dated_details_remain_reachable(self):
        for locator, expected in [('SAVOIR/TOOLS/CONVERGENCE', 'Signaux à confirmer'), ('SAVOIR/TOOLS/MOYENS', 'Typographie')]:
            with self.subTest(locator=locator):
                _, lines, index = routes.resolve(locator)
                self.assertIn(expected, '\n'.join(routes.extract(lines, index)))

    def test_writing_route_is_reachable_with_its_contract(self):
        # Écriture : route PILOT à contrat réduit, servie par son code, et citée par un lien dans les guides.
        _, lines, index = routes.resolve('SAVOIR/CRAFT/CFT-06')
        served = '\n'.join(routes.extract(lines, index))
        for fragment in ('Contrat réduit', 'Contre-indication', 'Limite', 'aucun gain mesuré'):
            self.assertIn(fragment, served)
        self.assertEqual(routes.code_du_lien('../design/savoir/qualite-creative.md#cft-06--écriture-et-contenu', routes.CARTE_SUJETS),
                         'SAVOIR/CRAFT/CFT-06')

    def test_package_names_no_third_party_skill(self):
        # Le système présente son propre contenu : aucune autre skill de design n'y est nommée ni citée comme source.
        manifest = json.loads((ROOT / 'scripts' / 'package_manifest.json').read_text(encoding='utf-8'))
        named = re.compile('ta' + r'ste[ -]?skill|' + 'leon' + 'xlnx', re.I)  # assemblé : ce fichier ne contient pas le nom
        for rel in manifest['github']:
            path = ROOT / rel
            if path.suffix in {'.md', '.py', '.json', '.html', '.txt', '.svg', '.yml'} and path.is_file():
                with self.subTest(file=rel):
                    self.assertIsNone(named.search(path.read_text(encoding='utf-8')))

    def test_setting_values_and_image_search_pilots_are_served_with_their_limits(self):
        # Valeurs de réglage `[À ADAPTER]` (grand texte, durées) et procédure d'images libres : servies par leur route, limites et source datée présentes.
        for locator, expected in [('SAVOIR/TYPE', ('Réglage d’un grand texte', 'À ADAPTER', 'non des mesures', 'Contre-indications')),
                                  ('SAVOIR/CONTEXT', ('Durées et courbes, points de départ', 'À ADAPTER', 'non des mesures', 'Contre-indications')),
                                  ('SAVOIR/SOURCE', ('Chercher le monde du sujet dans des collections ouvertes', 'Honnêteté', 'Droits', 'avis juridique'))]:
            with self.subTest(locator=locator):
                _, lines, index = routes.resolve(locator)
                served = '\n'.join(routes.extract(lines, index))
                for fragment in expected:
                    self.assertIn(fragment, served)

    def test_colour_relations_pilot_is_served_by_cft_05_with_its_limits(self):
        # Relations de couleur : sous-section de CFT-05 en PILOT ; la roue reste un vocabulaire, jamais une recette.
        _, lines, index = routes.resolve('SAVOIR/CRAFT/CFT-05')
        served = '\n'.join(routes.extract(lines, index))
        for fragment in ('Relations de couleur', 'La valeur d’abord', 'OKLCH', 'niveaux de gris', 'Fonds voisins',
                         'décrivent une palette ; elles n’en justifient pas une', 'Contre-indications', 'aucun gain démontré'):
            self.assertIn(fragment, served)

    def test_subject_inventory_pilot_and_substance_signal_are_served_by_their_routes(self):
        # Inventaire du sujet : sous-section de CFT-01 en PILOT, source datée ; substance : signal d'enquête de CFT-00, sans score.
        for locator, expected in [('SAVOIR/CRAFT/CFT-01', ('Inventaire du sujet et phrase d’idée', 'Test du concurrent', 'Contre-indication', 'aucun gain mesuré')),
                                  ('SAVOIR/CRAFT/CFT-00', ('Substance', 'sans seuil ni score', 'La retenue n’est pas le vide',
                                                           'qu’est-ce qui bouge sur cette surface', 'Aucun nombre d’éléments animés'))]:
            with self.subTest(locator=locator):
                _, lines, index = routes.resolve(locator)
                served = '\n'.join(routes.extract(lines, index))
                for fragment in expected:
                    self.assertIn(fragment, served)


class ReachabilityTests(unittest.TestCase):
    """Garde 19 (ATT-01) : une règle qu'aucune route ne sert et que le noyau ne porte pas est refusée."""

    def unreachable(self, text: str) -> list[int]:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "source.md"
            path.write_text(text, encoding="utf-8")
            return structure.unreachable_lines(path)

    def test_rule_outside_any_route_is_refused(self):
        text = ("# Titre\n\nIntroduction.\n\n## Section libre\n\nUne règle que rien ne sert.\n\n"
                "## DIRECTION/START — classer\n\nTexte servi.\n")
        self.assertEqual(self.unreachable(text), [7])

    def test_orientation_zone_is_admitted(self):
        text = ("# Titre\n\nIntroduction.\n\n<!-- orientation:début -->\n## Pour une personne\n\nOrientation.\n"
                "<!-- orientation:fin -->\n\n## DIRECTION/START — classer\n\nTexte servi.\n")
        self.assertEqual(self.unreachable(text), [])

    def test_compiled_core_block_is_reachable(self):
        text = ("# Titre\n\nIntroduction.\n\n## Rôle\n\n<!-- noyau:début ROLE -->\nTexte compilé dans le noyau.\n"
                "<!-- noyau:fin ROLE -->\n\nTexte qui ne l'est pas.\n")
        self.assertEqual(self.unreachable(text), [11])

    def test_maintenance_sections_are_read_by_their_file(self):
        text = "# Titre\n\nIntroduction.\n\n## ACTION/TEST — essai\n\nServi.\n\n## Cycle de vie\n\nLu par son fichier.\n"
        for folder, expected in (("maintenance", 0), ("design", 1)):
            with self.subTest(folder=folder), tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / folder / "x.md"
                path.parent.mkdir(parents=True)
                path.write_text(text, encoding="utf-8")
                errors = []
                with patch.multiple(routes, ROOT=Path(tmp)):
                    structure.check_reachability(errors)
                self.assertEqual(len(errors), expected, errors)

    def test_current_corpus_has_no_unreachable_rule(self):
        errors = []
        structure.check_reachability(errors)
        self.assertEqual(errors, [])


class FacadeSensitivityTests(unittest.TestCase):
    """L7-12 : chaque condition de façade tombe quand on lui retire son texte, ou quand on y ajoute le défaut qu'elle interdit."""

    # Conditions d'interdiction, vraies sur un texte vide par construction : leur mutation est un ajout ciblé.
    PROHIBITIONS = {"LCF-12", "LCF-13", "LCF-21", "LCF-22"}

    def setUp(self):
        self.texts = reading_map.load_texts()

    def failing(self, texts):
        errors = []
        with patch.object(reading_map, "load_texts", return_value=texts):
            reading_map.check_facades(errors)
        return {re.match(r"(LCF-[0-9A-Z]+)", e).group(1) for e in errors if re.match(r"LCF-", e)}

    def test_each_condition_falls_when_its_text_is_removed(self):
        source = (Path(reading_map.__file__)).read_text(encoding="utf-8")
        ids = set(re.findall(r"""\(["'](LCF-[0-9A-Z]+)["'],""", source))
        self.assertEqual(self.failing(dict(self.texts)), set())
        fallen = set()
        for key in self.texts:
            texts = dict(self.texts)
            texts[key] = ""
            fallen |= self.failing(texts)
        self.assertEqual(ids - fallen, self.PROHIBITIONS)

    def assert_added_defect_fails(self, key, addition, lcf_id):
        texts = dict(self.texts)
        texts[key] += "\n" + addition + "\n"
        self.assertIn(lcf_id, self.failing(texts))

    def test_reservation_without_conditions_fails(self):
        self.assert_added_defect_fails("EX", "```text\nVERDICT: ACCEPTED-WITH-RESERVATION\n```", "LCF-12")

    def test_not_observed_as_verdict_fails(self):
        self.assert_added_defect_fails("EX", "```text\nNOT-OBSERVED: rendu\n```", "LCF-13")

    def test_efficacy_claim_without_not_verified_fails(self):
        texts = dict(self.texts)
        texts["README"] = texts["README"].replace("NOT-VERIFIED", "vérifiée")
        self.assertIn("LCF-21", self.failing(texts))

    def test_decision_change_without_not_observed_fails(self):
        self.assert_added_defect_fails("A", "La conséquence `DECISION-CHANGE` vaut `N/A-JUSTIFIED` par défaut.", "LCF-22")


class SignalTableTests(unittest.TestCase):
    """Garde 21 (SIG-01) : la table des signaux du noyau est la seule table signal → route."""

    def test_current_corpus_has_one_signal_table(self):
        self.assertEqual(structure.signal_tables(), [])

    def test_second_signal_table_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            extra = Path(tmp) / "extra.md"
            extra.write_text("# X\n\n| Situation | Routes ciblées |\n|---|---|\n| Couleur | `SAVOIR/CRAFT` |\n", encoding="utf-8")
            with patch.object(structure.rr, "sources_normatives", return_value=structure.rr.sources_normatives() + [extra]):
                errors = []
                structure.check_signal_tables(errors)
        self.assertEqual(len(errors), 1, errors)
        self.assertIn("[SIG-01]", errors[0])


class WaveMarkerTests(unittest.TestCase):
    """VAG-01 : la liste datée des marqueurs est lue par une seule fonction, et chacun de ses noms est protégé ou déclaré."""

    def setUp(self):
        self.texte = routes.famille("SAVOIR")

    def test_current_list_is_covered(self):
        self.assertEqual(reading_map.couverture_marqueurs(self.texte), [])
        noms = [m["nom"] for m in routes.marqueurs_de_vague(self.texte)["marqueurs"]]
        self.assertIn("violet", noms)
        self.assertIn("bleu Klein", noms)

    def test_new_wave_must_be_protected_or_declared(self):
        ligne = next(l for l in self.texte.splitlines() if l.startswith("[VEILLE ") and "**Marqueurs de vague**" in l)
        ajoute = ligne.replace("Vague 3 :", "Vague 4 : néon pulsé. Vague 3 :", 1)
        erreurs = reading_map.couverture_marqueurs(self.texte.replace(ligne, ajoute))
        self.assertEqual(len(erreurs), 1, erreurs)
        self.assertIn("néon pulsé", erreurs[0])

    def test_missing_list_is_reported(self):
        self.assertIn("introuvable", reading_map.couverture_marqueurs("aucune liste")[0])


class FloorTests(unittest.TestCase):
    """Garde 20 (REQ-01) : chaque obligation [REQUIS] a son plancher dans le noyau ou dans le tronc des modes visés."""

    def test_current_corpus_has_a_floor_for_each_obligation(self):
        errors = []
        structure.check_floors(errors)
        self.assertEqual(errors, [])

    def test_unregistered_obligation_is_refused(self):
        planchers = dict(structure.PLANCHERS)
        planchers.pop("blast radius partagé, token ou primitive")
        errors = []
        structure.check_floors(errors, planchers)
        self.assertTrue(any("obligation sans plancher inscrit" in e and "systeme-de-design.md" in e for e in errors), errors)

    def test_floor_outside_core_or_trunk_is_refused(self):
        planchers = dict(structure.PLANCHERS)
        planchers["composant, état, surface `DIRECTION` ou Gate C"] = ("noyau", "COMP-VOCABULAIRE")  # bloc différé
        planchers["blast radius partagé, token ou primitive"] = ("tronc", "SAVOIR/SYSTEM", ("STANDARD",))
        errors = []
        structure.check_floors(errors, planchers)
        self.assertTrue(any("COMP-VOCABULAIRE n'est pas compilé" in e for e in errors), errors)
        self.assertTrue(any("SAVOIR/SYSTEM absent du tronc STANDARD" in e for e in errors), errors)

    def test_stale_entry_is_refused(self):
        planchers = dict(structure.PLANCHERS)
        planchers["scope disparu"] = ("noyau", "ANCRE")
        errors = []
        structure.check_floors(errors, planchers)
        self.assertTrue(any("obligation introuvable" in e for e in errors), errors)

    def test_legend_in_backticks_is_not_an_obligation(self):
        self.assertNotIn("scope", structure.obligations())


class ReviewFindingsTests(unittest.TestCase):
    """Témoins des défauts reproduits par la revue du système (carnet de revue, branche refonte)."""

    def test_skill_header_rejects_unquoted_non_string_scalars(self):
        # SC-03 : un scalaire non cité lu comme nul, booléen, nombre ou date n'est pas une description textuelle.
        for raw in ("null", "~", "true", "no", "123", "1.5", "0x1F", ".inf", "2026-10-14", "12:30"):
            with self.subTest(raw=raw):
                _, problems = structure.skill_header(f"---\nname: design-governance-practice\ndescription: {raw}\n---\n")
                self.assertTrue(any("nul, booléen, nombre ou date" in p for p in problems), problems)
        for raw in ('"null"', "v1.0", "1er octobre", "Produire un design situé"):
            with self.subTest(raw=raw):
                values, problems = structure.skill_header(f"---\nname: design-governance-practice\ndescription: {raw}\n---\n")
                self.assertEqual(problems, [])
                self.assertTrue(values["description"])

    def test_skill_header_follows_agent_skills_format(self):
        # Format ouvert Agent Skills : nom en minuscules et tirets, champs connus, longueurs bornées.
        cases = [("name: Design_Gov\ndescription: x", "hors du format Agent Skills"),
                 ("name: design-governance-practice\ndescription: x\nauteur: moi", "champ auteur inconnu"),
                 ("name: design-governance-practice\ndescription: " + "a" * 1100, "description dépasse 1024"),
                 ("name: design-governance-practice\ndescription: x\ncompatibility: " + "b" * 600, "compatibility dépasse 500")]
        for header, expected in cases:
            with self.subTest(expected=expected), tempfile.TemporaryDirectory() as tmp:
                (Path(tmp) / "SKILL.md").write_text(f"---\n{header}\n---\n", encoding="utf-8")
                errors = []
                with patch.object(structure, "SKILL_DIR", Path(tmp)):
                    structure.check_skill_header(errors)
                self.assertTrue(any(expected in e for e in errors), errors)

    def test_skill_header_accepts_agent_skills_metadata(self):
        # Format Agent Skills : metadata est une table de textes, en style bloc ou en ligne.
        accepted = ("metadata:\n  author: example-org\n  version: \"1.0\"", "metadata: {author: example-org, version: \"1.0\"}",
                    "license: Apache-2.0")
        for field in accepted:
            with self.subTest(field=field):
                _, problems = structure.skill_header(f"---\nname: design-governance-practice\ndescription: x\n{field}\n---\n")
                self.assertEqual(problems, [])
        _, problems = structure.skill_header("---\nname: design-governance-practice\ndescription: x\nmetadata:\n  version: 1.0\n---\n")
        self.assertTrue(any("metadata.version" in p for p in problems), problems)

    def generator(self, root: Path):
        shutil.copytree(ROOT / "supports", root / "supports", ignore=shutil.ignore_patterns("__pycache__"))
        (root / "scripts").mkdir()
        shutil.copy(ROOT / "scripts" / "package_manifest.json", root / "scripts" / "package_manifest.json")
        spec = importlib.util.spec_from_file_location("dg_supports_test", root / "supports" / "generer.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_support_relations_must_follow_the_drawing(self):
        # SV-01 : le dessin a une topologie fixe ; une relation modifiée dans le JSON ne peut pas diverger en silence.
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); module = self.generator(root)
            source = root / "supports" / "systeme.json"
            data = json.loads(source.read_text(encoding="utf-8"))
            data["relations"][0]["to"] = "maintenance"
            source.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "dessin fixe"):
                module.render_outputs()

    def test_support_version_comes_from_the_manifest(self):
        # SV-03 : toutes les cartes affichent la version du manifeste ; aucune carte n'en déclare une autre.
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = json.loads((ROOT / "scripts" / "package_manifest.json").read_text(encoding="utf-8"))
            self.generator(root)
            manifest["version"] = "9.9.9"
            (root / "scripts" / "package_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            spec = importlib.util.spec_from_file_location("dg_supports_test_v", root / "supports" / "generer.py")
            module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            outputs = module.render_outputs()
            svgs = [text for name, text in outputs.items() if name.endswith(".svg")]
            self.assertEqual(len(svgs), 8)  # quatre cartes, en clair et en sombre
            for text in svgs:
                self.assertIn("V9.9.9 expérimentale", text)
                self.assertNotIn("V1.0.0", text)
        self.assertNotIn("version", json.loads((ROOT / "supports" / "systeme.json").read_text(encoding="utf-8")))

    def test_equivalent_text_has_no_double_punctuation(self):
        # SV-02 : un titre déjà ponctué ne reçoit pas un second point.
        for name in ("systeme.md", "parcours.md", "boucle.md"):
            with self.subTest(name=name):
                self.assertNotIn(".**.", (ROOT / "supports" / name).read_text(encoding="utf-8"))



class TextConsistencyTests(unittest.TestCase):
    """Chaque correction de texte a sa garde, et chaque garde tombe sur le défaut qu'elle refuse."""

    def retired(self, line: str) -> list[str]:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "texte.md"
            path.write_text(line + "\n", encoding="utf-8")
            errors = []
            structure.check_retired({path: [line]}, errors)
            return errors

    def test_current_corpus_is_clean(self):
        errors = []
        corpus = structure.texts()
        structure.check_retired(corpus, errors)
        structure.check_fidelity(corpus, errors)
        structure.check_consent(errors)
        self.assertEqual(errors, [])

    def test_each_corrected_wording_is_refused_if_it_returns(self):
        for old in ("Après le build, vérifie : contrôle des huit dimensions du premier objet.",
                    "`RUN — [MODE] — [preuve suivante]`",
                    "Mode, risque principal, preuve minimale et condition d’arrêt.",
                    "Toute démonstration porte près de l’objet le marquage local `TRUTH/ILLUSTRATIVE`.",
                    "Les contrôles du package passent."):
            with self.subTest(old=old):
                self.assertTrue(self.retired(old), old)

    def test_software_package_keeps_its_name(self):
        self.assertEqual(self.retired("Une commande, un package ou une intégration cités dans une ressource."), [])

    def test_reuse_connection_cites_reuse(self):
        line = "**Sources.** `DIRECTION/FIRST-OBJECT` ; `BIBLIOTHEQUE/CONTRACTS` ; `SAVOIR/STYLE` ; `SAVOIR/SYSTEM` selon le choix repris."
        errors = []
        structure.check_fidelity({Path("connexions.md"): [line]}, errors)
        self.assertTrue(any("C05" in e for e in errors), errors)

    def test_consent_must_stay_in_asset_route(self):
        real = routes.extract

        def without(lines, index):
            body = real(lines, index)
            return [l.replace("accord de la personne", "avis") for l in body] if lines[index].startswith("### DIRECTION/ASSET-ROUTE") else body
        with patch.object(routes, "extract", side_effect=without):
            errors = []
            structure.check_consent(errors)
        self.assertTrue(any("ACC-01" in e for e in errors), errors)

    def test_contract_validator_speaks_french(self):
        import subprocess
        out = subprocess.run([sys.executable, str(ROOT / "gouvernance/outils/validate_contracts.py")],
                             capture_output=True, text=True, cwd=ROOT).stdout
        self.assertIn("CONTRACT VALIDATION PASSED — contrats de domaine", out)
        self.assertNotRegex(out, r"(?m): valid$|contracts$")



class OneOwnerTests(unittest.TestCase):
    """Renvois locaux déclarés (SIG-01) et dimensions du registre reliées à CFT-02 (REG-01)."""

    def test_current_corpus_is_clean(self):
        errors = []
        structure.check_signal_tables(errors)
        structure.check_register_axes(errors)
        self.assertEqual(errors, [])

    def test_undeclared_renvoi_table_is_refused(self):
        with patch.dict(structure.RENVOIS_LOCAUX, {}, clear=True):
            errors = []
            structure.check_signal_tables(errors)
        self.assertEqual(sum("non déclarée" in e for e in errors), 3, errors)

    def test_declared_renvoi_without_table_is_reported(self):
        with patch.dict(structure.RENVOIS_LOCAUX, {"SAVOIR/TYPE": "essai"}):
            errors = []
            structure.check_signal_tables(errors)
        self.assertTrue(any("SAVOIR/TYPE" in e and "aucune table" in e for e in errors), errors)

    def test_register_dimension_without_axes_is_refused(self):
        real = routes.extract

        def without(lines, index):
            body = real(lines, index)
            if lines[index].startswith("# SAVOIR/STYLE"):
                return [l.replace("| Temporalité |", "| |") for l in body]
            return body
        with patch.object(routes, "extract", side_effect=without):
            errors = []
            structure.check_register_axes(errors)
        self.assertTrue(any("Époque et culture" in e for e in errors), errors)

    def test_unknown_axis_is_refused(self):
        real = routes.extract

        def renamed(lines, index):
            body = real(lines, index)
            if lines[index].startswith("# SAVOIR/STYLE"):
                return [l.replace("| Mouvement |", "| Cinétique |") for l in body]
            return body
        with patch.object(routes, "extract", side_effect=renamed):
            errors = []
            structure.check_register_axes(errors)
        self.assertTrue(any("Cinétique" in e for e in errors), errors)



class CoreFloorTests(unittest.TestCase):
    """Ce qui doit arriver à l'agent reste au noyau compilé."""

    def floor_errors(self, old: str, new: str) -> list[str]:
        source = (structure.SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn(old, source)
        with tempfile.TemporaryDirectory() as tmp:
            skill_dir = Path(tmp)
            (skill_dir / "SKILL.md").write_text(source.replace(old, new), encoding="utf-8")
            with patch.object(structure, "SKILL_DIR", skill_dir):
                errors = []
                structure.check_core_floor(errors)
        return errors

    def test_current_core_carries_its_floor(self):
        errors = []
        structure.check_core_floor(errors)
        self.assertEqual(errors, [])

    def test_capture_review_cannot_leave_the_core(self):
        self.assertTrue(any("revue sur capture" in e for e in self.floor_errors("où va l’œil en premier", "regarde la page")))

    def test_gate_c_activation_cannot_leave_the_core(self):
        self.assertTrue(any("Gate C" in e for e in self.floor_errors("ouvre Gate C (`ACTION/GATE-C`)", "se note")))

    def test_mobile_sketches_cannot_leave_the_core(self):
        self.assertTrue(any("mobile" in e for e in self.floor_errors("aussi à 390 px pour un produit d’abord mobile", "au bureau")))


class HonestGuardsTests(unittest.TestCase):
    """Une garde dit ce qu'elle garantit ; une tournure nouvelle est refusée, pas seulement une phrase déjà vue."""

    def write(self, tmp: str, name: str, text: str) -> Path:
        path = Path(tmp) / name
        path.write_text(text, encoding="utf-8")
        return path

    def test_people_texts_keep_formal_address(self):
        errors = []
        structure.check_register(errors)
        self.assertEqual(errors, [])

    def test_second_person_is_refused(self):
        source = (ROOT / "guides" / "1-utiliser.md").read_text(encoding="utf-8")
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write(tmp, "1-utiliser.md", source + "\nTu peux choisir le mode toi-même.\n")
            errors = []
            structure.check_register(errors, [path])
        self.assertTrue(any("[VOU-01]" in e and "« Tu »" in e for e in errors), errors)

    def test_second_person_in_code_is_not_an_address(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write(tmp, "code.md", "Le mot `tu` cité.\n\n```text\ntu vois, t’as\n```\nLes outils et les tests restent.\n")
            errors = []
            structure.check_register(errors, [path])
        self.assertEqual(errors, [])

    def test_people_texts_are_readable_and_french(self):
        errors = []
        structure.check_readability(errors)
        structure.check_language(errors)
        self.assertEqual(errors, [])

    def test_long_cell_and_paragraph_are_refused(self):
        """LIS-01 : mutation rouge, une cellule de 501 signes visibles et un paragraphe de 901 ; un long lien ne compte pas."""
        with tempfile.TemporaryDirectory() as tmp:
            lien = "[court](" + "x" * 600 + ".md)"
            path = self.write(tmp, "guide.md", f"| A | {'a' * 501} |\n| B | {lien} |\n\n{'b' * 901}\n\n{'c' * 900}\n")
            errors = []
            structure.check_readability(errors, [path])
        self.assertEqual(len(errors), 2, errors)
        self.assertTrue(any("cellule de 501" in e for e in errors) and any("paragraphe de 901" in e for e in errors), errors)

    def test_replaced_english_word_is_refused(self):
        """LAN-01 : mutation rouge sur le guide 1 ; le code, les liens et le nom « Gate A » restent admis."""
        source = (ROOT / "guides" / "1-utiliser.md").read_text(encoding="utf-8")
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write(tmp, "1-utiliser.md", source + "\nLe owner valide le scope avant le rollback.\n")
            errors = []
            structure.check_language(errors, [path])
            self.assertEqual(len(errors), 3, errors)
            self.assertTrue(all("liste close" in e for e in errors), errors)
            admis = self.write(tmp, "admis.md", "Le Gate A passe ; `owner` est un champ ; owner.txt est un fichier ; [voir](scope.md).\n")
            errors = []
            structure.check_language(errors, [admis])
            self.assertEqual(errors, [])

    def test_kept_english_word_needs_its_glossary_row(self):
        glossaire = (ROOT / "guides" / "glossaire.md").read_text(encoding="utf-8")
        mutant = "\n".join(l for l in glossaire.splitlines() if not l.startswith("| **Skill** |"))
        errors = []
        structure.check_language(errors, [], mutant)
        self.assertTrue(any("« Skill »" in e and "liste close des mots gardés" in e for e in errors), errors)

    def test_dated_trends_live_in_watch_lines(self):
        self.assertEqual(reading_map.moments_non_dates(), [])

    def test_undated_trend_is_refused(self):
        source = (ROOT / "design" / "savoir" / "gout-et-tendances.md").read_text(encoding="utf-8")
        injection = "Les grilles à tuiles et le verre dépoli signent les pages de cette année."
        with tempfile.TemporaryDirectory() as tmp:
            bare = self.write(tmp, "nu.md", source + "\n" + injection + "\n")
            dated = self.write(tmp, "date.md", source + "\n[VEILLE 2026-11] " + injection + "\n")
            self.assertTrue(any("[VAG-02]" in e and "cette année" in e for e in reading_map.moments_non_dates([bare])))
            self.assertEqual(reading_map.moments_non_dates([dated]), [])

    def test_word_containing_the_phrase_is_not_a_claim(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.write(tmp, "mot.md", "Les risques sont rappelés factuellement.\n")
            self.assertEqual(reading_map.moments_non_dates([path]), [])

    def test_structure_summary_does_not_promise_reading(self):
        source = (ROOT / "scripts" / "validate_structure.py").read_text(encoding="utf-8")
        self.assertIn("la lecture effective n’est pas contrôlée", source)
        self.assertNotIn("règles atteignables", source)

    def test_core_names_the_trace_check(self):
        errors = []
        structure.check_core_floor(errors)
        self.assertEqual(errors, [])
        self.assertIn("`python3 scripts/parcours.py trace FICHIER`", (structure.SKILL_DIR / "SKILL.md").read_text(encoding="utf-8"))

    @unittest.skipUnless((ROOT / "scripts" / "build_distributions.sh").is_file() and shutil.which("zip") and shutil.which("bash"),
                         "build absent (export Local) ou zip indisponible")
    def test_build_copies_the_manifest_and_nothing_else(self):
        manifest = json.loads((ROOT / "scripts" / "package_manifest.json").read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "depot"
            for relative in manifest["github"]:
                (root / relative).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT / relative, root / relative)
            (root / "scripts" / "hors_manifeste.py").write_text("print('absent du manifeste')\n", encoding="utf-8")
            env = {**__import__("os").environ, "DG_BUILD_REPRODUCTIBILITE": "1"}
            result = __import__("subprocess").run(["bash", "scripts/build_distributions.sh"], cwd=root, env=env,
                                                  capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("CONTRÔLES DES DISTRIBUTIONS SAUTÉS", result.stdout)
            import zipfile
            with zipfile.ZipFile(root / "Design_Governance_V1_GITHUB.zip") as archive:  # hors git : date fixe déclarée, pas 1970
                self.assertEqual({i.date_time[0] for i in archive.infolist()}, {2026})
            for kind, name in (("github", "Design_Governance_V1_GITHUB.zip"), ("local", "Design_Governance_V1_LOCAL.zip")):
                with zipfile.ZipFile(root / name) as archive:
                    members = {i.filename for i in archive.infolist() if not i.is_dir()}
                self.assertEqual(members, set(manifest[kind]))
            listed = dict(manifest, github=manifest["github"] + ["scripts/fantome.py"])
            (root / "scripts" / "package_manifest.json").write_text(json.dumps(listed), encoding="utf-8")
            result = __import__("subprocess").run(["bash", "scripts/build_distributions.sh"], cwd=root, env=env,
                                                  capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("absent de la source : scripts/fantome.py", result.stdout + result.stderr)


class SocleTests(unittest.TestCase):
    """Socle de la V1 : sections retirables sans récit de run, cinq essais au plus, statut d'essai à un seul lieu,
    principes dits sans leur auteur (règle 6)."""

    EVOLUTION = (ROOT / "maintenance" / "evolution.md").read_text(encoding="utf-8")
    VERSIONS = (ROOT / "maintenance" / "versions.md").read_text(encoding="utf-8")

    def socle(self, evolution=None, versions=None) -> list[str]:
        errors = []
        package.check_socle(errors, evolution if evolution is not None else self.EVOLUTION,
                            versions if versions is not None else self.VERSIONS)
        return errors

    def test_current_socle_holds(self):
        self.assertEqual(self.socle(), [])
        for check in (package.check_trial_wording, package.check_principles_unsourced):
            errors = []
            check(errors)
            self.assertEqual(errors, [], check.__name__)

    def test_every_socle_row_has_a_removal(self):
        rows = package.socle_rows(self.EVOLUTION)
        self.assertGreaterEqual(len(rows), 30)
        self.assertTrue(all(len(r) == 3 and r[2].startswith("Retirer") for r in rows))

    def test_run_story_in_removal_table_is_refused(self):
        row = "| `SAVOIR/CRAFT/CFT-06` — écriture et contenu | Forme du texte. Observé sur quatre runs d’agents neufs. | Retirer la section. |"
        text = self.EVOLUTION.replace("| `SAVOIR/CRAFT/CFT-06` — écriture et contenu |", row + "\n| `SAVOIR/CRAFT/CFT-06` — écriture et contenu |", 1)
        self.assertTrue(any("[SOC-01] récit de run" in e for e in self.socle(evolution=text)))

    def test_removal_naming_a_missing_route_is_refused(self):
        text = self.EVOLUTION.replace("Retirer la sous-section et sa mention dans `SAVOIR/TOOLS/MOYENS`.",
                                      "Retirer la sous-section et sa mention dans `SAVOIR/TOOLS/INEXISTANT`.", 1)
        self.assertTrue(any("route introuvable `SAVOIR/TOOLS/INEXISTANT`" in e for e in self.socle(evolution=text)))

    def test_sixth_open_trial_is_refused(self):
        rows = "".join(f"| `SAVOIR/X{i}` | `PILOT` | essai | Retirer. |\n" for i in range(6))
        versions = self.VERSIONS + "\n## Sections à l’essai\n\n| Section | Statut | Couvre | Retrait |\n|---|---|---|---|\n" + rows
        self.assertTrue(any("[SOC-02] 6 routes `PILOT`" in e for e in self.socle(versions=versions)))
        five = self.VERSIONS + "\n## Sections à l’essai\n\n| Section | Statut | Couvre | Retrait |\n|---|---|---|---|\n" + rows.split("\n", 1)[1]
        self.assertEqual(self.socle(versions=five), [])

    def test_empty_trial_section_is_refused(self):
        versions = self.VERSIONS + "\n## Sections à l’essai\n\nAucune.\n"
        self.assertTrue(any("[SOC-02] section « Sections à l’essai » sans route" in e for e in self.socle(versions=versions)))

    def test_trial_status_in_knowledge_is_refused(self):
        source = (ROOT / "design" / "savoir" / "identite.md").read_text(encoding="utf-8")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "identite.md"
            path.write_text(source + "\nMéthode en `PILOT` (`maintenance/versions.md`).\n", encoding="utf-8")
            errors = []
            with patch.object(package, "ROOT", Path(tmp)):
                package.check_trial_wording(errors, [path])
        self.assertTrue(any("[SOC-03]" in e for e in errors), errors)

    def test_principle_cited_with_its_author_is_refused(self):
        source = (ROOT / "design" / "savoir" / "fondements.md").read_text(encoding="utf-8")
        injected = source.replace("pour ce type de surface.", "pour ce type de surface (Tuch et al., 2012).", 1)
        self.assertNotEqual(source, injected)
        with tempfile.TemporaryDirectory() as tmp:
            bare, dated = Path(tmp) / "nu.md", Path(tmp) / "date.md"
            bare.write_text(injected, encoding="utf-8")
            dated.write_text("[VEILLE 2026-11] Observation datée (Ottosson, 2020).\nWCAG 2.2 (1.4.3 et 1.4.11).\n", encoding="utf-8")
            with patch.object(package, "ROOT", Path(tmp)):
                bare_errors, dated_errors = [], []
                package.check_principles_unsourced(bare_errors, [bare])
                package.check_principles_unsourced(dated_errors, [dated])
        self.assertTrue(any("[PRO-01]" in e and "Tuch et al." in e for e in bare_errors), bare_errors)
        self.assertEqual(dated_errors, [])

    def test_efficacy_stays_not_verified(self):
        for name in ("README.md", "RELEASE_NOTES.md", "maintenance/versions.md"):
            self.assertIn("NOT-VERIFIED", (ROOT / name).read_text(encoding="utf-8"), name)


class OrdinarySectionsTests(unittest.TestCase):
    """Sections ordinaires : servies par leur route, atteintes depuis la séquence au tronc DIRECTION, trouvées par leur nom."""

    def test_route_serves_the_seven_sections(self):
        served = subprocess_text(["python3", "scripts/read_route.py", "BIBLIOTHEQUE/SECTIONS"])
        for name in ("**Fonctionnalités.**", "**Preuve : avis, chiffres, logos.**", "**Tarifs.**", "**Questions fréquentes.**",
                     "**Contact et accès.**", "**Inscription ou demande.**", "**Pied de page.**"):
            self.assertIn(name, served, name)
        self.assertEqual(served.count("- **Réflexe :**"), 7)
        self.assertNotIn("BIBLIOTHEQUE/SECTIONS —", (ROOT / "SKILL.md").read_text(encoding="utf-8"))

    def test_sequence_in_direction_trunk_points_to_sections(self):
        trunk = subprocess_text(["python3", "scripts/read_route.py", "--tronc", "DIRECTION"])
        self.assertIn("Section par section, la forme réflexe et ses leviers : `BIBLIOTHEQUE/SECTIONS`.", trunk)

    def test_section_names_find_the_route(self):
        for query in ("tarifs", "questions fréquentes", "horaires"):
            out = subprocess_text(["python3", "scripts/read_route.py", "--trouver", query])
            top = [l.split()[0] for l in out.splitlines() if "ligne(s)" in l and l.split()[0].count("/") >= 1][:3]
            self.assertIn("BIBLIOTHEQUE/SECTIONS", top, f"{query} : {top}")


class PrinciplePlatesTests(unittest.TestCase):
    """Planches de principes : six planches, chacune citée par sa route, au format ; une planche orpheline est refusée."""

    def copy(self, tmp: str) -> Path:
        root = Path(tmp)
        for d in ("agent", "design", "gouvernance"):
            shutil.copytree(ROOT / d, root / d)
        return root

    def plates(self, root: Path | None = None) -> list[str]:
        errors = []
        package.check_principles_plates(errors, root)
        return errors

    def test_six_plates_cited_and_in_format(self):
        self.assertEqual(self.plates(), [])
        self.assertEqual(len(list((ROOT / "design" / "principes").glob("*.png"))), 6)

    def test_uncited_plate_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self.copy(tmp)
            shutil.copy(root / "design" / "principes" / "rayons.png", root / "design" / "principes" / "orpheline.png")
            self.assertTrue(any("ne cite : design/principes/orpheline.png" in e for e in self.plates(root)))

    def test_missing_or_resized_plate_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self.copy(tmp)
            (root / "design" / "principes" / "chiffres.png").unlink()
            (root / "design" / "principes" / "rayons.png").write_bytes(b"pas une image")
            errors = self.plates(root)
        self.assertTrue(any("citée introuvable : design/principes/chiffres.png" in e for e in errors), errors)
        self.assertTrue(any("hors format : design/principes/rayons.png" in e for e in errors), errors)


class WeightTests(unittest.TestCase):
    """Poids et coût : les troncs servent les contrôles de Gate A seulement ; la marge reste l'affaire du mainteneur."""

    def test_trunks_serve_gate_a_controls_only(self):
        for mode in ("LITE", "ITER", "STANDARD", "DIRECTION", "SYSTÈME"):
            with self.subTest(mode=mode):
                trunk = routes.tronc_routes(mode)
                self.assertIn("ACTION/GATE-A/CONTROLES", trunk)
                self.assertNotIn("ACTION/GATE-A", trunk)
        _, total = routes.tronc_text("DIRECTION")
        self.assertLess(total, routes.TRONC_BUDGET * 0.9)

    def test_scope_contract_is_still_served_by_gate_a(self):
        served = subprocess_text(["python3", "scripts/read_route.py", "ACTION/GATE-A"])
        for fragment in ("### Contrat de portée", "### Familles de méthodes", "### Adéquation des preuves", "### CONTROLES"):
            self.assertIn(fragment, served)

    def test_reader_does_not_show_margin_advice_to_the_agent(self):
        out = subprocess_text(["python3", "scripts/read_route.py", "--tronc", "DIRECTION", "--fichier", str(Path(tempfile.mkdtemp()) / "t.txt")])
        self.assertIn("TOTAL DU TRONC", out)
        self.assertNotIn("MARGE FAIBLE", out)

    def test_cost_is_made_visible_without_a_ceiling(self):
        core = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("Coût : en une ligne, ce que le run a coûté", core)
        self.assertIn("la réponse en dit le coût réel, sans plafond", (ROOT / "design" / "direction" / "standard.md").read_text(encoding="utf-8"))

    def test_generated_image_cost_is_stated_with_consent(self):
        served = subprocess_text(["python3", "scripts/read_route.py", "DIRECTION/ASSET-ROUTE"])
        self.assertIn("L’accord demandé dit le coût : trois ou quatre générations par image retenue", served)


class DeliveryPassTests(unittest.TestCase):
    """Passe de livraison (8a) : codes glosés, déroulé dans son fichier, reprise sans gabarit mort, exemples en trace légère."""

    def test_codes_read_by_people_are_glossed(self):
        errors = []
        structure.check_codes_glossed(errors)
        self.assertEqual(errors, [])
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "guide.md"
            path.write_text("Le statut `PHANTOM-CODE` n’existe pas.\n\n```text\nCODE-EN-BLOC: ignoré\n```\n", encoding="utf-8")
            errors = []
            structure.check_codes_glossed(errors, [path])
        self.assertEqual(len(errors), 1)
        self.assertIn("[GLO-02] code « PHANTOM-CODE »", errors[0])

    def test_direction_pipeline_has_its_own_file(self):
        out = subprocess_text(["python3", "scripts/read_route.py", "ACTION/PIPELINE-DIRECTION"])
        self.assertIn("OWNER: gouvernance/pipeline.md", out)
        self.assertNotIn("ACTION/PIPELINE-DIRECTION", (ROOT / "gouvernance" / "travail.md").read_text(encoding="utf-8"))

    def test_resume_keeps_its_rules_without_the_dead_template(self):
        text = (ROOT / "gouvernance" / "travail.md").read_text(encoding="utf-8")
        self.assertIn("### Reprendre un run", text)
        self.assertNotIn("EXECUTION-SNAPSHOT", text)
        self.assertNotIn("Règles d’or", (ROOT / "gouvernance" / "integrite.md").read_text(encoding="utf-8"))

    def test_most_examples_show_the_light_trace(self):
        text = (ROOT / "references" / "examples.md").read_text(encoding="utf-8")
        blocks = re.findall(r"```text\n(.*?)```", text, re.S)
        legeres = [b for b in blocks if b.startswith("RUN:")]
        self.assertEqual(len(legeres), 3)
        self.assertEqual(len([b for b in blocks if b.startswith("MODE:")]), 2)


class ContextKnowledgeTests(unittest.TestCase):
    """Accessibilité et performance : ce qui se décide en concevant est servi par `SAVOIR/CONTEXT`, hors noyau et hors tronc."""

    def test_design_decisions_are_served_by_their_route(self):
        served = subprocess_text(["python3", "scripts/read_route.py", "SAVOIR/CONTEXT"])
        for fragment in ("Accessibilité : ce qui se décide en concevant", "320 px CSS", "2.4.11", "2.5.8",
                         "Performance : repères et leviers de conception", "[VEILLE 2026-11]", "75e centile", "parcours.py verifier"):
            self.assertIn(fragment, served, fragment)
        self.assertNotIn("Accessibilité : ce qui se décide en concevant", (ROOT / "SKILL.md").read_text(encoding="utf-8"))


def subprocess_text(command: list[str]) -> str:
    import subprocess
    return subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=True).stdout



class NomsDeRuns(unittest.TestCase):
    """[PRO-01] Un nom tiré d'un run, en mot entier, est refusé ; une sous-chaîne d'un autre mot ne l'est pas."""

    def test_nom_refuse_en_mot_entier(self):
        textes = {"design/a.md": "Exemple : le carton de Brume Nord, galerie.", "design/b.md": "des brumes douces",
                  "supports/c.json": "abcZorvaxyz"}
        erreurs = structure.noms_de_runs(textes, ["Brume Nord", "Zorva", "Les Brumes"])
        self.assertEqual(len(erreurs), 1)
        self.assertIn("[PRO-01]", erreurs[0])
        self.assertIn("design/a.md:1", erreurs[0])

    def test_la_garde_tourne_dans_la_validation(self):
        import os, tempfile
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
            f.write("Velvetyne\n")  # un nom présent dans le paquet, pour prouver que check() appelle la garde
        ancien = os.environ.get("DG_NOMS_INTERDITS")
        os.environ["DG_NOMS_INTERDITS"] = f.name
        try:
            self.assertTrue(any("[PRO-01]" in e and "Velvetyne" in e for e in structure.check()))
        finally:
            os.unlink(f.name)
            if ancien is None:
                os.environ.pop("DG_NOMS_INTERDITS", None)
            else:
                os.environ["DG_NOMS_INTERDITS"] = ancien

    def test_sans_liste_rien_n_est_controle(self):
        import os
        ancien = os.environ.pop("DG_NOMS_INTERDITS", None)
        try:
            erreurs = []
            structure.check_noms_de_runs(erreurs)
            self.assertEqual(erreurs, [])
        finally:
            if ancien is not None:
                os.environ["DG_NOMS_INTERDITS"] = ancien


class JournalOptionnel(unittest.TestCase):
    """Le journal de mobilisation est un outil d'atelier : chaque outil de production tourne sans lui."""

    def test_import_protege(self):
        for nom in ("check_render", "parcours", "planche", "regard", "read_route"):
            source = (ROOT / "scripts" / f"{nom}.py").read_text(encoding="utf-8")
            bloc = source[source.index('if __name__ == "__main__":'):]
            with self.subTest(outil=nom):
                self.assertIn("import journal_mobilisation", bloc)
                self.assertIn("except ImportError", bloc)


class CartesSansDebordement(unittest.TestCase):
    """Supports : aucune ligne d'une carte de séquence ne dépasse son encadré (mesure par les métriques de la police)."""

    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("dg_generer_test", ROOT / "supports" / "generer.py")
        cls.gen = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.gen)

    def encadre(self, *lignes):
        return {"nodes": [], "panels": [{"title": "Titre", "lines": list(lignes)}]}

    def test_cartes_reelles(self):
        for nom in ("parcours", "boucle", "lecture"):
            data = json.loads((ROOT / "supports" / f"{nom}.json").read_text(encoding="utf-8"))
            self.assertEqual(self.gen.debordements(data), [], nom)

    def test_ligne_trop_large_relevee(self):
        trop = self.gen.debordements(self.encadre("Une obligation n’est jamais seulement résumée."))
        self.assertEqual(len(trop), 1)

    def test_ligne_courte_admise(self):
        self.assertEqual(self.gen.debordements(self.encadre("le texte complet y reste servi :")), [])


class ReferenceGeneree(unittest.TestCase):
    """[DOC-03] La référence est identique à sa génération ; elle cite chaque commande et chaque section."""

    @classmethod
    def setUpClass(cls):
        import reference
        cls.ref = reference
        cls.genere = reference.generer()

    def test_page_reelle_identique(self):
        errors: list[str] = []
        structure.check_reference(errors, genere=self.genere)
        self.assertEqual(errors, [])

    def test_page_retouchee_refusee(self):
        errors: list[str] = []
        structure.check_reference(errors, page=self.genere.replace("## Commandes", "## Commandes (retouché)"), genere=self.genere)
        self.assertTrue(errors and "[DOC-03]" in errors[0] and "ligne" in errors[0])

    def test_chaque_section_et_commande(self):
        for locator, *_ in routes.summary_rows():
            self.assertIn(f"| `{locator}` |", self.genere)
        for commande in ("verifier", "captures", "chantier", "trace"):
            self.assertIn(f"#### `parcours.py {commande}`", self.genere)

    def test_code_ambigu_nomme_sans_planter(self):
        errors: list[str] = []
        with patch.object(self.ref, "generer", side_effect=routes.RouteError("code porté par deux titres")):
            try:
                structure.check_reference(errors)
            except Exception as exc:  # noqa: BLE001 — un plantage est l'échec que ce test nomme
                self.fail(f"la garde plante au lieu de nommer l'écart : {exc!r}")
        self.assertTrue(errors and errors[0].startswith("[DOC-03] référence non générée"))

    def test_titre_sans_sujet_arrete_la_generation(self):
        with patch.object(self.ref.rr, "resolve", return_value=(None, ["### `ACTION/NEUVE`"], 0)):
            with self.assertRaises(SystemExit):
                self.ref.titre("ACTION/NEUVE")


class PagesPourLesPersonnes(unittest.TestCase):
    """[DOC-01] Les pages d'entrée parlent en mots ; [DOC-02] toute page est à trois clics au plus du README."""

    def codes(self, texte):
        errors: list[str] = []
        structure.check_codes_pages(errors, {"guides/x.md": texte})
        return errors

    def profondeur(self, pages):
        errors: list[str] = []
        structure.check_profondeur(errors, pages)
        return errors

    def test_pages_reelles(self):
        errors: list[str] = []
        structure.check_codes_pages(errors)
        structure.check_profondeur(errors)
        self.assertEqual(errors, [])

    def test_code_nu_refuse(self):
        self.assertTrue(self.codes("1. Il classe la demande avec `DIRECTION/START` : mode et risque."))
        self.assertTrue(self.codes("La règle CFT-04a s'applique ; le gate B1b aussi."))

    def test_commande_et_exemple_admis(self):
        self.assertEqual(self.codes("python3 scripts/read_route.py SAVOIR/TYPE"), [])
        self.assertEqual(self.codes("Chaque section porte un code, par exemple `SAVOIR/TYPE`."), [])

    def test_statut_et_sigle_admis(self):
        self.assertEqual(self.codes("Écrivez `N/A-JUSTIFIED` ; une surface UI/UX nouvelle."), [])

    def test_quatre_clics_refuses(self):
        pages = {"README.md": "[a](a.md)", "a.md": "[b](b.md)", "b.md": "[c](c.md)", "c.md": "[d](d.md)", "d.md": "fin"}
        erreurs = self.profondeur(pages)
        self.assertEqual(len(erreurs), 1)
        self.assertIn("d.md", erreurs[0])

    def test_page_orpheline_refusee(self):
        self.assertTrue(any("inatteignable" in e for e in self.profondeur({"README.md": "rien", "seule.md": "x"})))

    def test_ancre_et_dossier_suivis(self):
        pages = {"README.md": "[g](guides/1.md#commencer)", "guides/1.md": "[r](../ref.md)", "ref.md": "x"}
        self.assertEqual(self.profondeur(pages), [])


class UnSeulAgent(unittest.TestCase):
    """[SUB-01] Aucune consigne du noyau ne suppose un sous-agent, sauf si elle le dit facultatif ou soumis à l'environnement."""

    def erreurs(self, noyau):
        errors: list[str] = []
        structure.check_sous_agent(errors, noyau)
        return errors

    def test_noyau_reel(self):
        self.assertEqual(self.erreurs(None), [])

    def test_second_agent_refuse(self):
        self.assertTrue(self.erreurs("Puis fais critiquer la page par un second agent."))

    def test_parallele_refuse(self):
        self.assertTrue(self.erreurs("Lance les trois esquisses en parallèle."))

    def test_facultatif_admis(self):
        self.assertEqual(self.erreurs("Si l’environnement le permet, fais critiquer la page par un second agent."), [])
        self.assertEqual(self.erreurs("Facultatif : un sous-agent peut relire la page."), [])

    def test_agent_seul_admis(self):
        self.assertEqual(self.erreurs("Ce que l’agent sait de la personne reste une hypothèse."), [])


class IndexComplet(unittest.TestCase):
    """[IDX-01] La table des signaux du noyau cite chaque route du sommaire, en 8 000 octets au plus."""

    TABLE = "| Signal | Route |\n|---|---|\n| Brief vague | `DIRECTION/EXTERNAL-START`, `SAVOIR/TYPE` |\n\nAucun détail n’est considéré lu."

    def erreurs(self, noyau, routes):
        errors: list[str] = []
        structure.check_index(errors, noyau, routes)
        return [e for e in errors if e.startswith("[IDX-01]")]

    def test_noyau_reel_complet(self):
        self.assertEqual(self.erreurs(None, None), [])

    def test_route_absente_signalee(self):
        erreurs = self.erreurs(self.TABLE, ["DIRECTION/EXTERNAL-START", "SAVOIR/TYPE", "ACTION/GATE-B"])
        self.assertEqual(len(erreurs), 1)
        self.assertIn("ACTION/GATE-B", erreurs[0])

    def test_route_hors_table_ne_compte_pas(self):
        noyau = "Voir `ACTION/GATE-B`.\n" + self.TABLE
        self.assertTrue(self.erreurs(noyau, ["ACTION/GATE-B"]))

    def test_index_trop_long(self):
        longue = self.TABLE.replace("| Brief vague |", "| " + "x" * structure.INDEX_MAX + " |")
        self.assertTrue(any("trop long" in e for e in self.erreurs(longue, ["SAVOIR/TYPE"])))

    def test_table_introuvable(self):
        self.assertTrue(self.erreurs("aucune table", ["SAVOIR/TYPE"]))


class PlancherEnLigne(unittest.TestCase):
    """[REQ-01] Forme « ligne » : l'obligation tient au noyau par une ligne qui nomme sa route, et la route garde le texte."""

    SCOPE = "premier écran, identité ou scène d’une surface `DIRECTION` dont la décision visuelle est ouverte ; pas pour un correctif local"

    def erreurs(self, plancher, noyau):
        errors: list[str] = []
        structure.check_floors(errors, {self.SCOPE: plancher}, noyau)
        return [e for e in errors if self.SCOPE[:30] in e]

    def test_ligne_valide(self):
        ligne = f"- [REQUIS PAR LE MODULE — {self.SCOPE}] Diverge sur image. Détail : `DIRECTION/DIVERGENCE`."
        self.assertEqual(self.erreurs(("ligne", "DIRECTION/DIVERGENCE"), ligne), [])

    def test_ligne_sans_route(self):
        ligne = f"- [REQUIS PAR LE MODULE — {self.SCOPE}] Diverge sur image."
        self.assertTrue(any("aucune ligne du noyau" in e for e in self.erreurs(("ligne", "DIRECTION/DIVERGENCE"), ligne)))

    def test_route_sans_le_texte(self):
        ligne = f"- [REQUIS PAR LE MODULE — {self.SCOPE}] Voir `SAVOIR/TYPE`."
        self.assertTrue(any("ne garde pas le texte complet" in e for e in self.erreurs(("ligne", "SAVOIR/TYPE"), ligne)))

    def test_route_introuvable(self):
        ligne = f"- [REQUIS PAR LE MODULE — {self.SCOPE}] Voir `DIRECTION/ABSENTE`."
        self.assertTrue(any("introuvable" in e for e in self.erreurs(("ligne", "DIRECTION/ABSENTE"), ligne)))

if __name__ == "__main__":
    result = unittest.TextTestRunner(stream=sys.stdout).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    print(f"AUDIT REGRESSIONS {'PASSED' if result.wasSuccessful() else 'FAILED'} — {result.testsRun} cas")
    sys.exit(0 if result.wasSuccessful() else 1)
