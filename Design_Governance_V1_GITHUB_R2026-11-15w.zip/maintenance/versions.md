# Fiche de version — Design Governance V1.0.0

**Version expérimentale :** `V1.0.0`
**Statut expérimental :** Design Governance V1.0.0 est une expérimentation maintenue.  
**Révision :** `R2026-11-15w`, 22 novembre 2026.  
**Usage recommandé :** pilote avec revue humaine et preuves adaptées au risque.

Cette fiche décrit ce que le système possède aujourd’hui et ce qui en est vérifié. Elle ne retrace pas son histoire.

## Ce que fait le système

Design Governance aide un agent, ou une personne, à concevoir des pages, des écrans et des identités visuelles qui ont une direction, qui sont construits et soignés dès la première proposition, puis à les améliorer en regardant le rendu. Quand un travail doit être repris, livré ou accepté, il garde la trace de ce qui a été vérifié et de ce qui ne l’a pas été.

**Périmètre.** Éprouvé sur le Web : pages, écrans, parcours et composants, du bureau au mobile. L’identité de marque (signe, déclinaisons, règles d’usage) a sa méthode et sa planche d’épreuve ; elle est moins éprouvée que le Web. Les autres médiums (imprimé, mobile natif, vidéo, 3D, espace) sont nommés avec la preuve qu’ils demandent, sans outil ni run ; l’e-mail et le parcours d’achat sont hors périmètre.

## Cap

| Niveau | Contenu |
|---|---|
| **Utilité** | Aider une personne ou un agent à transformer une demande en réalisation de design pertinente, avec une vraie direction, construite et soignée dès la première proposition, puis améliorée à partir du rendu réel ; analyser et corriger un existant. |
| **Objectif** | Obtenir un niveau élevé plus régulièrement, avec moins d’oublis, de tâtonnements et de reprises inutiles : esthétique, identité, usage et solidité de l’exécution. |
| **Hypothèse à éprouver** | Le système oriente-t-il les choix ? Mobilise-t-il les bons moyens ? Conduit-il au niveau visé ? Chaque question se juge par comparaison avec un travail fait sans lui, sur des demandes comparables. |

L’état de cette hypothèse est décrit dans [ce qui est vérifié](#ce-qui-est-vérifié-ce-qui-ne-lest-pas). Toute évolution du système dit quelle question elle sert et comment on le saura.

## Ce que contient le paquet

| Partie | Contenu |
|---|---|
| `design/` | Direction (cadrer, diriger, boucle d’édition, cinq règles), savoir (composition, typographie, couleur, styles, images et sources, contexte, techniques, qualité créative, écriture et contenu, identité de marque), formes (supports, grilles, scènes, sections ordinaires, composants), six planches de principes en image (`design/principes/`) et qualité du produit (premier rendu, plancher, finition, preuve visuelle, interface). |
| `SKILL.md`, `references/` | La skill : point d’entrée de l’agent (noyau commun) et ses références. Le paquet entier est le dossier de la skill. |
| `agent/` | Les chemins de l’agent par mode et la forme de sa réponse. |
| `gouvernance/` | Trace, statuts, vérification, clôture et structure ; schémas `RUN_CARD` et contrats de production, exemples, fixtures et validateurs. |
| `guides/` | Trois niveaux de maîtrise (utiliser, comprendre, maîtriser) et un glossaire. |
| `supports/` | Quatre cartes du système (responsabilités, parcours d’un travail, boucle créer/apprendre, lecture de l’agent) en HTML, SVG clair et sombre, et texte. |
| `scripts/` | Lecteur de routes, recette de rendu, planche de comparaison, commande de regard, parcours par défaut, journal de mobilisation, compilation du noyau, contrôles du paquet et construction des distributions. |
| `maintenance/` | Cette fiche, l’évolution du système et la préparation des livraisons. |

## Ce que le système sait faire

- **Classer un travail** en cinq modes (retouche, itération, écran cadré, direction, système), lire le noyau de fabrication (premier objet, composition, typographie, couleur, boucle d’édition), puis le tronc de son mode (routes lues à chaque run, sous un budget de 40 000 caractères, `read_route.py --tronc MODE --fichier`, lu une fois) ; le reste se charge quand son signal apparaît.
- **Diriger une proposition** :
  - premier objet, cible visuelle et divergence sur image : cinq directions et leur probabilité, trois esquisses sur une planche, la modale en référence, au bureau et aussi en mobile pour un produit d’abord mobile, sinon la recomposition mobile sur la seule direction gardée ; trois directions et une esquisse quand un seul axe reste ouvert ;
  - la modale au second degré observée (la première idée astucieuse de l’agent), non estimée ; des directions tirées de pistes différentes du sujet et de registres distincts, puis une direction déclarée : nom, vision et registre, relue contre le défaut ;
  - des polices cherchées par leur construction, au-delà des plus vues (catalogue de Fontshare), et la vague typographique du moment relevée au premier écran ;
  - avant le build, le caractère visé traduit en leviers et pièges, avec l’ordre de composition (structure attendue du genre, écart porté sur une ou deux dimensions) ;
  - un atelier ouvert par une lecture de l’idée en une seconde : test de retrait des accessoires, défaut dominant corrigé, intensification seulement si la décision paraît timide ; direction lisible dans le rendu ;
  - une reprise se compare à ses antécédents sur six champs (teinte, paire typographique, ossature, objet de preuve, thèse, registre).
- **Construire avec un contenu vrai** : exemples marqués plutôt qu’emplacements vides ; un artefact fictif ou de démonstration le dit visiblement, en langage produit, sans baisser son niveau visuel ; données et graphiques d’exemple cohérents, sources et droits vérifiés au moment de l’intégration, provenance des images générées conservée.
- **Protéger la personne** : dans les flux d’inscription, de paiement, de consentement ou de résiliation, refuser reste aussi visible et aussi court qu’accepter ; une culture se calibre par des références locales nommées, jamais par un registre régional générique.
- **Choisir ses moyens** :
  - une carte datée nomme, par couche, des sources gratuites avec leurs restrictions connues : bases techniques, typographie, couleur, icônes, composants, mouvement et 3D, données et cartes, textures, photographie, illustration, références à observer ;
  - une ressource nommée n’est ni atteinte ni vérifiée ; sa licence se relit au moment de l’intégrer ;
  - sur une décision visuelle ouverte, le niveau visé est haut et proportionné à la demande : l’agent calibre ce niveau sur deux ou trois références réelles, essaie la route disponible pour chaque couche qui porte la thèse avant de déclarer un plafond, ne dessine pas de mémoire un sujet figuratif, et finit par une passe de finition sur le premier écran, l’objet de preuve et les sections suivantes, par lots du plus visible au plus fin, jusqu’à ce que `verifier` ne laisse aucun signal sans correction ni raison ; un défaut connu et corrigeable ne se déclare pas, il se corrige.
- **Rassembler et juger des références** : les sites trouvés par l’agent et des images de collections ouvertes sont capturés avec leur source, leur auteur, leur licence et leur date de consultation, sur une planche ; l’agent écrit pour chacun ce qu’il change et ce qui ne se transfère pas ; une page lue reste une donnée, un refus d’accès se déclare. Une image générée se dirige par un prompt tiré de la direction, se choisit parmi plusieurs variantes et s’exploite au cadrage réel. Une référence restée sans jugement est signalée ; le niveau se calibre sur une référence du même type d’objet venue d’une source éditée.
- **Concevoir une identité de marque** : un signe dessiné en noir d’abord, dans la portée de l’agent, des esquisses en signes noirs face à la modale, des déclinaisons dessinées et des règles d’usage ; une planche d’épreuve le montre de 16 à 256 px, en noir, en gris, inversé, sur photo, en avatar, en onglet et en en-tête, avec des signaux mesurés. Un signe proposé se marque comme proposition ; la disponibilité juridique n’est pas vérifiée.
- **Chercher une méthode** : une technique que l’agent ne maîtrise pas de mémoire se cherche dans le savoir du système, puis dans une source primaire datée et un exemple ouvert, et s’essaie seule avant d’entrer dans l’artefact.
- **Construire sur le socle des navigateurs** : un levier encore limité à un ou deux moteurs s’ajoute en amélioration progressive, avec un repli qui garde la direction lisible.
- **Observer et corriger** — tous les outils donnent des signaux et non des verdicts :
  - boucle d’édition sur capture ;
  - recette de rendu automatisée pour les fautes objectivables (débordement, contraste, y compris sur fond en image ou en dégradé, mesuré sur capture, noms accessibles, clavier, cibles, images visibles qui ne se chargent pas, stabilité au chargement, contraste du focus dans les cas lisibles, mouvement réduit observé dès le chargement, textes qui se recouvrent ou sont tronqués) ;
  - preuve à l’état qui compte, après clic et attente : assertions sur un texte calculé (`--assert`) et objet de l’état clé dans son cadre (`--in-frame`) ;
  - comparaison à une mesure antérieure pour distinguer les défauts introduits ;
  - planche de premiers écrans côte à côte et commande de regard (attention au premier écran, foyer déclaré, contraste sur le fond capturé, marqueurs de vague datés relevés au premier écran, comparaison avec un rendu précédent) ;
  - un parcours par défaut qui les enchaîne avec des captures, des signaux de finition (habillage de gabarit compris) et une planche de mouvement (entrée image par image, défilement, survol, mouvement réduit) en une fiche, et prépare un regard séparé sur images seules quand un second agent est possible.
  - un travail sobre : démarrage en un appel (`chantier`), une image par version pendant la boucle, et un `verifier` qui, d’un appel au suivant, ne montre que ce qui a changé ;
- **Tracer selon le besoin** : trace légère par défaut, qui dit qui a choisi la direction (l’auteur du rendu, la personne ou personne) ; trace complète et fiche `RUN_CARD` validable lorsqu’un travail est repris, partagé, audité ou accepté.
- **Retrouver un savoir** : lecteur de routes par code, recherche (la section propriétaire du sujet d’abord) ou connexions entre domaines ; un journal de mobilisation relève ce que les outils ont servi et ce qui a été lancé.

## Compatibilité

Un code de route (`DIRECTION/START`) désigne une seule section, où qu’elle soit rangée ; le lecteur la retrouve par son titre. Cette fiche est aussi accessible par le code `CHANGELOG`. Les distributions GitHub et Local ont la même arborescence ; Local est un export dérivé, sans les outils de construction. La skill suit le format ouvert Agent Skills ; son installation est décrite dans le README.

Une promotion, une dépréciation ou une migration décidée se reflète ici, dans l’état courant ; la règle de cycle de vie et le contrat de la décision sont dans `maintenance/evolution.md`.

**Contrats de projection.** Dans une `RUN_CARD`, le champ `direction` porte la thèse, le modal (`direction.modal`), le parti (`direction.parti`), la trame modale facultative (`direction.trame`) et le premier objet ; une fiche qui porte le champ `anti_direction` est refusée avec l’indication de conversion (son premier élément devient `modal`, la décision prise face à lui devient `parti`). Le contrat `EVALUATION_CASE` porte la condition (avec ou sans le système), la campagne et le cas apparié, l’évaluateur et son indépendance ; un gain affirmé y cite sa référence, sinon le validateur le refuse.

## Socle de la V1

Toutes les sections du paquet forment le socle de la V1, au statut `SEED` du [cycle de vie](evolution.md#cycle-de-vie-des-routes) : canoniques, sans gain mesuré. Chacune reste retirable, selon [la procédure de retrait](evolution.md#retirer-une-section-du-socle). Aucune section n’est à l’essai. Une nouvelle route entre au statut `PILOT`, au plus cinq à la fois, et se liste ici, dans une section « Sections à l’essai » qui n’existe que tant qu’une route l’est.

## Ce qui est vérifié, ce qui ne l’est pas

Le paquet contrôle sa cohérence : inventaire, liens et références, noyau compilé, atteignabilité des règles, planchers des obligations `[REQUIS]`, schémas et fixtures, carte de lecture, lecteur de routes, fraîcheur des cartes et, dans le dépôt GitHub, reproductibilité des distributions. La recette de rendu et ses tests de pages demandent un navigateur.

**Efficacité : `NOT-VERIFIED`.** Aucune mesure comparative n’établit une amélioration générale de qualité, de variété ou de coût. Les essais internes faits jusqu’ici ne l’établissent pas ; leur relevé est tenu hors du paquet. Coût mesuré d’un run de direction en novembre 2026, sans comparaison avec un run sans système : 116 à 208 tours d’agent, 22 à 46 millions de jetons relus en cache, 14 à 27 minutes.

Une validation du paquet ou d’une `RUN_CARD` confirme les contrôles exécutés ; elle ne remplace ni l’observation d’un rendu, ni un test utilisateur, ni une vérification d’accessibilité exécutée, ni une mesure de performance. Toute conclusion d’usage précise ce qui a été observé, par quelle méthode, dans quel périmètre et avec quelle limite.

Pour faire évoluer le système, suivre [la maintenance](README.md) et [le cycle de vie](evolution.md) ; pour s’en servir, [les guides](../guides/README.md).
