# Recettes de procédé

Des procédés déjà résolus pour des difficultés de code où un rendu perd du temps ou se trompe. Chaque recette règle un comportement ou un procédé, jamais une apparence : police, couleur, taille, rythme et aspect d’une matière restent à la direction. `python3 scripts/parcours.py recette NOM` affiche une recette ; `python3 scripts/parcours.py recette` les liste. Une technique sans recette se cherche avec `SAVOIR/TECH`, « Chercher une méthode ».

Une recette n’entre ici que si plusieurs rendus ont achoppé sur la même difficulté. Si deux rendus en sortent avec la même apparence, elle impose un style : elle se réécrit ou se retire.

## graphique

**Problème.** Un graphique lisible au bureau devient illisible ou chevauché à 390 px : le texte d’un SVG mis à l’échelle rapetisse avec lui, et les étiquettes se recouvrent.

**Quand.** Une série de valeurs à comparer (barres, volume par semaine, évolution). **Pas quand** la donnée tient en une phrase ou en un seul chiffre.

**Procédé.** Les marques se dessinent à l’échelle, le texte reste en HTML à sa taille. Les étiquettes s’éclaircissent sous une largeur donnée ; la valeur mise en avant et les extrêmes restent écrits.

```html
<figure class="graph" aria-label="Kilomètres par semaine">
  <ol class="barres">
    <li style="--v:.70"><span class="val">21</span><span class="lab">S1</span></li>
    <li style="--v:.77"><span class="val">23</span><span class="lab">S2</span></li>
    <li style="--v:.83"><span class="val">25</span><span class="lab">S3</span></li>
    <li style="--v:1" class="cle"><span class="val">30</span><span class="lab">S4</span></li>
    <li style="--v:.53"><span class="val">16</span><span class="lab">S5</span></li>
  </ol>
</figure>
<style>
.graph { container-type: inline-size; margin: 0 }
.barres { list-style: none; margin: 0; padding: 0; display: grid; grid-auto-flow: column; grid-auto-columns: 1fr;
  gap: clamp(2px, 1.5cqi, 12px); align-items: end; height: 220px; border-bottom: 1px solid currentColor }
.barres li { display: flex; flex-direction: column; justify-content: flex-end; height: 100%; position: relative }
.barres li::before { content: ""; order: 2; height: calc(var(--v) * 80%); background: var(--marque, #888) }
.barres .cle::before { background: var(--accent, #111) }
.val { order: 1; font-variant-numeric: tabular-nums; font-size: .8rem; text-align: center }
.lab { position: absolute; top: 100%; left: 0; right: 0; text-align: center; font-size: .75rem; padding-top: 4px }
@container (max-width: 420px) {
  .barres li:not(.cle):not(:first-child):not(:last-child) .val { visibility: hidden }
  .barres li:nth-child(even):not(.cle) .lab { visibility: hidden }
}
</style>
```

**La direction décide.** Couleurs des marques et de la valeur clé, hauteur, épaisseur des barres, police des chiffres, axe ou non.

**Vérifier sur capture.** À 390 px : aucune étiquette recouverte, la valeur clé et les extrêmes lisibles à au moins 12 px, chiffres alignés.

## grand-chiffre

**Problème.** Un grand chiffre qui change (saisie, recalcul, compteur) saute en largeur, déborde de son cadre ou écrase le champ voisin, et son contraste se perd quand il sort de son fond.

**Quand.** Un montant, un temps, un score mis en scène en grand. **Pas quand** le chiffre est secondaire.

**Procédé.** Figures tabulaires, largeur réservée en `ch` selon le nombre de caractères, taille bornée par la largeur du conteneur, recalcul sans animation sous mouvement réduit.

```html
<div class="montant">
  <label for="m">Vous envoyez</label>
  <input id="m" inputmode="decimal" value="200" autocomplete="off">
  <output for="m" id="r" aria-live="polite">131 191</output>
</div>
<style>
.montant { container-type: inline-size; display: grid; gap: .25rem; overflow: hidden }
.montant input, .montant output { font: inherit; font-variant-numeric: tabular-nums; white-space: nowrap;
  font-size: min(8rem, 18cqi); line-height: .95; border: 0; background: none; color: inherit; padding: 0 }
.montant input { width: calc(var(--n, 3) * 1ch + .1ch); min-width: 2ch; border-bottom: 2px solid currentColor }
</style>
<script>
const m = document.getElementById('m'), r = document.getElementById('r');
const fmt = new Intl.NumberFormat('fr-FR', {maximumFractionDigits: 0});
function maj() {
  m.style.setProperty('--n', Math.max(2, m.value.length));
  const v = parseFloat(m.value.replace(',', '.')) || 0;
  r.textContent = fmt.format(v * 2);  // le calcul vient du produit
}
m.addEventListener('input', maj); maj();
</script>
```

**La direction décide.** Police et graisse du chiffre, unité et sa place, couleur et fond, le calcul lui-même.

**Vérifier sur capture.** Avec 1, 4 et 7 chiffres saisis : rien ne déborde du cadre, le voisin ne bouge pas, le contraste du chiffre se mesure sur son propre fond (`check_render`).

## moment-orchestre

**Problème.** Les entrées animées se posent sur chaque bloc (fondu-glissé partout), retardent l’action ou ignorent le mouvement réduit ; sans script, le contenu peut rester caché.

**Quand.** Une page faite pour se montrer, avec un objet de preuve qui gagne à apparaître. **Pas quand** la page est un outil ou une lecture.

**Procédé.** Un seul moment, sur l’objet de preuve et au plus deux éléments liés, défini seulement sous `prefers-reduced-motion: no-preference` : sans préférence ou sans animation, tout est visible et à sa place.

```html
<div class="scene"><h1>Titre</h1><div class="preuve">Objet de preuve</div><a class="action" href="#">Agir</a></div>
<style>
@media (prefers-reduced-motion: no-preference) {
  .preuve { animation: pose .7s cubic-bezier(.2, .7, .2, 1) .15s both }
  .preuve > * { animation: monte .5s ease-out .5s both }
}
@keyframes pose { from { opacity: 0; transform: translateY(18px) rotate(-1.5deg) } }
@keyframes monte { from { opacity: 0; transform: translateY(8px) } }
</style>
```

**La direction décide.** Ce qui bouge, la trajectoire, la durée (au plus une seconde au total), la courbe.

**Vérifier sur la planche de mouvement** (`parcours.py mouvement`) : une seule entrée, l’action visible dès la première image, rien sous mouvement réduit.

## focus

**Problème.** Le contour de focus disparaît sur un fond de sa couleur, ou se mesure sous 3:1 quand la page mêle fonds clairs et sombres.

**Quand.** Toute page, dès que les fonds varient. **Pas quand** un design system impose déjà son focus.

**Procédé.** Un double contour : un trait clair contre l’élément, un trait sombre au-delà. L’un des deux contraste toujours avec le fond.

```html
<a href="#" class="exemple">Lien</a> <button>Bouton</button>
<style>
:focus-visible { outline: 3px solid var(--focus-sombre, #111); outline-offset: 2px;
  box-shadow: 0 0 0 2px var(--focus-clair, #fff) }
</style>
```

**La direction décide.** Les deux couleurs, l’épaisseur et le décalage.

**Vérifier.** Contraste du focus relevé par `check_render` sur chaque fond ; parcours au clavier complet (`parcours.py verifier`, ordre de tabulation).

## controles

**Problème.** Groupes segmentés, onglets, champs et boutons recodés à la main perdent le clavier, le nom accessible ou l’état : boutons radio hors de Tab, onglet sans flèches, erreur non annoncée, bouton qui change de nom pendant le chargement.

**Quand.** Tout contrôle ordinaire. **Pas quand** un design system ou une bibliothèque du projet fournit déjà le composant.

**Procédé.** L’élément natif d’abord, avec son comportement ; la direction habille, sans changer le comportement.

```html
<fieldset class="seg"><legend>Distance</legend>
  <label><input type="radio" name="d" value="5" checked><span>5 km</span></label>
  <label><input type="radio" name="d" value="10"><span>10 km</span></label>
</fieldset>
<div class="champ">
  <label for="e">Adresse e-mail</label>
  <input id="e" type="email" required aria-describedby="e-err">
  <p id="e-err" class="err" hidden>Écrivez une adresse complète, comme nom@exemple.fr.</p>
</div>
<button class="envoi" type="button"><span>Envoyer</span><i class="roue" aria-hidden="true"></i></button>
<div role="tablist" aria-label="Vues">
  <button role="tab" id="t1" aria-selected="true" aria-controls="p1">Semaine</button>
  <button role="tab" id="t2" aria-selected="false" aria-controls="p2" tabindex="-1">Mois</button>
</div>
<div role="tabpanel" id="p1" aria-labelledby="t1">…</div><div role="tabpanel" id="p2" aria-labelledby="t2" hidden>…</div>
<style>
.seg { border: 0; padding: 0; display: inline-flex }
.seg input { position: absolute; opacity: 0; width: 1px; height: 1px }
.seg input:checked + span { font-weight: 700; text-decoration: underline }
.seg input:focus-visible + span { outline: 3px solid #111; outline-offset: 2px }
.roue { display: none } .envoi[aria-busy="true"] .roue { display: inline-block }
</style>
<script>
const e = document.getElementById('e'), err = document.getElementById('e-err');
e.addEventListener('blur', () => { const ko = !e.checkValidity(); e.setAttribute('aria-invalid', ko); err.hidden = !ko; });
const b = document.querySelector('.envoi');
b.addEventListener('click', () => { b.setAttribute('aria-busy', 'true'); b.setAttribute('aria-disabled', 'true'); });
const tabs = [...document.querySelectorAll('[role=tab]')];
tabs.forEach((t, i) => t.addEventListener('keydown', ev => {
  const d = {ArrowRight: 1, ArrowLeft: -1}[ev.key]; if (!d) return;
  const n = tabs[(i + d + tabs.length) % tabs.length]; n.click(); n.focus(); }));
tabs.forEach(t => t.addEventListener('click', () => tabs.forEach(x => {
  const on = x === t; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1;
  document.getElementById(x.getAttribute('aria-controls')).hidden = !on; })));
</script>
```

**La direction décide.** L’habillage de chaque contrôle : voix typographique, bord, couleur par rôle, alignement sur la grille (`BIBLIOTHEQUE/COMPONENTS`, « Parties ordinaires »). Un menu de sélection reste un `<select>` natif, habillé.

**Vérifier.** Ordre de tabulation et noms accessibles (`parcours.py verifier`) ; flèches dans le groupe et dans les onglets ; l’erreur annoncée et liée au champ ; le bouton garde son libellé pendant le chargement.

## matiere

**Problème.** Une matière codée de mémoire (émail, papier, bois, verre, métal) paraît dessinée : un dégradé unique et lisse, un reflet blanc plaqué en haut à gauche, un grain qui grossit avec l’élément ou dont la tuile se voit, un filtre posé sur tout l’élément qui ralentit la page et floute le texte.

**Quand.** La direction déclare une matière que le sujet possède. **Pas quand** la planéité est choisie, ou quand une vraie photo de la matière est disponible : elle l’emporte.

**Procédé.** D’abord regarder : deux photos réelles de la matière (`parcours.py references --polyhaven "texture: …"` ou `--commons "…"`), et trois observations écrites (où la couleur s’accumule, comment finit le bord, d’où vient la lumière). Puis coder en couches, de la plus lente à la plus fine : la couleur de base ; deux ou trois variations lentes, irrégulières, placées où la photo les montre ; un grain fin en image de fond tuilée, à taille fixe en pixels, jamais en `filter` sur l’élément ; l’accident observé (coulure, fibre, bulle, rayure) en dernier, une seule fois.

```html
<div class="matiere" role="img" aria-label="Matière du sujet"><span class="accident"></span></div>
<style>
.matiere { position: relative; aspect-ratio: 4 / 3; overflow: hidden; isolation: isolate;
  background:
    radial-gradient(55% 40% at var(--lumiere, 70% 20%), rgb(255 255 255 / var(--eclat, .22)), transparent 70%),
    radial-gradient(70% 55% at 25% 85%, rgb(0 0 0 / var(--creux, .18)), transparent 75%),
    var(--base, #8a8f86) }
.matiere::after { content: ""; position: absolute; inset: 0; pointer-events: none; opacity: var(--grain, .35); mix-blend-mode: multiply;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 .6 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23g)'/%3E%3C/svg%3E");
  background-size: 180px 180px }
.accident { position: absolute; inset: var(--accident-place, 0 0 45% 0); background: var(--accident, transparent);
  clip-path: var(--accident-forme, none) }
</style>
```

**La direction décide.** La matière, sa couleur, la place de la lumière et des creux, la force du grain, la forme et la place de l’accident : tout vient des photos regardées, pas de cette recette.

**Vérifier.** Une page de deux images à la même échelle, la photo et un carré de la matière codée, capturée (`parcours.py captures`) : paraît-elle observée ou dessinée ? Dessinée, elle se reprend d’après la photo, ou part au test de retrait. Grain de même taille à 390 et à 1440 px ; texte posé dessus mesuré sur le fond réel (`regard.py`).

## police-variable

**Problème.** Une graisse animée ou pilotée par un curseur ne bouge pas (fichier non variable, plage absente de `@font-face`), fait sauter la mise en page en s’élargissant, déborde à 390 px dans sa graisse la plus forte, tourne sans fin sous mouvement réduit, ou se règle avec un curseur sans nom ni valeur lisible.

**Quand.** Un spécimen, un titre ou un objet de preuve dont la graisse est l’idée. **Pas quand** la police n’est pas variable : on montre alors les graisses existantes côte à côte.

**Procédé.** La plage déclarée dans `@font-face` ; la graisse pilotée par une variable ; la taille calée une fois sur la graisse la plus forte, pour que rien ne déborde ni ne bouge quand elle change ; un curseur natif, nommé, qui annonce la graisse en mots ; le balayage seulement sans préférence de mouvement réduit, et arrêté dès que la personne prend la main.

```html
<div class="specimen">
  <p class="echantillon balaye" id="ech">Échantillon</p>
  <label for="gr">Graisse</label>
  <input id="gr" type="range" min="200" max="900" step="1" value="400">
  <output for="gr" id="grv">400</output>
</div>
<style>
@font-face { font-family: "Variable"; src: url("police-variable.woff2") format("woff2"); font-weight: 100 900; font-display: swap }
.specimen { container-type: inline-size }
.echantillon { font-family: "Variable", Georgia, serif; font-weight: var(--wght, 400); font-size: min(9rem, 15cqi);
  line-height: 1.1; margin: 0; white-space: nowrap; overflow: hidden }
@media (prefers-reduced-motion: no-preference) {
  .echantillon.balaye { animation: balaye 5s ease-in-out infinite alternate }
}
@keyframes balaye { from { font-weight: 200 } to { font-weight: 900 } }
</style>
<script>
{
  const g = document.getElementById('gr'), e = document.getElementById('ech'), v = document.getElementById('grv');
  const noms = [[300, 'légère'], [500, 'normale'], [650, 'demi-grasse'], [800, 'grasse'], [1000, 'noire']];
  function caler() {
    const balaye = e.classList.contains('balaye'); e.classList.remove('balaye'); e.style.fontSize = '';
    e.style.setProperty('--wght', 900); let t = parseFloat(getComputedStyle(e).fontSize);
    while (e.scrollWidth > e.clientWidth && t > 12) { t -= 2; e.style.fontSize = t + 'px'; }
    e.style.setProperty('--wght', g.value); if (balaye) e.classList.add('balaye');
  }
  function maj() {
    e.classList.remove('balaye'); e.style.setProperty('--wght', g.value); v.textContent = g.value;
    g.setAttribute('aria-valuetext', g.value + ', ' + noms.find(([s]) => g.value < s)[1]);
  }
  g.addEventListener('input', maj); addEventListener('resize', caler);
  document.fonts.ready.then(caler); caler();
  g.setAttribute('aria-valuetext', g.value + ', normale');
}
</script>
```

**La direction décide.** La police, le mot ou la phrase, la plage et la courbe du balayage, la place et l’habillage du curseur.

**Vérifier.** À 390 px dans la graisse la plus forte, rien ne déborde ; au clavier, les flèches changent la graisse et sa valeur annoncée ; sous mouvement réduit, rien ne bouge (`parcours.py mouvement`).

## reponse-courriel

**Problème.** Un formulaire de réponse sans serveur perd la réponse : `<form action="mailto:">` mal pris en charge, accents et retours à la ligne mal encodés, aucune issue quand aucune messagerie ne s’ouvre, et un « Merci, c’est envoyé » qui ment.

**Quand.** Une invitation, une inscription, une demande sans serveur derrière. **Pas quand** un service de formulaire existe : il l’emporte.

**Procédé.** Un vrai formulaire, validé avant l’envoi, l’erreur annoncée et liée au champ. À l’envoi, le message se compose (`encodeURIComponent`, retours `\r\n`) et la messagerie s’ouvre ; la page dit ce qui reste à faire, montre l’adresse en clair et le message prêt à copier, au cas où rien ne s’ouvre.

```html
<form class="reponse" id="rep" novalidate>
  <label for="rn">Votre nom</label>
  <input id="rn" name="nom" required autocomplete="name" aria-describedby="rn-err">
  <p id="rn-err" class="err" hidden>Écrivez votre nom.</p>
  <fieldset><legend>Vous venez ?</legend>
    <label><input type="radio" name="vient" value="oui" checked> Oui</label>
    <label><input type="radio" name="vient" value="non"> Non</label>
  </fieldset>
  <label for="rp">Combien serez-vous ?</label>
  <input id="rp" name="nombre" type="number" min="1" max="6" value="1" inputmode="numeric">
  <button type="submit">Préparer ma réponse</button>
  <div id="rep-ok" role="status" hidden>
    <p>Votre messagerie s’ouvre avec la réponse prête : il reste à l’envoyer. Rien ne s’ouvre ? Écrivez à
      <a id="rep-lien" href="mailto:reponse@exemple.fr">reponse@exemple.fr</a> ce message :</p>
    <textarea id="rep-texte" readonly rows="4" aria-label="Votre message"></textarea>
  </div>
</form>
<script>
{
  const f = document.getElementById('rep'), ADRESSE = 'reponse@exemple.fr';
  f.addEventListener('submit', ev => {
    ev.preventDefault();
    const nom = f.nom.value.trim(), err = document.getElementById('rn-err');
    f.nom.setAttribute('aria-invalid', String(!nom)); err.hidden = !!nom;
    if (!nom) { f.nom.focus(); return; }
    const corps = [`Nom : ${nom}`, `Je viens : ${f.vient.value}`, `Nombre : ${f.nombre.value}`].join('\r\n');
    const url = `mailto:${ADRESSE}?subject=${encodeURIComponent('Réponse : ' + nom)}&body=${encodeURIComponent(corps)}`;
    document.getElementById('rep-lien').href = url;
    document.getElementById('rep-texte').value = corps;
    document.getElementById('rep-ok').hidden = false;
    location.href = url;
  });
}
</script>
```

**La direction décide.** Les questions posées, leur ton, l’habillage des champs (recette `controles`), la place du formulaire dans la page.

**Vérifier.** Envoi sans nom : l’erreur s’affiche et le focus revient au champ. Avec un nom accentué : le lien composé le garde, la confirmation dit ce qui reste à faire, jamais « envoyé ».

## agenda

**Problème.** Un fichier d’agenda écrit à la main est refusé ou décalé : retours à la ligne sans `\r`, heure sans fuseau (l’invité d’un autre fuseau voit la mauvaise heure), virgules et points-virgules non échappés, `UID` ou `DTSTAMP` absents, lignes de plus de 75 octets non pliées.

**Quand.** Un événement daté que la personne doit retrouver : vernissage, rendez-vous, lancement. **Pas quand** la date n’est pas encore fixée.

**Procédé.** L’heure écrite avec son décalage (`+01:00`), convertie en UTC ; le texte échappé ; chaque ligne pliée à 75 octets ; le fichier produit dans la page et téléchargé par un lien nommé.

```html
<a class="agenda" id="ics" href="#" download="evenement.ics">Ajouter à mon agenda</a>
<script>
{
  const EV = { titre: 'Vernissage, atelier du Pont', lieu: '12 rue des Potiers, Nantes',
    debut: '2026-12-04T18:30:00+01:00', fin: '2026-12-04T21:00:00+01:00',
    texte: 'Pièces nouvelles; entrée libre, sur réponse.', uid: 'evenement-2026-12-04@exemple.fr' };
  const utc = d => new Date(d).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const esc = s => s.replace(/\\/g, '\\\\').replace(/([,;])/g, '\\$1').replace(/\n/g, '\\n');
  const octets = s => new TextEncoder().encode(s).length;
  function plier(l) {
    const out = []; let cur = '';
    for (const c of l) { if (octets(cur + c) > (out.length ? 74 : 75)) { out.push(cur); cur = ''; } cur += c; }
    out.push(cur); return out.join('\r\n ');
  }
  function ics(e) {
    return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//exemple//agenda//FR', 'CALSCALE:GREGORIAN', 'BEGIN:VEVENT',
      'UID:' + e.uid, 'DTSTAMP:' + utc(Date.now()), 'DTSTART:' + utc(e.debut), 'DTEND:' + utc(e.fin),
      'SUMMARY:' + esc(e.titre), 'LOCATION:' + esc(e.lieu), 'DESCRIPTION:' + esc(e.texte),
      'END:VEVENT', 'END:VCALENDAR'].map(plier).join('\r\n') + '\r\n';
  }
  document.getElementById('ics').href = URL.createObjectURL(new Blob([ics(EV)], { type: 'text/calendar;charset=utf-8' }));
}
</script>
```

**La direction décide.** Le libellé, la place et l’habillage du lien ; le nom du fichier.

**Vérifier.** Le fichier téléchargé : `DTSTART` en UTC, aucune ligne de plus de 75 octets, retours `\r\n`, virgules et points-virgules échappés ; ouvert dans un agenda, l’heure est la bonne.

## objet-en-scene

**Problème.** Un objet posé sur la page (photo de produit, pièce, spécimen) paraît collé : une seule ombre grise et floue qui le fait flotter, un recadrage qui coupe au hasard à 390 px, une image sans dimensions qui pousse le texte au chargement.

**Quand.** Un objet réel qui porte la preuve ou l’idée. **Pas quand** l’image est un fond d’atmosphère (`SAVOIR/SOURCE`, « Construire une atmosphère »).

**Procédé.** Un cadre au rapport fixé, qui réserve sa place ; l’image recadrée sur son point d’intérêt, choisi pour chaque largeur ; deux ombres, une courte et sombre au contact, une longue et douce au-delà, teintées de la couleur du fond, jamais noires. Un objet détouré prend les mêmes deux ombres en `filter: drop-shadow`, qui suit sa forme.

```html
<figure class="scene-objet">
  <div class="cadre"><img src="objet.jpg" width="1200" height="1500" alt="Décrire l’objet, sa matière et son angle de vue"></div>
  <figcaption>Légende de l’objet</figcaption>
</figure>
<style>
.scene-objet { margin: 0; container-type: inline-size }
.cadre { aspect-ratio: var(--rapport, 4 / 5); overflow: hidden; background: var(--fond, #e8e4dd);
  box-shadow: 0 1px 2px rgb(var(--ombre, 45 35 25) / .28), 0 22px 44px -14px rgb(var(--ombre, 45 35 25) / .32) }
.cadre img { display: block; width: 100%; height: 100%; object-fit: cover; object-position: var(--point, 50% 40%) }
@container (max-width: 420px) {
  .cadre { aspect-ratio: var(--rapport-mobile, 1) }
  .cadre img { object-position: var(--point-mobile, var(--point, 50% 40%)) }
}
</style>
```

**La direction décide.** Le rapport du cadre, le point d’intérêt, la couleur du fond et des ombres, la lumière ; l’objet lui-même.

**Vérifier.** À 1440 et 390 px, l’objet garde son point d’intérêt dans le cadre ; rien ne bouge au chargement ; l’ombre se lit comme un contact, pas comme un flottement, sur capture agrandie.

## emplacement-photo

**Problème.** Sans photo réelle du lieu, du produit ou des personnes, la page remplace l’image par un objet codé (étiquette, tableau, dessin) qui la déguise, ou laisse un rectangle gris qui fait gabarit. Un vrai studio fait l’inverse : il compose la page pour ses photos à venir.

**Quand.** La catégorie vend par l’image (commerce, lieu, service, portfolio, restaurant) et les photos manquent. **Pas quand** les photos sont fournies, ou quand la page n’a pas besoin d’image.

**Procédé.** Un cadre au ratio du futur cliché, à la place et à l’échelle qu’aura la photo ; un fond du ton dominant attendu, pris dans la palette ; une légende de prise de vue (sujet, cadrage, lumière) ; une mention discrète « photo à fournir ». Le cadre est décrit comme l’image attendue, pour la lecture d’écran. Aucune fausse photo, aucune icône d’appareil, aucun objet codé à la place.

```html
<figure class="emplacement-photo" style="--ratio: 4 / 5; --ratio-mobile: 1; --ton: #8a7b6a">
  <div class="cadre" role="img" aria-label="Photo à fournir : l’établi de l’atelier, lumière du matin, un vélo sur le pied"></div>
  <figcaption><span class="consigne">Photo à fournir</span> L’établi, lumière du matin, cadrage serré sur les mains et l’outil.</figcaption>
</figure>
<style>
.emplacement-photo { margin: 0; container-type: inline-size }
.emplacement-photo .cadre { aspect-ratio: var(--ratio); background: var(--ton);
  background-image: linear-gradient(160deg, rgb(255 255 255 / .10), transparent 60%);
  box-shadow: inset 0 0 0 1px rgb(0 0 0 / .08) }
.emplacement-photo figcaption { font-size: .8rem; margin-top: .5rem; opacity: .75 }
.emplacement-photo .consigne { font-weight: 600; margin-right: .4em }
@container (max-width: 420px) { .emplacement-photo .cadre { aspect-ratio: var(--ratio-mobile, var(--ratio)) } }
</style>
```

**La direction décide.** Le ratio, la place et l’échelle de chaque photo, le ton attendu, la consigne de prise de vue ; la mise en page reste celle qu’aura la page avec ses photos.

**Vérifier.** À 1440 et 390 px, le cadre garde son ratio et sa place ; il est décrit pour la lecture d’écran ; la page ne contient aucune image qui se donne pour une vraie photo du client.

## grille-modulaire

**Problème.** Une grille de cartes toutes égales se lit comme une galerie de boîtes : aucune priorité, aucun rythme.

**Quand.** Collection, plans, catalogue, tableau de bord, archive : plusieurs éléments de poids proche. **Pas quand** un seul élément porte la page.

**Procédé.** Des modules égaux, mais un ou deux qui en couvrent plusieurs pour désigner ce qui compte ; une gouttière constante ; la grille se resserre à 390 px sans tout empiler à égalité.

```html
<section class="grille-mod">
  <article class="module large">Module principal</article>
  <article class="module">Module</article><article class="module">Module</article>
  <article class="module">Module</article><article class="module haut">Module haut</article>
  <article class="module">Module</article>
</section>
<style>
.grille-mod { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); grid-auto-rows: 160px;
  gap: var(--gouttiere, 16px); grid-auto-flow: dense }
.grille-mod .large { grid-column: span 2; grid-row: span 2 }
.grille-mod .haut { grid-row: span 2 }
.module { background: var(--surface, #eee); padding: 16px }
@media (max-width: 500px) { .grille-mod { grid-template-columns: 1fr 1fr } .grille-mod .large { grid-column: 1 / -1 } }
</style>
```

**En application, en affiche.** En application : tableau de bord, galerie. En affiche : un programme, une grille d'événements.

**La direction décide.** Le module de base, la gouttière, lesquels s'agrandissent et pourquoi.

**Vérifier.** À 1440 px, au moins trois colonnes et un module qui en couvre deux ; à 390 px, deux colonnes au plus, sans débordement.

## grille-colonnes

**Problème.** Le texte court toute la largeur, ou les blocs se posent sans rapport entre eux ; la page n'a pas de mesure.

**Quand.** Lecture, article, page de service, présentation : un texte qui doit se lire. **Pas quand** la page est un tableau ou une scène d'image.

**Procédé.** Douze colonnes ; le texte occupe six à sept colonnes (45 à 80 signes), les notes et images s'alignent sur les mêmes lignes de colonnes ; à 390 px, une seule colonne.

```html
<div class="grille-col">
  <h2 class="titre">Titre de section</h2>
  <p class="corps">Un texte de lecture tient sa mesure : ni trop long, ni trop court. Il commence sur la même ligne de colonne que le titre et laisse la place à une note.</p>
  <aside class="note">Note alignée sur la colonne 10.</aside>
</div>
<style>
.grille-col { display: grid; grid-template-columns: repeat(12, 1fr); column-gap: 24px; max-width: 1200px; margin: 0 auto; padding: 0 24px }
.grille-col .titre { grid-column: 2 / span 8 }
.grille-col .corps { grid-column: 2 / span 6; max-width: 70ch }
.grille-col .note { grid-column: 10 / span 3; font-size: .875rem }
@media (max-width: 700px) { .grille-col { grid-template-columns: 1fr } .grille-col .titre, .grille-col .corps, .grille-col .note { grid-column: 1 / -1 } }
</style>
```

**En application, en affiche.** En application : écran de lecture, aide. En affiche : colonnes d'un texte long, programme.

**La direction décide.** Le nombre de colonnes occupées, la gouttière, la place des notes.

**Vérifier.** Le corps garde 45 à 80 signes par ligne à 1440 px ; titre et corps partent de la même ligne de colonne ; à 390 px, une colonne.

## grille-radiale

**Problème.** Des éléments qui dépendent d'un même centre (un temps, un lieu, une valeur) sont posés en liste, et le centre ne se voit pas.

**Quand.** Une journée, un cycle, un lieu central, des choix autour d'un foyer. **Pas quand** les éléments n'ont pas de centre commun : le cercle devient un décor.

**Procédé.** Les éléments se placent sur un cercle autour du foyer, par rotation puis contre-rotation pour garder le texte droit ; l'ordre du document reste l'ordre de lecture ; à 390 px, le rayon se réduit ou les éléments repassent en liste.

```html
<div class="radiale" style="--n: 6">
  <div class="foyer">Foyer</div>
  <ol class="rayons">
    <li style="--i: 0">8 h</li><li style="--i: 1">10 h</li><li style="--i: 2">12 h</li>
    <li style="--i: 3">14 h</li><li style="--i: 4">16 h</li><li style="--i: 5">18 h</li>
  </ol>
</div>
<style>
.radiale { position: relative; width: min(520px, 90vw); aspect-ratio: 1; margin: 0 auto; --r: min(200px, 34vw) }
.radiale .foyer { position: absolute; inset: 50% auto auto 50%; translate: -50% -50%; font-weight: 700 }
.radiale .rayons { list-style: none; margin: 0; padding: 0 }
.radiale .rayons li { position: absolute; left: 50%; top: 50%; width: 64px; margin: -12px 0 0 -32px; text-align: center;
  transform: rotate(calc(var(--i) * 360deg / var(--n))) translateY(calc(-1 * var(--r))) rotate(calc(var(--i) * -360deg / var(--n))) }
</style>
```

**En application, en affiche.** En application : sélecteur d'heure, état d'un cycle. En affiche : composition autour d'un centre fort.

**La direction décide.** Le foyer, le rayon, le nombre d'éléments, ce qui se lit au centre.

**Vérifier.** Les éléments sont à égale distance du foyer ; à 390 px, rien ne déborde ; l'ordre de lecture suit l'ordre du document.

## grille-hierarchique

**Problème.** Toutes les zones ont la même taille : l'œil ne sait pas par où entrer.

**Quand.** Une page d'accueil, une une, un tableau de bord avec un indicateur principal. **Pas quand** les éléments sont réellement égaux.

**Procédé.** Une zone maîtresse au moins deux fois plus grande que les autres, des zones secondaires rangées autour ; à 390 px, la zone maîtresse passe en premier.

```html
<div class="hier">
  <div class="maitre">Zone maîtresse</div>
  <div class="second">Secondaire</div><div class="second">Secondaire</div><div class="second">Secondaire</div>
</div>
<style>
.hier { display: grid; grid-template-columns: 2fr 1fr; grid-template-rows: repeat(3, 120px); gap: 16px }
.hier .maitre { grid-row: 1 / -1; background: var(--surface-forte, #ddd); padding: 24px }
.hier .second { background: var(--surface, #eee); padding: 16px }
@media (max-width: 600px) { .hier { grid-template-columns: 1fr; grid-template-rows: auto } .hier .maitre { min-height: 240px } }
</style>
```

**En application, en affiche.** En application : l'indicateur principal d'un tableau de bord. En affiche : le sujet principal et ses informations.

**La direction décide.** Ce qui est maître, l'écart de taille, l'ordre des secondaires.

**Vérifier.** La zone maîtresse a au moins deux fois la surface de chaque autre ; à 390 px, elle vient en premier.

## grille-ligne-de-base

**Problème.** Les blocs de texte voisins ne tombent pas sur les mêmes lignes ; les espacements sont choisis au hasard, et la page paraît flottante.

**Quand.** Lecture dense, édition, documentation, affiche typographique. **Pas quand** la page est faite surtout d'images.

**Procédé.** Une unité de ligne (par exemple 8 px) ; interlignes, marges et hauteurs en multiples de cette unité.

```html
<div class="base">
  <h2>Titre sur la ligne</h2>
  <p>Un paragraphe dont l'interligne et les marges sont des multiples de l'unité de ligne.</p>
  <p>Un second paragraphe qui tombe sur la même trame.</p>
</div>
<style>
.base { --ligne: 8px }
.base h2 { font-size: 32px; line-height: calc(var(--ligne) * 5); margin: 0 0 calc(var(--ligne) * 2) }
.base p { font-size: 17px; line-height: calc(var(--ligne) * 3); margin: 0 0 calc(var(--ligne) * 3) }
</style>
```

**En application, en affiche.** En application : écrans de lecture, listes. En affiche : colonnes de texte alignées d'un bloc à l'autre.

**La direction décide.** L'unité de ligne, les multiples de chaque rôle.

**Vérifier.** Interlignes et marges des titres et paragraphes sont des multiples de l'unité.

## grille-axiale

**Problème.** Un centrage par défaut (tout au milieu, sans tension) se confond avec un axe voulu.

**Quand.** Une invitation, une couverture, une page de manifeste, un moment solennel. **Pas quand** la page sert une tâche longue ou une comparaison.

**Procédé.** Un axe unique, rendu visible par des écarts francs (grand vide, puis un bloc serré), et au plus un élément qui s'en écarte pour désigner l'idée.

```html
<section class="axe">
  <p class="sur">Sur-titre</p><h2 class="grand">Titre</h2><p class="ligne">Une ligne d'information</p>
  <a class="action" href="#">Agir</a>
</section>
<style>
.axe { display: flex; flex-direction: column; align-items: center; text-align: center; padding: 96px 24px; gap: 8px }
.axe .grand { font-size: clamp(40px, 8vw, 96px); line-height: 1; margin: 24px 0 }
.axe .action { margin-top: 48px }
</style>
```

**En application, en affiche.** En application : écran d'accueil, confirmation. En affiche : composition symétrique, avec ses écarts.

**La direction décide.** Les écarts, l'élément qui s'écarte de l'axe, s'il y en a un.

**Vérifier.** Les éléments sont centrés sur l'axe ; les écarts sont francs, pas égaux partout.

## superposition

**Problème.** Tout est rangé côte à côte ; aucune profondeur, aucun lien visible entre une image et son texte.

**Quand.** Une image et son titre, une carte et sa donnée, un objet et son annotation. **Pas quand** le chevauchement gênerait la lecture ou l'action.

**Procédé.** Les deux éléments dans les mêmes cellules d'une grille, l'un décalé d'une ou deux colonnes ; l'ordre de profondeur est réglé (`z-index`) et le texte garde son contraste sur le fond réel.

```html
<div class="couches">
  <div class="fond-image" role="img" aria-label="Image principale"></div>
  <div class="carte-texte"><h3>Titre posé sur l'image</h3><p>Le texte reste lisible.</p></div>
</div>
<style>
.couches { display: grid; grid-template-columns: repeat(12, 1fr); align-items: end; max-width: 1100px; margin: 0 auto }
.couches .fond-image { grid-column: 1 / span 8; grid-row: 1; aspect-ratio: 4 / 3; background: var(--image, #9aa) }
.couches .carte-texte { grid-column: 7 / span 5; grid-row: 1; z-index: 1; background: var(--surface, #fff); padding: 24px; margin-bottom: -32px }
@media (max-width: 600px) { .couches .fond-image { grid-column: 1 / -1 } .couches .carte-texte { grid-column: 2 / -1 } }
</style>
```

**En application, en affiche.** En application : une carte posée sur une image. En affiche : un titre qui mord sur l'image.

**La direction décide.** Ce qui passe devant, le décalage, la part de recouvrement.

**Vérifier.** Les deux éléments se recouvrent ; le texte est devant ; à 390 px, rien ne déborde.

## decoupe-masque

**Problème.** Toutes les images sont des rectangles ; la forme ne dit rien du sujet.

**Quand.** Une forme qui appartient au sujet (une arche, une fenêtre, une étiquette, un pli). **Pas quand** la découpe n'aurait pas de raison : elle devient un effet.

**Procédé.** `clip-path` ou `mask-image` sur l'image, avec un repli rectangulaire quand la propriété manque ; le texte ne se découpe pas.

```html
<div class="decoupe" role="img" aria-label="Image découpée en arche"></div>
<style>
.decoupe { width: min(420px, 100%); aspect-ratio: 3 / 4; background: var(--image, #8a9) }
@supports (clip-path: inset(0 round 1px)) {
  .decoupe { clip-path: inset(0 round 50% 50% 0 0 / 30% 30% 0 0) }
}
</style>
```

**En application, en affiche.** En application : un avatar, une vignette de marque. En affiche : une image découpée par la forme du sujet.

**La direction décide.** La forme et sa raison dans le sujet.

**Vérifier.** La découpe s'applique quand elle est prise en charge, et le rectangle reste propre sinon.

## fond-perdu

**Problème.** Tout tient dans une colonne centrée ; rien ne touche le bord, et la page manque d'ampleur.

**Quand.** Une image, une bande de couleur ou un objet qui doit occuper l'espace. **Pas quand** le texte courant deviendrait trop large.

**Procédé.** L'élément sort de la colonne jusqu'au bord de la fenêtre, sans barre de défilement horizontale ; le texte, lui, reste dans sa mesure.

```html
<div class="colonne">
  <p>Texte dans sa colonne.</p>
  <div class="perdu" role="img" aria-label="Image à fond perdu"></div>
  <p>Le texte reprend dans sa colonne.</p>
</div>
<style>
.colonne { max-width: 680px; margin: 0 auto; padding: 0 24px }
.perdu { width: 100vw; margin-left: calc(50% - 50vw); height: 320px; background: var(--image, #9ab) }
html, body { overflow-x: clip }
</style>
```

**En application, en affiche.** En application : une bannière, une image d'en-tête. En affiche : une image qui touche le bord du papier.

**La direction décide.** Ce qui part à fond perdu, et à quel moment de la séquence.

**Vérifier.** À 1440 et 390 px, l'élément touche les deux bords et la page ne défile pas en largeur.

## grille-rompue

**Problème.** Tout est parfaitement aligné, et rien ne se distingue ; ou au contraire tout bouge, et plus rien ne tient.

**Quand.** Un seul élément doit désigner l'idée. **Pas quand** plusieurs éléments rompraient en même temps : la rupture devient du désordre.

**Procédé.** Tous les éléments sur la grille, sauf un, qui la dépasse (marge négative, colonne hors de la zone de texte) ; la rupture est unique et voulue.

```html
<div class="rompue">
  <h2>Titre aligné</h2><p>Paragraphe aligné sur la grille.</p>
  <figure class="hors" role="img" aria-label="L'élément qui rompt la grille"></figure>
  <p>Paragraphe aligné, après la rupture.</p>
</div>
<style>
.rompue { max-width: 720px; margin: 0 auto; padding: 0 24px }
.rompue .hors { margin: 32px -120px 32px 40%; height: 220px; background: var(--accent, #c63) }
@media (max-width: 900px) { .rompue .hors { margin: 24px -24px 24px 30% } }
html, body { overflow-x: clip }
</style>
```

**En application, en affiche.** En application : une carte mise en avant qui dépasse sa liste. En affiche : un élément qui sort de la marge.

**La direction décide.** L'élément qui rompt, et la seule raison de le faire.

**Vérifier.** Un seul élément sort de la zone de texte, les autres restent alignés, et la page ne défile pas en largeur.

## details-composants

**Problème.** Les composants sont justes mais plats : une ombre unique et grise, des bords qui se perdent, des états qui se ressemblent, des icônes trop fines, des cibles trop petites.

**Quand.** Tout composant ordinaire : bouton, carte, champ, image, navigation. **Pas quand** un design system fournit déjà ces détails.

**Procédé.** Ombre en deux couches (ambiante et directe) et bord semi-transparent ; bords et ombres teintés vers le fond quand il n'est pas neutre ; survol, appui et focus plus contrastés que le repos, sans déplacer la cible ; contour intérieur de 1 px sur les images ; marge réduite du côté de l'icône ; cibles de 44 px au toucher ; coins en superellipse là où c'est pris en charge.

```html
<article class="carte-pro">
  <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='320' height='180'%3E%3Crect width='320' height='180' fill='%23e8e2d8'/%3E%3C/svg%3E" width="320" height="180" alt="Vignette">
  <h3>Titre de carte</h3>
  <button class="btn-icone tactile" type="button"><svg aria-hidden="true" width="16" height="16" viewBox="0 0 16 16"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="2"/></svg>Ajouter</button>
</article>
<style>
.carte-pro { --teinte: 30 25 20; max-width: 320px; padding: 16px; border-radius: 16px; background: #fff;
  border: 1px solid rgb(var(--teinte) / .10);
  box-shadow: 0 1px 2px rgb(var(--teinte) / .08), 0 8px 24px -6px rgb(var(--teinte) / .16) }
@supports (corner-shape: superellipse(1.5)) { .carte-pro { corner-shape: superellipse(1.5) } }
.carte-pro img { display: block; width: 100%; height: auto; border-radius: 8px; outline: 1px solid rgb(0 0 0 / .08); outline-offset: -1px }
.btn-icone { display: inline-flex; align-items: center; gap: 8px; padding: 0 16px 0 12px; min-height: 36px; border-radius: 10px;
  border: 1px solid rgb(var(--teinte) / .14); background: #222; color: #fff; font: inherit; cursor: pointer;
  transition: background-color .12s ease, box-shadow .12s ease }
.btn-icone.tactile { min-height: 44px }
.btn-icone:hover { background: #000; box-shadow: 0 2px 8px rgb(0 0 0 / .25) }
.btn-icone:active { background: #000; box-shadow: inset 0 1px 2px rgb(0 0 0 / .4) }
.btn-icone:focus-visible { outline: 2px solid #1a5cff; outline-offset: 2px }
</style>
```

**En application, en affiche.** En application : toutes les parties ordinaires. En affiche : sans objet pour les états, mais les ombres, les bords et les contours d'image valent aussi.

**La direction décide.** La teinte des bords et des ombres, les rayons, la couleur des états ; la recette règle le comportement.

**Vérifier.** La carte a deux couches d'ombre ; l'appui ne déplace pas le bouton ; l'image a son contour intérieur ; le bouton tactile mesure au moins 44 px ; le focus se voit au clavier.

Pour l’ensemble des références de la skill, revenir à leur [index](README.md).
