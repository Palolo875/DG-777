# Journal des changements

Les changements visibles de Design Governance, par version publique. Le détail de ce que contient la version en cours est dans [la fiche de version](maintenance/versions.md) ; ce qui est vérifié, et ce qui ne l’est pas, aussi.

## V1.1.1 — 25 novembre 2026

Révision interne `R2026-11-15y`. Correctif issu d’une première évaluation sur deux rendus jugés à l’aveugle.

### Corrigé

- **L’atelier sur capture vaut dans tous les modes** dès que la décision visuelle est ouverte : lecture sans le texte, test de retrait, défaut dominant corrigé, puis passe de finition. Depuis la V1.1.0, il n’était dit que pour le mode direction ; un rendu en mode standard s’en est passé et en est sorti trop dense.

### Mesuré

- Sur deux objets refaits avec la V1.1.0 et comparés à la révision précédente : environ 29 % de tours et 32 % de lecture en moins. Qualité : une paire gagnée, une perdue ; rien n’est conclu sur ce point.

## V1.1.0 — 22 novembre 2026

Révision interne `R2026-11-15x`. Aucune mesure comparative de qualité n’accompagne cette version : l’évaluation sur des rendus reste à faire.

### Ajouté

- **Un noyau-index.** La skill porte les règles de chaque demande, une ligne pour chaque obligation, et l’index de toutes les sections (85) : tel signal, telle section à lire. Le détail des procédures reste servi par sa section, lue au moment utile.
- **Un passage « Sans outils ».** Sans exécution de code, l’agent lit les fichiers directement ; ce qui demande une capture ou un script est déclaré non vérifié, jamais réussi. Le guide de niveau 1 le dit aussi aux personnes.
- **Des outils plus sobres** : une image par version pendant la boucle (`parcours.py captures --version`), une vérification qui ne répète que ce qui a changé, un démarrage en une commande (`parcours.py chantier`), un sommaire en tête du tronc d’un mode.
- **Une référence générée** depuis les sources : toutes les commandes et leurs options, toutes les sections et leur sujet ([`guides/reference.md`](guides/reference.md)).
- **Une quatrième carte**, « Comment l’agent lit » ([`supports/lecture.md`](supports/lecture.md)).
- **Les fichiers du projet** : licences, ce journal, citation, guide de contribution, présentation en anglais.

### Changé

- Le noyau passe de 45 876 à 31 057 octets ; un run en mode direction lit d’office environ 16 % de texte en moins.
- Les pages d’entrée parlent en mots, sans codes internes, et toute page est à trois clics au plus du README.

### Contrôles ajoutés

- Chaque obligation reste visible au noyau, en bloc ou en ligne qui nomme sa section ; l’index cite chaque section ; aucune consigne du noyau ne suppose un second agent.
- La référence générée reste identique à ses sources ; aucune ligne des cartes ne déborde de son encadré.
- Aucun nom tiré des essais du système (brief, lieu, titre) n’entre dans le paquet.

## V1.0.0

Première version publiée. Son contenu est décrit dans [la fiche de version](maintenance/versions.md) ; les révisions internes qui l’ont suivie sont reprises dans la V1.1.0.
