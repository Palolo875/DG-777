# Références — exemples de runs

> Ces exemples sont des aides non canoniques. Reprendre la séquence, pas le style, les valeurs, les composants ou les décisions visuelles. Les cas sont `ILLUSTRATIVE` et `SIMULATED` sauf mention contraire. Les champs affichés varient volontairement selon le mode : une omission dans une condensation n’est pas une suppression de la règle correspondante et ces blocs ne constituent pas un formulaire universel de `RUN_CARD`. Les champs affichés respectent les contrats d’ACTION ; un champ omis reste dû dans la `RUN_CARD`.
>
> **Trace, pas sérialisation.** Ces blocs sont des traces : leurs noms (`OBSERVED`, `AXES`, `RISK` en phrase…) ne sont pas des clés JSON. Pour produire une `RUN_CARD`, partir de `gouvernance/schemas/run_card.example.json`, suivre [machine_projection.md](machine_projection.md) et la table de correspondance d’`ACTION/RUN_CARD`, puis contrôler avec `gouvernance/outils/validate_run_card.py`.
>
> **Niveau de trace.** Les exemples qui se terminent par `CLOSED` montrent une trace complète (clôture demandée ou run persistant) ; « fabrication depuis un brief flou » montre la sortie par défaut : une proposition, sa réponse visible et sa trace légère, sans clôture.

## LITE — correctif local

**Demande :** améliorer le contraste du bouton secondaire sans modifier la structure.

**Chemin :** classer `LITE` (fix local qui conserve la direction déjà tranchée, selon `DIRECTION/START`) → déclarer `DECISION-INTENT` → modifier → vérifier le ratio et l’état focus → clôturer avec la limite. Une retouche qui demande de rappeler et réévaluer la direction retrouvable relève de `ITER`. La clôture courte ci-dessous suit `ACTION/HANDOFF` et `ACTION/CLOSE-PACKAGE` ; elle est une trace complète sans RUN_CARD, avec artefact retrouvé et conditions de reprise applicables.

```text
MODE: LITE
DECISION-INTENT: améliorer la lisibilité sans élargir le scope
RISK: libellé secondaire illisible en contraste faible
ARTIFACT: diff et snapshot avant/après
OBSERVED: ratio 3,1:1 → 5,2:1 ; focus visible ; structure et interaction conservées
LIMIT: autres thèmes hors scope
AXES: V PASS · A PASS (contraste, focus) · U N/A-JUSTIFIED · T N/A-JUSTIFIED
DECISION-CHANGE: CONFIRMED — garder la hiérarchie du bouton secondaire et ne corriger que sa couleur (observation : snapshot avant/après, ratio mesuré)
VERDICT: ACCEPTED
STATE: CLOSED
```

Ne pas charger l’atlas ou une analyse de style si aucune responsabilité de design ne change.

## DIRECTION — fabrication depuis un brief flou

**Demande :** « Il me faut un site pour mon atelier de réparation de vélos. » Rien d’autre.

Les crochets marquent ce que chaque run tire de son propre brief : l’exemple ne fournit volontairement ni thèse ni objet de preuve, pour qu’ils ne soient pas recopiés.

**Prise de brief, dans le même tour :** la destination est une vraie mise en ligne. L’agent n’attend pas de réponse pour construire : il nomme ses hypothèses, marque les contenus d’exemple et place ses trois demandes dans la proposition (contenus réels : services, tarifs, horaires, adresse, numéro ; logo ou couleurs s’ils existent ; deux ou trois photos de l’atelier).

**Réponse visible :** « [Nom de la direction] : [sa vision, en une phrase]. J’ai construit une page d’accueil organisée autour de [l’objet de preuve, nommé avec ce qu’il montre]. Pourquoi : [ce qu’un client veut savoir avant de venir, et comment l’objet y répond] ; j’ai écarté la grande photo d’entrée suivie de trois cartes de services, que n’importe quel atelier aurait. Ce qui manque pour la vraie version : vos tarifs, vos horaires et votre numéro, votre logo ou vos couleurs s’ils existent, et deux ou trois photos de l’atelier ; les contenus affichés sont des exemples marqués comme tels, et le bouton « Appeler l’atelier » fonctionne avec un numéro d’exemple. Sans photos, la page tient sur l’objet codé ; avec les vôtres, la première scène gagnerait sa matière. La suite : envoyez ces éléments, je les intègre et je vérifie le mobile. Deux questions sur le rendu : [un point faible nommé, par exemple le bas de l’écran mobile, vous gêne-t-il ?] ; [le registre écarté sur la planche vous parlait-il davantage ?] Coût : [deux passes de `verifier`, aucune génération, deux références capturées]. »

**Trace (trace légère, écrite à côté de l’artefact) :**

```text
RUN: DIRECTION · décision : la première scène de l’atelier · risque : page de services interchangeable · preuve : planche, atelier, `parcours.py verifier` (recette à 1440, 768 et 390 px) · arrêt : aucun défaut bloquant, action au premier écran
DIRECTION DÉCLARÉE ET THÈSE: « [nom tiré du sujet] » : [vision en une phrase] ; registre : [base et modificateur, deux marqueurs] ; expression : [sobre, affirmée ou expressive] ; mouvement : [le moment orchestré, ou « aucun » et sa raison] ; lignes non vues : [aucune, ou celles qui restent] ; [ce que le client veut savoir] → [objet de preuve, composant codé, contenus marqués « exemple »] → [le geste attendu]
MODAL, TRAME ET PARTI: photo pleine largeur, titre centré, trois cartes « nos services » ; trame héros → services → avis → contact, rompue : l’objet de preuve ouvre la page ; s’écarter pour la première scène seulement, garder la navigation et le contact attendus ; marqueur relevé : [nom], gardé par l’atelier contre une variante sans lui ; choisi par : auteur du rendu, sur la planche
PLAFOND, ESSAIS ET CONTENUS MARQUÉS: typographie et couleur au plafond (polices libres atteintes et vues sur capture, palette choisie pour la thèse) ; références : [deux ateliers réels ouverts, ce que chacun change dans le build] ; photos : vrai commerce, génération non autorisée, donc route SANS-ASSET assumée, l’objet codé porte la scène, aucune fausse photo ni vélo dessiné de mémoire ; tarifs, horaires et numéro marqués « exemple »
DÉFAUT DOMINANT RESTANT: aucun bloquant ; ce qui retient : [l’objet de preuve] ; ce qui reste générique : [une partie ordinaire] ; geste de `SAVOIR/STATE` appliqué et recapturé : [son nom], ou l’atelier qui a conservé
PROCHAINE PREUVE: vrais tarifs, horaires et numéro intégrés, puis capture mobile
```

## DIRECTION — première scène identitaire

**Demande :** créer une première scène mémorable pour [un service au domaine précis], sans page générique.

Comme plus haut, les crochets marquent ce que chaque run tire de son propre brief : l’exemple ne fournit ni thèse, ni objet, ni parti, pour qu’ils ne soient pas recopiés. La séquence et les champs, eux, sont à reprendre.

**Décisions :** thèse située, premier objet tiré du produit, composition, matière utile, composant construit pour ce produit, modal et parti. L’artefact doit être ouvrable et les données fictives marquées.

**Trace (trace légère) :**

```text
RUN: DIRECTION · décision : la première scène de [ce service] · risque : page générique · preuve : planche, atelier, `parcours.py verifier` · arrêt : premier objet lu en premier, aucun défaut bloquant
DIRECTION DÉCLARÉE ET THÈSE: « [nom tiré du sujet] » : [vision en une phrase] ; registre : [base et modificateur] ; expression : [sobre, affirmée ou expressive] ; mouvement : [le moment orchestré, ou « aucun » et sa raison] ; lignes non vues : [aucune, ou celles qui restent] ; [ce que la personne veut savoir] → [premier objet tiré du produit] → [premier geste]
MODAL, TRAME ET PARTI: [ce que n’importe quelle IA produirait : structure, palette, typographie, assets] ; trame [l’ordre attendu], rompue : [le premier objet] ouvre la page ; s’écarter pour [ce qui sert la thèse], garder [ce qui sert l’usage] ; choisi par : [auteur du rendu, personne ou absent]
PLAFOND, ESSAIS ET CONTENUS MARQUÉS: [couches au plafond, et l’essai fait pour chacune] ; données fictives marquées « exemple »
DÉFAUT DOMINANT RESTANT: aucun bloquant ; [le premier objet] remplace [l’élément attendu du modal] (paire v1/v1b : le premier geste est lu en premier) ; ce qui reste générique : [les états secondaires] ; geste de `SAVOIR/STATE` appliqué et recapturé : [son nom]
PROCHAINE PREUVE: parcours clavier et lecteur d’écran du premier objet
```

Une belle capture ne prouve pas l’usage. Une rationale ne prouve pas l’implémentation. Si le run est partagé, audité ou soumis à acceptation, la trace complète porte ces décisions dans la fiche (`ACTION/RUN_CARD`) : modal et parti, axes, verdict, et toute réserve avec owner, prochaine preuve, revue et condition de sortie.

## DIRECTION + STYLE — profil d’expression situé

**Demande :** donner une présence culturelle à [une collection ou une archive précise] sans transformer l’interface en décor.

**Choix :** tester [un profil de `SAVOIR/STYLE` choisi pour ce contenu] comme hypothèse d’expression. Le profil modifie la matière, le rythme et le traitement des pièces ; il ne choisit ni la structure ni le verdict. Les crochets marquent ce que le run tire de son brief.

**Trace (trace légère) :**

```text
RUN: DIRECTION · décision : la présence culturelle de [cette collection] sans décor · risque : un traitement qui nuit à la lecture · preuve : paire de captures avec et sans le traitement · arrêt : métadonnées lisibles, contrôles intacts
DIRECTION DÉCLARÉE ET THÈSE: « [nom tiré du sujet] » : [vision en une phrase] ; registre : [profil de `SAVOIR/STYLE`] comme hypothèse, réglé zone par zone (densité, mouvement, variance) ; expression : [sobre, affirmée ou expressive] ; [ce que la personne cherche] → [les pièces] → [le geste]
MODAL, TRAME ET PARTI: [grille de vignettes uniforme] ; trame [attendue], gardée : la collection se parcourt d’abord ; le profil transforme la matière, le rythme et le traitement des pièces, pas la structure ; choisi par : la personne, entre deux esquisses
PLAFOND, ESSAIS ET CONTENUS MARQUÉS: pièces et métadonnées réelles ; droits des pièces externes non validés ; contre-indication relue : lecture critique, contraste faible, effet sans relation au contenu
DÉFAUT DOMINANT RESTANT: le traitement débordait sur les contrôles ; il est limité aux pièces et retiré des contrôles critiques (paire de captures) ; mémorisation et tâche non vérifiées
PROCHAINE PREUVE: un protocole utilisateur (participants, tâche, mesure) si la mémorisation devient une décision
```

Le profil peut être refusé si la paire ne change aucune décision ou si la matière nuit à la lisibilité. En trace complète, le profil se décide dans `PROFILE-DECISION` (`SAVOIR/STYLE`), qui n’autorise pas à imiter une référence.

## SYSTÈME — composant partagé

**Demande :** ajouter au Select un libellé long, une aide et un état d’erreur sans casser les écrans existants.

**Chemin :** classer `SYSTÈME` → inventorier les dépendances → modifier la primitive et ses états → inspecter des consommateurs représentatifs → corriger ou restaurer.

```text
MODE: SYSTÈME
DECISION-INTENT: étendre le Select sans rompre clavier, focus ou compatibilité
RISK: blast radius partagé
ARTIFACT: composant, états, captures et consommateurs représentatifs
OBSERVED: libellé long, erreur, focus et clavier dans trois consommateurs ; troncature observée sur mobile dans le consommateur 2
EVIDENCE: captures avant/après des trois consommateurs, à 390 et 1440 px : la troncature du consommateur 2 est visible (claim visuel seulement)
NOT-VERIFIED: autres écrans, plateformes et thèmes
DECISION-CHANGE: ABANDONED — l’extension du Select en l’état est abandonnée : la troncature mobile casse ce consommateur ; une version corrigée reprend dans le même mode (observation : consommateur 2)
ISSUE: RETURNED
VERDICT: RETURN
STATE: CLOSED
```

Le blast radius appartient au scope du run ; il ne devient pas un score global.

