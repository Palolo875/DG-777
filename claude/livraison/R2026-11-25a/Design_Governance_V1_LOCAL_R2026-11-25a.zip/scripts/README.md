# Outils du paquet

Ce dossier contient les scripts qui lisent le système, observent un rendu et contrôlent la cohérence du paquet. Les commandes s’exécutent depuis la racine du paquet ; leur mode d’emploi complet est dans [la validation](../maintenance/README.md#validation).

| Script | Rôle |
|---|---|
| `read_route.py` | Lecteur de routes : sert une section par son code, la ligne d’un mode et son tronc (`--mode`, `--tronc`, `--tronc MODE --fichier CHEMIN` pour écrire la ligne du mode et le tronc dans un fichier lu une fois), une recherche (`--trouver`) et les connexions situées. |
| `check_render.py` | Recette de rendu dans un navigateur : fautes objectivables d’une page HTML aux largeurs courantes. Son périmètre et ses limites sont décrits dans `ACTION/RECETTE-RENDU`. |
| `journal_mobilisation.py` | Journal de mobilisation, passif : avec la variable `DG_JOURNAL=chemin.jsonl`, les outils de lecture et de rendu notent ce qu’ils ont servi ; sans elle, rien n’est écrit. `python3 scripts/journal_mobilisation.py chemin.jsonl` en tire une fiche : ce qui a été servi et où la sortie est allée (écran, fichier, `/dev/null`) ; un filtre vu dans la commande (« … \| head ») y est un indice. Une route servie n’est pas une route lue ; conséquence et preuve restent à établir. |
| `planche.py` | Planche de comparaison : plusieurs premiers écrans côte à côte, en bureau et en mobile, ou au bureau seul (`--bureau-seul`) pour comparer des esquisses, la modale en référence ; sert le levier « Diverger sur image » (`DIRECTION/DIVERGENCE`). Elle ne juge rien. |
| `regard.py` | Commande de regard : attention au premier écran (approximation classique, ou modèle ONNX à brancher), foyer déclaré, contraste de tout texte sur le fond réel capturé (SVG compris), page réduite, test de support, comparaison avec un rendu précédent (`--antecedent` : paire typographique, teinte dominante, registre) et marqueurs de vague relevés au premier écran, d’après la liste datée de `SAVOIR/TOOLS/CONVERGENCE`. Des signaux, pas des verdicts. Demande NumPy, SciPy et Pillow. |
| `parcours.py` | Parcours par défaut : quinze sous-commandes, décrites ci-dessous. Des signaux, pas des verdicts ; seuils `[À ADAPTER]`. Demande Pillow et NumPy, et ce que demandent les outils qu’il enchaîne. |
| `build_core.py` | Compile le noyau de la skill dans `SKILL.md` depuis les blocs « noyau » des fichiers de règles ; un bloc « différé » reste servi par sa route ; `--check` vérifie sans écrire. |
| `reference.py` | Écrit `guides/reference.md` depuis les sources : l’aide de chaque outil et de chaque commande de `parcours.py`, et les sections servies par le lecteur avec leur sujet. `--verifier` rend le code 1 si la page diffère de sa génération (garde DOC-03). |
| `validate_all.py` | Lance l’ensemble des contrôles ci-dessous. |
| `validate_design_governance.py`, `validate_structure.py`, `validate_reading_map.py`, `validate_supports.py` | Inventaire, liens et références, structure et chargement, carte de lecture, fraîcheur des cartes. |
| `test_read_route.py`, `test_core_budget.py`, `test_audit_regressions.py`, `test_check_render.py`, `test_journal_mobilisation.py`, `test_regard.py`, `test_parcours.py` | Tests du lecteur, du budget du noyau, des régressions de navigation, de la recette de rendu, du journal de mobilisation, de la commande de regard, de la planche et du parcours par défaut. |
| `package_manifest.json` | Liste des fichiers attendus dans chaque distribution. |
| `scripts/preparer_livraison.py`, `scripts/build_distributions.sh`, `scripts/test_preparer_livraison.py` | Distribution GitHub seulement : préparation d’une livraison (compilation, contrôles, exports), construction des deux distributions et ses tests. <!-- références:github --> |
| `scripts/principes.py` | Distribution GitHub seulement : régénère les six planches de principes de `design/principes/` (Playwright, Chromium et Pillow requis). Une planche montre un mécanisme en avant/après sur un contenu neutre ; elle est citée par sa route. <!-- références:github --> |

### Sous-commandes de `parcours.py`

Chacune s’appelle avec `python3 scripts/parcours.py SOUS-COMMANDE` ; `--help` en donne les options.

| Sous-commande | Ce qu’elle fait |
|---|---|
| `verifier` | Une passe sur une page : recette de rendu (1440, 768 et 390 px), regard, captures, signaux de finition, noms accessibles et ordre de tabulation, poids de la page (signal au-delà de repères), page entière réduite, planche de mouvement. Écrit une seule fiche `parcours.md` à côté de la page et n’affiche que les défauts, les réserves, les signaux et la première image à regarder. `--refs` ajoute les mesures des références. Dès le troisième appel pour une page, il affiche le compte des appels. |
| `captures` | Premier écran, page entière et @2x à chaque largeur, foyer agrandi, téléphone émulé sous 768 px. `--version v2` fait la capture d’une version pendant la boucle, en une image (premiers écrans côte à côte, 1×) ; `--separees` une image par largeur ; `--pleine` la page entière à livrer. |
| `finition` | Signaux mesurables de finition, chacun avec sa question et son geste lus dans `SAVOIR/STATE` (rayons, ombres, familles, tailles, teintes, typographie fine, habillage de gabarit…). |
| `mouvement` | Planche de mouvement : entrée image par image, défilement, survol, mouvement réduit, avec ses questions. |
| `references` | Capture des sites donnés (premier écran, page entière découpée et mesurée), des images de collections ouvertes et de banques à clé, et un fichier trouvé ailleurs avec sa licence, chacun avec sa provenance. Signale une page courte ou couverte par un bandeau de consentement. |
| `polices` | Télécharge des polices libres (Fontsource, puis Google Fonts, puis Fontshare ; `--source fontshare` pour Fontshare seul) et écrit leur feuille, licence rapportée. `--catalogue` liste les familles de Fontshare par catégorie. |
| `icones` | Télécharge des icônes d’une seule famille ouverte, avec leur licence. |
| `typo` | Espaces insécables du français et points de suspension dans le texte visible ; `--corriger` les écrit. |
| `identite` | Planche d’épreuve d’un signe de marque, de 16 à 256 px, en noir, gris, inversé, sur photo, en avatar, onglet et en-tête ; signaux mesurés dans une fiche `identite.md` (`SAVOIR/IDENTITY`). |
| `chantier` | Le démarrage en un appel : dossiers, tirage, leviers des pôles donnés (`--poles`), gabarit de trace légère ; aucune décision écrite. |
| `tirage` | Tire au sort deux pistes du sujet et une dimension de registre, pour l’une des esquisses. |
| `leviers` | Avant le build : leviers de départ et piège réflexe des pôles de caractère choisis (`BIBLIOTHEQUE/READ`), avec l’ordre de composition et « Classique et expressif » (`SAVOIR/FRAME`), lus à leur lieu. |
| `recette` | Affiche une recette de procédé (`references/recettes.md`). |
| `trace` | Contrôle la forme de la trace légère écrite à côté de l’artefact (fichier de trace ou en-tête du fichier livré) : les six lignes nommées de l’exemple de `references/examples.md`, présentes, dans l’ordre, une fois chacune ; une ligne de plus de 600 caractères, un geste seulement envisagé et une ligne « modal, trame et parti » qui ne dit pas qui a choisi sont signalés. `verifier` la propose quand une trace se trouve à côté de la page. |
| `critique` | Prépare un regard séparé : images seules, et consigne pour un agent neuf qui ne lit ni la direction ni la trace. |

Ces outils attestent la cohérence du paquet et observent des fautes mesurables ; ils ne jugent ni la direction, ni le goût, ni l’usage. Les schémas et validateurs de la fiche de travail sont dans [`gouvernance/`](../gouvernance/README.md).
