#!/usr/bin/env python3
"""Référence du paquet, générée depuis les sources : `guides/reference.md`.

La page n'est jamais écrite à la main. Elle reprend l'aide de chaque outil (`--help`, et chaque commande de
`parcours.py`) et la liste des routes servies par le lecteur, rangées par famille, avec le sujet que nomme leur titre. Elle ne nomme
pas le fichier d'une route : une section déplacée avec son titre ne la rend pas fausse.

Usage :
  python3 scripts/reference.py            écrit guides/reference.md
  python3 scripts/reference.py --verifier rend le code 1 si la page diffère de sa génération (garde DOC-03)
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "guides" / "reference.md"
OUTILS = ("read_route", "parcours", "check_render", "planche", "regard")
FAMILLES = ("DIRECTION", "ACTION", "SAVOIR", "BIBLIOTHEQUE")

sys.path.insert(0, str(ROOT / "scripts"))
import read_route as rr  # noqa: E402


def aide(*args: str) -> str:
    """Aide d'une commande, à largeur fixe, pour qu'elle ne dépende pas du terminal."""
    env = {**os.environ, "COLUMNS": "100", "DG_JOURNAL": ""}
    r = subprocess.run([sys.executable, *args, "--help"], cwd=ROOT, env=env, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"REFERENCE FAILED — aide indisponible : {' '.join(args)} ({r.stderr.strip()[:200]})")
    return r.stdout.rstrip()


def sous_commandes() -> list[str]:
    import re
    m = re.search(r"\{([a-z,_-]+)\}", aide("scripts/parcours.py"))
    if not m:
        raise SystemExit("REFERENCE FAILED — liste des commandes de parcours.py introuvable")
    return m.group(1).split(",")


# Sujets dits pour les personnes quand le titre de la section ne porte que son code, ou un mot gardé pour l'agent
# seulement (garde LAN-01). Le titre propriétaire ne change pas : ses ancres restent valides.
SUJETS = {
    "ACTION/RUN-LITE": "exécution du mode LITE",
    "ACTION/RUN-ITER": "exécution du mode ITER",
    "ACTION/RUN-STANDARD": "exécution du mode STANDARD",
    "ACTION/RUN-DIRECTION": "exécution du mode DIRECTION",
    "ACTION/RUN-SYSTEM": "exécution du mode SYSTÈME",
    "ACTION/ANTI-SLOP": "conséquence au contrôle d'un motif générique",
    "SAVOIR/SYSTEM": "jetons de design et composants",
}


def titre(locator: str) -> str:
    """Le sujet d'une section, tel que son titre le nomme après le code : une étiquette, pas une consigne."""
    if locator in SUJETS:
        return SUJETS[locator]
    _, lines, index = rr.resolve(locator)
    titre = lines[index].lstrip("#").strip().replace("`", "")
    if " — " not in titre:
        raise SystemExit(f"REFERENCE FAILED — {locator} : titre sans sujet ; l'ajouter à SUJETS dans scripts/reference.py")
    return titre.split(" — ", 1)[-1].strip()


def generer() -> str:
    out = ["# Référence",
           "",
           "_Page générée par `scripts/reference.py` depuis les sources ; ne pas la modifier à la main. "
           "Après un changement d’outil ou de route : `python3 scripts/reference.py`._",
           "",
           "Pour chercher un sujet plutôt qu’une commande : le [glossaire](glossaire.md) et le [niveau 2](2-comprendre.md).",
           "",
           "## Commandes",
           ""]
    for outil in OUTILS:
        out += [f"### `{outil}.py`", "", "```text", aide(f"scripts/{outil}.py"), "```", ""]
        if outil == "parcours":
            for commande in sous_commandes():
                out += [f"#### `parcours.py {commande}`", "", "```text", aide("scripts/parcours.py", commande), "```", ""]
    rows = rr.summary_rows()
    out += ["## Sections servies par le lecteur",
            "",
            f"{len(rows)} sections, chacune lue par son code : `python3 scripts/read_route.py CODE`.",
            ""]
    for famille in FAMILLES:
        lignes = sorted((loc, titre(loc)) for loc, *_ in rows if loc.split("/")[0] == famille)
        if not lignes:
            continue
        out += [f"### {famille}", "", "| Code | Sujet |", "|---|---|"]
        out += [f"| `{loc}` | {sujet.replace('|', '/')} |" for loc, sujet in lignes]
        out.append("")
    autres = [loc for loc, *_ in rows if loc.split("/")[0] not in FAMILLES]
    if autres:
        raise SystemExit(f"REFERENCE FAILED — famille inconnue : {', '.join(autres)}")
    return "\n".join(out).rstrip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Écrit ou vérifie la référence générée (guides/reference.md).")
    parser.add_argument("--verifier", action="store_true", help="vérifie sans écrire ; code 1 si la page diffère")
    args = parser.parse_args()
    texte = generer()
    if args.verifier:
        actuel = PAGE.read_text(encoding="utf-8") if PAGE.is_file() else ""
        if actuel != texte:
            print("REFERENCE FAILED — guides/reference.md diffère de sa génération : lancer python3 scripts/reference.py")
            return 1
        print("REFERENCE PASSED — guides/reference.md identique à sa génération")
        return 0
    PAGE.write_text(texte, encoding="utf-8")
    print(f"REFERENCE ÉCRITE — guides/reference.md, {len(texte)} caractères")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
