# Contribuer

Merci de vouloir améliorer Design Governance. Le système est expérimental : une proposition argumentée vaut mieux qu’un changement rapide.

## Proposer

- **Un constat** (une règle floue, un rendu raté, un outil qui se trompe) : ouvrez une issue avec ce que vous avez demandé, ce que l’agent a produit, et ce qui aurait dû se passer. Une capture aide.
- **Un changement** : décrivez d’abord le problème et la règle ou l’outil touché, puis proposez le changement dans une pull request.

## Écrire une règle

Suivez la procédure « Ajouter ou modifier une règle » de [`maintenance/README.md`](maintenance/README.md) : titre à code, manifeste et README du dossier, noyau si la règle vaut à chaque demande, plancher si c’est une obligation, référence régénérée, validation.

Trois principes du projet :

1. **Un principe s’énonce sans son auteur.** Les normes, lois et ressources à atteindre restent nommées ; une observation datée garde son type de source et sa date.
2. **Pas de matériau d’essai dans le paquet** : ni nom de brief, ni lieu, ni titre tiré d’un essai.
3. **Une garde nouvelle a son test**, et ce test échoue quand on casse la propriété qu’il protège.

## Vérifier

```bash
python3 scripts/validate_all.py --require-browser
```

Sans navigateur, `python3 scripts/validate_all.py` fait les contrôles qui n’en demandent pas.

## Licence des contributions

En contribuant, vous acceptez que votre code soit publié sous licence MIT et vos textes sous licence CC BY 4.0, comme le reste du projet ([licences](LICENSE)).
