# Maintenance — évolution

Comment une modification du système est recettée, comment une route naît, change ou disparaît.

## ACTION/MAINTENANCE — recette documentaire

Tout cycle qui modifie ACTION ou un contrat connexe se clôt par une recette avant adoption.

| Contrôle | Preuve attendue |
|---|---|
| Fichiers et renvois | Chaque fichier et route référencés existent et portent la bonne portée. |
| Statuts | Les états, issues, verdicts et statuts de direction appartiennent aux listes closes de leurs sections propriétaires ; aucun plan de maturité concurrent n’est ajouté. |
| Scopes | Chaque obligation précise son mode, contexte ou niveau de proportionnalité. |
| Exemples | Aucun exemple ne propage un statut ou une règle dépréciée. |
| Claims datés | Source, version/date, portée, limite et prochaine preuve sont renseignées dans la trace locale quand le run en dépend. |
| Routage | Chaque signal a une route principale ; les miroirs sont dérivés explicitement. |
| Quotas artificiels | Aucun quota de variantes, retraits, comparaisons, itérations ou appels ne gouverne la qualité. |
| Échappatoire théâtrale | Chaque mécanisme est testé contre sa manière la plus facile d’être satisfait sans intention. |
| Run réel | Une nouvelle route est exercée sur un run réel avant de quitter `PILOT`. |
| Ownership | Owner du changement, statut de cycle de vie et prochaine revue sont nommés. |
| Réserves | Owner, périmètre, date ou version, impact, date de revue, prochaine preuve et condition de sortie sont persistants. |

La recette peut être automatisée pour les fichiers, routes, statuts et renvois. Elle doit rester humaine pour le scope, l’intention, l’échappatoire théâtrale, la proportionnalité et le jugement du risque.

Une contradiction non résolue devient un risque explicite, jamais une règle silencieusement concurrente.

---

## BIBLIOTHEQUE/EVOLUTION — promotion et dépréciation

BIBLIOTHEQUE est stable dans ses responsabilités, mais pilotée dans ses routes. Une route devient durable après plusieurs usages contrastés documentés, lorsque sa responsabilité reste stable, son contrat est complet, sa maintenance est assumée, ses rendus ne s’homogénéisent pas et un gain réel est observé ou mesuré avec baseline, contexte et limite. Elle doit également démontrer qu’elle permet des premiers objets composés, spécifiques et crédibles dans ces contextes, et pas seulement des structures conformes ou jolies dans un screenshot.

**Mesure de lecture.** Pour mesurer ce qu’un run instrumenté lit dans les routes structurelles, les catégories de `DIRECTION/LECTURE-INSTRUMENTEE` s’appliquent ; un run ordinaire ne les déclare pas.

### Contrat minimal par périmètre de contribution et statut de route

| Niveau | Minimum attendu | Ne pas exiger par défaut |
|---|---|---|
| Local | Contrat réduit (`BIBLIOTHEQUE/CONTRACTS`) ; héritage ou cas documentaire si la structure suffit, avec source et justification ; `N/A-JUSTIFIED` seulement si réellement non applicable selon ACTION. | Contrat complet de promotion. |
| Route au statut `PILOT` | Contrat réduit, contre-indication, preuve, `DECISION-CHANGE` et périmètre déclaré. | Adoption ou compatibilité générale. |
| Partagé | Contrat complet, consumers, owner, compatibilité, états, mobile, accessibilité, migration et rollback selon le risque. | Promotion silencieuse. |
| Durable | Usages contrastés, baseline, observation ou mesure de gain, maintenance, owner et prochaine revue. | Validation par beauté, fréquence ou capture unique. |

`SEED`, `PILOT`, `ADOPTED`, `DEPRECATED` et `ABANDONED` sont des statuts de cycle de vie définis dans `maintenance/evolution.md`, jamais des modes, niveaux de structure, états, issues ou verdicts `ACTION`. `OWNER` désigne le responsable de la décision et de sa prochaine preuve ; `NEXT-OWNER` désigne le destinataire de l’action suivante ; l’owner de maintenance d’une route partagée reste distinct et se conserve dans le contrat d’évolution.

### Contrat de gain réel

Le gain réel ne doit pas être déclaré sans :

```text
TASK / DECISION
BASELINE
OBSERVATION OR MEASURE
CONTEXT
LIMIT
OWNER
NEXT-REVIEW
```

Il peut s’agir d’une réduction d’erreur, d’une décision plus directe, d’un temps de décision réduit, d’une diminution de réassemblage ou d’une maintenance plus fiable. La nature du gain et la limite de l’observation sont toujours nommées.

| Critère | Preuve attendue |
|---|---|
| Usages contrastés | Plusieurs usages distincts, documentés dans des runs et non une répétition du même cas. |
| Responsabilité claire | La route réduit une décision identifiable. |
| Contrat complet | Usage, contre-indication, preuve, états, mobile, a11y, owner et revue. |
| Gain réel | Tâche/baseline/observation ou mesure/contexte/limite. |
| Non-homogénéisation | Les rendus restent situés malgré la route commune. |
| Maintenance | Owner et prochaine revue nommés. |

Une route peut être `SEED`, `PILOT`, `ADOPTED`, `DEPRECATED` ou `ABANDONED` selon le cycle de vie de `maintenance/evolution.md`. Ces statuts ne sont pas des verdicts d’écran, des issues de run ou des statuts de gate.

### Contribution et retour d’usage

Une proposition de route commence par ce qui existe déjà : vérifier les routes compatibles, les discussions ou les usages documentés, puis expliquer la décision que la nouvelle combinaison permet de mieux prendre. Une contribution n’est promue que si ses usages, sa contre-indication, sa preuve, son owner, son coût de maintenance et sa prochaine revue sont lisibles. Les retours d’équipe, d’usagers ou de production peuvent corriger le contrat ; ils ne remplacent pas l’observation du run ni ne créent un gate supplémentaire.

Le niveau de contribution reste proportionné au risque : un run local peut conserver une trace courte ; une route partagée exige un contrat et une preuve de gain ; une promotion ou une dépréciation suit `maintenance/evolution.md` et sa décision est conservée dans `maintenance/versions.md`. Ne pas transformer la recherche de feedback, la revue communautaire ou le nombre de réutilisations en quota ou en verdict automatique.

**Chaîne de promotion et de gouvernance.** Lorsqu’une route devient partagée ou candidate à une durée canonique, `DIRECTION/START` classe le risque et le blast radius ; `ACTION/RUN-SYSTEM` prépare l’impact, les consumers, l’owner, la preuve, la compatibilité, la migration et le rollback ; `BIBLIOTHEQUE/EVOLUTION` examine les usages contrastés, le gain réel, la non-homogénéisation et la maintenance ; `maintenance/versions.md` persiste uniquement la décision de cycle de vie autorisée. Une route locale ou exploratoire ne doit pas ouvrir cette chaîne complète sans raison.

Un style reste dans `SAVOIR/STYLE`. Une image, un site, une capture ou un asset reste local à la `RUN_CARD` ou à l’artefact de projet déjà disponible. Une route locale ne devient pas canonique simplement parce qu’elle est jolie ou fréquemment demandée.


## Cycle de vie des routes

Les statuts de route décrivent la maintenance d’une route candidate ou canonique. Ils ne sont pas des verdicts de design.

| Statut | Sens | Transition autorisée |
|---|---|---|
| `SEED` | Route du socle de la V1 (seed d’origine et sections versées au socle), canonique, sans gain mesuré. | `ADOPTED` (contrat de gain réel satisfait, `BIBLIOTHEQUE/EVOLUTION`) ou `DEPRECATED`. |
| `PILOT` | Route locale ou candidate testée dans un périmètre déclaré ; au plus cinq à la fois `[À ADAPTER]`, listées dans la fiche de version. | `ADOPTED` ou `ABANDONED` ; `DEPRECATED` lorsque la route a des consumers. |
| `ADOPTED` | Route canonique dont le contrat, la maintenance et le gain sont acceptés. | `DEPRECATED`. |
| `DEPRECATED` | Route conservée pour migration ou compatibilité ; elle ne doit pas être choisie dans un nouveau run. Aucun nouvel usage ; migration par `ACTION/RUN-SYSTEM` (paquet SYSTÈME). | `ABANDONED` après migration. |
| `ABANDONED` | Route qui n’est plus maintenue ni proposée. | Aucune transition silencieuse. |

Les routes du socle de la V1 ont le statut `SEED` : canoniques, sans gain mesuré. Une nouvelle route qui trouverait cinq routes `PILOT` ouvertes attend qu’une d’elles soit tranchée : versée au socle ou retirée. `ADOPTED` exige le contrat de gain réel (`BIBLIOTHEQUE/EVOLUTION`). Une route peut être dépréciée depuis tout état publié ou utilisé (`SEED`, `PILOT` avec consumers, `ADOPTED`) ; une dépréciation interdit les nouveaux usages, exige une migration et ne revendique aucun gain. Toute nouvelle route ou promotion doit indiquer son problème, sa décision, son owner, son contrat, sa preuve, sa limite, sa compatibilité et sa prochaine revue.

## Retirer une section du socle

Chaque section versée au socle reste retirable : ce retrait est une décision de maintenance, recettée comme toute modification (`ACTION/MAINTENANCE`), puis reflétée dans la fiche de version. Pour retirer une section :

1. retirer ce que dit sa ligne ci-dessous ;
2. retirer les renvois qui la citent (`python3 scripts/read_route.py --trouver` et une recherche de son code) et les cas de test qui la nomment ;
3. recompiler le noyau si un bloc compilé est touché (`python3 scripts/build_core.py`) ;
4. relancer `python3 scripts/validate_all.py`.

| Section | Ce qu’elle apporte, et sa limite | Retrait |
|---|---|---|
| `SAVOIR/CRAFT/CFT-06` — écriture et contenu | Forme et spécificité du texte : argument, budget et formes de titre, actions, micro-typographie française. Ne juge ni la justesse commerciale, ni la conformité légale, ni la conversion. | Retirer la section. |
| `SAVOIR/TYPE-VOIX` — trouver, apparier et comparer des voix typographiques | Chercher des candidats par construction, filtrer, apparier, comparer sur le vrai titre, trancher par la thèse. Ne cite aucune police et ne garantit pas une meilleure voix. | Retirer la sous-route et son renvoi au noyau (`COMP-CONVERGENCE`). |
| `SAVOIR/CRAFT/CFT-01` « Inventaire du sujet et phrase d’idée » | Trouver l’idée dans ce que le sujet a de propre : inventaire, phrase d’idée, test du concurrent, une chose vivante. Ne garantit ni la qualité ni une préférence ; ne remplace ni `MODAL` ni le test de singularité. | Retirer la sous-section. |
| `SAVOIR/CRAFT/CFT-00` « Mouvement » | Qu’est-ce qui bouge, et pourquoi ? Sans quota ni seuil ; ne dit pas que le mouvement améliore une page. | Retirer le paragraphe. |
| `SAVOIR/CRAFT/CFT-05` « Relations de couleur » | Fixer un rôle par sa luminosité (OKLCH), nommer la relation d’une palette, fonds voisins, neutres teintés, fond sombre. Repères établis sur des neutres ; WCAG reste le critère. | Retirer la sous-section. |
| `SAVOIR/CRAFT/CFT-05` « Variable visuelle et nature de la donnée » | Polarité, grandeur et ordre d’une donnée accordés à sa variable visuelle. Ne choisit pas le type de graphique. | Retirer le paragraphe. |
| `BIBLIOTHEQUE/READ` « Traduire un caractère en leviers » | Leviers de départ et piège réflexe pour douze caractères perceptuels (calme, tension, intimité…), valeurs `[À ADAPTER]`. Servi par sa route et, avant le build, par `parcours.py leviers` pour les pôles choisis, avec l’ordre de composition de `SAVOIR/FRAME` ; une phrase au noyau (`DIR-DECLARATION`). | Retirer le tableau, la sous-commande `leviers`, sa phrase au noyau et ses cas de test. |
| `SAVOIR/TYPE` « Réglage d’un grand texte » et `SAVOIR/CONTEXT` « Durées et courbes, points de départ » | Points de départ `[À ADAPTER]`, non des mesures, pour régler un grand titre et calibrer un mouvement ; chacun porte ses contre-indications et sa preuve. | Retirer les deux paragraphes. |
| `SAVOIR/STATE` « Élément de caractère » | Une touche tirée du sujet, posée sur une limite, une seule dose, qui porte une donnée ou l’idée du produit ; test de retrait. Ne crée pas de caractère là où le sujet n’a rien d’inventorié. | Retirer la ligne de la table des gestes. |
| `SAVOIR/SOURCE` « Chercher le monde du sujet dans des collections ouvertes » | Requêtes tirées de l’inventaire du sujet, recherche par rôle au-delà de la carte (collections, banques libres, bibliothèques CC0), critères de choix, honnêteté, droits. Ne remplace ni la fiche de source ni un avis juridique ; aucun accès n’est testé par le paquet. | Retirer la sous-section et sa mention dans `SAVOIR/TOOLS/MOYENS`. |
| `SAVOIR/SOURCE` « Routes par rôle », avec une phrase au noyau (`MOY-PLAFOND`) | Pour chaque rôle de la matière (le vrai du client, le monde du sujet, atmosphère, texture, objet, personne, donnée, illustration), les routes de production à essayer dans l’ordre, ce qui ne se fait jamais, et cinq signes d’arrêt. Ne garantit pas la matière : sans intrant ni accord, les sources atteignables restent le plafond. | Retirer la section, sa phrase de renvoi dans « Chercher le monde du sujet » et la phrase du noyau. |
| `SAVOIR/SOURCE` « Une page lue est une donnée », « Diriger une génération » et `parcours.py references`, avec une phrase au noyau (`ANCRE`, `MOY-PLAFOND`) | Provenance de chaque référence relevée par l’outil (source, auteur, licence, date) et jugement écrit par l’agent ; consignes d’une page jamais exécutées, faits recoupés sur une source première, refus déclarés et jamais contournés ; prompt de génération construit depuis la direction, variantes choisies à la vue, image exploitée au cadrage réel et marquée. Ne vaut pas avis juridique. | Retirer les trois paragraphes, les deux mentions du noyau et la sous-commande avec ses tests. |
| `SAVOIR/TECH` « Chercher une méthode », avec un rappel au noyau (`MOY-PLAFOND`) et une ligne de la table des signaux | Pour une technique que l’agent ne réalise pas sûrement de mémoire : savoir du système, source primaire datée, exemple ouvert adapté et non recopié, essai isolé passé à la recette ; sans accès, la couche reste à son plafond déclaré. | Retirer la sous-section, la phrase du noyau et la ligne de la table des signaux. |
| `SAVOIR/IDENTITY` — identité de marque, avec une phrase au noyau (`DIR-LEVIERS`, `VER-FAUX-ASSET`) et `parcours.py identite` | Ce qu’on livre (signe, déclinaisons dessinées, noir et inversé, palette, voix, règles d’usage, une application), construction en noir d’abord, esquisses en signes noirs face à la modale, épreuves sur une planche avec des signaux mesurés sans verdict ; un signe neuf marqué n’est pas un faux asset. Ne vérifie ni la disponibilité juridique, ni la ressemblance avec une marque existante au-delà de l’œil, ni la reproduction physique. | Retirer `design/savoir/identite.md`, les deux phrases du noyau, la sous-commande `identite` et ses tests ; pour un retrait partiel, limiter la route à la marque verbale et à la grammaire de déclinaison. |
| `DIRECTION/CHARGE` — tronc par mode | Routes lues à chaque run d’un mode, sous un budget de 35 000 caractères ; une route bloquante citée dans la ligne d’un mode est dans son tronc, et le budget se règle sur l’explicatif, jamais sur une contrainte bloquante. `--tronc` affiche la taille et la marge ; `validate_structure.py` signale une marge sous 10 %. | Retirer les mentions « Tronc » de la table de `DIRECTION/CHARGE` et l’option `--tronc` du lecteur, avec ses tests. |
| `DIRECTION/DIVERGENCE` « Diverger sur image » (`DIR-LEVIERS`, au noyau), avec `scripts/planche.py` | Cinq directions et leur probabilité, trois esquisses sous la modale sur une planche (`--bureau-seul`, sauf pour un produit d’abord mobile), recomposition mobile sur la seule direction gardée ; en décision étroite, trois directions et une esquisse ; atelier sur capture, regard et recette avant de montrer. Ne garantit pas le niveau. | Retirer l’étape du bloc `DIR-LEVIERS`, le script et ses tests ; l’atelier revient à une seule branche. |
| `DIRECTION/DIVERGENCE` « Déclarer la direction » (`DIR-DECLARATION`, au noyau) | Avant de construire la suite : nom tiré du sujet et vision en une phrase, montrés dès qu’ils sont fixés, puis en tête de la réponse ; l’antécédent et le profil se décident à leur place, sans s’annoncer. Une intention, pas un verdict. | Retirer le bloc `DIR-DECLARATION` et sa mention dans la réponse et la trace légère. |
| `DIRECTION/DIVERGENCE` « Déclarer la direction » : cible concrète, et `SAVOIR/SOURCE` « Construire une atmosphère », avec une phrase au noyau (`DIR-DECLARATION`, `MOY-PLAFOND`) | Avant de construire, six lignes vérifiables sur capture disent ce qui fera le niveau (niveau, asset, composant, finition, mouvement, mobile) ; sans photo, une image d’atmosphère se construit en plans, formes variées, lumière orientée et grain, plutôt qu’un aplat ou un dessin. | Retirer les six lignes et leur phrase, le paragraphe d’atmosphère et sa mention au noyau. |
| `DIRECTION/DIVERGENCE` : registre nommé et divergence par registre, ligne `MOUVEMENT`, relecture contre le défaut ; paragraphe du registre dans `SAVOIR/STYLE` ; gestes « Mouvement » et « Habillage de gabarit » de `SAVOIR/STATE` | Chaque direction nomme son registre (une base et un modificateur pris dans deux dimensions de `SAVOIR/STYLE`) ; les esquisses diffèrent de la modale et entre elles sur deux dimensions au moins ; la déclaration porte `REGISTRE` et `MOUVEMENT` et se relit contre la page qu’on produirait pour un brief semblable. Ne garantit pas que les mises en page divergent. | Retirer les deux lignes de la déclaration et leur phrase, la phrase de l’échantillonnage, la relecture, le paragraphe de `SAVOIR/STYLE` et les deux gestes. |
| `DIRECTION/DIVERGENCE` : modale au second degré, hypothèse de produit sur un brief vague, une esquisse issue de `parcours.py tirage` | L’idée astucieuse que tout agent trouverait est observée, non estimée : c’est la première idée astucieuse de l’agent, écrite avant les pistes ; elle ne gagne qu’en battant les autres, comme un nom de produit inventé ; la piste d’attribut part du deuxième attribut qui signe le sujet ; une des trois esquisses part de deux pistes et d’une dimension de registre tirées au sort, et passe le test du lien. Agit à l’intérieur d’un run, pas d’un run à l’autre. | Retirer les phrases de l’échantillonnage (modale au second degré observée, deuxième attribut) et la sous-commande `tirage` avec ses tests. |
| `DIRECTION/DIVERGENCE` « Pistes du sujet », `ACTION/ATELIER-EDITION` « Idée lue en une seconde », `ACTION/HANDOFF` « Geste envisagé », `DIRECTION/FIRST-OBJECT` « Action principale au premier écran », `SAVOIR/TOOLS/CONVERGENCE` « Dose », planéité choisie (`MOY-PLAFOND`, gate C1) | Les directions non modales viennent de pistes différentes du sujet ; un sujet ancré dans un lieu se calibre par des références de ce lieu ; l’idée se lit sans le texte ; un geste seulement envisagé ne clôt pas un signal qui touche la décision dominante ; l’action principale d’un premier contact se voit au premier écran (`--in-frame`) ; un marqueur de vague dosé une fois sur l’idée est un moyen ; au niveau haut, l’aplat se garde contre un essai de matière. | Retirer ces phrases de leurs blocs (au noyau, sauf la dose et le critère C1, servis par leur route), puis le signal `parcours.py trace` du geste envisagé. |
| `DIRECTION/DIVERGENCE` « La suite se construit comme une séquence » (`DIR-LEVIERS`), `BIBLIOTHEQUE/SEQUENCE` au tronc `DIRECTION` ; palette de base prélevée sur l’asset principal ou le monde du sujet (`COMP-CONVERGENCE`) | Avant de bâtir la première section après le premier écran, la suite s’écrit en une ligne et se vérifie sur la page réduite ; la palette vient du sujet. | Retirer l’étape de séquence de `DIR-LEVIERS`, sortir `BIBLIOTHEQUE/SEQUENCE` du tronc `DIRECTION` et y remettre `DIRECTION/CADRES` et `DIRECTION/REUSE` ; retirer la phrase de la palette de `COMP-CONVERGENCE`. |
| `DIRECTION/CREATIVE-BOOT` « Atteindre avant de déclarer » et « Pas de figuratif de mémoire » (`MOY-PLAFOND`), `DIRECTION/STANDARD` « Calibrer le niveau avant de construire » (`ANCRE`), `ACTION/ATELIER-EDITION` « Passe de finition » (`BOUCLE-ATELIER`) | Niveau visé haut et proportionné ; inventaire de la portée de l’environnement avant le premier essai ; un essai par couche qui porte la thèse avant tout plafond déclaré ; accord de la personne avant une génération ou un outil branché sur son compte ; sujet figuratif sourcé, généré et marqué, ou laissé en emplacement marqué ; deux ou trois références réelles ouvertes avant le premier build ; une passe de finition sans symptôme. Ne garantit pas le niveau atteint. | Retirer les quatre paragraphes du noyau et la mention « essais par couche » de la trace légère et de la réponse. |
| `DIRECTION/START/TREE` (question 2) et `ACTION/RUN-STANDARD` : la convention bien exécutée | Un composant ou un écran d’un produit, même nouveau, reste `STANDARD` si la demande ne porte ni sur la marque ni sur le premier contact ; la finition visible y est nommée (rayons emboîtés, gris hiérarchisés, un accent par rôle, chiffres alignés, états vrais). | Retirer la phrase de l’arbre, la liste de finition et la phrase sur les marqueurs de `ACTION/RUN-STANDARD`. |
| `BIBLIOTHEQUE/COMPONENTS` « Parties ordinaires », `BIBLIOTHEQUE/SEQUENCE` « Recomposer une idée », geste « Partie ordinaire » de `SAVOIR/STATE`, avec un rappel au noyau (`COMP-CONTROLES`) | Navigation, bouton, onglets et pied gardent un comportement conventionnel et empruntent une propriété de la direction, pas un motif ; en mobile, l’idée survit à son arrangement. `parcours.py` signale l’objet de preuve perdu en mobile. | Retirer les deux paragraphes, la ligne du geste, les deux mentions du noyau, le signal et le rappel de `parcours.py`. |
| `ACTION/ATELIER-EDITION` test de retrait, passe de finition par lots, « Garder se décide à l’atelier », « Regard séparé », lecture de l’idée sur l’image sans texte ; questions de critique en fin de réponse | Un signal ou un marqueur du premier écran non corrigé se garde par comparaison à la vue, dans un test de retrait ; l’intensification ne se construit que si la décision paraît timide ; si un second agent est possible, la version gardée est critiquée sur images seules (`parcours.py critique`) ; la réponse finit par une ou deux questions de critique. | Retirer le paragraphe, les deux phrases du noyau, la ligne de la réponse et les mentions des fiches de `parcours.py` et `regard.py`. |
| `scripts/regard.py` — commande de regard | Attention au premier écran (approximation classique ; un modèle de saillance au format ONNX peut s’y brancher), foyer déclaré, contraste de tout texte sur le fond capturé, page réduite, test de support, comparaison avec un rendu précédent, marqueurs de vague relevés d’après la liste datée de `SAVOIR/TOOLS/CONVERGENCE` (seuils `[À ADAPTER]`). Des signaux, pas des verdicts : un relevé vide ne prouve pas la singularité. | Retirer le script, son test et son appel au journal ; pour les seuls marqueurs, retirer leur partie du script, le paragraphe « Relevé des marqueurs » et leurs cas de test. |
| `scripts/parcours.py` — parcours par défaut | Enchaîne recette, regard, captures, signaux de finition, noms accessibles et ordre de tabulation, page entière réduite et planche de mouvement en une fiche ; chaque signal pose une question et cite son geste de `SAVOIR/STATE` ; télécharge des polices ouvertes, rassemble et mesure des références, contrôle la forme de la trace légère. Seuils `[À ADAPTER]` ; un relevé vide ne prouve pas la finition. | Retirer le script, son test, son appel au journal et ses mentions au noyau ; les outils qu’il enchaîne restent inchangés. |
| `references/recettes.md` et `parcours.py recette` — recettes de procédé | Cinq procédés de code (graphique lisible du bureau au mobile, grand chiffre vivant, moment orchestré, focus sur tout fond, contrôles ordinaires), chacun avec ce que la direction décide et ce qui se vérifie sur capture. | Retirer le fichier, la sous-commande, ses tests et la mention de la table des signaux. |
| `scripts/journal_mobilisation.py` — journal de mobilisation | Passif, activé par `DG_JOURNAL` : routes servies ou proposées et destination de leur sortie, appels des outils et leurs résultats, puis fiche de mobilisation. Observe ce qui est servi, ni la lecture, ni l’attention de l’agent, ni l’application d’une route. | Retirer le script, son test et son appel dans `read_route.py`, `check_render.py`, `planche.py`, `regard.py` et `parcours.py` ; les outils restent inchangés. |
| `SAVOIR/FRAME` « Classique et expressif » | La clarté attendue du genre et l’écart qui donne un caractère sont deux qualités distinctes : garder la structure attendue quand elle sert la lecture, porter l’écart sur une ou deux dimensions. Servi aussi par `parcours.py leviers`. Ne dit pas quelle dimension choisir. | Retirer le paragraphe et sa lecture dans `leviers`. |
| `BIBLIOTHEQUE/SELECT` signal « plan, schéma ou diagramme comme objet principal » | Signal de convergence et question de reprise vers `SAVOIR/CRAFT/CFT-04a` ; la fiche de `verifier` le sert quand un objet de preuve est nommé. Ne détecte pas un diagramme : la question se juge sur capture. | Retirer la ligne de la table, son service dans la fiche et ses cas de test. |
| Ligne « modal, trame et parti » : qui a choisi (`DIR-LEVIERS`, au noyau), et « relevé vide » de la passe de finition (`BOUCLE-ATELIER`) | La trace légère dit si le choix vient de l’auteur du rendu, de la personne ou de personne ; `parcours.py trace` le signale s’il manque. Un relevé vide de `verifier` ne vaut pas réussite. | Retirer les deux phrases, le signal de `trace`, les mentions des exemples et leurs cas de test. |

## Contrats de maintenance

**Budget de chargement.** Le fichier `SKILL.md` complet (métadonnées, noyau compilé et contenu hors noyau) est borné à 46 000 octets UTF-8. Le contrôle commun de `scripts/build_core.py` refuse une compilation excessive avant écriture et contrôle chaque distribution via la validation structurelle ; la construction directe contrôle aussi la source canonique avant staging. Au-delà du budget, retirer une redondance ou déplacer un détail vers une route en conservant son activation, sans supprimer un plancher protégé pour satisfaire la taille. Ce budget ne mesure ni la charge cognitive ni le coût complet d’un run. Les deux budgets n’ont pas la même unité, et c’est voulu : le noyau se compte en octets, poids du fichier que l’hôte de la skill charge ; le tronc d’un mode (35 000) se compte en caractères, texte que l’agent lit.

**Portée des contrôles.** La validation couvre la cohérence documentaire et technique, dont la liste close des conditions de façade. Une divergence hors de cette liste n’est pas détectée. Le contrôle des supports vérifie leur fraîcheur, leur version et leurs relations ; il ne juge pas le rendu. Les tests de pages exigent un navigateur et restent non vérifiés lorsqu’ils ne sont pas exécutés.

**Autorité.** Une règle fait foi dans sa section propriétaire, à son emplacement actuel. DIRECTION, ACTION, SAVOIR et BIBLIOTHEQUE désignent quatre familles de routes, réparties dans les dossiers du paquet ; chaque section porte son code en tête de son titre, et le lecteur la retrouve par ce code. CHANGELOG désigne la fiche de version. Les guides et les cartes orientent la lecture sans créer de règle concurrente. Le schéma `RUN_CARD` et ses validateurs définissent les projections machine dans leur périmètre.

**Identifiants structurels.** Le lecteur projette les identifiants structurels documentés vers leur titre ou leur section porteuse ; `LAYER/*` reste chez `BIBLIOTHEQUE/COMPONENTS`. Ce raccourci est compatible avec les locators existants, conserve le refus d’un nom absent ou ambigu et ne crée pas de route normative.

**Évolution.** Toute évolution identifie une source normative unique, un propriétaire, le périmètre concerné, la compatibilité, la preuve attendue, la limite, la prochaine revue et la procédure de retour. Elle ne devient une règle transversale qu’après décision explicite du propriétaire du corpus. La fiche `maintenance/versions.md` décrit l’état courant du système ; l’historique de conception et de travail n’est pas livré avec le paquet.

Ce que le système contient aujourd’hui est décrit dans [la fiche de version](versions.md).
