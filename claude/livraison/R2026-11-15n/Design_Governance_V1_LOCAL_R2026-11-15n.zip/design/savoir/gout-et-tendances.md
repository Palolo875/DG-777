# Savoir — goût et tendances

Claims, goût, références, tendances datées et ressources.

# SAVOIR/TOOLS — claims, tendances et calibration

## Claims externes et péremption

[REQUIS PAR LE MODULE — claim qui influence une décision, un seuil, une route, une tendance ou un livrable] Tout claim utilisé dans un run indique :

```text
CLAIM-TYPE — empirique, normatif, technique, culturel, réglementaire ou local.
STATEMENT
SCOPE
SOURCE
VERSION / DATE-VERIFIED
LIMIT
INTENDED-USE
OWNER
REVIEW-DATE
NEXT-PROOF
```

Il reste dans la trace locale du run tant qu’il ne modifie pas une règle partagée. Toute promotion vers une règle commune exige une décision explicite du propriétaire, la compatibilité, l’owner, la preuve et l’entrée de gouvernance appropriée ; un claim local ne devient pas une règle par répétition.

Un claim `À REVÉRIFIER` peut guider une recherche ou un test local. Il ne justifie jamais seul une règle universelle, un seuil, une obligation de production ou une promesse de résultat.

Sépare :

- claim transférable ;
- source observée ;
- asset et droit ;
- observation locale de run.

Une source ou un asset ne devient pas automatiquement un claim. Une observation de run ne devient pas automatiquement une règle durable. Une référence observée ne devient pas automatiquement une autorisation de réemploi.

## Goût, références et tendances

[DURABLE] Le goût n’est pas un canon de marques. C’est la capacité à reconnaître une solution proportionnée, spécifique, lisible et tenue.

Observe une référence pour extraire une relation — rythme, densité, hiérarchie, matériau ou compromis — et non une surface à copier.

En `DIRECTION`, nomme une interface, une ressource hors écran ou un principe réellement observé qui apporte une calibration utile sur un axe concret. Lorsque la direction est nouvelle, ambiguë, risquée ou exposée à une forte convergence générique, un sourcing Web ou une recherche de références est recommandé ; il devient requis seulement si le contrat du run dépend d’un claim, d’une tendance, d’une provenance ou d’une décision qui ne peut pas être honnêtement fondée en mémoire. Si aucune calibration pertinente n’est disponible, déclare cette limite et recherche ou génère une ancre utile.

Le sourcing de `DIRECTION` sépare trois rôles : **ancrage de direction** — pourquoi une référence éclaire un axe ou une décision ; **ancrage de production** — comment un asset, une matière ou un composant peut être construit ; **ancrage de vérification** — comment contrôler lisibilité, accessibilité, comportement, performance ou crédibilité. Une même source peut remplir plusieurs rôles seulement si chacun est explicité. La référence est analysée puis transformée en choix propres au produit ; elle ne sert jamais simultanément de moodboard décoratif, de spécification implicite et de preuve de réussite.

[VEILLE] Les listes de produits contemporains, tendances, registres culturels et snapshots ne sont pas neutres. Chaque élément mobilisé dans un run porte source, date, portée et limite dans sa trace locale.

<!-- différé:début COMP-VAGUES -->
<!-- concept:ANT-01 -->
**Marqueurs de vague** : pour nommer `MODAL` (`DIRECTION/CREATIVE-BOOT`), jamais pour interdire ; un marqueur gardé par décision reste valide. La dose fait la différence : employé une fois, sur l’élément qui porte l’idée, un marqueur est un moyen ; répandu sur la surface ou sans lien au sujet, il est la vague. Ils sont datés, avec leurs sources, limites et Signaux à confirmer, dans `SAVOIR/TOOLS/CONVERGENCE` ; `scripts/regard.py` relève sur un rendu ceux qui se mesurent : charge-la si la convergence peut changer une décision, et retrouve les sources avant tout claim de fréquence, tendance ou provenance.
<!-- différé:fin COMP-VAGUES -->

### CONVERGENCE — observations datées

[VEILLE 2026-11] **Marqueurs de vague**, pour nommer `MODAL` (`DIRECTION/CREATIVE-BOOT`), jamais pour interdire : un marqueur gardé par décision reste valide. Vague 1 : violet, police Inter, halos et gradient décoratif, hero SaaS à cartes répétées. Vague 2 : fond beige ou crème, brun, serif de caractère ou serif italique, orange rouille, bandeau défilant, illustration peinte, tramage. Vague 3 : dithering, logos pixel, ASCII, hachures de plan, gravures, bleu Klein, libellés mono en capitales, repères de recadrage, paysage peint en fond. Vague 4 : police d’affichage de gabarit en titre. Polices d’affichage de gabarit : Fraunces, Instrument Serif, Young Serif, Playfair Display, Bricolage Grotesque, Space Grotesk, Space Mono ; recommandées par les consignes « anti-slop » de 2025, elles sont devenues des signes de page générée ; un candidat modal à nommer comme tel (`SAVOIR/TYPE-VOIX`), pas un interdit. Convergences relevées avec le système : une donnée calculée devenue l’image principale (état, brume, nuit ou ciel mesurés) ; grotesque condensée en titre ; didone (Bodoni) en titre quand le brief dit « haut de gamme », souvent sur fond crème ; fiche de données en petit tableau à filets et libellés en capitales espacées, en registre éditorial calme ; d’un run à l’autre sur un même brief, même objet central et même grotesque de titre. Signaux à confirmer : grotesque large ou condensée (Archivo) sur fond blanc neutre avec un seul accent vif. Réponses au style génératif devenues à leur tour des défauts, selon la veille publiée (non mesurées ici) : grille « bento » à tuiles de tailles variées ; interface presque invisible (filets fins, une seule famille de caractères, gris clairs) ; imperfection simulée posée partout (grain, rature, papier). Source : essais internes et revue de références, 09 à 11-2026 ; veille publiée et relevés de praticiens sur les polices (articles, détecteur de pages Show HN, relevé de galeries), 11-2026. À revoir avant 2027-01.

**Relevé des marqueurs.** `scripts/regard.py` lit la liste datée ci-dessus à son lieu actuel et relève, au premier écran de la première largeur, les marqueurs qu’il sait mesurer par les pixels ou les styles calculés ; il nomme les autres comme non mesurés et signale une échéance de revue passée. Le relevé aide à nommer le `MODAL` sans dépendre de la seule estimation de l’agent : chaque marqueur relevé se dit, dans la ligne « modal, trame et parti », écarté, ou gardé après l’atelier qui l’a éprouvé (`ACTION/ATELIER-EDITION`, « Garder se décide à l’atelier »). Un marqueur relevé n’est pas une faute ; un relevé vide ne prouve pas la singularité. Les seuils du script sont des points de départ `[À ADAPTER]`. Les signaux à confirmer ne sont pas relevés.

**Tenue d’un marqueur gardé.** Un marqueur gardé après l’atelier (`ACTION/ATELIER-EDITION`) tient s’il réunit quatre conditions. Une dose : une occurrence qui porte, pas une texture partout. Une limite : il est posé sur un bord, un passage ou un objet. Un lien : il dit quelque chose du produit. Une exécution exacte : il est mesuré, aligné, sans approximation. S’il en manque une, il se lit comme une tendance appliquée.

[VEILLE 2026-10] **Signaux à confirmer** (presse et veille, non observés sur rendus d’agents) : la vague 3 est présentée comme tendance par la presse grand public (brutalisme mono façon terminal, pixel et dithering), ce qui suggère sa saturation ; artisanat simulé (gravure, point de croix ou textile générés, présentés comme gage d’humanité) ; dégradé doux et lumineux sur logos et icônes ; verre et transparence façon plateforme mobile, brillant bleu-vert ; mono de titre avec curseur ou badge à point clignotant ; blanc cassé plein écran et minimalisme « audacieux » ; mascotte d’interface arrondie ; chrome, formes molles et pastel brumeux ; titre en deux impératifs (« Construisez plus vite. Livrez mieux. »). Sources : presse design et veilles de tendances, 12-2025 à 06-2026, de fiabilité inégale. À observer sur rendus avant toute promotion en marqueur ; à revoir avant 2027-04.

<!-- différé:début MOY-CARTE -->
<!-- concept:MOY-01 -->
**Carte des moyens par couche** (datée, dans `SAVOIR/TOOLS/MOYENS`) : des sources, jamais des styles ; un point de départ, pas une liste close. Si une ressource ou son intégration reste à choisir, charge-la et cherche par rôle, au-delà si elle ne donne rien de juste. Vérifie accès, licence et conditions de chaque ressource retenue avant de l’intégrer ; un nom de plateforme ne vaut ni connexion ni autorisation.
<!-- différé:fin MOY-CARTE -->

### MOYENS — ressources par couche

[VEILLE 2026-10] **Carte des moyens par couche** : des sources, jamais des styles. Licence et conditions d’usage vérifiées pour chaque ressource retenue, au moment de l’intégrer ; le nom d’une plateforme ne vaut pas autorisation. Pour chaque couche : où chercher, comment choisir, ce qui limite. Les ressources nommées sont gratuites ; une restriction connue est dite à côté du nom.
- **Bases techniques :** MDN pour le comportement d’une API ; webstatus.dev pour le statut Baseline d’une fonctionnalité (API publique) ; le guide des motifs ARIA du W3C (APG) pour le clavier et les rôles d’un composant ; Open UI pour ce que le navigateur fournit déjà. Une référence technique décide d’un comportement, jamais d’une apparence.
- **Typographie :** polices de la marque ; Google Fonts (licences ouvertes, surtout SIL OFL) ; Fontshare (licence FFL ou OFL selon la police ; la FFL interdit sous-ensemble, conversion et redistribution ; liste et téléchargement : `parcours.py polices --catalogue`, `--source fontshare`) ; fonderies libres pour une voix plus marquée (Velvetyne, licence propre à chaque police et crédit demandé ; Collletttivo). Choisir par la voix et la donnée à porter ; inspecter glyphes, accents, chiffres et licence d’une police avec Wakamai Fondue ; héberger une police libre avec Fontsource (`python3 scripts/parcours.py polices "Famille:400,700i"` en télécharge les fichiers et écrit leur feuille, licence rapportée) ; Utopia calcule une échelle fluide et signale les tailles qui cassent le zoom à 200 %. La carte nomme des fonderies, pas une police : une police expressive proposée par défaut deviendrait un marqueur.
- **Couleur :** oklch.com pour choisir et convertir en OKLCH, avec les limites sRGB et P3 ; Harmonizer pour des rampes à contraste régulier. Le contraste final se mesure sur le rendu.
- **Icônes :** une famille qui couvre les pictogrammes nécessaires (par exemple Lucide, Phosphor, Tabler Icons ; `python3 scripts/parcours.py icones NOM` télécharge les icônes Lucide et leur licence) ; Iconify réunit de nombreuses familles, chacune sous sa licence. Poids, taille et sens accordés au texte ; mélanger des familles demande une raison visible.
- **Composants :** design system fourni, sinon bibliothèque éprouvée : sans style (Radix, Base UI, React Aria Components ; Ark UI pour Vue ou Solid), stylée (shadcn, Intent UI) ou en composants web sans framework (Web Awesome), sous MIT ou Apache 2.0. Un dépôt sous AGPL ne fournit pas de composants à copier dans un produit client. Les conventions d’un composant se comparent dans The Component Gallery (le même composant dans des dizaines de design systems) ; les parcours, dans le GOV.UK Design System (parcours éprouvés auprès d’usagers). Hors Web, les idiomes de la plateforme.
- **Mouvement et 3D :** Motion (MIT, sans son extension payante) ; GSAP, gratuit avec ses plugins sous une licence propre qui exclut les outils d’animation sans code concurrents ; Three.js (MIT). Les démos de Codrops (code ouvert et expliqué) et les galeries d’effets prêts à l’emploi (React Bits, 21st.dev) servent un geste déjà décidé, licence vérifiée composant par composant ; elles ne fournissent pas la direction, et leurs effets reprennent souvent les marqueurs de vague (`SAVOIR/TOOLS/CONVERGENCE`).
- **Données et objets de preuve :** contenu du client, sinon exemples marqués ; codables, donc au plafond sans intrant. Le graphique se choisit par ce qu’il doit montrer (FT Visual Vocabulary) ; Observable Plot (ISC) pour un graphique juste en peu de code, Apache ECharts (Apache 2.0) pour un tableau de bord interactif ; une carte géographique avec MapLibre et les tuiles d’OpenFreeMap (sans clé, mention OpenStreetMap visible ; service sans garantie, à héberger soi-même si la carte est critique).
- **Texture et traitement :** CSS, SVG, canvas ; rendu inspecté sur capture, performance mesurée dans le runtime cible. Matières photographiées : Texturelabs (redistribution et usage en template restreints), ambientCG et Poly Haven (CC0). Motifs SVG générés : fffuel (usage commercial permis, redistribution des images interdite) ; un motif généré sert un traitement décidé, il ne remplace pas une matière du sujet.
- **Photographie :** client (même au téléphone, en lumière du jour), banques libres pour un sujet actuel (Pexels, Pixabay, Unsplash ; leur API demande une clé gratuite, et Pexels et Unsplash demandent de créditer), Wikimedia Commons, collections ouvertes d’archives et de musées pour le monde du sujet (Openverse, Art Institute of Chicago, Metropolitan Museum of Art, Smithsonian Open Access, domaine public de la New York Public Library, Rijksmuseum ; droits vérifiés image par image ; `SAVOIR/SOURCE`, « Chercher le monde du sujet dans des collections ouvertes »).
- **Illustration et 3D :** commande, packs sous licence, génération dirigée avec références (`GÉNÉRÉ-DIRIGÉ`). Scènes 3D : Poly Haven (HDRI, textures et modèles, CC0 ; ses panoramas de lumière servent aussi d’atmosphère photographique) ; Pixabay pour des illustrations et vecteurs sous sa licence ; Kenney et Quaternius (modèles CC0 au style de jeu marqué, pour une direction qui le veut). Les packs de personnages plats génériques ne sont pas une source : ils donnent l’image commune des produits logiciels.
- **Références à observer :** Siteinspire et Godly (sites identifiés, à filtrer par typographie, grille ou secteur), Fonts In Use (polices dans des usages réels), Letterform Archive en ligne (graphisme et lettrage, en consultation). Une référence dit la décision qu’elle peut modifier ; une image sans auteur ni source (tableau d’épingles, flux de réseau social) n’est pas une référence.
- **Fichiers et marque :** Figma ou kit de marque par connecteur.

Sans intrant ni route autorisée, les assets figuratifs et le contenu réel restent hors plafond (`FABRICATION`). À revoir avant 2027-04.

**Ce que vaut cette carte.** Elle nomme des sources : le paquet n’en contient aucune et n’a testé ni leur accès ni leur intégration. Une ressource compte dans le plafond seulement une fois atteinte depuis l’environnement du run, chargée dans l’artefact et vue sur capture ; nommée ou seulement atteignable, elle reste une intention. Une police ou une image externe bloquée par `scripts/check_render.py` sans `--allow-external` n’est pas observée. Si l’accès échoue (réseau, licence, connecteur), dis-le et prends la route de production qui tient sans elle (`DIRECTION/VISUAL_TARGET` : `CODE-NATIVE`, `SANS-ASSET` ou emplacement marqué) ; le plafond baisse et la trace le dit.

Une tendance est une hypothèse de direction. Avant de l’utiliser, vérifie qu’elle sert le JTBD, améliore la compréhension, reste accessible et performante et survit lorsque son nom marketing disparaît.

Distingue :

| Niveau | Définition |
|---|---|
| Signal de veille | Observation datée. |
| Principe durable | Mécanisme transférable. |
| Style | Décision située d’expression. |
| Technique | Moyen de production ou de preuve. |

Le terme `same-energy` peut indexer un risque de convergence, mais ne remplace jamais une description causale de l’échec.

---
