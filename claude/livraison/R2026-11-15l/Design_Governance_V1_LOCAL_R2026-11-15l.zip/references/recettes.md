# Recettes de procédé

Des procédés déjà résolus pour des difficultés de code où un rendu perd du temps ou se trompe. Chaque recette règle un comportement, jamais une apparence : police, couleur, taille, matière et rythme restent à la direction. `python3 scripts/parcours.py recette NOM` affiche une recette ; `python3 scripts/parcours.py recette` les liste. Une technique sans recette se cherche avec `SAVOIR/TECH`, « Chercher une méthode ».

Une recette n’entre ici que si plusieurs rendus ont achoppé sur la même difficulté. Si deux rendus en sortent avec la même apparence, elle impose un style : elle se réécrit ou se retire.

## graphique

**Problème.** Un graphique lisible au bureau devient illisible ou chevauché à 390 px : le texte d’un SVG mis à l’échelle rapetisse avec lui, et les étiquettes se recouvrent.

**Quand.** Une série de valeurs à comparer (barres, volume par semaine, évolution). **Pas quand** la donnée tient en une phrase ou en un seul chiffre.

**Procédé.** Les marques se dessinent à l’échelle, le texte reste en HTML à sa taille. Les étiquettes s’éclaircissent sous une largeur donnée ; la valeur mise en avant et les extrêmes restent écrits.

```html
<figure class="graph" aria-label="Kilomètres par semaine">
  <ol class="barres">
    <li style="--v:.70"><span class="val">21</span><span class="lab">S1</span></li>
    <li style="--v:.77"><span class="val">23</span><span class="lab">S2</span></li>
    <li style="--v:.83"><span class="val">25</span><span class="lab">S3</span></li>
    <li style="--v:1" class="cle"><span class="val">30</span><span class="lab">S4</span></li>
    <li style="--v:.53"><span class="val">16</span><span class="lab">S5</span></li>
  </ol>
</figure>
<style>
.graph { container-type: inline-size; margin: 0 }
.barres { list-style: none; margin: 0; padding: 0; display: grid; grid-auto-flow: column; grid-auto-columns: 1fr;
  gap: clamp(2px, 1.5cqi, 12px); align-items: end; height: 220px; border-bottom: 1px solid currentColor }
.barres li { display: flex; flex-direction: column; justify-content: flex-end; height: 100%; position: relative }
.barres li::before { content: ""; order: 2; height: calc(var(--v) * 80%); background: var(--marque, #888) }
.barres .cle::before { background: var(--accent, #111) }
.val { order: 1; font-variant-numeric: tabular-nums; font-size: .8rem; text-align: center }
.lab { position: absolute; top: 100%; left: 0; right: 0; text-align: center; font-size: .75rem; padding-top: 4px }
@container (max-width: 420px) {
  .barres li:not(.cle):not(:first-child):not(:last-child) .val { visibility: hidden }
  .barres li:nth-child(even):not(.cle) .lab { visibility: hidden }
}
</style>
```

**La direction décide.** Couleurs des marques et de la valeur clé, hauteur, épaisseur des barres, police des chiffres, axe ou non.

**Vérifier sur capture.** À 390 px : aucune étiquette recouverte, la valeur clé et les extrêmes lisibles à au moins 12 px, chiffres alignés.

## grand-chiffre

**Problème.** Un grand chiffre qui change (saisie, recalcul, compteur) saute en largeur, déborde de son cadre ou écrase le champ voisin, et son contraste se perd quand il sort de son fond.

**Quand.** Un montant, un temps, un score mis en scène en grand. **Pas quand** le chiffre est secondaire.

**Procédé.** Figures tabulaires, largeur réservée en `ch` selon le nombre de caractères, taille bornée par la largeur du conteneur, recalcul sans animation sous mouvement réduit.

```html
<div class="montant">
  <label for="m">Vous envoyez</label>
  <input id="m" inputmode="decimal" value="200" autocomplete="off">
  <output for="m" id="r" aria-live="polite">131 191</output>
</div>
<style>
.montant { container-type: inline-size; display: grid; gap: .25rem; overflow: hidden }
.montant input, .montant output { font: inherit; font-variant-numeric: tabular-nums; white-space: nowrap;
  font-size: min(8rem, 18cqi); line-height: .95; border: 0; background: none; color: inherit; padding: 0 }
.montant input { width: calc(var(--n, 3) * 1ch + .1ch); min-width: 2ch; border-bottom: 2px solid currentColor }
</style>
<script>
const m = document.getElementById('m'), r = document.getElementById('r');
const fmt = new Intl.NumberFormat('fr-FR', {maximumFractionDigits: 0});
function maj() {
  m.style.setProperty('--n', Math.max(2, m.value.length));
  const v = parseFloat(m.value.replace(',', '.')) || 0;
  r.textContent = fmt.format(v * 2);  // le calcul vient du produit
}
m.addEventListener('input', maj); maj();
</script>
```

**La direction décide.** Police et graisse du chiffre, unité et sa place, couleur et fond, le calcul lui-même.

**Vérifier sur capture.** Avec 1, 4 et 7 chiffres saisis : rien ne déborde du cadre, le voisin ne bouge pas, le contraste du chiffre se mesure sur son propre fond (`check_render`).

## moment-orchestre

**Problème.** Les entrées animées se posent sur chaque bloc (fondu-glissé partout), retardent l’action ou ignorent le mouvement réduit ; sans script, le contenu peut rester caché.

**Quand.** Une page faite pour se montrer, avec un objet de preuve qui gagne à apparaître. **Pas quand** la page est un outil ou une lecture.

**Procédé.** Un seul moment, sur l’objet de preuve et au plus deux éléments liés, défini seulement sous `prefers-reduced-motion: no-preference` : sans préférence ou sans animation, tout est visible et à sa place.

```html
<div class="scene"><h1>Titre</h1><div class="preuve">Objet de preuve</div><a class="action" href="#">Agir</a></div>
<style>
@media (prefers-reduced-motion: no-preference) {
  .preuve { animation: pose .7s cubic-bezier(.2, .7, .2, 1) .15s both }
  .preuve > * { animation: monte .5s ease-out .5s both }
}
@keyframes pose { from { opacity: 0; transform: translateY(18px) rotate(-1.5deg) } }
@keyframes monte { from { opacity: 0; transform: translateY(8px) } }
</style>
```

**La direction décide.** Ce qui bouge, la trajectoire, la durée (au plus une seconde au total), la courbe.

**Vérifier sur la planche de mouvement** (`parcours.py mouvement`) : une seule entrée, l’action visible dès la première image, rien sous mouvement réduit.

## focus

**Problème.** Le contour de focus disparaît sur un fond de sa couleur, ou se mesure sous 3:1 quand la page mêle fonds clairs et sombres.

**Quand.** Toute page, dès que les fonds varient. **Pas quand** un design system impose déjà son focus.

**Procédé.** Un double contour : un trait clair contre l’élément, un trait sombre au-delà. L’un des deux contraste toujours avec le fond.

```html
<a href="#" class="exemple">Lien</a> <button>Bouton</button>
<style>
:focus-visible { outline: 3px solid var(--focus-sombre, #111); outline-offset: 2px;
  box-shadow: 0 0 0 2px var(--focus-clair, #fff) }
</style>
```

**La direction décide.** Les deux couleurs, l’épaisseur et le décalage.

**Vérifier.** Contraste du focus relevé par `check_render` sur chaque fond ; parcours au clavier complet (`parcours.py verifier`, ordre de tabulation).

## controles

**Problème.** Groupes segmentés, onglets, champs et boutons recodés à la main perdent le clavier, le nom accessible ou l’état : boutons radio hors de Tab, onglet sans flèches, erreur non annoncée, bouton qui change de nom pendant le chargement.

**Quand.** Tout contrôle ordinaire. **Pas quand** un design system ou une bibliothèque du projet fournit déjà le composant.

**Procédé.** L’élément natif d’abord, avec son comportement ; la direction habille, sans changer le comportement.

```html
<fieldset class="seg"><legend>Distance</legend>
  <label><input type="radio" name="d" value="5" checked><span>5 km</span></label>
  <label><input type="radio" name="d" value="10"><span>10 km</span></label>
</fieldset>
<div class="champ">
  <label for="e">Adresse e-mail</label>
  <input id="e" type="email" required aria-describedby="e-err">
  <p id="e-err" class="err" hidden>Écrivez une adresse complète, comme nom@exemple.fr.</p>
</div>
<button class="envoi" type="button"><span>Envoyer</span><i class="roue" aria-hidden="true"></i></button>
<div role="tablist" aria-label="Vues">
  <button role="tab" id="t1" aria-selected="true" aria-controls="p1">Semaine</button>
  <button role="tab" id="t2" aria-selected="false" aria-controls="p2" tabindex="-1">Mois</button>
</div>
<div role="tabpanel" id="p1" aria-labelledby="t1">…</div><div role="tabpanel" id="p2" aria-labelledby="t2" hidden>…</div>
<style>
.seg { border: 0; padding: 0; display: inline-flex }
.seg input { position: absolute; opacity: 0; width: 1px; height: 1px }
.seg input:checked + span { font-weight: 700; text-decoration: underline }
.seg input:focus-visible + span { outline: 3px solid #111; outline-offset: 2px }
.roue { display: none } .envoi[aria-busy="true"] .roue { display: inline-block }
</style>
<script>
const e = document.getElementById('e'), err = document.getElementById('e-err');
e.addEventListener('blur', () => { const ko = !e.checkValidity(); e.setAttribute('aria-invalid', ko); err.hidden = !ko; });
const b = document.querySelector('.envoi');
b.addEventListener('click', () => { b.setAttribute('aria-busy', 'true'); b.setAttribute('aria-disabled', 'true'); });
const tabs = [...document.querySelectorAll('[role=tab]')];
tabs.forEach((t, i) => t.addEventListener('keydown', ev => {
  const d = {ArrowRight: 1, ArrowLeft: -1}[ev.key]; if (!d) return;
  const n = tabs[(i + d + tabs.length) % tabs.length]; n.click(); n.focus(); }));
tabs.forEach(t => t.addEventListener('click', () => tabs.forEach(x => {
  const on = x === t; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1;
  document.getElementById(x.getAttribute('aria-controls')).hidden = !on; })));
</script>
```

**La direction décide.** L’habillage de chaque contrôle : voix typographique, bord, couleur par rôle, alignement sur la grille (`BIBLIOTHEQUE/COMPONENTS`, « Parties ordinaires »). Un menu de sélection reste un `<select>` natif, habillé.

**Vérifier.** Ordre de tabulation et noms accessibles (`parcours.py verifier`) ; flèches dans le groupe et dans les onglets ; l’erreur annoncée et liée au champ ; le bouton garde son libellé pendant le chargement.

Pour l’ensemble des références de la skill, revenir à leur [index](README.md).
