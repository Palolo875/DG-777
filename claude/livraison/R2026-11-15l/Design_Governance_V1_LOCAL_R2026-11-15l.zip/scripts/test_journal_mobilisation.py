#!/usr/bin/env python3
"""Tests du journal de mobilisation : passif sans DG_JOURNAL, fidèle avec, jamais bloquant."""
import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import journal_mobilisation as jm


def lancer(*args, journal=None):
    env = {k: v for k, v in os.environ.items() if k != jm.VAR}
    if journal is not None:
        env[jm.VAR] = str(journal)
    return subprocess.run([sys.executable, str(ROOT / "scripts" / "read_route.py"), *args],
                          capture_output=True, text=True, encoding="utf-8", env=env, cwd=ROOT)


class Journal(unittest.TestCase):
    def test_sans_variable_rien_n_est_ecrit_et_la_sortie_est_identique(self):
        with tempfile.TemporaryDirectory() as tmp:
            chemin = Path(tmp) / "j.jsonl"
            sans, avec = lancer("SAVOIR/TYPE"), lancer("SAVOIR/TYPE", journal=chemin)
            self.assertEqual(sans.stdout, avec.stdout)
            self.assertEqual(sans.returncode, avec.returncode)
            self.assertFalse((Path(tmp) / "autre.jsonl").exists())
            entrees = jm.lire(chemin)
            self.assertEqual(len(entrees), 1)
            self.assertEqual(entrees[0]["routes_lues"], ["SAVOIR/TYPE"])
            self.assertEqual(entrees[0]["code"], 0)

    def test_echec_de_lecture_journalise_avec_son_code(self):
        with tempfile.TemporaryDirectory() as tmp:
            chemin = Path(tmp) / "j.jsonl"
            r = lancer("NEXISTE/PAS", journal=chemin)
            self.assertNotEqual(r.returncode, 0)
            self.assertEqual(jm.lire(chemin)[0]["code"], r.returncode)

    def test_journal_impossible_a_ecrire_ne_bloque_pas(self):
        with tempfile.TemporaryDirectory() as tmp:
            r = lancer("SAVOIR/TYPE", journal=Path(tmp))  # un dossier : écriture impossible
            self.assertEqual(r.returncode, 0)
            self.assertIn("ROUTE: SAVOIR/TYPE", r.stdout)
            self.assertIn("journal de mobilisation non écrit", r.stderr)

    def test_resume_des_recettes(self):
        rendu = "[RETURN               ] Contraste du texte sur fond uni : 2 textes\n[PASS                 ] Débordement : aucun\n"
        self.assertEqual(jm.resumer("check_render", rendu)["resultats"], {"RETURN": ["Contraste du texte sur fond uni"], "PASS": ["Débordement"]})
        avec_route = rendu.replace("2 textes\n", "2 textes\n                        → savoir : SAVOIR/CRAFT/CFT-05 ; SAVOIR/CRAFT/CFT-03\n")
        self.assertEqual(jm.resumer("check_render", avec_route)["routes_proposees"], ["SAVOIR/CRAFT/CFT-05", "SAVOIR/CRAFT/CFT-03"])
        entree = {"outil": "check_render", "commande": ["p.html"], "code": 1, **jm.resumer("check_render", avec_route)}
        self.assertIn("savoir proposé : `SAVOIR/CRAFT/CFT-05`", jm.niveau_outil(entree))
        self.assertTrue(jm.resumer("check_render", "NOT-VERIFIED — navigateur indisponible")["non_verifie"])

    def test_fiche_signale_le_tronc_non_servi(self):
        entrees = [{"horodatage": "2026-10-21T10:00:00+00:00", "outil": "read_route", "commande": ["--mode", "ITER"], "code": 0,
                    "routes_lues": [], "routes_proposees": []}]
        texte = jm.fiche(entrees)
        self.assertIn("ligne du mode ITER", texte)
        self.assertIn("Tronc ITER non servi", texte)
        servi = [{"outil": "read_route", "commande": ["--tronc", "ITER"], "code": 0, "routes_lues": ["ACTION/RUN-ITER", "ACTION/GATE-A/CONTROLES"],
                  "routes_proposees": []}]
        self.assertNotIn("Tronc ITER non servi", jm.fiche(servi))
        self.assertIn("servi en entier", jm.fiche(servi))

    def test_tronc_compare_a_celui_du_run(self):
        # Le tronc noté au moment de l'appel fait foi, pas celui du paquet présent quand la fiche est écrite.
        e = [{"outil": "read_route", "commande": ["--tronc", "ITER"], "code": 0, "mode": "ITER", "tronc": ["X/ANCIENNE"],
              "routes_lues": ["X/ANCIENNE"], "routes_proposees": []}]
        texte = jm.fiche(e)
        self.assertIn("servi en entier", texte)
        self.assertNotIn("ACTION/RUN-ITER", texte.split("## Manques")[1])
        sans = [{"outil": "read_route", "commande": ["--mode", "ITER"], "code": 0, "routes_lues": [], "routes_proposees": []}]
        self.assertIn("tronc du paquet présent : non noté au run", jm.fiche(sans))
        with tempfile.TemporaryDirectory() as tmp:
            chemin = Path(tmp) / "j.jsonl"
            lancer("--mode", "ITER", journal=chemin)
            entree = jm.lire(chemin)[0]
            self.assertEqual(entree["mode"], "ITER")
            self.assertIn("ACTION/RUN-ITER", entree["tronc"])

    def test_tronc_ecrit_dans_un_fichier_n_est_pas_lu(self):
        with tempfile.TemporaryDirectory() as tmp:
            chemin = Path(tmp) / "j.jsonl"
            lancer("--tronc", "ITER", "--fichier", str(Path(tmp) / "tronc.txt"), journal=chemin)
            fiche = jm.fiche(jm.lire(chemin))
            self.assertIn("écrite dans un fichier (`--fichier`", fiche)
            self.assertIn("lecture non observée", fiche)
            self.assertIn("servi seulement filtré, jeté ou écrit dans un fichier", fiche)

    def test_fiche_outil_en_echec(self):
        e = [{"outil": "check_render", "commande": ["p.html"], "code": 2, "non_verifie": True, "resultats": {}}]
        self.assertIn("sollicité, en échec", jm.fiche(e))

    def test_sortie_en_erreur_sans_resultat_n_est_pas_un_succes(self):
        e = [{"outil": "check_render", "commande": ["p.html"], "code": 1, "non_verifie": False, "resultats": {}}]
        self.assertIn("en échec (code 1, aucun résultat)", jm.fiche(e))
        usage = [{"outil": "check_render", "commande": ["--inconnue"], "code": 2, "non_verifie": False, "resultats": {}}]
        self.assertNotIn("NOT-VERIFIED", jm.fiche(usage))
        self.assertIn("en échec (code 2", jm.fiche(usage))
        retour = [{"outil": "check_render", "commande": ["p.html"], "code": 1, "non_verifie": False, "resultats": {"RETURN": ["Contraste"]}}]
        self.assertIn("RETURN — Contraste", jm.fiche(retour))

    def test_options_ecrites_avec_egal(self):
        e = [{"outil": "read_route", "commande": ["--mode=ITER"], "code": 0, "routes_lues": [], "routes_proposees": []}]
        texte = jm.fiche(e)
        self.assertIn("ligne du mode ITER", texte)
        self.assertIn("Tronc ITER non servi", texte)
        self.assertEqual(jm.option(["--tronc=DIRECTION"], "--tronc"), "DIRECTION")

    def ligne(self, commande: str) -> list[dict]:
        """Lance une ligne de shell avec le journal actif et rend ses entrées."""
        with tempfile.TemporaryDirectory() as tmp:
            chemin = Path(tmp) / "j.jsonl"
            env = {**{k: v for k, v in os.environ.items() if k != jm.VAR}, jm.VAR: str(chemin)}
            py = f"'{sys.executable}' scripts/read_route.py"
            subprocess.run(["bash", "-c", commande.replace("RR", py).replace("TMP", tmp)], env=env, cwd=ROOT, check=False,
                           capture_output=True)
            return jm.lire(chemin)

    def lisible(self, entrees: list[dict]) -> None:
        if not any(e.get("extraction") for e in entrees):
            self.skipTest("commande du shell parent illisible sur cette plateforme")

    def test_filtre_attribue_a_son_appel(self):
        # Deux appels enchaînés ; seul le premier est coupé.
        a, b = self.ligne("RR SAVOIR/TYPE | head -3 > /dev/null ; RR SAVOIR/STATE > /dev/null ; true")
        self.assertEqual(a.get("extraction"), "head -3")
        self.assertNotIn("extraction", b)
        # Et l'inverse : le second seulement.
        a, b = self.ligne("RR SAVOIR/SOURCE | cat > /dev/null ; RR SAVOIR/STYLE | head -3 > /dev/null ; true")
        self.lisible([b])
        self.assertNotIn("extraction", a)
        self.assertEqual(b.get("extraction"), "head -3")

    def test_filtre_qui_ne_coupe_rien_n_est_pas_note(self):
        (e,) = self.ligne("RR ACTION/ATELIER-EDITION | head -500 | cat > /dev/null ; RR SAVOIR/TYPE | head -2 > /dev/null")[:1]
        self.assertNotIn("extraction", e)

    def test_compte_seul_et_redirection(self):
        (wc,) = self.ligne("RR SAVOIR/CONTEXT | wc -l > /dev/null ; true")
        self.lisible([wc])
        self.assertTrue(wc["extraction"].startswith("wc"))
        (fichier,) = self.ligne("RR SAVOIR/TECH > TMP/x.txt")
        self.assertEqual(fichier.get("destination"), "fichier")
        self.assertIn("sortie redirigée vers un fichier : lecture non observée", jm.fiche([fichier]))
        (jete,) = self.ligne("RR SAVOIR/TECH > /dev/null")
        self.assertIn("servie puis jetée", jm.fiche([jete]))

    def test_route_servie_n_est_pas_dite_lue(self):
        (e,) = self.ligne("RR SAVOIR/TYPE | cat > /dev/null")
        fiche = jm.fiche([e])
        self.assertRegex(fiche, r"`SAVOIR/TYPE` \| servie \(\d+ car\.\)")
        self.assertNotIn("consultée", fiche)
        self.assertNotIn("lecture partielle", fiche)

    def test_sortie_du_parcours_relevee(self):
        sortie = ("# Parcours — p.html\n\n## 1. Défauts bloquants\n- **Débordement horizontal** : 790 px\n\n"
                  "## 2. Réserves à vérifier\n- Contraste du texte sur fond uni : rien sous le seuil\n"
                  "- Noms accessibles calculés par le navigateur à 1440 px : 3 contrôle(s), tous nommés ; levée.\n\n"
                  "## 3. Signaux et questions\n- 1440 px · **Cohérence de rayon** — 4 rayons. Question ?\n"
                  "- À regarder, non mesuré : **Partie ordinaire** — x\n\n## 4. Images (extrait)\n")
        r = jm.resumer("parcours", sortie, ["verifier", "p.html"])
        self.assertEqual(r["sous_commande"], "verifier")
        self.assertEqual(r["resultats"], {"RETURN": ["Débordement horizontal"], "PASS-WITH-RESERVATION": ["Contraste du texte sur fond uni"],
                                          "SIGNAL": ["Cohérence de rayon"]})
        e = {"outil": "parcours", "commande": ["verifier", "p.html"], "code": 1, **r}
        self.assertIn("parcours verifier sur `p.html` | exécuté : RETURN — Débordement horizontal", jm.fiche([e]))
        autre = {"outil": "parcours", "commande": ["tirage"], "code": 0, **jm.resumer("parcours", "pistes : a, b", ["tirage"])}
        self.assertIn("parcours tirage", jm.fiche([autre]))
        self.assertNotIn("rien à traiter", jm.fiche([autre]))

    def test_direction_sans_planche_ni_regard_est_signale(self):
        mode = {"outil": "read_route", "commande": ["--mode", "DIRECTION"], "code": 0, "routes_lues": [], "routes_proposees": []}
        fiche = jm.fiche([mode])
        self.assertIn("Mode DIRECTION sans planche", fiche)
        self.assertIn("Mode DIRECTION sans regard", fiche)
        planche = {"outil": "planche", "commande": ["p.png", "modale.html", "a.html"], "code": 0}
        regard = {"outil": "regard", "commande": ["a.html"], "code": 0}
        fiche = jm.fiche([mode, planche, regard])
        self.assertNotIn("sans planche", fiche)
        self.assertNotIn("sans regard", fiche)
        self.assertIn("planche sur `modale.html`, `a.html` | exécuté", fiche)

    def test_rendu_sans_ligne_de_mode_est_signale(self):
        rendu = {"outil": "check_render", "commande": ["page.html"], "code": 0, "resultats": {"PASS": ["x"]}}
        self.assertIn("sans ligne de mode servie", jm.fiche([rendu]))

    def test_journal_absent(self):
        erreur = io.StringIO()
        with contextlib.redirect_stderr(erreur):  # échec attendu : capté ici, pas dans la sortie de la préparation
            self.assertEqual(jm.main(["/chemin/inexistant.jsonl"]), 2)
        self.assertIn("journal introuvable", erreur.getvalue())


if __name__ == "__main__":
    res = unittest.main(exit=False, verbosity=0).result
    if res.failures or res.errors:
        print(f"JOURNAL TESTS FAILED — {len(res.failures) + len(res.errors)} échec(s) sur {res.testsRun}"); sys.exit(1)
    print(f"JOURNAL TESTS PASSED — {res.testsRun} cas")
