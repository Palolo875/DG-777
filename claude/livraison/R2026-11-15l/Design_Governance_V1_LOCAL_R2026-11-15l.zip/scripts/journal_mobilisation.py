#!/usr/bin/env python3
"""Journal de mobilisation, passif : ce que le lecteur de routes et les recettes ont servi pendant un run.

Sans la variable d'environnement DG_JOURNAL, rien n'est écrit et les outils se comportent à l'identique.
Avec DG_JOURNAL=chemin.jsonl, chaque appel de read_route.py, check_render.py, planche.py, regard.py ou parcours.py ajoute
une ligne JSON : horodatage, commande, code de sortie, routes servies ou résultats. Un journal illisible
ou impossible à écrire ne bloque jamais l'outil : un avertissement part sur la sortie d'erreur.

Le journal observe ce que les outils ont servi et où leur sortie est allée (terminal ou tube, fichier, /dev/null),
plus un indice : le filtre vu dans la commande de l'appel. Il ne voit ni la lecture ni l'attention de l'agent : une route
servie n'est pas une route lue, et une route lue n'est pas une route appliquée. La fiche produite par ce script laisse
la conséquence et la preuve à remplir.

Usage : python3 scripts/journal_mobilisation.py JOURNAL.jsonl   (fiche de mobilisation en Markdown)
"""
from __future__ import annotations

import io
import json
import os
import re
import sys
sys.dont_write_bytecode = True  # les imports entre outils n’écrivent rien dans le paquet
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

VAR = "DG_JOURNAL"
ROUTE = r"[A-Z]+(?:/[A-Za-z0-9_\-]+)+"


def actif() -> bool:
    return bool(os.environ.get(VAR))


def noter(entree: dict) -> None:
    chemin = os.environ.get(VAR)
    if not chemin:
        return
    ligne = {"horodatage": datetime.now(timezone.utc).isoformat(timespec="seconds"), **entree}
    try:
        with open(chemin, "a", encoding="utf-8") as f:
            f.write(json.dumps(ligne, ensure_ascii=False) + "\n")
    except OSError as exc:
        print(f"journal de mobilisation non écrit ({exc.strerror or exc}) : {chemin}", file=sys.stderr)


class _Copie(io.TextIOBase):
    """Laisse passer la sortie et en garde une copie pour le résumé du journal."""

    def __init__(self, cible):
        self.cible, self.texte = cible, io.StringIO()

    def write(self, s):
        self.texte.write(s)
        return self.cible.write(s)

    def flush(self):
        self.cible.flush()

    @property
    def encoding(self):
        return getattr(self.cible, "encoding", "utf-8")

    def fileno(self):
        return self.cible.fileno()


def resumer(outil: str, texte: str, argv: list[str] | None = None) -> dict:
    """Ce que la sortie d'un outil dit de la mobilisation, sans interpréter au-delà."""
    if outil == "read_route":
        lues = re.findall(rf"^ROUTE: ({ROUTE})", texte, re.M) + re.findall(rf"^======== ({ROUTE}) \(", texte, re.M)
        tailles = {r: int(n) for r, n in re.findall(rf"^======== ({ROUTE}) \((\d+) caractères\)", texte, re.M)}
        proposees = [r for r in re.findall(rf"^\s*({ROUTE})\s{{2,}}\d+ ligne", texte, re.M) if r not in lues]
        return {"routes_lues": list(dict.fromkeys(lues)), "routes_proposees": list(dict.fromkeys(proposees)),
                "caracteres": len(texte), **({"tailles": tailles} if tailles else {})}
    if outil in ("planche", "regard"):  # instruments du levier « Diverger sur image » : leur exécution suffit à la fiche
        pages = [ligne for ligne in texte.splitlines() if ligne.startswith(("Planche écrite", "# Fiche de regard"))]
        return {"resultats": {}, "non_verifie": False, "routes_proposees": [], "sortie": pages[:1]}
    if outil == "parcours":
        return resumer_parcours(texte, argv or [])
    routes: list[str] = []
    if outil == "check_render":
        res = re.findall(r"^\[([A-Z-]+)\s*\] ([^:\n]+?) :", texte, re.M)
        for ligne in re.findall(r"^\s+→ savoir : (.+)$", texte, re.M):  # route proposée sous un défaut
            routes += [r.strip() for r in ligne.split(";") if r.strip()]
    else:
        res = re.findall(r"^\[([A-ZÉ]+)\] [^·\n]+· ([^·\n]+?) ·", texte, re.M)
    statuts: dict[str, list[str]] = {}
    for statut, controle in res:
        statuts.setdefault(statut, [])
        if controle.strip() not in statuts[statut]:
            statuts[statut].append(controle.strip())
    return {"resultats": statuts, "non_verifie": "NOT-VERIFIED —" in texte, "routes_proposees": list(dict.fromkeys(routes))}


def _section(texte: str, numero: int) -> list[str]:
    """Lignes « - … » d'une section numérotée de la fiche du parcours (« ## 1. … »)."""
    m = re.search(rf"^## {numero}\. [^\n]*\n(.*?)(?=^## |\Z)", texte, re.M | re.S)
    return [l[2:].strip() for l in (m.group(1).splitlines() if m else []) if l.startswith("- ")]


def resumer_parcours(texte: str, argv: list[str]) -> dict:
    """Sous-commande lancée et, pour `verifier`, ce que la fiche affichée porte : défauts, réserves, signaux."""
    sous = next((x for x in argv if not x.startswith("-")), "")
    out = {"sous_commande": sous, "resultats": {}, "non_verifie": "NOT-VERIFIED —" in texte, "routes_proposees": []}
    if sous != "verifier":
        return out
    titre = lambda l: re.sub(r"\*\*", "", (re.search(r"\*\*(.+?)\*\*", l) or re.match(r"([^:]+)", l)).group(1)).strip()
    bloquants = [titre(l) for l in _section(texte, 1) if not l.startswith("Aucun")]
    reserves = [titre(l) for l in _section(texte, 2) if not l.startswith(("Aucune", "Noms accessibles calculés"))]
    signaux = [titre(l) for l in _section(texte, 3)
               if "**" in l and not l.startswith(("À regarder, non mesuré", "Aucun signal"))]
    for cle, valeurs in (("RETURN", bloquants), ("PASS-WITH-RESERVATION", reserves), ("SIGNAL", signaux)):
        if valeurs:
            out["resultats"][cle] = list(dict.fromkeys(valeurs))
    return out


# Commandes qui ne laissent passer qu'une partie de la sortie, ou seulement un compte (wc).
FILTRE = re.compile(r"\|\s*((?:head|tail|grep|rg|sed|awk|cut|less|more|wc)\b[^|;&'\"<>]*)")


def _segments(commande: str) -> list[str]:
    """Commandes successives d'une ligne de shell (; && || et retours à la ligne), chacune avec ses tubes."""
    return [s for s in re.split(r";|&&|\|\||\n", commande) if s.strip()]


def extraction(outil: str, argv: list[str] | None = None, lignes: int | None = None) -> str | None:
    """Filtre vu dans la commande du shell parent pour CET appel (« … | head -20 ») ; None si aucun, s'il ne coupe rien,
    ou si la commande est illisible.

    L'appel se retrouve par son script et ses arguments, pas par sa position : une ligne qui enchaîne plusieurs appels
    ne prête pas le filtre de l'un à l'autre. Un `head -N` ou `tail -N` plus long que la sortie ne coupe rien. Le journal
    voit une commande, jamais une lecture : un filtre vu ne prouve pas qu'une partie a été ignorée.
    """
    parent = ""
    try:  # /proc garde les retours à la ligne de la commande ; `ps` les remplace par des espaces
        parent = Path(f"/proc/{os.getppid()}/cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace")
    except OSError:
        try:
            import subprocess
            parent = subprocess.run(["ps", "-o", "args=", "-p", str(os.getppid())], capture_output=True, text=True, timeout=2).stdout
        except Exception:  # ni /proc ni ps : rien n'est déduit
            return None
    args = re.sub(r"[\"']", "", " ".join(argv or []))
    vus = []
    for seg in _segments(parent):
        for m_appel in re.finditer(re.escape(f"{outil}.py"), seg):
            appel, _, suite = seg[m_appel.start():].partition("|")
            appel = re.sub(r"\s*\d?[<>].*$", "", re.sub(r"[\"']", "", appel)).strip()
            if args and not appel.endswith(args):
                continue
            m = FILTRE.search("|" + suite) if suite else None
            vus.append(m.group(1).strip()[:40] if m else None)
    if not vus or len(set(vus)) > 1:  # aucun appel retrouvé, ou deux appels identiques avec des filtres différents
        return None if not vus or all(v is None for v in vus) else "filtre incertain (appels semblables)"
    filtre = vus[0]
    n = re.match(r"(?:head|tail)\s+(?:-n\s*)?-?(\d+)\s*$", filtre or "")
    if n and lignes is not None and int(n.group(1)) >= lignes:
        return None  # le filtre laisse passer toute la sortie
    return filtre


def destination_sortie() -> str | None:
    """« fichier » si la sortie est redirigée vers un fichier, « null » vers /dev/null ; None pour un terminal ou un tube."""
    import stat
    try:
        st = os.fstat(sys.stdout.fileno())
        nul = os.stat(os.devnull)
    except (OSError, ValueError, AttributeError):
        return None
    if (st.st_dev, st.st_ino) == (nul.st_dev, nul.st_ino):
        return "null"
    return "fichier" if stat.S_ISREG(st.st_mode) else None


def tronc_au_run(argv: list[str]) -> dict:
    """Mode et routes du tronc au moment de l'appel : la fiche compare à ce tronc, pas à celui du paquet présent plus tard."""
    mode = option(argv, "--tronc") or option(argv, "--mode")
    if not mode:
        return {}
    mode = "SYSTÈME" if mode == "SYSTEME" else mode
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import read_route
        return {"mode": mode, "tronc": read_route.tronc_routes(mode)}
    except Exception:
        return {"mode": mode}


def executer(outil: str, principal: Callable[[], int], argv: list[str]) -> int:
    """Lance l'outil ; avec DG_JOURNAL, note la commande, le code de sortie et le résumé de la sortie."""
    if not actif():
        return principal()
    destination = destination_sortie()
    copie, origine = _Copie(sys.stdout), sys.stdout
    sys.stdout = copie
    code = 1
    try:
        code = principal()
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
        raise
    finally:
        sys.stdout = origine
        texte = copie.texte.getvalue()
        filtre = extraction(outil, argv, texte.count("\n") + (not texte.endswith("\n") and bool(texte)))
        noter({"outil": outil, "commande": argv, "code": code, **({"extraction": filtre} if filtre else {}),
               **({"destination": destination} if destination else {}),
               **(tronc_au_run(argv) if outil == "read_route" else {}),
               **resumer(outil, texte, argv)})
    return code


def lire(chemin: Path) -> list[dict]:
    entrees = []
    for n, ligne in enumerate(chemin.read_text(encoding="utf-8").splitlines(), 1):
        if ligne.strip():
            try:
                entrees.append(json.loads(ligne))
            except json.JSONDecodeError:
                print(f"ligne {n} illisible, ignorée", file=sys.stderr)
    return entrees


def option(cmd: list[str], nom: str) -> str | None:
    """Valeur d'une option, écrite « --nom VALEUR » ou « --nom=VALEUR »."""
    for i, c in enumerate(cmd):
        if c == nom and i + 1 < len(cmd):
            return cmd[i + 1]
        if c.startswith(nom + "="):
            return c[len(nom) + 1:]
    return None


def niveau_outil(e: dict) -> str:
    res = e.get("resultats") or {}
    if e.get("non_verifie"):
        return "sollicité, en échec (NOT-VERIFIED)"
    if not res and e.get("code") not in (0, None):
        return f"sollicité, en échec (code {e.get('code')}, aucun résultat)"
    utiles = {k: v for k, v in res.items() if k in ("RETURN", "PASS-WITH-RESERVATION", "SIGNAL", "RELEVÉ")}
    if not utiles:
        if e.get("outil") == "parcours" and e.get("sous_commande") not in (None, "verifier"):
            return "exécuté"
        return "exécuté, rien à traiter"
    proposees = e.get("routes_proposees") or []
    return ("exécuté : " + " ; ".join(f"{k} — {', '.join(v)}" for k, v in utiles.items())
            + (f" ; savoir proposé : {', '.join(f'`{r}`' for r in proposees)}" if proposees else ""))


# Niveaux d'une route servie, du plus au moins observable. Le journal voit ce que l'outil a servi et où la sortie est
# allée ; il ne voit jamais ce que l'agent a lu.
SERVIE, FILTREE, FICHIER, JETEE = "servie", "filtrée", "fichier", "jetée"
RANG = {SERVIE: 3, FILTREE: 2, FICHIER: 1, JETEE: 0}


def niveau_route(e: dict, route: str) -> tuple[str, str]:
    """(niveau, libellé) d'une route dans une entrée du lecteur."""
    taille = (e.get("tailles") or {}).get(route)
    if option(e.get("commande", []), "--fichier"):
        return FICHIER, f"écrite dans un fichier (`--fichier`{f', {taille} car.' if taille else ''}) : lecture non observée"
    if e.get("destination") == "null":
        return JETEE, "servie puis jetée (`/dev/null`)"
    if e.get("destination") == "fichier":
        return FICHIER, "sortie redirigée vers un fichier : lecture non observée"
    if e.get("extraction"):
        return FILTREE, f"servie ; filtre vu dans la commande (`{e['extraction']}`)"
    n = taille or (e.get("caracteres") if len(e.get("routes_lues", [])) == 1 else None)
    return SERVIE, "servie" + (f" ({n} car.)" if n else "")


def fiche(entrees: list[dict]) -> str:
    lignes = ["# Fiche de mobilisation", "",
              "Présent dans le contexte à chaque run : le noyau de la skill. Les appels ci-dessous sont observés : une route "
              "« servie » a été affichée par le lecteur, ce qui ne prouve pas qu'elle a été lue. La conséquence et la preuve "
              "restent à établir sur la trace et l'artefact.", "",
              "Catégories de lecture (`DIRECTION/LECTURE-INSTRUMENTEE`) : `STARTUP-NOMINAL` (recommandé avant la première "
              "décision), `CONDITIONAL-READ` (ouvert sur une condition du brief ou du risque), `AUDIT-READ` (contrôle du corpus, "
              "jamais compté pour le run), `ACTUAL-READ` (effectivement lu). Ce journal sert de base à `ACTUAL-READ`, sans le prouver.", "",
              "| Ordre | Heure (UTC) | Élément | Niveau observé | Conséquence | Preuve |", "|---|---|---|---|---|---|"]
    vues: dict[str, str] = {}
    modes: set[str] = set()
    troncs: dict[str, list[str]] = {}
    for i, e in enumerate(entrees, 1):
        heure = e.get("horodatage", "")[11:19]
        cmd = e.get("commande", [])
        for opt in ("--mode", "--tronc"):
            valeur = option(cmd, opt)
            if valeur:
                modes.add("SYSTÈME" if valeur == "SYSTEME" else valeur)
        if e.get("tronc") and e.get("mode"):
            troncs.setdefault(e["mode"], e["tronc"])
        if e.get("outil") == "read_route":
            for r in e.get("routes_lues", []):
                niveau, libelle = niveau_route(e, r)
                if r not in vues or RANG[niveau] > RANG[vues[r]]:
                    vues[r] = niveau
                lignes.append(f"| {i} | {heure} | `{r}` | {libelle} | | |")
            if e.get("routes_proposees"):
                terme = option(cmd, "--trouver") or ""
                lignes.append(f"| {i} | {heure} | recherche « {terme} » | proposée, non servie : {', '.join(f'`{r}`' for r in e['routes_proposees'][:6])} | | |")
            if not e.get("routes_lues") and not e.get("routes_proposees"):
                if option(cmd, "--mode") and e.get("code") == 0:
                    lignes.append(f"| {i} | {heure} | ligne du mode {option(cmd, '--mode')} | servie (routes citées, non servies) | | |")
                else:
                    lignes.append(f"| {i} | {heure} | read_route {' '.join(cmd)} | code {e.get('code')}, rien servi | | |")
        elif e.get("outil") in ("planche", "regard"):
            pages = [Path(c).name for c in cmd if c.endswith(".html")]
            fait = "exécuté" if e.get("code") == 0 else f"en échec (code {e.get('code')})"
            lignes.append(f"| {i} | {heure} | {e.get('outil')} sur {', '.join(f'`{p}`' for p in pages) or '—'} | {fait} | | |")
        else:
            cible = next((c for c in cmd if c.endswith(".html")), " ".join(cmd))
            sous = f" {e['sous_commande']}" if e.get("sous_commande") else ""
            lignes.append(f"| {i} | {heure} | {e.get('outil')}{sous} sur `{Path(cible).name}` | {niveau_outil(e)} | | |")
    manques = []
    for mode in sorted(modes):
        tronc, note = troncs.get(mode), ""
        if tronc is None:
            try:
                sys.path.insert(0, str(Path(__file__).resolve().parent))
                import read_route
                tronc, note = read_route.tronc_routes(mode), " (tronc du paquet présent : non noté au run)"
            except Exception:  # ligne de mode illisible : signalé, jamais deviné
                manques.append(f"- Tronc du mode {mode} illisible : non contrôlé.")
                continue
        absentes = [r for r in tronc if r not in vues]
        indirectes = [r for r in tronc if vues.get(r) in (FILTREE, FICHIER, JETEE)]
        if absentes:
            manques.append(f"- Tronc {mode} non servi{note} : {', '.join(f'`{r}`' for r in absentes)}.")
        if indirectes:
            manques.append(f"- Tronc {mode} servi seulement filtré, jeté ou écrit dans un fichier{note} : "
                           f"{', '.join(f'`{r}`' for r in indirectes)} (lecture non observée).")
    rendus = any(e.get("outil") in ("check_render", "regard", "planche", "parcours") for e in entrees)
    if rendus and not modes:
        manques.append("- Rendu observé sans ligne de mode servie (`--mode` ou `--tronc`) : le run n'a pas chargé son mode.")
    if "DIRECTION" in modes:
        if not any(e.get("outil") == "planche" and e.get("code") == 0 for e in entrees):
            manques.append("- Mode DIRECTION sans planche : le levier « Diverger sur image » (directions écrites, esquisses "
                           "face à la modale) n'a pas été exécuté ; à justifier s'il s'agissait d'un correctif local.")
        if not any(e.get("outil") == "regard" and e.get("code") == 0 for e in entrees):
            manques.append("- Mode DIRECTION sans regard : la version gardée n'a pas été mesurée (`scripts/regard.py`).")
    lignes += ["", "## Manques", "",
               *(manques or ["- Tronc des modes observés : servi en entier."]),
               "- À établir sur la trace : routes pertinentes jamais ouvertes, déclencheur mal formulé, problème non reconnu, "
               "moyen absent ou en échec."]
    return "\n".join(lignes) + "\n"


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 1:
        print("Usage : python3 scripts/journal_mobilisation.py JOURNAL.jsonl", file=sys.stderr)
        return 2
    chemin = Path(args[0])
    if not chemin.is_file():
        print(f"journal introuvable : {chemin}", file=sys.stderr)
        return 2
    print(fiche(lire(chemin)), end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
