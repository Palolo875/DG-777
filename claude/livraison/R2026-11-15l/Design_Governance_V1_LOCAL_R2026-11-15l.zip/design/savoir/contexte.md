# Savoir — contexte et accessibilité

Accessibilité, contextes à fort enjeu, responsive et mouvement.

# SAVOIR/CONTEXT — accessibilité, contexte et robustesse

[REQUIS PAR LE MODULE — contrôle applicable dans ACTION] SAVOIR décrit la décision de conception contextualisée. ACTION porte le contrôle, le scope, la méthode, la preuve et le verdict. Une phrase de conformité dans SAVOIR ne remplace pas un contrôle Gate A.

Les principes de livraison sont : contraste calculé, sémantique, nom accessible, clavier, focus visible, information non chromatique, cibles adaptées, reduced motion, contenu long et récupération compréhensible.

### Accessibilité : ce qui se décide en concevant

La plupart des défauts d’accessibilité se décident dans la maquette, pas dans la correction finale. Le contrôle reste celui d’`ACTION/GATE-A` ; ces repères disent ce qui le rend facile à tenir.

- **Texte.** La page tient quand l’espacement du texte est agrandi (interligne 1,5 ; paragraphes 2 fois la taille ; lettres 0,12 em ; mots 0,16 em) et à 320 px CSS de large sans défilement horizontal, ce qui correspond au zoom à 400 % (WCAG 2.2, 1.4.12 et 1.4.10). Cela exclut une hauteur fixe sur un bloc de texte et un texte rendu en image. Corps, interligne et mesure du texte courant : `SAVOIR/TYPE`, « Texte de lecture ».
- **Ordre.** L’ordre de lecture et de tabulation suit l’ordre visuel. Une composition asymétrique ne réordonne pas le document pour l’effet.
- **Focus.** L’état de focus se dessine comme les autres états, dans la direction de la page, avec un contraste d’au moins 3:1 contre ce qui l’entoure. Un en-tête collant ou un bandeau ne le recouvre jamais (2.4.11).
- **Cibles.** 24 px CSS au moins, ou l’espacement équivalent (2.5.8). `[À ADAPTER]` Sur mobile, l’action principale vise plutôt 44 px.
- **Formulaires.** Une étiquette visible accompagne chaque champ : un texte d’exemple n’est pas une étiquette. L’erreur se dit en texte à côté du champ, avec ce qui la corrige. Une information déjà donnée ne se redemande pas (3.3.7).
- **Couleur et mouvement.** L’information ne dépend pas de la couleur seule (`SAVOIR/CRAFT/CFT-05`) ; le mouvement réduit suit « Motion et espace », plus bas.

La recette (`ACTION/RECETTE-RENDU`) mesure le contraste, les noms, le clavier, les cibles, le focus, la stabilité au chargement et le mouvement réduit. Elle ne juge ni l’ordre de lecture, ni le zoom, ni l’espacement du texte : ceux-là se regardent sur capture, à 320 px.

### Contextes à fort enjeu

Cette liste est indicative et non exhaustive.

| Catégorie | Exemples | Priorité |
|---|---|---|
| Réglementé ou sécurité critique | Santé, paiement, commande machine, sécurité. | Convention, confirmation, traçabilité, prévention et récupération. |
| Décision intensive | Supervision, finance professionnelle, data dense. | Hiérarchie, densité utile, vitesse de lecture et précision. |
| Réactivité ou gameplay | Jeu, contrôle temps réel, action à latence sensible. | Lisibilité, feedback et réponse immédiate. |

La singularité d’un contexte critique peut être la clarté, la robustesse et la convention fiable. Elle ne requiert ni spectacle ni rupture de repère.

Lorsque expression et sécurité, clarté, conformité ou récupération entrent en tension, la protection critique déclarée par `DIRECTION/START` prévaut. Résous la direction par hiérarchie, contenu, confirmation et robustesse, non par un effet spectaculaire ; le référentiel, le médium, le scope, la méthode et la limite restent explicites dans ACTION.

### Responsive et performance

Recompose plutôt que comprimer. Contenu, priorité, ordonnancement et interaction peuvent changer selon appareil et contexte. Réserve l’espace des médias, donne un feedback immédiat, rends les erreurs récupérables, évite les attentes silencieuses et protège l’information prioritaire.

Les propriétés CSS, valeurs de viewport, formats, budgets et support navigateur sont des ressources techniques, non des lois de style.

### Performance : repères et leviers de conception

[VEILLE 2026-11] `[À ADAPTER]` Repères de terrain, mesurés au 75e centile des visites (indicateurs de performance des navigateurs, 11-2026) : plus grand élément affiché en 2,5 s au plus, réponse à une interaction en 200 ms au plus, décalage cumulé de mise en page de 0,1 au plus. Une page ouverte en local ne mesure pas les deux premiers ; elle montre le troisième. À revoir avant 2027-04.

Ce qui se décide en concevant :

- **L’image du premier écran** est souvent l’élément le plus lourd et le plus grand. On la dimensionne à 2 fois sa taille d’affichage, en AVIF ou WebP, chargée en priorité ; les images plus bas se chargent en différé.
- **Les polices.** `[À ADAPTER]` Deux familles et quatre fichiers au plus, en sous-ensemble, avec une police de repli de métriques voisines pour que le texte ne saute pas.
- **La stabilité.** L’espace de chaque média se réserve (dimensions ou `aspect-ratio`) : rien ne bouge pendant le chargement.
- **Le mouvement et la 3D** au premier écran se justifient par la thèse, et leur coût se mesure.

`[À ADAPTER]` Le poids se lit avec `parcours.py verifier`. Au-delà d’environ 2 Mo pour la page, 500 Ko pour une image ou 300 Ko de polices intégrées, l’écart se décide et se dit.

### Motion et espace

La motion doit expliquer, confirmer, orienter ou rendre une relation matérielle compréhensible. Elle ne doit pas retarder la tâche. Intensité, durée, easing, distance et ressort s’ajustent à l’action, au device et au langage du produit.

**Durées et courbes, points de départ.** `[À ADAPTER]` Ordres de grandeur, **non des mesures** : ils se règlent sur l’action, l’appareil et la distance parcourue. Plus un mouvement revient souvent, plus il est court et discret : une action répétée sans cesse (saisie, raccourci) ne s’anime pas, une révélation vue une seule fois peut prendre son temps. Un retour d’appui ou un survol se compte en une à deux centaines de millisecondes ; un menu ou un panneau qui s’ouvre, en deux à trois ; un dialogue ou un tiroir qui traverse l’écran, un peu plus ; une révélation de section reste sous la seconde. Une sortie est plus brève que l’entrée qui lui correspond. Ce qui entre ralentit en arrivant ; ce qui sort accélère en partant ; ce qui passe d’une place visible à une autre accélère puis ralentit ; une couleur ou une opacité suit une courbe douce. Contre-indications : un geste direct qui suit le pointeur n’a pas de durée à régler ; un contexte critique ou une tâche rapide préfère la suppression ; sous mouvement réduit, l’état et la conséquence restent. Preuve : jouer l’interaction à sa fréquence réelle, répétée puis interrompue (`SAVOIR/TECH`).

Une animation interactive est décrite comme un système d’états : état initial, trigger, transition, interruption et résultat. Une scène 3D ou spatiale est justifiée seulement lorsqu’elle rend un produit, une relation de profondeur, une navigation ou une information spatiale plus compréhensible.

Documente l’équivalent de motion réduite, l’interruption, le fallback statique, clavier/tactile, contenu alternatif, performance, device, runtime, mobile et capture. Une capture documente le rendu dans son scope, mais ne remplace pas un test d’accessibilité, de performance ou de tâche. Si motion ou scène ne donnent ni feedback, ni information, ni relation spatiale, préfère la suppression ou une composition 2D plus juste.

Pour choisir le mécanisme, gérer des interruptions ou traduire un geste mobile, consulte les méthodes de `SAVOIR/TECH` au moment de l’implémentation. Un mouvement réduit conserve l’état, la conséquence et l’accès à l’action ; il réduit la transition, sans enlever le feedback utile.

---
