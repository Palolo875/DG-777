# Savoir — le livre de référence

Le savoir de design, par sujet. Chaque fichier se lit seul ; le lecteur sert aussi chaque section par son code (`python3 scripts/read_route.py SAVOIR/TYPE`).

| Fichier | Sujet |
|---|---|
| [`fondements.md`](fondements.md) | Principe fondateur, compromis, cadrage du contexte |
| [`qualite-creative.md`](qualite-creative.md) | Ambition, forme située, registres, composition, émotion, premier contact, couleur, écriture et contenu |
| [`typographie.md`](typographie.md) | Typographie et données |
| [`composition.md`](composition.md) | Jugement visuel, vocabulaire perceptuel, états |
| [`images-et-sources.md`](images-et-sources.md) | Ancre, sourcing visuel, familles visuelles |
| [`styles.md`](styles.md) | Profils de style et réglages |
| [`systeme-de-design.md`](systeme-de-design.md) | Tokens et composants |
| [`contexte.md`](contexte.md) | Accessibilité, contextes à fort enjeu, responsive, mouvement |
| [`techniques.md`](techniques.md) | Techniques, tests et production par médium |
| [`identite.md`](identite.md) | Identité de marque : signe, déclinaisons, épreuves |
| [`gout-et-tendances.md`](gout-et-tendances.md) | Goût, références, tendances datées, ressources |
| [`connexions.md`](connexions.md) | Quand plusieurs domaines se croisent |

La façon de lire ce savoir est dans [comment utiliser cette bibliothèque](../../agent/chemins.md#savoirread--comment-utiliser-cette-bibliothèque) ; le routage des questions de jugement, dans [routes stables](../../agent/chemins.md#savoirrouting--routes-stables) ; les règles d’or et l’intégrité, dans [limites, délégation et critique](../../gouvernance/integrite.md#savoirintegrity--limites-délégation-et-critique).

Suite : les [formes](../formes/README.md). Retour au [design](../README.md).
