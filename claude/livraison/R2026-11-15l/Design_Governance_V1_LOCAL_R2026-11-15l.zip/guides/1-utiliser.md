# Niveau 1 — Utiliser

Ce niveau suffit pour obtenir un résultat : quoi demander, quoi fournir, ce que vous recevrez, comment poursuivre. Il ne suppose rien, ni connaissance du système, ni pratique du design. Pour comprendre comment le système raisonne et aller chercher un savoir précis, passez au [niveau 2](2-comprendre.md).

## Commencer
<!-- entree:début -->

Design Governance aide un agent à produire un design dirigé, construit et soigné dès la première proposition, puis à l’améliorer avec vous. Vous n’avez besoin de connaître ni les modes, ni le vocabulaire interne : l’agent s’en charge.

**1. Que demander ?** Décrivez en quelques phrases ce que vous voulez obtenir (une page, un écran, une identité, une correction), pour qui, et où cela servira : démonstration, maquette ou vrai produit. S’il s’agit d’un vrai commerce ou d’un vrai service, dites-le.

**2. Que fournir ?** Ce que vous avez déjà : textes, prix, horaires, logo, couleurs, photos (même prises au téléphone, à la lumière du jour), exemples que vous aimez, lien vers l’existant. Vos textes, votre marque et vos photos aident à produire une proposition plus spécifique et crédible. S’il en manque, l’agent construit quand même une première proposition, avec des exemples marqués, et vous pose dans sa réponse au plus trois questions, seulement celles qui améliorent vraiment le résultat : contenu réel, marque, image principale ou source d’images autorisée, destination si elle est incertaine. Il vous demande aussi votre accord avant de générer une image ou d’utiliser un outil connecté à votre compte, et avant de tirer une hypothèse de ce qu’il sait déjà de vous ; sans accord, il s’en passe. Si vous préférez répondre avant qu’il construise, dites-le.

**3. Que recevoir ?** Une première proposition réellement construite, pas un gabarit vide. La réponse commence par la direction choisie : son nom et sa vision en une phrase, dits en mots simples. Elle dit ensuite ce qui a été fait et pourquoi, ce qui est un exemple à remplacer (une démonstration le dit aussi visiblement dans la page), ce qui manque pour la vraie version, ce que l’agent a essayé pour aller plus haut et ce que vous pouvez apporter pour y arriver (vos photos, l’autorisation d’une image générée), et la suite proposée. C’est une proposition à discuter, pas une validation.

**4. Comment poursuivre ?** Validez pour continuer, réorientez ou arrêtez. Pour retenir cette direction pour votre vrai produit, dites-le : l’agent réunit alors les éléments réels et fait les vérifications nécessaires. Dites en une phrase ce qui ne va pas (« le titre écrase la photo », « trop froid pour une boulangerie ») : l’agent corrige le défaut principal, regarde de nouveau le résultat et vous dit ce qui a changé. La réponse finit souvent par une ou deux questions précises sur le rendu ; y répondre suffit pour lancer cette reprise. Avant toute action irréversible ou coûteuse (publier, envoyer, payer, remplacer l’existant), il vous demande votre accord.

Pour aller plus loin : [comprendre](2-comprendre.md) (niveau 2), [maîtriser](3-maitriser.md) (niveau 3), la [skill](../SKILL.md) pour les agents et le [glossaire](glossaire.md). Les règles qui font foi sont rangées dans [`design/`](../design/README.md), [`agent/`](../agent/README.md) et [`gouvernance/`](../gouvernance/README.md).
<!-- entree:fin -->
