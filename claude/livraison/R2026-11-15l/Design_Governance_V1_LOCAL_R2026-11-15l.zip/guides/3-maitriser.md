# Niveau 3 — Maîtriser

Ce niveau sert à piloter un travail de bout en bout : cadrer, confier à un agent, vérifier, décider, conserver et transmettre, seul avec un agent ou à plusieurs. Il suppose les niveaux [1](1-utiliser.md) et [2](2-comprendre.md). Design Governance V1.0.0 est une expérimentation maintenue.

> **Ce que fait ce guide :** il oriente la lecture et l’action, sans ajouter aucune règle. Ce sont les sections citées qui font foi.

> **Pour faire simplement une demande,** le [niveau 1](1-utiliser.md#commencer) suffit : vous n’avez pas à choisir de mode.

Le but : transformer une demande en **décision adaptée au projet, rendu réel, observation utile et trace honnête**. Le système ne promet ni beauté automatique, ni réussite universelle, ni usage validé sans preuve adaptée. Il vise pourtant haut : quand la décision visuelle est ouverte et que les moyens sont là, le premier rendu doit déjà être composé, spécifique, crédible, présentable et assez abouti pour être jugé comme un vrai objet.

Dans ce guide, un **run** est un travail délimité : une décision, un risque, un rendu, une preuve. Chaque lien mène à la section qui fait foi ; la même section se lit aussi par son code, avec `python3 scripts/read_route.py CODE` (par exemple `DIRECTION/START` pour [classer avant d’agir](../agent/chemins.md#directionstart--classer-avant-dagir)).

## Parcours commun

Pour piloter un run, commencez ici ; la suite ne sert que si le risque, le périmètre ou la décision le demande. Une fois la demande classée ([classer avant d’agir](../agent/chemins.md#directionstart--classer-avant-dagir)) (par l’opérateur ou l’agent, jamais par la personne qui demande), notez :

```text
RUN — MODE — DECISION — RISK — NEXT-PROOF — STOP
```

Soit : le chemin choisi, la décision dominante, le risque principal, la prochaine preuve et la condition d’arrêt. C’est la seule déclaration de lancement ([classer avant d’agir](../agent/chemins.md#directionstart--classer-avant-dagir)). Répondez ensuite à ces cinq questions :

| Question | Réponse minimale |
|---|---|
| Quelle décision doit changer ? | Le choix concret à trancher, confirmer ou abandonner. |
| Quel risque domine ? | Identité, usage, accessibilité, technique, système ou autre risque déclaré. |
| Quelle preuve peut départager les options ? | Mesure, capture, test, comparaison, inspection ou observation adaptée. |
| Qu’a-t-on réellement à disposition ? | Rendu, navigateur, code de la page, contraste, clavier et technologies d’assistance, participants, environnement, données ou sources. |
| Qui porte la décision et la suite ? | Un responsable nommé, avec confirmation ou remontée si nécessaire. |

Écrivez la ligne de run, faites l’action la moins coûteuse qui peut changer la décision, puis choisissez une seule suite : **corriger**, **approfondir la preuve**, **rouvrir**, **reclasser**, **proposer** ou **fermer**. Par défaut, le run s’arrête à la proposition, en trace légère : la première proposition vaut point de contrôle, sauf action irréversible ou coûteuse ; **fermer** suppose la trace complète (run persistant, partagé, audité ou acceptation demandée).

## Où trouver la suite

Si la demande est déjà claire, le [niveau 2](2-comprendre.md) indique quoi combiner, quels angles examiner et quand s’arrêter. Si le brief est vague, commencez par classer la demande ([classer avant d’agir](../agent/chemins.md#directionstart--classer-avant-dagir)).

Une sortie de run a deux formes : la **réponse visible**, par défaut, et la trace de reprise, pour un travail qui sera repris ou conservé (voir [sortie minimale commune](../agent/repondre.md#actionhandoff--sortie-minimale-commune)). Le niveau de trace ne dépend pas du mode : sans conservation, partage, audit ni acceptation demandée, la **trace légère** suffit (six lignes au plus, à côté du rendu ou sous « Trace » après la réponse) ; sinon, la **trace complète** s’impose. Écrivez `N/A-JUSTIFIED` (« sans objet, justifié ») quand un champ ou un angle ne s’applique pas.

## 1. Lire juste ce qu’il faut

Ne chargez pas tout le système par réflexe : seulement ce qui peut changer la prochaine décision. L’agent classe la demande, lit le tronc de son mode, puis ouvre une section quand son signal apparaît ([classer, puis charger](../agent/chemins.md#directioncharge--classer-puis-charger)). Si un risque critique est actif, le chemin court ne veut jamais dire une profondeur insuffisante.

Pour une décision visuelle ouverte, l’agent fait d’abord le lancement créatif ([activer la boucle avant le premier pixel](../design/direction/diriger.md#directioncreative-boot--activer-la-boucle-avant-le-premier-pixel)). Sur un brief vague, la prise de brief ([activation portable sur brief vague](../design/direction/cadrer.md#directionexternal-start--activation-portable-sur-brief-vague)) accompagne un rendu construit dans le même tour. Les cinq règles essentielles protègent chaque run ([les cinq règles absolues](../design/direction/standard.md#directionstandard--les-cinq-règles-absolues)).

## 2. La ligne de run

Avant de construire ou de modifier, l’agent répond aux cinq questions du parcours commun et écrit sa ligne de run ([classer avant d’agir](../agent/chemins.md#directionstart--classer-avant-dagir)). `DECISION-CHANGE` ne s’écrit qu’après une observation qui a réellement confirmé, modifié ou abandonné une décision ; rien ne se dit construit, observé ou vérifié qui ne l’a pas été. Si une section qui fait foi est indisponible, l’agent le dit, et la proposition reste une hypothèse.

## 3. Le parcours complet

> **Classer → diriger → construire → observer → choisir une suite (corriger, approfondir la preuve, rouvrir, reclasser, proposer ou fermer) → conserver.**

Deux boucles se suivent : créer un premier rendu complet, puis l’améliorer en l’observant ([créer puis apprendre](../design/direction/boucle.md#directiondouble-loop--créer-puis-apprendre)). Sur une surface `DIRECTION`, l’amélioration commence par l’atelier sur capture ([opération observable](../design/produit/finition.md#actionatelier-edition--opération-observable)). Chaque mode ne garde que les étapes de sa route ([routes d’exécution](../agent/chemins.md#actionrun--routes-dexécution)).

### Lire une section et vérifier une fiche de travail

```bash
python3 scripts/read_route.py DIRECTION/START
python3 scripts/read_route.py --trouver "cohérence de rayon"
python3 scripts/read_route.py --trouver "le titre écrase la photo"
python3 gouvernance/outils/validate_run_card.py --strict chemin/vers/run_card.json
```

Le lecteur cherche en mots entiers et classe les sections qui en parlent ; sans résultat, reformulez : l’absence d’occurrence ne prouve pas l’absence du savoir. Ses options sont décrites dans la [résolution des routes](../maintenance/README.md#résolution-des-routes). Le mode strict du validateur refuse les champs laissés en gabarit et vérifie que les fichiers cités existent ; il ne transforme pas une preuve écrite en preuve d’usage.

## 4. Choisir le mode sans le deviner

L’agent classe avec l’[arbre de classification](../agent/chemins.md#tree--arbre-de-classification) : système partagé, direction ouverte, itération, retouche, puis écran cadré, dans cet ordre ; sans réponse nette, une seule question ciblée. Le mode est une hypothèse de travail, jamais un moyen de baisser la protection : si le périmètre ou le risque grandit, l’agent reclasse.

## 5. Charger seulement ce qui peut changer la décision

La liste de lecture par mode est unique : [classer, puis charger](../agent/chemins.md#directioncharge--classer-puis-charger). La skill active la ligne utile dans cette source unique.

« Non chargé par défaut » veut dire qu’une section n’est pas lue sans raison ; jamais qu’il est interdit de lire une section nécessaire. Lire moins ne baisse ni le mode, ni le niveau de preuve, ni la protection d’un risque.

## 6. Produire une qualité positive dès le premier rendu

Quand la décision visuelle est ouverte, le premier rendu n’est pas un échafaudage volontairement générique : il doit permettre de juger la présence, le foyer, la signature, l’intégration, la résolution, la désirabilité située, la vérité de scène et la résilience. Ces huit dimensions et leurs signaux de retour forment le contrat du premier objet ([compiler le brief et produire le premier objet](../design/direction/premier-objet.md#directionfirst-object--compiler-le-brief-et-produire-le-premier-objet)) : un niveau d’intention, jamais un style, une note ou un verdict.

## 7. En une seule passe : plus court, jamais dispensé

Un run peut se faire en une seule passe (one-shot) quand le périmètre est stable, que la direction est assez déterminée, que les moyens critiques sont disponibles, que le premier objet peut être observé dans son périmètre et qu’aucun risque critique ne reste sans protection.

Une seule passe réduit le nombre de cycles ; elle ne supprime pas :

1. le classement et la déclaration du risque ;
2. la construction d’un rendu réel ;
3. l’observation du premier rendu ou comportement ;
4. la revue créative quand la décision est visuelle ;
5. la vérification du risque dominant ;
6. la trace des preuves, des limites et des décisions, à son niveau (légère par défaut, complète si le run est persistant, partagé ou audité).

En trace légère, la sortie one-shot est la proposition. En trace complète, la sortie one-shot peut être une décision directement clôturée si l’observation confirme que le défaut dominant est absent ou corrigé, et qu’aucune nouvelle passe ne promet de changement visible ou utile. Sinon, le run repart vers la bonne suite : correction, réouverture, reclassement ou prochaine preuve.

## 8. Confier le travail à un agent

Pour qu’un agent travaille avec le système, donnez-lui :

```text
OBJECTIVE — résultat recherché.
SCOPE — surface, état, public, médium et version.
AUTONOMY — actions autorisées sans confirmation.
CONFIRMATION — actions qui exigent un accord préalable.
CONSTRAINTS — contraintes de produit, technique, contenu, droits et délai.
OUTPUT — artefact, trace, preuve, limite et prochaine action attendus.
```

L’agent localise le paquet réellement fourni, lit le noyau de la skill, classe la demande ([classer avant d’agir](../agent/chemins.md#directionstart--classer-avant-dagir)), écrit puis lit une fois la ligne de son mode et son tronc (`read_route.py --tronc MODE --fichier tronc.txt`, voir [classer, puis charger](../agent/chemins.md#directioncharge--classer-puis-charger)), puis seulement les sections que leur signal rend utiles, produit le rendu, vérifie le risque dominant et rend par défaut la réponse visible en langage produit : ce qui a été fait, pourquoi, ce qui manque pour la vraie version, et la suite (voir [sortie minimale commune](../agent/repondre.md#actionhandoff--sortie-minimale-commune)), avec la trace légère par défaut.

Il demande confirmation avant toute action externe, irréversible, publique, destructive, financière ou durable hors du périmètre autorisé. Il ne choisit pas un mode plus léger parce qu’un moyen manque : il le dit, ajuste la protection nécessaire ou garde explicitement la limite.

Pour savoir ce que les outils du paquet ont servi à l’agent et ce qu’il a lancé, activez le journal de mobilisation : la variable `DG_JOURNAL=run.jsonl` dans l’environnement de l’agent, puis `python3 scripts/journal_mobilisation.py run.jsonl` après le run. La fiche relève les sections servies ou proposées, où leur sortie est allée (écran, fichier, `/dev/null`), les appels des recettes et du parcours avec leurs résultats, et signale un run DIRECTION qui n’a pas fait sa planche. Une section servie n’est pas une section lue : la fiche n’observe ni la lecture, ni l’attention de l’agent, ni les fichiers qu’il ouvre directement.

## 9. Exemple complet minimal

Une nouvelle page d’accueil dont la direction visuelle est ouverte, en trace légère, la forme que le système produit par défaut :

```text
RUN: DIRECTION · décision : rendre la promesse mémorable sans ralentir la compréhension · risque : identité et usage · preuve : captures à 1440 et 390 px, `parcours.py verifier` · arrêt : aucun défaut bloquant, premier geste lu en premier
DIRECTION DÉCLARÉE ET THÈSE: « [nom tiré du sujet] » : la preuve du produit porte la première scène ; registre : [base et modificateur] ; mouvement : aucun, la preuve suffit ; lignes non vues : aucune ; ce que la personne veut savoir → l’objet de preuve → le premier geste
MODAL, TRAME ET PARTI: titre centré, sous-titre, deux boutons, trois cartes de bénéfices ; trame promesse → bénéfices → preuve → contact, rompue : la preuve ouvre la page ; s’écarter pour la première scène seulement ; choisi par : auteur du rendu
PLAFOND, ESSAIS ET CONTENUS MARQUÉS: typographie et couleur au plafond ; objet de preuve codé ; contenus d’exemple marqués
DÉFAUT DOMINANT RESTANT: sur mobile, le bouton secondaire concurrençait le premier geste ; geste de `SAVOIR/STATE` appliqué et recapturé : « Masse visuelle », l’objet rapproché du titre ; lecteur d’écran et performance non vérifiés
PROCHAINE PREUVE: lecteur d’écran sur le premier geste
```

Pour un run conservé ou partagé, la trace complète et la fiche `RUN_CARD` suivent le schéma réel ([carte de run minimale](../gouvernance/travail.md#actionrun_card--carte-de-run-minimale)) ; d’autres exemples sont dans [les exemples de la skill](../references/examples.md). Une validation confirme la structure, jamais l’usage ni la qualité visuelle.

## 10. Observer, interpréter et améliorer

Regardez le rendu ou le comportement réel dans le périmètre déclaré. Toute méthode de preuve doit pouvoir répondre à quatre questions :

| Question | Réponse attendue |
|---|---|
| Qu’a-t-on réellement observé ? | Rendu, état, taille d’écran, tâche, participant, mesure, version et date. |
| Que peut-on en déduire ? | Une interprétation limitée au périmètre et à la méthode. |
| Que ne peut-on pas en déduire ? | La limite explicite : usage, accessibilité, robustesse, droits, préférence ou performance. |
| Quelle décision change maintenant ? | Une des suites du parcours commun, avec sa réserve éventuelle. |

Une capture prouve un rendu dans son périmètre ; à elle seule, elle ne prouve ni une tâche utilisateur, ni un lecteur d’écran, ni la sécurité, la performance ou une intégration réelle. Une mesure d’accessibilité limitée ne certifie pas toute l’expérience. Une revue experte du craft ne remplace pas un test d’usage.

Pour un rendu HTML, la recette de rendu (`scripts/check_render.py`, navigateur requis) relève les fautes objectivables aux largeurs courantes : débordement, contraste, clavier, cibles, textes qui se recouvrent ou sont tronqués. Un texte calculé, un état animé ou le résultat d’une action se prouve à l’état qui compte, après clic et attente : `--assert` recoupe une phrase dérivée avec ses valeurs, `--in-frame` vérifie que l’objet de l’état clé est dans son cadre ([rendre la direction vérifiable](../design/produit/preuve-visuelle.md#actionvisual_proof--rendre-la-direction-vérifiable)). La recette ne juge ni la direction, ni le goût, ni l’usage ; son périmètre et ses limites sont dans [recette de rendu check_render.py](../design/produit/plancher.md#actionrecette-rendu--recette-de-rendu-check_renderpy).

Pour une décision créative, appliquez la revue en six points ([qualité créative et niveau d’ambition](../design/savoir/qualite-creative.md#cft-00--qualité-créative-et-niveau-dambition)), puis notez avec la boucle d’édition ([créer puis apprendre](../design/direction/boucle.md#directiondouble-loop--créer-puis-apprendre)) le changement observé et les régressions.

La finition est l’aboutissement cohérent de la structure, du contenu, de la typographie, de la matière, de l’action et des états. Ce n’est pas une couche automatique de dégradés, d’ombres, de flou ou de grands arrondis.

## 11. Conserver et fermer honnêtement

Pour un run conservé, suivez [sortie minimale commune](../agent/repondre.md#actionhandoff--sortie-minimale-commune) et gardez un emplacement de trace (`TRACE-LOCATOR`) : la forme courte LITE sans RUN_CARD est admise selon [paquet de clôture](../gouvernance/cloture.md#actionclose-package--paquet-de-clôture) ; les autres traces structurées utilisent la fiche de travail et son validateur. Ces fichiers transportent les contrats ; ils ne remplacent ni les sections qui font foi, ni l’observation, ni le jugement humain.

Avant de fermer, vérifiez que :

1. le défaut dominant est corrigé, absent ou explicitement réservé ;
2. la preuve attendue est obtenue ou déclarée `NOT-VERIFIED` ; une conséquence attendue non observée est `NOT-OBSERVED` ; `N/A-JUSTIFIED`, avec sa raison, ne vaut que si la preuve ne s’applique pas ;
3. une correction technique ou de conformité n’a pas effacé la direction spécifique ;
4. la trace, les rendus, les limites et le responsable sont retrouvables ;
5. une nouvelle passe ne promet plus de changement visible ou utile, ou bien la prochaine action est nommée.

`STATE: CLOSED` veut dire que la trace et les rendus sont conservés. Cela ne veut pas dire que le run a réussi, que l’usage est validé ou que toutes les limites ont disparu. Un run peut être fermé sans être accepté ; les conditions dépendent de l’issue (voir [paquet de clôture](../gouvernance/cloture.md#actionclose-package--paquet-de-clôture) et [FAIL-ASSUMED et péremption](../gouvernance/verification.md#actionoverride--fail-assumed-et-péremption)) : simple archive pour `BLOCKED`, `RETURNED` ou `EXPLORATORY` (responsable, limite et prochaine preuve) ; réserve structurée pour une acceptation avec réserve ; exception pour `FAIL-ASSUMED` (voir [FAIL-ASSUMED et péremption](../gouvernance/verification.md#actionoverride--fail-assumed-et-péremption)). Archiver un blocage n’exige aucune approbation.

Si une étape, une variante, une référence ou une étiquette ne change aucune décision, observation, preuve, limite ou prochaine action, retirez-la ou justifiez `N/A-JUSTIFIED`. Une trace complète sans conséquence est du slop procédural.

## 12. Où se trouvent les règles

| Besoin | Où lire |
|---|---|
| Classer et choisir quoi lire | [`agent/chemins.md`](../agent/chemins.md) |
| Direction, cinq règles essentielles | [`design/direction/`](../design/direction/README.md) |
| Craft, contenu, contexte, sources | [`design/savoir/`](../design/savoir/README.md) |
| Structures, grilles, scènes, composants | [`design/formes/`](../design/formes/README.md) |
| Qualité du rendu, plancher, finition | [`design/produit/`](../design/produit/README.md) |
| Trace, statuts, vérification, clôture | [`gouvernance/`](../gouvernance/README.md) |
| Version et évolution du système | [`maintenance/`](../maintenance/README.md) |

Ne lisez une section détaillée que si elle peut changer une décision, un rendu, une preuve, une limite ou la prochaine action. Pour des exemples, le déroulé et le format des fiches, voir les références de la skill quand c’est utile : `references/examples.md`, `references/flow.md` et `references/machine_projection.md`.
