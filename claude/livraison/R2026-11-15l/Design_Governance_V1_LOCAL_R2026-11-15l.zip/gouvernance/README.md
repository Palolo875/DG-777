# Gouvernance — adaptée au travail, utile selon le besoin

Ce module aide à vérifier une affirmation, protéger un risque, permettre une reprise ou préparer une acceptation. Ses contrôles et sa trace s’adaptent au contexte ; ils ne sont pas un formulaire à remplir systématiquement. L’agent réutilise les éléments déjà présents et n’ajoute que ceux qui servent la décision.

| Situation | Gouvernance utile |
|---|---|
| Proposition exploratoire | Trace légère, limites visibles et vérifications applicables ; pas de RUN_CARD ni d’acceptation implicite. |
| Correction locale | Preuve ciblée sur le changement et ses effets ; la forme courte LITE suffit si ses conditions sont remplies. |
| Travail persistant, partagé, audité ou soumis à acceptation | Trace complète, preuves et clôture adaptées ; RUN_CARD selon `ACTION/HANDOFF` et `ACTION/CLOSE-PACKAGE`. |
| Risque critique ou affirmation non vérifiée | Protection et preuve adaptées au risque ; capacité absente déclarée, jamais remplacée par une formalité ou une validation documentaire. |

Le niveau de trace suit [la règle propriétaire](../agent/repondre.md). Alléger la formalité ne supprime aucune preuve applicable. Montrer une proposition ne vaut pas accepter un produit.

Chaque section porte un code stable en tête de son titre (`ACTION/…`, `DIRECTION/…`, `BIBLIOTHEQUE/…`) : [états, issues et verdicts](statuts.md#actionstatus--états-issues-et-verdicts) se lit aussi avec `python3 scripts/read_route.py ACTION/STATUS`.

| Fichier | Contenu |
|---|---|
| [`principes.md`](principes.md) | Relation ou contrat à ne pas confondre, portée d’action et reprise |
| [`statuts.md`](statuts.md) | États, issues et verdicts d’un travail |
| [`travail.md`](travail.md) | Conditions de départ et fiche de travail |
| [`pipeline.md`](pipeline.md) | Déroulé d’un run de direction, du cadrage au rendu vérifié |
| [`verification.md`](verification.md) | Contrats de décision, vérification en contexte, dérogation |
| [`cloture.md`](cloture.md) | Dossier de clôture, test de sortie, clôture de direction |
| [`structure.md`](structure.md) | Contrats de structure et contrôle d’un module structurel |
| [`integrite.md`](integrite.md) | Ce que le système peut affirmer : modes d’échec, contrôle d’intégrité, limites et délégation |
| [`schemas/`](schemas/run_card.schema.json) | Schémas de la fiche de travail et des contrats, exemples et fichiers de test |
| `outils/` | `validate_run_card.py` (fiches) et `validate_contracts.py` (contrats) : `python3 gouvernance/outils/validate_run_card.py chemin/vers/fiche.json` |

Suite : la [maintenance](../maintenance/README.md), pour faire évoluer le système. Retour au [README](../README.md).
