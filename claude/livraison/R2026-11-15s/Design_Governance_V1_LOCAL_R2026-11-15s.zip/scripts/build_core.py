#!/usr/bin/env python3
"""Compile le noyau de fabrication dans la skill.

Les blocs du noyau restent normatifs dans leur fichier propriétaire, encadrés par
`<!-- noyau:début ID -->` et `<!-- noyau:fin ID -->`. Ce script les assemble, dans l'ordre du registre
ci-dessous, entre `<!-- noyau:compilé début -->` et `<!-- noyau:compilé fin -->` dans SKILL.md.
Un bloc différé (`<!-- différé:début ID -->` … `<!-- différé:fin ID -->`) n'est pas compilé : il est servi en entier
par sa route, et le noyau ou `DIRECTION/CHARGE` y renvoie. La balise d'un bloc doit correspondre à son registre.
La copie est générée : elle ne se modifie jamais à la main (`validate_structure.py` compare).

Usage :
  python3 scripts/build_core.py           # écrit la section compilée de la skill
  python3 scripts/build_core.py --check   # code 1 si la skill diffère ou dépasse son budget

Le plafond s'applique au fichier SKILL.md complet, en octets UTF-8. Une compilation
qui le dépasserait est refusée avant écriture ; le même contrôle est utilisé par
la validation structurelle des distributions GitHub et Local.
"""
from __future__ import annotations

import argparse
import re
import sys
sys.dont_write_bytecode = True  # les imports entre outils n’écrivent rien dans le paquet
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILL_DIR = ROOT  # le paquet est la skill : SKILL.md à la racine, références dans references/
SKILL = SKILL_DIR / "SKILL.md"
BEGIN, END = "<!-- noyau:compilé début -->", "<!-- noyau:compilé fin -->"
BLOCK = re.compile(r"^<!-- (noyau|différé):(début|fin) ([A-Z0-9\-]+) -->$")
CONCEPT = re.compile(r"^\s*<!-- concept:[A-Z0-9\-]+ -->\s*$")
CORE_BUDGET_BYTES = 48_500  # provisoire (lot 11b) : redescend avec le sous-lot 11c

# Registre : (titre de section, [identifiants de bloc]), dans l'ordre de compilation. Un bloc se cherche dans les fichiers
# de règles, où qu'il soit : déplacer un bloc avec sa section ne change pas ce registre.
NOYAU: list[tuple[str, list[str]]] = [
    # Ordre par moment du run. Les blocs repliés restent entiers dans leur route.
    ("Rôle et posture", ["ROLE", "POSTURE", "ABSOLUS"]),
    ("Classer, puis charger", ["CHARGE-REGLE", "CHARGE-REGLE-SUITE",
                               "CHARGE-TROUVER", "CHARGE-RECHERCHE",
                               "CHARGE-TABLE", "CHARGE-FIN",
                               "CHARGE-LECTEUR", "REGISTRES"]),
    ("Avant de construire — contenu réel et premier objet", ["BRIEF", "CONTENU",
                                                    "CONTENU-SUITE",
                                                    "PREMIER-OBJET-CADRES", "PREMIER-OBJET",
                                                    "PREMIER-OBJET-SUITE", "DONNEES-EXEMPLE",
                                                    "MOY-PLAFOND",
                                                    "RECONCILIATION", "FND-CADRAGE"]),
    ("Avant de construire — diverger, puis déclarer la direction", ["DIR-LEVIERS", "DIR-DECLARATION"]),
    ("Avant de construire — le test de trame", ["STRUCT-OU",
                   "STRUCT-EXPRESSION", "STRUCT-LEVIERS",
                   "STRUCT-TENSION", "STRUCT-TRAME",
                   "STRUCT-ACTIVATION",
                   "STRUCT-SIGNAUX"]),
    ("En construisant — composition, typographie et couleur", ["COMP-GRAMMAIRE", "COMP-SINGULARITE",
                     "COMP-FORME", "COMP-CONTROLES", "STATE-PLANCHER",
                     "COMP-TYPO", "COMP-TITRE", "COMP-TEXTE-IMAGE",
                     "COMP-VOCABULAIRE",
                     "COMP-COULEUR", "COMP-CONVERGENCE", "COMP-VAGUES"]),
    ("En construisant — moyens et vérité", ["ANCRE", "MOY-CARTE",
                          "MOY-ASSETS", "MOY-CALIBRATION",
                          "VER-FAUX-ASSET", "VER-SCENE",
                          "VER-AUDIENCE"]),
    ("En regardant — boucle d’édition", ["BOUCLE", "BOUCLE-CAPTURE", "BOUCLE-RECETTE",
                          "BOUCLE-DIAGNOSTIC",
                          "BOUCLE-ATELIER", "BOUCLE-REVUE",
                          "BOUCLE-QUESTIONS", "BOUCLE-REPASSE",
                          "BOUCLE-AXE"]),
    ("En répondant — proposition, sortie et trace", ["CHECKPOINT", "CHECKPOINT-SUITE",
                                      "SORTIE", "SORTIE-SILENCE",
                                      "TRACE", "TRACE-CONTRATS",
                                      "INTEG-RECITATION", "INTEG-LIMITES"]),
    ("Lire les détails selon le signal", ["CHARGE-DETAILS"]),
]

# Noyau court : seuls ces blocs sont chargés à chaque run ; les autres restent entiers dans leur route.
COMMUN = frozenset({
    "ROLE", "POSTURE", "ABSOLUS", "CHARGE-REGLE", "CHARGE-TROUVER", "CHARGE-FIN", "REGISTRES", "CHARGE-DETAILS",
    "BRIEF", "CONTENU", "PREMIER-OBJET", "DONNEES-EXEMPLE", "MOY-PLAFOND", "FND-CADRAGE",
    "DIR-LEVIERS", "DIR-DECLARATION", "STRUCT-TRAME",
    "COMP-SINGULARITE", "COMP-CONTROLES", "STATE-PLANCHER", "COMP-TYPO", "COMP-TITRE", "COMP-COULEUR", "COMP-CONVERGENCE",
    "ANCRE", "VER-FAUX-ASSET", "VER-SCENE", "VER-AUDIENCE",
    "BOUCLE", "BOUCLE-CAPTURE", "BOUCLE-ATELIER",
    "CHECKPOINT", "SORTIE", "TRACE", "INTEG-RECITATION", "INTEG-LIMITES",
})
DETAILS = {
    "STRUCT-LEVIERS": "BIBLIOTHEQUE/READ",
    "CHARGE-TABLE": "DIRECTION/CHARGE",
    "CHARGE-RECHERCHE": "DIRECTION/CHARGE",
    "CHARGE-LECTEUR": "DIRECTION/CHARGE",
    "CHARGE-REGLE-SUITE": "DIRECTION/CHARGE",
    "MOY-ASSETS": "SAVOIR/SOURCE",
    "MOY-CALIBRATION": "SAVOIR/SOURCE",
    "STRUCT-ACTIVATION": "BIBLIOTHEQUE/SELECT",
    "STRUCT-SIGNAUX": "BIBLIOTHEQUE/SELECT",
    "COMP-VOCABULAIRE": "SAVOIR/STATE",
    "BOUCLE-QUESTIONS": "DIRECTION/DOUBLE-LOOP",
    "BOUCLE-REPASSE": "SAVOIR/INTEGRITY/REPASSE",
    # Repliés : servis par leur route, signalés dans la table des signaux
    "CONTENU-SUITE": "DIRECTION/EXTERNAL-START",
    "PREMIER-OBJET-CADRES": "DIRECTION/FIRST-OBJECT",
    "PREMIER-OBJET-SUITE": "DIRECTION/FIRST-OBJECT",
    "RECONCILIATION": "DIRECTION/DIRECTION-ATELIER",
    "STRUCT-OU": "BIBLIOTHEQUE/READ",
    "STRUCT-EXPRESSION": "BIBLIOTHEQUE/READ",
    "STRUCT-TENSION": "BIBLIOTHEQUE/TENSION",
    "COMP-GRAMMAIRE": "SAVOIR/FRAME",
    "COMP-FORME": "SAVOIR/CRAFT",
    "COMP-TEXTE-IMAGE": "SAVOIR/CRAFT",
    "COMP-VAGUES": "SAVOIR/TOOLS",
    "MOY-CARTE": "SAVOIR/TOOLS",
    "BOUCLE-RECETTE": "DIRECTION/DOUBLE-LOOP",
    "BOUCLE-DIAGNOSTIC": "DIRECTION/DOUBLE-LOOP",
    "BOUCLE-REVUE": "SAVOIR/CRAFT",
    "BOUCLE-AXE": "SAVOIR/CRAFT",
    "CHECKPOINT-SUITE": "ACTION/PIPELINE-DIRECTION",
    "SORTIE-SILENCE": "ACTION/HANDOFF",
    "TRACE-CONTRATS": "ACTION/HANDOFF",
}


class CoreError(Exception):
    pass


def check_budget(raw: bytes) -> int:
    """Contrôle le fichier complet, y compris métadonnées et contenu hors noyau."""
    size = len(raw)
    if size > CORE_BUDGET_BYTES:
        raise CoreError(f"CORE BUDGET FAILED — SKILL.md complet {size} octets UTF-8 > "
                        f"budget {CORE_BUDGET_BYTES} : retirer une redondance ou déplacer "
                        "un détail vers une route en conservant son activation")
    return size


def blocks_of(path: Path, kinds: dict[str, str] | None = None) -> dict[str, list[str]]:
    """Blocs du fichier ; `kinds` reçoit la balise de chacun (`noyau` ou `différé`)."""
    lines = path.read_text(encoding="utf-8").splitlines()
    found: dict[str, list[str]] = {}
    current, kind, buf = None, None, []
    for line in lines:
        m = BLOCK.match(line.strip())
        if m and m.group(2) == "début":
            if current:
                raise CoreError(f"{path.name} : bloc {m.group(3)} ouvert dans {current}")
            current, kind, buf = m.group(3), m.group(1), []
        elif m and m.group(2) == "fin":
            if m.group(3) != current or m.group(1) != kind:
                raise CoreError(f"{path.name} : fin {m.group(1)} {m.group(3)} sans début correspondant")
            if current in found:
                raise CoreError(f"{path.name} : bloc {current} défini deux fois")
            found[current] = buf
            if kinds is not None:
                kinds[current] = kind
            current = None
        elif current:
            if not CONCEPT.match(line):
                buf.append(line)
    if current:
        raise CoreError(f"{path.name} : bloc {current} non fermé")
    return found


def blocs_regles(kinds: dict[str, str] | None = None) -> dict[str, list[str]]:
    """Blocs de tous les fichiers de règles ; un bloc défini dans deux fichiers est une erreur."""
    import read_route
    found: dict[str, list[str]] = {}
    where: dict[str, str] = {}
    for path in read_route.regles():
        for bid, body in blocks_of(path, kinds).items():
            if bid in found:
                raise CoreError(f"bloc {bid} défini dans deux fichiers : {where[bid]} et {read_route.nom(path)}")
            found[bid], where[bid] = body, read_route.nom(path)
    return found


def compile_core() -> str:
    import read_route

    kinds: dict[str, str] = {}
    blocks = blocs_regles(kinds)
    parts = ["_Section générée par `scripts/build_core.py` depuis les blocs « noyau » des sources ; ne pas modifier à la main._", ""]
    registered = [bid for _, items in NOYAU for bid in items]
    if len(registered) != len(set(registered)) or set(registered) != COMMUN | DETAILS.keys() or COMMUN & DETAILS.keys():
        raise CoreError("registre du noyau : chaque bloc doit être commun ou servi par une route unique")
    n = 0
    for title, items in NOYAU:
        loaded = []
        for bid in items:
            if bid not in blocks:
                raise CoreError(f"bloc {bid} absent des fichiers de règles")
            body = blocks[bid]
            if bid in COMMUN:
                loaded.extend(body)
                loaded.append("")
            else:
                locator = DETAILS[bid]
                try:
                    _, lines, index = read_route.resolve(locator)
                    served = "\n".join(read_route.extract(lines, index))
                except (read_route.RouteError, OSError) as exc:
                    raise CoreError(f"activation de {bid} : {locator} indisponible ({exc})") from exc
                if "\n".join(body).strip() not in served:
                    raise CoreError(f"activation de {bid} : {locator} ne sert pas le bloc complet")
        if not loaded:
            continue
        n += 1
        parts.append(f"### {n}. {title}")
        parts.append("")
        parts.extend(loaded)
    if set(blocks) != set(registered):
        raise CoreError("registre du noyau : bloc source non classé : " + ", ".join(sorted(set(blocks) - set(registered))))
    wrong = sorted(bid for bid, kind in kinds.items() if (kind == "noyau") != (bid in COMMUN))
    if wrong:
        raise CoreError("balise contraire au registre (noyau : compilé ; différé : servi par sa route) : " + ", ".join(wrong))
    core = "\n".join(parts).rstrip() + "\n"
    _, lines, index = read_route.resolve("DIRECTION/CHARGE")
    activation = core + "\n" + "\n".join(read_route.extract(lines, index))
    for bid, locator in DETAILS.items():
        if bid == "CHARGE-TABLE" and "python3 scripts/read_route.py --mode MODE" in core:
            continue  # --mode résout la table propriétaire, sans en recopier le locator.
        if f"`{locator}`" not in activation:
            raise CoreError(f"activation de {bid} : renvoi {locator} absent du noyau et de CHARGE")
    return core


def render(skill_text: str, core: str) -> str:
    i, j = skill_text.find(BEGIN), skill_text.find(END)
    if i < 0 or j < i:
        raise CoreError("marqueurs de section compilée absents de la skill")
    return skill_text[: i + len(BEGIN)] + "\n" + core + skill_text[j:]


def main() -> int:
    parser = argparse.ArgumentParser(description="Compiler le noyau et contrôler le budget du fichier SKILL.md complet.")
    parser.add_argument("--check", action="store_true", help="vérifier sans écrire : compilation et budget")
    args = parser.parse_args()
    import read_route  # encodage nommé avant toute lecture

    bad = read_route.non_utf8(read_route.ROOT)
    if bad:
        print(f"NOYAU : erreur — Markdown non UTF-8 : {', '.join(bad)}")
        return 1
    try:
        raw = SKILL.read_bytes()
        text = raw.decode("utf-8")
        new = render(text, compile_core())
        size = check_budget(raw if args.check else new.encode("utf-8"))
    except (CoreError, OSError, UnicodeError) as exc:
        print(f"NOYAU : erreur — {exc}")
        return 1
    if args.check:
        if new != text:
            print("NOYAU : la skill diffère de sa compilation (lancer scripts/build_core.py)")
            return 1
        print("NOYAU : skill conforme à sa compilation")
        print(f"CORE BUDGET PASSED — SKILL.md complet {size} / {CORE_BUDGET_BYTES} octets UTF-8")
        return 0
    SKILL.write_bytes(new.encode("utf-8"))
    print("NOYAU : section compilée écrite dans la skill")
    print(f"CORE BUDGET PASSED — SKILL.md complet {size} / {CORE_BUDGET_BYTES} octets UTF-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
