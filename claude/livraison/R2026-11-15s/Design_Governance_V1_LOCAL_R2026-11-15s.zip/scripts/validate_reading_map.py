#!/usr/bin/env python3
"""Valide les cartes de lecture et les façades, sans créer d’autorité.

Trois contrôles :
1. cartes : un titre par code dans les fichiers de règles, résolution de tout code cité (le résolveur de
   read_route.py, sans table), témoin synthétique du lecteur, carte des sujets (guides, niveau 2) et connexions
   situées (`design/savoir/connexions.md`) ;
2. façades : liste close des conditions de façade (LCF). Chaque entrée nomme une
   façade, la condition du propriétaire qu’elle doit conserver et sa source. Une
   entrée n’entre que par une décision écrite, avec sa mutation rouge ; `FacadeSensitivityTests`
   (test_audit_regressions.py) vérifie que chaque condition tombe quand son texte est retiré
   ou, pour une interdiction, quand le défaut interdit est ajouté.
3. vague : chaque marqueur de la liste datée est protégé (VAG-01, liste close) ; toute affirmation située dans le
   temps (« cette année », « en ce moment »…) vit sur une ligne `[VEILLE AAAA-MM]` (VAG-02, garde générale).
Les guides citent les sections par des liens : les contrôles les lisent comme les codes qu’ils désignent.
Limite déclarée : une contradiction nouvelle hors de la LCF n’est pas détectée ;
la revue bornée des façades avant release la complète.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True  # l’import du résolveur ne doit rien écrire dans le package
sys.path.insert(0, str(Path(__file__).resolve().parent))
import read_route as rr  # noqa: E402

ROOT = rr.ROOT
SKILL_DIR = ROOT  # le paquet est la skill : SKILL.md à la racine, références dans references/
# Documents de la carte de lecture : sujets, combinaisons, angles et arrêt (guides) ; connexions ; résolution des routes.
CARTES = (rr.CARTE_SUJETS, rr.CONNEXIONS, ROOT / "maintenance" / "README.md")
REQUIRED = (
    "## Carte des sujets",
    "## Combinaisons par résultat recherché",
    "## Les angles à examiner",
    "## Quand s’arrêter de lire",
    "## Connexions situées",
    "## Résolution des routes",
    "c’est la section indiquée qui fait foi",
    "ne classe pas le mode",
    "NOT-VERIFIED",
)
CITED = re.compile(rf"`((?:{'|'.join(rr.PREFIXES)})/[A-Z0-9_\-]+(?:/[A-Z0-9_\-]+)?)`")


def fail(message: str) -> None:
    raise SystemExit(f"READING MAP VALIDATION FAILED — {message}")


# ---------- 1. Cartes ----------
def check_map(errors: list[str]) -> None:
    """Un titre par code dans les fichiers de règles ; tout code cité se résout."""
    carriers: dict[str, list[str]] = {}
    for path, lines, heads in rr.index_regles():
        for index, _, heading in heads:
            own = rr.heading_locator(heading)
            if own:
                carriers.setdefault(own, []).append(f"{rr.nom(path)}:{index + 1}")
    for locator, places in sorted(carriers.items()):
        if len(places) > 1:
            errors.append(f"locator ambigu : {locator} porté par {', '.join(places)}")
    cited: set[str] = set()
    for source in rr.fichiers_officiels() + [SKILL_DIR / "SKILL.md", ROOT / "README.md"]:
        if source.is_file():
            cited.update(CITED.findall(source.read_text(encoding="utf-8")))
    for locator in sorted(cited):
        try:
            rr.resolve(locator)
        except rr.RouteError as exc:
            errors.append(f"locator cité non résolu : {locator} ({exc})")


def check_connections(errors: list[str]) -> None:
    """Provenance et forme de l’index ; pertinence et qualité restent hors contrôle."""
    try:
        rr.connections()
    except (rr.RouteError, OSError) as exc:
        errors.append(f"connexions situées : {exc}")


def check_reader_witness(errors: list[str]) -> None:
    """Le lecteur refuse un code porté par deux titres et un code sans titre (témoins synthétiques)."""
    lines = ["# Témoin", "", "## SAVOIR/TEMOIN — premier", "", "texte", ""]
    heads = rr.headings(lines)
    double = [(Path("a.md"), lines, heads), (Path("b.md"), lines, heads)]
    try:
        rr.resolve("SAVOIR/TEMOIN", double)
        errors.append("témoin du lecteur : un code porté par deux titres est accepté")
    except rr.RouteError as exc:
        if "ambigu" not in str(exc):
            errors.append(f"témoin du lecteur : code dupliqué non diagnostiqué ({exc})")
    try:
        rr.resolve("SAVOIR/ABSENT", double[:1])
        errors.append("témoin du lecteur : un code sans titre est accepté")
    except rr.RouteError:
        pass


def check_topics(errors: list[str], text: str | None = None) -> None:
    """Carte des sujets : chaque lien mène à une route qui traite le sujet (ou un alias) en mots entiers."""
    try:
        table = rr.topics(text)
    except rr.RouteError as exc:
        errors.append(f"[SUJ-01] carte des sujets : {exc}")
        return
    if not table:
        errors.append("[SUJ-01] carte des sujets absente ou vide")
        return
    for topic, owner, also in table.values():
        patterns = [rr._word(term) for term in rr.aliases(topic)]
        for locator in [owner, *also]:
            try:
                _, lines, index = rr.resolve(locator)
            except rr.RouteError as exc:
                errors.append(f"[SUJ-01] carte des sujets : {topic} → {locator} ne se résout pas ({exc})")
                continue
            if not any(p.search(rr._fold(line)) for line in rr.extract(lines, index) for p in patterns):
                errors.append(f"[SUJ-01] carte des sujets : {locator} ne traite pas « {topic} »")


# ---------- 2. Façades : liste close des conditions (LCF) ----------
HANDOFF_TOKENS = re.compile(r"\b(MODE|DECISION-CHANGE|DECISION|RISK|SCOPE|ARTIFACT|OBSERVATION|METHOD|TRACE-LOCATOR|NOT-VERIFIED|"
                            r"NEXT-ACTION|OWNER|NEXT-PROOF|EXIT-CONDITION)\b")
VISIBLE = "MODE — DECISION — CHANGE — PROOF — LIMIT — NEXT-ACTION — OWNER"
OUTCOME = r"(CHANGED|CONFIRMED|ABANDONED|N/A-JUSTIFIED|NOT-OBSERVED)"
USER_EFFECT = re.compile(r"(?i)mémorable|mémoris|tâche|usage|utilisabilit")
PROTOCOL = re.compile(r"(?i)protocole|participant")
UNBOUNDED = re.compile(r"(?<!vise à )(?<!visent à )augmente la (probabilité|qualité)")
STATUS_TOKEN = re.compile(r"`(SEED|PILOT|ADOPTED|DEPRECATED|ABANDONED)`")


def cells(line: str) -> list[str]:
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


VISIBLE_RUBRIQUES = ("Ce que j’ai fait :", "Pourquoi :", "Ce qui manque pour la vraie version :", "La suite :")


def charge_row(t: dict[str, str], mode: str) -> list[str] | None:
    sec = t["D"][t["D"].find("## DIRECTION/CHARGE"):]
    sec = sec[:sec.find("\n## ", 5)]
    return row(sec, f"**{mode}**")


def row(text: str, key: str, col: int = 0) -> list[str] | None:
    for line in text.splitlines():
        if line.startswith("|") and not line.startswith("|---"):
            found = cells(line)
            if len(found) > col and key in found[col]:
                return found
    return None


def before(text: str, first: str, second: str) -> bool:
    return first in text and second in text and text.index(first) < text.index(second)


def after(text: str, marker: str, length: int) -> str:
    index = text.find(marker)
    return text[index:index + length] if index >= 0 else ""


def fenced_after(text: str, marker: str) -> str:
    index = text.find(marker)
    if index < 0:
        return ""
    match = re.search(r"```(?:text)?\n(.*?)```", text[index:], re.S)
    return match.group(1) if match else ""


def rows_between(text: str, start: str, stop: str) -> list[list[str]]:
    index = text.find(start)
    if index < 0:
        return []
    segment = text[index:]
    end = segment.find(stop, len(start))
    segment = segment[: end if end > 0 else len(segment)]
    found = [cells(line) for line in segment.splitlines() if line.startswith("| ") and not line.startswith("|---")]
    return found[1:]


def plain(cell: str) -> str:
    return re.sub(r"[*`]", "", cell).strip()


def load_texts() -> dict[str, str]:
    """Familles construites à partir de leurs routes ; guides et autres façades lus par leur fichier, liens lus comme
    les codes qu’ils désignent."""
    def lire(path: Path) -> str:
        return rr.liens_en_codes(path.read_text(encoding="utf-8"), path) if path.is_file() else ""
    out = {key: rr.famille(prefix) for key, prefix in
           {"D": "DIRECTION", "A": "ACTION", "S": "SAVOIR", "B": "BIBLIOTHEQUE", "C": "CHANGELOG"}.items()}
    comprendre = lire(ROOT / "guides" / "2-comprendre.md")
    travail = comprendre[comprendre.find("## Comment le système travaille"):]
    out["G"] = lire(ROOT / "guides" / "glossaire.md") + "\n" + travail[:travail.find("\n## ", 5)]
    out["Q"] = lire(ROOT / "guides" / "3-maitriser.md")
    out["RM"] = "\n".join(lire(p) for p in CARTES)
    files = {
        "README": ROOT / "README.md", "NOTES": ROOT / "RELEASE_NOTES.md",
        "SK": SKILL_DIR / "SKILL.md", "EX": SKILL_DIR / "references" / "examples.md",
        "MP": SKILL_DIR / "references" / "machine_projection.md",
    }
    out.update({key: lire(path) for key, path in files.items()})
    return out


def lcf_07(t: dict[str, str]) -> bool:
    prio = fenced_after(t["D"], "```text\nRUN-PRIORITY")
    pointers = [row(t["RM"], "Direction forte et spécifique")]
    rows = [charge_row(t, "DIRECTION")]
    # L'ordre cible → premier objet de la ligne DIRECTION de CHARGE est aussi tenu par CHG-07 (validate_structure.py).
    return (before(prio, "DIRECTION —", "FIRST-OBJECT —")
            and all(r and before(" ".join(r), "VISUAL_TARGET", "FIRST-OBJECT") for r in rows)
            and all(p and "`DIRECTION/CHARGE`" in " ".join(p) for p in pointers))


def lcf_03(t: dict[str, str]) -> bool:
    ui, proof, system = row(t["RM"], "UI/UX habitable"), row(t["RM"], "Preuve et décision fiables"), row(t["RM"], "Système maintenable")
    keys = ("migration", "retour arrière", "maintenance/versions.md")
    return (bool(ui) and "ACTION/GATE-A" in ui[1] and "ACTION/GATE-A" not in ui[2]
            and bool(proof) and re.search(r"(?i)gate|contrôle", proof[1]) is not None and re.search(r"(?i)gate|contrôle", proof[2]) is None
            and bool(system) and all(k in system[1] for k in keys) and not any(k in system[2] for k in keys))


def lcf_11(t: dict[str, str]) -> bool:
    lines = [l for b in re.findall(r"```text\n(.*?)```", t["EX"], re.S) for l in b.splitlines() if l.startswith("DECISION-CHANGE:")]
    glossary = next((l for l in t["G"].splitlines() if l.startswith("| **DECISION-CHANGE** |")), "")
    return (bool(lines) and all(re.match(rf"DECISION-CHANGE: {OUTCOME} — .+\(observation : .+\)", l) for l in lines)
            and re.search(OUTCOME, glossary) is not None and "observation" in glossary)


def lcf_12(t: dict[str, str]) -> bool:
    blocks = [b for b in re.findall(r"```text\n(.*?)```", t["EX"], re.S) if "ACCEPTED-WITH-RESERVATION" in b]
    glossary = [l for l in t["G"].splitlines() if l.startswith("|") and "ACCEPTED-WITH-RESERVATION" in l and "Exemple" not in l and "**Verdict" not in l]
    complete = lambda s: all(re.search(p, s, re.I) for p in (r"owner|responsable", r"prochaine preuve", r"revue", r"(condition de )?sortie"))
    return all(re.search(r"(?m)^RESERVATION: ", b) and complete(b) for b in blocks) and all(complete(l) for l in glossary)


def lcf_13(t: dict[str, str]) -> bool:
    blocks = re.findall(r"```text\n(.*?)```", t["EX"], re.S)
    return (all(not re.search(r"(?m)^NOT-OBSERVED:", b) for b in blocks)
            and all("STATE: CLOSED" not in b or re.search(r"(?m)^VERDICT: ", b) for b in blocks))


def lcf_14(t: dict[str, str]) -> bool:
    evidence = [l for b in re.findall(r"```text\n(.*?)```", t["EX"], re.S) for l in b.splitlines() if l.startswith("EVIDENCE:") and "capture" in l]
    return bool(evidence) and all(not USER_EFFECT.search(l) or PROTOCOL.search(l) for l in evidence)


def lcf_15_16_17(t: dict[str, str]) -> tuple[bool, bool, bool]:
    first = rows_between(t["D"], "### Contrat positif du premier objet", "\n#")
    dims = [plain(r[0]) for r in first]
    quick = [plain(r[0]) for r in rows_between(t["Q"], "## 6. Produire une qualité positive", "\n#")]
    cft = {plain(r[0]) for r in rows_between(t["S"], "## CFT-00", "### Creative Quality Review")}
    header = next((l for l in t["D"][t["D"].find("### Contrat positif du premier objet"):].splitlines() if l.startswith("| Dimension")), "")
    col = next((k for k, c in enumerate(cells(header)) if "CFT-00" in c), None)
    mapped = [v.strip() for r in first if col is not None and len(r) > col for v in re.split(r"[,+/]| et ", plain(r[col])) if v.strip()]
    triggers = {plain(r[0]): r[1] for r in signal_rows(t) if len(r) > 1}  # table des signaux du noyau, seule table de routage par signal
    pick = lambda start: next((v for k, v in triggers.items() if k.startswith(start)), "")
    motif, scene, density = pick("Motif générique"), pick("Asset, motion, scène"), pick("Détail final")
    return (bool(dims) and quick == dims,
            col is not None and bool(mapped) and all(v in cft or v in {"—", "DIRECTION"} for v in mapped),
            "SAVOIR/CRAFT/CFT-01" in motif and "ACTION/ANTI-SLOP" in motif and "BIBLIOTHEQUE/" in scene and "SAVOIR/CRAFT" in density)


def signal_rows(t: dict[str, str]) -> list[list[str]]:
    """Lignes de la table des signaux compilée dans le noyau (bloc CHARGE-DETAILS de DIRECTION/CHARGE)."""
    return rows_between(t["D"], "| Signal | Route |", "Aucun détail n’est considéré lu")


def lcf_06(t: dict[str, str]) -> bool:
    """Une table de signaux ajoute une lecture ; elle ne classe pas : la structure ouverte ne mène à aucune route RUN-*."""
    rows = [r for r in signal_rows(t) if plain(r[0]).startswith("Structure ouverte")]
    return len(rows) == 1 and len(rows[0]) > 1 and "ACTION/RUN-" not in rows[0][1]


def lcf_20(t: dict[str, str]) -> bool:
    section = t["C"][t["C"].find("## Cycle de vie des routes"):t["C"].find("## Retirer une section du socle")]
    table = {m.group(1) for m in (re.match(r"\| `([A-Z]+)` \|", l) for l in section.splitlines()) if m}
    listed = [l for l in t["B"].splitlines() if "`PILOT`" in l and "`DEPRECATED`" in l]
    return bool(table) and len(listed) >= 2 and all(set(STATUS_TOKEN.findall(l)) == table for l in listed)


def lcf_21(t: dict[str, str]) -> bool:
    present = [t[k] for k in ("README", "NOTES", "C") if t[k]]  # un fichier absent n'est pas contrôlé ici ; l'inventaire le refuse
    return all("NOT-VERIFIED" in text for text in present) and not UNBOUNDED.search(t["D"])


# ---------- LCF-22 à LCF-35 ----------
SCHEMA = ROOT / "gouvernance" / "schemas" / "run_card.schema.json"
NUM_WORDS = {3: "trois", 4: "quatre", 5: "cinq", 6: "six", 7: "sept"}
CHANGE_ENUM = re.compile(r"DECISION-CHANGE[^.\n]{0,120}N/A-JUSTIFIED|N/A-JUSTIFIED[^.\n]{0,120}DECISION-CHANGE")
BOOT_COUNT = re.compile(r"(?i)\b(une|deux|trois|\d+)\s+(anti-directions?|tensions?)\b")


def lcf_22(t: dict[str, str]) -> bool:
    lines = [l for k in ("A", "D", "G", "Q", "S", "SK", "EX", "MP") for l in t[k].splitlines()
             if not l.startswith("DECISION-CHANGE:") and (CHANGE_ENUM.search(l) or ("`CHANGE` vaut" in l and "N/A-JUSTIFIED" in l))]
    return bool(lines) and all("NOT-OBSERVED" in l for l in lines) and not any("obtenue ou attendue" in t[k] for k in ("A", "G"))


def lcf_23(t: dict[str, str]) -> bool:
    b1b = t["A"][t["A"].find("### B1b"):]
    scope = next((p for p in b1b.split("\n\n")[1:3] if "requis par module" in p), "")
    return all(k in scope for k in ("`DIRECTION`", "`ACCEPTED-WITH-RESERVATION`", "`PASS-WITH-RESERVATION`"))


def lcf_24(t: dict[str, str]) -> bool:
    boots = [[l for l in t[k].splitlines() if "Creative Boot" in l or "CREATIVE-BOOT" in l] for k in ("Q", "SK")]
    return all(boots) and not any(BOOT_COUNT.search(l) for group in boots for l in group)


def lcf_26(t: dict[str, str]) -> bool:
    try:
        props = json.loads(SCHEMA.read_text(encoding="utf-8"))["properties"]["run_card"]["properties"]
        axes = set(props["closure"]["properties"]["axes"]["properties"]["V"]["enum"])
        fields = props["profile_decision"]["required"]
    except (OSError, KeyError, ValueError):
        return False
    axis_line = next((l for l in t["MP"].splitlines() if "`closure.axes`" in l), "")
    listed = set(re.findall(r"`([A-Z/-]+)`", axis_line.split("`closure.axes`", 1)[-1].split(";")[0])) if axis_line else set()
    pd_line = next((l for l in t["MP"].splitlines() if "`profile_decision`" in l and "champs" in l), "")
    count = re.search(r"(\w+) champs sont obligatoires", pd_line)
    return (listed == axes and bool(count) and count.group(1) == NUM_WORDS.get(len(fields))
            and all(f"`{f}`" in pd_line for f in fields))


def lcf_27(t: dict[str, str]) -> bool:
    texts = [t[k] for k in ("C", "NOTES", "README") if t[k]]
    return all("alignés sur leurs propriétaires" not in x for x in texts) and "liste close des conditions de façade" in t["C"]


def lcf_28(t: dict[str, str]) -> bool:
    vt = t["D"][t["D"].find("## DIRECTION/VISUAL_TARGET"):t["D"].find("### Compilation de la première proposition")]
    fields = {plain(r[0]).lower() for r in rows_between(vt, "| Champ |", "\n\n")}
    claims = [c.strip().lower() for l in t["A"].splitlines() if l.startswith("| VISUAL_TARGET :")
              for c in re.split(r",| et ", cells(l)[0].split(":", 1)[1])]
    return bool(fields) and bool(claims) and all(c in fields for c in claims)


def lcf_29(t: dict[str, str]) -> bool:
    legend = t["D"][t["D"].find("### Légende"):]
    legend = legend[:legend.find("\n#", 5)]
    sentence = next((l for l in legend.splitlines() if "SAVOIR" in l and not l.startswith("|")), "")
    tags = re.findall(r"`(\[[^\]`]+\])`", sentence)
    return bool(tags) and all(tag[:-1] in t["S"] or f"`{tag}` n’y est pas employé" in sentence for tag in tags)


def retour_si(text: str, start: str) -> dict[str, str]:
    i = text.find(start)
    if i < 0:
        return {}
    seg = text[i:]
    j = seg.find("\n#", len(start))
    seg = seg[: j if j > 0 else len(seg)]
    header = next((cells(l) for l in seg.splitlines() if l.startswith("| Dimension")), [])
    k = next((n for n, c in enumerate(header) if c.startswith("Retour si")), None)
    if k is None:
        return {}
    return {plain(r[0]): plain(r[k]) for r in rows_between(seg, "| Dimension", "\n\n") if len(r) > k}


def lcf_31(t: dict[str, str]) -> bool:
    head = t["EX"][:t["EX"].find("\n## ")]
    return all(k in head for k in ("schemas/run_card.example.json", "machine_projection.md", "validate_run_card.py"))


def lcf_32(t: dict[str, str]) -> bool:
    l = next((x for x in t["A"].splitlines() if "Un droit inconnu" in x), "")
    return "interdit `ACCEPTED`" in l and "`ACCEPTED-WITH-RESERVATION`" in l and "avant diffusion" in l


def lcf_33(t: dict[str, str]) -> bool:
    sav = next((l for l in t["S"].splitlines() if l.startswith("Toute ressource de stack")), "")
    pol = t["A"][t["A"].find("Toute ressource technique maintenue indique"):].splitlines()[1:]
    items: list[str] = []
    for l in pol:
        if l.startswith("- "):
            items.append(l)
        elif items:
            break
    return (bool(sav) and "ACTION/POLICIES" in sav and "date de vérification" not in sav
            and len(items) == 7 and "sept champs" in t["A"])


def lcf_34(t: dict[str, str]) -> bool:
    outs = [l for l in t["A"].splitlines() if l.startswith("**Sortie.**")]
    return len(outs) == 5 and all(re.match(r"\*\*Sortie\.\*\* Paquet `[A-ZÈ]+` d’`ACTION/CLOSE-PACKAGE`\.", l) for l in outs)


def lcf_35(t: dict[str, str]) -> bool:
    closed = next((l for l in t["G"].splitlines() if l.startswith("| **CLOSED** |")), "")
    return bool(closed) and "n’est pas éligible" not in closed and "NOT-VERIFIED" in closed and "exclut `ACCEPTED`" in closed


# ---------- LCF-36 à LCF-42 ----------
NO_DECISION = re.compile(r"(?i)aucune décision (ne change|n’est changée|modifiée)")


def lcf_36(t: dict[str, str]) -> bool:
    l = next((x for x in t["A"].splitlines() if "Un droit inconnu" in x), "")
    return "que pour une `RUN_CARD` `DIRECTION`" in l and "contrôle seulement l’exclusion" not in l


def lcf_37(t: dict[str, str]) -> bool:
    seg = t["A"][t["A"].find("## ACTION/CLOSE-PACKAGE"):]
    rows = [l for l in seg[:seg.find("\n\n", seg.find("| Mode | Paquet minimal"))].splitlines() if l.startswith("| **")]
    return len(rows) == 5 and all("NOT-OBSERVED" in l for l in rows)


def lcf_38(t: dict[str, str]) -> bool:
    lines = [l for k in ("A", "D", "S", "B", "Q", "G", "SK", "EX") for l in t[k].splitlines()
             if NO_DECISION.search(l) and "N/A-JUSTIFIED" in l]
    sav = next((l for l in t["S"].splitlines() if l.startswith("La sortie de SAVOIR")), "")
    return (all("NOT-OBSERVED" in l or "non applicable" in l or "selon le contrat ACTION" in l for l in lines)
            and "À la clôture" in sav)


def lcf_39(t: dict[str, str]) -> bool:
    sec = t["Q"][t["Q"].find("## 5. Charger"):t["Q"].find("## 6.")]
    return ("`DIRECTION/CHARGE`" in sec and not row(sec, "`LITE`")
            and all((r := charge_row(t, m)) and "ACTION/GATE-A" in r[1] and "ACTION/GATE-B" in r[1] for m in ("LITE", "ITER")))


def lcf_40(t: dict[str, str]) -> bool:
    closed = next((l for l in t["G"].splitlines() if l.startswith("| **CLOSED** |")), "")
    exit_rows = [l for l in t["A"].splitlines() if l.startswith("| Réserves |") or l.startswith("7. La réserve")]
    return "date ou version" in closed and len(exit_rows) == 2 and all("date ou version" in l for l in exit_rows)


def lcf_41(t: dict[str, str]) -> bool:
    try:
        schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    found: list[str] = []

    def walk(node: object, path: list[str]) -> None:
        if isinstance(node, dict):
            enum, typ = node.get("enum"), node.get("type")
            if (isinstance(enum, list) and None in enum) or typ == "null" or (isinstance(typ, list) and "null" in typ):
                found.append(".".join(p for p in path if p not in ("properties", "run_card")))
            for key, value in node.items():
                walk(value, path + [key])
        elif isinstance(node, list):
            for value in node:
                walk(value, path)

    walk(schema.get("properties", {}), [])
    line = next((l for l in t["A"].splitlines() if "`null` signifie" in l), "")
    return (bool(found) and all(f"`{f}`" in line for f in found) and "champ facultatif sans valeur est omis" in line
            and "schéma l’admet" in t["MP"] and "champ facultatif sans valeur est omis" in t["MP"])


# ---------- LCF-43 à LCF-46 ----------
BRIEF_ORDER = re.compile(r"contenu réel.{0,80}?marque.{0,120}?asset principal.{0,120}?destination")
WAVE_MARKERS = re.compile(r"hero SaaS|gradient décoratif|\bviolet\b|\bInter\b|\bhalos?\b|\bbeige\b|\bcrème\b|serif italique|"
                          r"orange rouille|bandeau défilant|illustration peinte|\btramage\b|"
                          r"\bdithering\b|logos? pixel|\bASCII\b|hachures de plan|bleu Klein|paysage peint|"
                          r"\bbrun\b|libellés mono|repères de recadrage|police d’affichage de gabarit")
# Marqueurs de la liste datée que le motif ci-dessus ne protège pas, chacun avec sa raison. Tout autre nom de la liste
# doit être couvert : une vague ajoutée au corpus échoue ici tant qu'elle n'est ni protégée ni déclarée (VAG-01).
NON_PROTEGES = {
    "gravures": "les gravures des collections ouvertes sont une source de matière légitime (SAVOIR/SOURCE)",
}


def couverture_marqueurs(texte: str) -> list[str]:
    """[VAG-01] Chaque nom de la liste datée est protégé par WAVE_MARKERS ou déclaré dans NON_PROTEGES."""
    noms = [m["nom"] for m in rr.marqueurs_de_vague(texte)["marqueurs"]]
    if not noms:
        return ["[VAG-01] liste datée des marqueurs de vague introuvable (« Vague N : … » sous [VEILLE AAAA-MM])"]
    erreurs = [f"[VAG-01] marqueur « {n} » de la liste datée ni protégé (WAVE_MARKERS) ni déclaré (NON_PROTEGES)"
               for n in noms if n not in NON_PROTEGES and not WAVE_MARKERS.search(n)]
    erreurs += [f"[VAG-01] NON_PROTEGES cite « {n} », absent de la liste datée" for n in NON_PROTEGES if n not in noms]
    return erreurs


# Garde générale (VAG-02) : une phrase qui situe un goût ou une tendance dans le temps se date. Elle vit sur une
# ligne `[VEILLE AAAA-MM]`, jamais dans une règle, un guide, le README ou la skill sans date.
MOMENT = re.compile(r"\b(?:cette année|de l[’']année|en ce moment|actuellement)\b", re.IGNORECASE)
VEILLE_DATEE = re.compile(r"\[VEILLE \d{4}-\d{2}\]")


def textes_dates() -> list[Path]:
    """Règles, guides, références de la skill, README et SKILL : là où une affirmation de mode serait lue comme durable."""
    fichiers = [p for d in ("agent", "design", "gouvernance", "maintenance", "guides", "references")
                for p in sorted((ROOT / d).rglob("*.md"))]
    return fichiers + [ROOT / "README.md", SKILL_DIR / "SKILL.md"]


def moments_non_dates(fichiers: list[Path] | None = None) -> list[str]:
    """[VAG-02] Toute affirmation située dans le temps sans ligne [VEILLE AAAA-MM]."""
    erreurs = []
    for path in textes_dates() if fichiers is None else fichiers:
        for i, line in enumerate(path.read_text(encoding="utf-8").splitlines()):
            m = MOMENT.search(line)
            if m and not VEILLE_DATEE.search(line):
                erreurs.append(f"[VAG-02] « {m.group(0)} » hors d’une ligne [VEILLE AAAA-MM] : {rr.nom(path)}:{i + 1} "
                               "(une affirmation de mode située dans le temps se date)")
    return erreurs


def boot_block(t: dict[str, str]) -> list[str]:
    return fenced_after(t["D"], "il tient au maximum les décisions suivantes").splitlines()


def skill_activates(t: dict[str, str], locator: str, mode: str | None = None) -> bool:
    """La façade peut embarquer une règle ou activer sa route propriétaire.

    Une ligne de mode se lit dans CHARGE, jamais dans une seconde table. Ce
    contrôle borné vérifie le renvoi ; build_core vérifie le bloc servi complet.
    """
    text = t["SK"]
    begin, end = text.find("<!-- noyau:compilé début -->"), text.find("<!-- noyau:compilé fin -->")
    core = text[begin:end] if 0 <= begin < end else ""
    if f"`{locator}`" in core:
        return True
    selected = charge_row(t, mode) if mode else None
    return bool(selected and len(selected) > 1 and f"`{locator}`" in selected[1]
                and "python3 scripts/read_route.py --mode MODE" in core)


def lcf_43(t: dict[str, str]) -> bool:
    entry = fenced_after(t["D"], "### Entrée minimale").splitlines()
    boot = boot_block(t)
    vt = t["D"][t["D"].find("### DIRECTION/ASSET-ROUTE"):t["D"].find("### DIRECTION/ANCHOR-RESERVE")]
    return (any(l.startswith("CONSTRAINT —") and "destination" in l for l in entry) and any(l.startswith("FABRICATION:") for l in boot)
            and not any(l.startswith(("ANCHOR-BASIS:", "ANCHOR-LIMIT:")) for l in boot)
            and "jamais un faux asset" in vt and "bilan `FABRICATION`" in t["A"]
            and ("`FABRICATION`" in t["SK"] or skill_activates(t, "DIRECTION/CREATIVE-BOOT", "DIRECTION")))


def lcf_44(t: dict[str, str]) -> bool:
    ext = t["D"][t["D"].find("## DIRECTION/EXTERNAL-START"):t["D"].find("### Traduction humaine minimale")]
    return (BRIEF_ORDER.search(ext) and "au plus trois" in ext.lower()
            and ((BRIEF_ORDER.search(t["SK"]) and "au plus trois" in t["SK"].lower())
                 or skill_activates(t, "DIRECTION/EXTERNAL-START", "DIRECTION")))


def lcf_45(t: dict[str, str]) -> bool:
    boot = boot_block(t)
    return (any(l.startswith("MODAL:") for l in boot) and any(l.startswith("PARTI:") for l in boot)
            and not any(l.startswith("ANTI-DIRECTIONS:") for l in boot)
            and ("`MODAL`/`PARTI`" in t["SK"] or skill_activates(t, "DIRECTION/CREATIVE-BOOT", "DIRECTION"))
            and ("MODAL:" in t["EX"] or "MODAL, TRAME ET PARTI:" in t["EX"]))


# Un halo de détourage ou de bord est un défaut de production, pas une affirmation de tendance :
# la ligne est exemptée seulement si « halo » est son unique marqueur, que ce contexte y est nommé
# et qu'aucune formulation décorative n'apparaît. « halos lumineux » non daté reste refusé.
HALO_PRODUCTION = re.compile(r"détour|\bbords?\b|\bcontours?\b", re.IGNORECASE)


def wave_hit(line: str) -> bool:
    hits = [m.group(0) for m in WAVE_MARKERS.finditer(line)]
    if not hits:
        return False
    only_halo = all(re.fullmatch(r"halos?", h, re.IGNORECASE) for h in hits)
    decorative = re.search(r"halos? (?:décoratifs?|lumineux|diffus)", line, re.IGNORECASE)
    return not (only_halo and HALO_PRODUCTION.search(line) and not decorative)


def lcf_46(t: dict[str, str]) -> bool:
    keys = ("D", "A", "S", "B", "G", "Q", "RM", "README", "SK", "EX")
    stray = [l for k in keys for l in t[k].splitlines() if wave_hit(l) and not l.startswith("[VEILLE 20")]
    dated = [l for l in t["S"].splitlines() if l.startswith("[VEILLE 20") and wave_hit(l)]
    return not stray and bool(dated)


# ---------- LCF-47 à LCF-50 ----------
def savoir_section(t: dict[str, str], start: str, stop: str) -> str:
    return t["S"][t["S"].find(start):t["S"].find(stop)]


def lcf_47(t: dict[str, str]) -> bool:
    fo = t["D"][t["D"].find("## DIRECTION/FIRST-OBJECT"):t["D"].find("### Contrat positif du premier objet")]
    return ("de préférence **codé**" in fo
            and (bool(re.search(r"de préférence (\*\*)?codé", t["SK"]))
                 or skill_activates(t, "DIRECTION/FIRST-OBJECT", "DIRECTION")))


def lcf_48(t: dict[str, str]) -> bool:
    vt = t["D"][t["D"].find("### DIRECTION/ASSET-ROUTE"):t["D"].find("### DIRECTION/ANCHOR-RESERVE")]
    carte = [l for l in t["S"].splitlines() if l.startswith("[VEILLE 20") and "Carte des moyens par couche" in l]
    return bool(carte) and "jamais des styles" in carte[0] and "carte des moyens" in vt


def lcf_49(t: dict[str, str]) -> bool:
    atlas = savoir_section(t, "# SAVOIR/DESIGN-ATLAS", "# SAVOIR/STYLE")
    source = savoir_section(t, "# SAVOIR/SOURCE", "# SAVOIR/DESIGN-ATLAS")
    vt = t["D"][t["D"].find("### DIRECTION/ASSET-ROUTE"):t["D"].find("### DIRECTION/ANCHOR-RESERVE")]
    return ("**Traitement des assets moyens.**" in source and "`SAVOIR/SOURCE`" in atlas
            and "jamais un dessin de remplacement" in vt and skill_activates(t, "SAVOIR/SOURCE"))


def lcf_50(t: dict[str, str]) -> bool:
    return any(l.startswith("[VEILLE 20") and "Vague 3 :" in l for l in t["S"].splitlines())


# Corrections de la révision de mobilisation ; chaque condition possède sa mutation rouge.
def lcf_51(t: dict[str, str]) -> bool:
    entry = next((l for l in t["B"].splitlines() if l.startswith("**Zéro route est valide")), "")
    local = row(t["B"], "Local")
    return (all(word in entry for word in ("héritage", "source", "justification", "non-applicabilité réelle"))
            and "conserve-la et justifie `N/A-JUSTIFIED`" not in entry
            and "`N/A-JUSTIFIED` si aucune route ne change" not in t["B"]
            and bool(local) and "héritage" in local[1] and "réellement non applicable" in local[1])


def lcf_52(t: dict[str, str]) -> bool:
    definition = row(t["G"], "**RUN_CARD**")
    return bool(definition) and all(value in definition[1] for value in
                                   ("niveau de trace", "trace légère", "ne produit pas", "ACTION/RUN_CARD", "ACTION/CLOSE-PACKAGE"))


def lcf_53(t: dict[str, str]) -> bool:
    policy = next((l for l in t["D"].splitlines() if l.startswith("policy_profile:")), "")
    return all(f"`{key}`" in policy for key in
               ("risk_triggers", "required_controls", "risk_coverage", "depth_rules", "contraindications"))


def lcf_54(t: dict[str, str]) -> bool:
    snapshot = after(t["A"], "### Reprendre un run", 5000)
    return (all("python3 scripts/read_route.py --connexions" in t[key] for key in ("D", "SK"))
            and all(value in snapshot for value in ("trace existante", "source pertinente change", "effet comme attendu",
                                                   "capacités d’observation attestées", "autorité d’action")))


def lcf_55(t: dict[str, str]) -> bool:
    tree = after(t['D'], '### TREE — arbre de classification', 3000)
    iter_line = next((line for line in tree.splitlines() if line.startswith('3. ')), '')
    return all(term in iter_line for term in ('rappeler et réévaluer', 'au-delà d’un fix ou delta local qui la conserve'))


def lcf_56(t: dict[str, str]) -> bool:
    handoff = after(t['A'], '### ACTION/HANDOFF', 7500)
    definition = row(t['G'], '**Trace complète**')
    return ('sauf la forme courte LITE définie ci-dessus' in handoff
            and 'une demande de projection structurée requiert la `RUN_CARD` validée' in handoff
            and bool(definition) and 'est complète sans RUN_CARD' in definition[1]
            and 'forme courte LITE sans RUN_CARD est admise' in t['Q']
            and 'La forme courte LITE conserve une trace complète sans RUN_CARD' in t['SK'])


def check_facades(errors: list[str]) -> None:
    t = load_texts()
    rm49 = row(t["RM"], "Accessibilité")
    rd_dir, rd_iter = row(t["README"], "`DIRECTION`", 1), row(t["README"], "`ITER`", 1)
    entry = after(t["D"], "Ce gabarit est la projection de la ligne `RUN`", 600)  # A11 : OWNER et SCOPE dus en trace complète
    fast = next(([l, l] for l in t["A"].splitlines() if l.startswith("Pour `LITE` et les petits `ITER`")), None)  # C22 : questions dans ACTION/FAST-PATH
    prio = fenced_after(t["D"], "```text\nRUN-PRIORITY")
    canon = HANDOFF_TOKENS.findall(fenced_after(t["A"], "### ACTION/HANDOFF"))
    f15, f16, f17 = lcf_15_16_17(t)
    # (ID, façade, source propriétaire, condition tenue)
    table = [
        ("LCF-01", "ligne DIRECTION de CHARGE : RUN-DIRECTION chargé d’abord", "DIRECTION/START ; ACTION/RUN-DIRECTION",
         bool(charge_row(t, "DIRECTION"))
         and "ACTION/RUN-DIRECTION" in charge_row(t, "DIRECTION")[1] and "ACTION/RUN-DIRECTION" not in charge_row(t, "DIRECTION")[2]),
        ("LCF-02", "READING_MAP, ligne « Accessibilité »", "ACTION/GATE-A (contrôles applicables dus)",
         bool(rm49) and "N/A-JUSTIFIED" not in rm49[-1] and "ACTION/GATE-A" in rm49[-1]),
        ("LCF-03", "READING_MAP (combinaisons), noyau UI/UX, preuve, système", "ACTION/GATE-A ; gate du risque ; paquet SYSTÈME (B3)", lcf_03(t)),
        # Le classement vit dans DIRECTION/START ; l'entrée humaine (README) ne demande aucun mode et ne porte
        # aucune table de mode ; le guide opérateur y renvoie par l'arbre, sans la redire.
        ("LCF-04", "README sans table de mode ; guide opérateur renvoyant à l'arbre", "DIRECTION/START (classement)",
         rd_dir is None and rd_iter is None and "DIRECTION/START/TREE" in t["Q"]),
        ("LCF-06", "table des signaux du noyau, ligne « Structure ouverte »", "DIRECTION/START (classification)", lcf_06(t)),
        ("LCF-07", "RUN-PRIORITY, ligne DIRECTION de CHARGE, combinaisons du niveau 2 des guides", "DIRECTION/VISUAL_TARGET avant DIRECTION/FIRST-OBJECT", lcf_07(t)),
        ("LCF-08", "DIRECTION, gabarit START et FAST-PATH", "DIRECTION/START (OWNER et SCOPE jamais omis)",
         re.search(r"En trace complète, `?OWNER`? et `?SCOPE`?[^.]*jamais omis", entry) is not None and bool(fast) and "et son owner" in fast[1] and "si nécessaire" not in fast[1]),
        ("LCF-09", "DIRECTION, RUN-PRIORITY", "BIBLIOTHEQUE/SELECT, SCENE",
         bool(re.search(r"FIRST-OBJECT —[\s\S]*?sauf si", prio))),
        ("LCF-C2", "QUICKSTART et skill, réponse visible", "ACTION/HANDOFF",
         all(r in after(t["A"], "### ACTION/HANDOFF", 4000) for r in VISIBLE_RUBRIQUES)
         and "réponse visible en langage produit" in t["Q"] and "`ACTION/HANDOFF`" in t["Q"]
         and all(r in t["SK"] for r in VISIBLE_RUBRIQUES) and VISIBLE not in t["Q"] + t["SK"]),
        ("LCF-11", "exemples de la skill et GLOSSAIRE, DECISION-CHANGE", "ACTION/STATUS (triade)", lcf_11(t)),
        ("LCF-12", "exemples et GLOSSAIRE, ACCEPTED-WITH-RESERVATION", "ACTION (réserve complète)", lcf_12(t)),
        ("LCF-13", "exemples de la skill, NOT-OBSERVED et VERDICT", "ACTION/STATUS (triade)", lcf_13(t)),
        ("LCF-14", "exemples de la skill, EVIDENCE fondées sur des captures", "ACTION (claims et protocole)", lcf_14(t)),
        ("LCF-16", "DIRECTION, contrat du premier objet, colonne CFT-00", "SAVOIR/CRAFT/CFT-00", f16),
        ("LCF-17", "table des signaux du noyau : motif générique, scène, détail final", "SAVOIR/CRAFT ; BIBLIOTHEQUE ; ACTION/ANTI-SLOP", f17),
        ("LCF-20", "BIBLIOTHEQUE, listes des statuts de route", "CHANGELOG, cycle de vie", lcf_20(t)),
        ("LCF-21", "DIRECTION, README, RELEASE_NOTES, CHANGELOG", "CHANGELOG (efficacité NOT-VERIFIED)", lcf_21(t)),
        ("LCF-22", "ACTION (table RUN_CARD, réponse visible, paquets), GLOSSAIRE et façades : DECISION-CHANGE", "ACTION/STATUS (triade)", lcf_22(t)),
        ("LCF-23", "ACTION/GATE-B — B1b, portée", "validate_run_card (check_b1b)", lcf_23(t)),
        ("LCF-24", "QUICKSTART et skill, Creative Boot", "DIRECTION/CREATIVE-BOOT ; BIBLIOTHEQUE/TENSION", lcf_24(t)),
        ("LCF-26", "machine_projection : axes et profile_decision", "schemas/run_card.schema.json", lcf_26(t)),
        ("LCF-27", "CHANGELOG, RELEASE_NOTES, README : portée de la cohérence des façades", "liste close des conditions de façade", lcf_27(t)),
        ("LCF-28", "ACTION, table de correspondance RUN_CARD : lignes VISUAL_TARGET", "DIRECTION/VISUAL_TARGET (table canonique)", lcf_28(t)),
        ("LCF-29", "DIRECTION, légende des tags", "SAVOIR (Niveaux d’autorité)", lcf_29(t)),
        ("LCF-31", "exemples de la skill : renvoi à la sérialisation", "ACTION/RUN_CARD ; schemas/run_card.example.json", lcf_31(t)),
        ("LCF-32", "ACTION, droits inconnus", "validate_run_card (rights_status)", lcf_32(t)),
        ("LCF-33", "SAVOIR, ressource de stack", "ACTION/POLICIES (sept champs)", lcf_33(t)),
        ("LCF-34", "ACTION, sorties des blocs RUN-*", "ACTION/CLOSE-PACKAGE", lcf_34(t)),
        ("LCF-35", "GLOSSAIRE, exemple CLOSED", "ACTION (protection critique) ; B1", lcf_35(t)),
        ("LCF-36", "ACTION, droits inconnus : portée du contrôle machine", "validate_run_card (rights_status, DIRECTION)", lcf_36(t)),
        ("LCF-37", "ACTION/CLOSE-PACKAGE, cinq paquets", "ACTION/STATUS (triade) ; validate_run_card (decision_change)", lcf_37(t)),
        ("LCF-38", "sources et façades : « aucune décision » et N/A-JUSTIFIED", "ACTION/STATUS (triade)", lcf_38(t)),
        ("LCF-39", "QUICKSTART §5, chargement LITE et ITER", "DIRECTION/CHARGE (Gate B du risque)", lcf_39(t)),
        ("LCF-40", "GLOSSAIRE, exemple CLOSED : réserve à sept attributs", "ACTION (réserve) ; RESERVATION_FIELDS", lcf_40(t)),
        ("LCF-41", "ACTION et machine_projection : champs admettant null", "schemas/run_card.schema.json", lcf_41(t)),
        ("LCF-43", "DIRECTION (entrée, boot, route de production), ACTION, QUICKSTART, skill : bilan de fabrication", "DIRECTION/CREATIVE-BOOT (FABRICATION)", lcf_43(t)),
        ("LCF-44", "EXTERNAL-START, QUICKSTART, skill : prise de brief, même ordre", "DIRECTION/EXTERNAL-START (prise de brief)", lcf_44(t)),
        ("LCF-45", "boot, QUICKSTART, skill, exemples : MODAL / PARTI", "DIRECTION/CREATIVE-BOOT (MODAL, PARTI)", lcf_45(t)),
        ("LCF-46", "textes et façades : marqueurs de vague seulement en [VEILLE] daté", "SAVOIR ([VEILLE] daté)", lcf_46(t)),
        ("LCF-47", "FIRST-OBJECT et skill : objet de preuve codé, de préférence", "DIRECTION/FIRST-OBJECT", lcf_47(t)),
        ("LCF-48", "SAVOIR ([VEILLE] daté) et route de production : carte des moyens", "SAVOIR ([VEILLE])", lcf_48(t)),
        ("LCF-49", "SAVOIR/SOURCE, atlas et route de production : traitement des assets moyens", "SAVOIR/SOURCE", lcf_49(t)),
        ("LCF-50", "SAVOIR, [VEILLE] daté : vague 3", "SAVOIR ([VEILLE])", lcf_50(t)),
        ("LCF-51", "BIBLIOTHEQUE, entrée et résumés locaux", "BIBLIOTHEQUE/AVANT-SELECTION ; ACTION/STATUS (héritage distinct de non-applicabilité)", lcf_51(t)),
        ("LCF-52", "GLOSSAIRE, RUN_CARD", "ACTION/HANDOFF ; ACTION/RUN_CARD (niveau de trace et mode)", lcf_52(t)),
        ("LCF-53", "DIRECTION, gabarit DOMAIN-FRAME", "schemas/domain_frame.schema.json (risk_coverage)", lcf_53(t)),
        ("LCF-54", "DIRECTION, noyau et reprise d’un run", "DIRECTION/CHARGE ; ACTION/RUN_CARD (mobilisation, limites et fraîcheur)", lcf_54(t)),
        ('LCF-55', 'START et QUICKSTART : frontière LITE / ITER', 'DIRECTION/START (fix conservé ou direction réévaluée)', lcf_55(t)),
        ('LCF-56', 'HANDOFF, glossaire, guide opérateur et noyau : exception de trace complète LITE', 'ACTION/HANDOFF ; ACTION/CLOSE-PACKAGE', lcf_56(t)),
    ]
    for lcf_id, facade, source, held in table:
        if not held:
            errors.append(f"{lcf_id} : condition de façade non tenue — {facade} (propriétaire : {source})")


def main() -> int:
    bad = rr.non_utf8(rr.ROOT)  # encodage nommé avant toute lecture
    if bad:
        fail(f"Markdown non UTF-8 : {', '.join(bad)}")
    missing = [rr.nom(p) for p in CARTES if not p.is_file()]
    if missing:
        fail(f"document de la carte absent : {', '.join(missing)}")
    text = "\n".join(rr.liens_en_codes(p.read_text(encoding="utf-8"), p) for p in CARTES)
    for item in REQUIRED:
        if item not in text:
            fail(f"élément obligatoire absent : {item}")
    for route in [f"{prefix}/*" for prefix in rr.FAMILLES] + ["CHANGELOG"]:
        if f"`{route}`" not in text:
            fail(f"propriétaire de route absent de la résolution des routes : {route}")
    for path in CARTES:  # chaque lien depuis le fichier qui le porte
        for target in re.findall(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
            target = target.split("#", 1)[0]
            if not target or target.startswith(("http://", "https://", "mailto:")):
                continue
            if not (path.parent / target).exists():
                fail(f"lien relatif non résolu : {rr.nom(path)} -> {target}")
    errors: list[str] = []
    check_map(errors)
    check_connections(errors)
    check_reader_witness(errors)
    check_topics(errors)
    check_facades(errors)
    errors += couverture_marqueurs(rr.famille("SAVOIR"))
    errors += moments_non_dates()
    if errors:
        print("READING MAP VALIDATION FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    print("READING MAP VALIDATION PASSED — cartes dérivées, titres à code, codes cités, liens, conditions de façade (liste close) et affirmations de mode datées contrôlés")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
