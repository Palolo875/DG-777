# Savoir — identité de marque

Concevoir et éprouver une identité : signe ou marque verbale, déclinaisons, palette, voix, règles d’usage.

# SAVOIR/IDENTITY — signe, déclinaisons et épreuves

[MÉTHODE] Cette route sert quand la demande est une identité de marque : un signe, une marque verbale ou le système qui les porte. Le chemin reste celui de `DIRECTION` (classement, absolus, ancre pour accepter) ; cette route dit ce qu’on livre, comment on construit le signe et comment on l’éprouve.

### Ce qu’on livre

Une identité est un système, pas un fichier. Elle comprend, à la mesure de la demande :

- **le signe** : marque verbale, monogramme, symbole, ou leur combinaison, en vectoriel maître ;
- **les déclinaisons, dessinées et non réduites** : la version complète, une version compacte pour un carré, le symbole seul pour l’avatar et l’icône, une version simplifiée pour 16 à 32 px si le symbole ne tient pas tel quel ;
- **le noir et l’inversé** : une couleur pleine, sans dégradé ni transparence, en noir et en blanc ; une version réglée pour les fonds sombres, et non simplement passée en blanc ;
- **la palette et la voix typographique** : peu de couleurs, chacune avec son rôle (`SAVOIR/CRAFT/CFT-05`), prélevées sur le sujet ; une voix comparée sur le vrai nom (`SAVOIR/TYPE-VOIX`) ;
- **un ou deux éléments graphiques tirés du signe** (une forme, un trait, un rythme), pas un motif ajouté ;
- **les règles d’usage** : zone de protection mesurée par un élément du signe (la hauteur d’une lettre, le diamètre d’une forme), jamais en pixels ; taille minimale de chaque déclinaison ; deux ou trois usages à éviter, montrés ;
- **une application qui prouve le système** : un en-tête de page, un avatar, un document ou un emballage, au niveau de finition d’une page (`DIRECTION/FIRST-OBJECT`).

Quand l’identité doit devenir une décision répétable dans une interface, la planche de grammaire de marque (`OBJECT/BRAND_GRAMMAR_PLATE`) et la couche `LAYER/BRAND_GRAMMAR` en portent la traduction (`BIBLIOTHEQUE/COMPONENTS`).

Pour une démonstration ou une proposition, le signe et le nom se marquent comme proposition (« proposition d’identité ») ; ils ne sont jamais présentés comme la marque existante d’un client.

### Construire le signe

1. **Partir du sujet.** L’idée vient des pistes du noyau (« Diverger sur image ») : ce que le sujet produit, son deuxième attribut qui le signe (le plus saillant est déjà modal), son nom et ses lettres, son lieu, son rituel, l’objet imprimé de son monde. Le littéral (la tasse pour un café, l’appareil photo pour un photographe) est l’étiquette d’une catégorie, pas une marque : il ne gagne qu’en battant les autres pistes.
2. **Choisir le type de signe par l’usage.** Une marque verbale suffit quand le nom est court et porte la différence ; un monogramme ou un symbole quand la marque vivra souvent en petit (application, avatar, tampon) ; la combinaison quand les deux usages coexistent.
3. **Dessiner en noir d’abord**, en formes simples, sur une grille et des proportions nommées (module, épaisseur de trait, rayon). La couleur vient après, quand la forme tient seule ; si elle ne tient qu’en couleur, la couleur fait le travail de la forme.
4. **Composer la marque verbale** dans une police ouverte choisie pour la voix, puis la régler à la main : approche des paires, alignements optiques, un détail propre au nom si la thèse le demande. Une police modifiée garde sa licence (`SAVOIR/TOOLS/MOYENS`).
5. **Rester dans la portée de l’agent.** Un signe géométrique, typographique ou construit se code en SVG et s’éprouve sur rendu. Un signe figuratif complexe ne se dessine pas de mémoire (« Pas de figuratif de mémoire », noyau) : génération dirigée marquée, ou emplacement marqué, avec la limite dite.

**Diverger.** Les esquisses de la planche sont des signes en noir, au même niveau, à côté de la modale : ce que tout agent ferait pour ce brief (l’initiale dans un cercle, le pictogramme littéral, le dégradé à la mode). Une esquisse ne l’emporte qu’en battant la modale à la vue, et à 32 px comme en grand.

### Éprouver le signe

`[À ADAPTER]` Points de départ, **non des normes**. La planche d’épreuve (`python3 scripts/parcours.py identite signe.svg [--marque-verbale verbale.svg] [--photo image.jpg]`) montre le signe dans ses conditions réelles et relève des signaux mesurés (couleur qui porte la forme, forme peinte, trait ou contreforme sous 1 px à 32 px, détail perdu à 16 px, signe trop large pour un carré, dégradé, couleurs nombreuses) ; chacun est une question, pas un verdict. Le jugement se fait sur la planche, à taille réelle, pas en zoom.

| Épreuve | Ce qu’on regarde | Retour si… |
|---|---|---|
| Noir et gris | Le signe en une couleur pleine, puis en gris | Des formes se confondent ou disparaissent : une forme peinte dans la silhouette disparaît en noir plein, la version d’une couleur l’évide |
| Petite taille | 16, 24 et 32 px à taille réelle | Un trait disparaît, une contreforme se bouche, un texte devient illisible |
| Inversé | Blanc sur la couleur la plus sombre et sur du noir | Les traits s’amincissent ou les lettres bavent |
| Sur photo | Sur une matière claire et une sombre | Le signe s’y perd sans zone calme |
| Avatar | Dans un cercle, en vignette | Une marque large devient illisible |
| Retourné | Le signe à l’envers et en miroir | Une silhouette accidentelle apparaît |
| En une phrase | Le décrire comme au téléphone | Il faut plus d’une phrase |
| À côté des autres | Avec les signes de deux ou trois acteurs du même secteur, observés (`SAVOIR/SOURCE`) | On ne le distingue pas d’un coup d’œil |

**Simplifier le maître, pas réduire.** Si une déclinaison oblige à redessiner les formes, au-delà d’un changement de couleur ou d’épaisseur, le maître est trop détaillé : c’est lui qui se simplifie. Une version pour 16 px dessinée exprès reste permise quand le symbole complet porte un détail qui fait sa force en grand.

**Seuils de départ.** Le symbole seul se lit à 24 px et se reconnaît à 16 ; une marque verbale reste lisible à environ 80 à 120 px de large ; la zone de protection vaut au moins la hauteur d’une capitale du nom. Ces valeurs s’éprouvent sur la planche ; elles ne s’affirment pas.

### Limites

Le design n’établit pas la disponibilité juridique d’un nom ou d’un signe : la recherche d’antériorité et le dépôt sont hors de portée et se disent dans la réponse (« Ce qui manque pour la vraie version »). La ressemblance avec une marque existante s’écarte à l’œil, sans garantie. La reproduction physique (broderie, gravure, impression d’une couleur) n’est pas vérifiée par une capture : elle reste `NOT-VERIFIED`, avec sa prochaine preuve.
