# Maintenance — faire évoluer le système

Pour qui fait évoluer le système : d’où vient chaque distribution, comment la préparer et la valider. Ce module se charge quand une règle ou une route doit évoluer, être promue ou dépréciée ; il ne fait pas partie du chargement ordinaire d’une proposition.

| Fichier | Contenu |
|---|---|
| [`evolution.md`](evolution.md) | Recette d’une modification, promotion et dépréciation des routes, cycle de vie, anciens alias |
| [`versions.md`](versions.md) | Fiche de version : ce que contient le système, ses capacités, sa compatibilité, son socle et ce qui en est vérifié |

## Source de vérité et distributions

Le dépôt GitHub est la **source de vérité**. La distribution Local est un export dérivé : même arborescence, sans les outils de préparation ni l’intégration continue ; son README remplace les passages balisés `github:` (installation par dépôt, CI, outils de construction) par leur variante locale, définie dans `scripts/build_distributions.sh`. Elle ne doit pas être modifiée à la main. <!-- références:github -->

Depuis la distribution GitHub, préparez la livraison :

```bash
python3 scripts/preparer_livraison.py
```

Cette commande compile le noyau, exécute les contrôles du paquet et construit les deux distributions reproductibles, sans envoi ni déploiement.

| Option | Résultat |
|---|---|
| `--empreintes` | Affiche les empreintes SHA256 des archives. |
| `--log CHEMIN` ou `--journal CHEMIN` | Conserve la sortie détaillée des contrôles dans un fichier `.log` ; les deux options sont équivalentes. Par défaut : `.logs/preparer_livraison.log`. Dans le paquet, le journal doit rester sous `.logs/` ; ailleurs, choisir un chemin hors du paquet. |
| `--require-browser` | Exige l’exécution des tests de pages et fait échouer la préparation si le navigateur est indisponible. |

Sans navigateur, les tests de pages restent `NOT-VERIFIED`. Les limites des contrôles restent visibles même lorsque la préparation réussit.

Dans l’export Local, utilisez `python3 scripts/validate_all.py`, avec `--require-browser` si ces essais sont exigés. Cet export ne contient pas la commande de préparation.

Le budget décrit dans `maintenance/evolution.md` (contrats de maintenance) concerne le fichier `SKILL.md` complet, mesuré en octets UTF-8. Le même contrôle est exécuté lors de la compilation et de la validation des distributions. Il borne la taille chargée ; il ne mesure ni la charge cognitive ni le coût complet d’un run.

### Noyau commun et détails

Le compilateur tient la table de tous les blocs protégés : communs, ou disponibles dans une route propriétaire avec leur activation. Le lecteur ne replie que les textes complets effectivement présents dans la skill. Installer une ancienne skill avec un paquet récent ne prouve donc pas que les détails récents sont déjà chargés ; après mise à jour, recompiler et recopier la skill.

La commande `python3 scripts/read_route.py --mode MODE` affiche uniquement la ligne du mode déjà classé, sans créer de classification ni de table concurrente. Les détails se lisent selon la décision et le périmètre ; le nombre de contrôles et la taille du fichier ne remplacent pas la preuve de leur utilité.

### Reprendre une préparation interrompue

Un verrou `.distribution.lock` bloque un second build. Le fichier owner.txt est produit pendant le build dans ce verrou, et ne fait pas partie des fichiers distribués. Lorsqu’il existe, il indique PID, début UTC et dossier ; ces indices peuvent être absents sur un ancien verrou et ne suffisent pas à prouver qu’un processus est arrêté. Dans le même environnement, inspectez le PID et sa commande (`ps -p PID -o pid,ppid,lstart,args`), les builds de ce dossier et le job ou la session qui les lance. Un PID peut être réutilisé. Tant que l’absence de build actif n’est pas établie, conservez le verrou ; son ancienneté ne justifie aucune suppression.

Avant toute reprise, conservez à part les archives, `dist`, `.dist.previous`, `.archives.previous` et le journal s’ils existent. Si `.archives.previous` existe, ou si `dist` et `.dist.previous` coexistent, le script s’arrête : comparez les inventaires et empreintes, identifiez la dernière livraison complète à l’aide du journal, puis conservez cette livraison et les autres exemplaires dans des dossiers distincts. Ne promouvez pas un mélange de versions et ne supprimez pas une sauvegarde pour forcer le build. Une sauvegarde `.dist.previous` seule est restaurée par le script ; elle ne prouve pas à elle seule l’état des archives.

Dans la distribution GitHub, lorsque le build est confirmé inactif et les sauvegardes identifiées, retirez uniquement le fichier owner.txt produit par le build, puis le dossier de verrou vide (`rmdir` refuse un contenu inattendu). Relancez `python3 scripts/preparer_livraison.py` ; le succès exige les contrôles et les exports complets. Si la situation reste ambiguë, conservez les fichiers et le diagnostic pour le mainteneur. Aucun verrou ni backup n’est effacé automatiquement selon son âge. <!-- références:github -->

Pour produire seulement les deux archives, exécutez :

```bash
bash scripts/build_distributions.sh
```

Le build régénère les distributions de travail dans `dist/` et écrit les archives déterministes suivantes à la racine du dépôt :

```text
Design_Governance_V1_GITHUB.zip
Design_Governance_V1_LOCAL.zip
```

Le build copie exactement les fichiers listés dans `scripts/package_manifest.json`, pour chaque distribution : ajouter un fichier au paquet, c’est l’ajouter au manifeste (liste `github`, et liste `local` s’il est livré aussi en Local). Il contrôle ensuite les deux distributions avant l’archivage. `validate_all.py` construit deux fois pour vérifier que les archives sont reproductibles ; le second build, lancé avec la variable `DG_BUILD_REPRODUCTIBILITE`, saute ces contrôles déjà passés sur le même contenu. Ne posez pas cette variable à la main. <!-- références:github -->

Les modifications doivent être apportées aux sources du dépôt, puis vérifiées par les contrôles et le build. Les archives et exports ne sont pas des sources normatives indépendantes.

## Validation

Utilisez Python **3.10 ou plus récent**. Les contrôles documentaires et machine utilisent la bibliothèque standard Python. La recette de rendu et les tests qui ouvrent des pages nécessitent en plus **Playwright et son navigateur Chromium** ; sans eux, ces tests restent `NOT-VERIFIED`. La planche demande **Pillow** ; la commande de regard, **numpy, SciPy et Pillow** ; le parcours par défaut, les mêmes, l’accès au registre npm ou à Google Fonts pour `polices`, et aux sites et collections demandés pour `references` ; sans ces dépendances, leurs tests restent `NOT-VERIFIED`. La construction des archives de la distribution GitHub nécessite Bash, `zip` et les outils Unix utilisés par `scripts/build_distributions.sh` ; elle est contrôlée sous Linux. <!-- références:github -->

Un Chromium déjà installé peut être choisi explicitement avec `--browser-executable CHEMIN` dans la recette de rendu, ou `DG_BROWSER_EXECUTABLE` pour elle et ses tests ; elle bloque aussi par défaut les ressources hébergées ailleurs (`--allow-external` pour les laisser passer), afin de mesurer la même page. Sa version et son exécutable sont conservés dans la provenance ; ce choix ne remplace pas silencieusement le navigateur Playwright. Si la politique du navigateur interdit les fichiers locaux, `--serve-local` (ou `DG_RENDER_SERVE_LOCAL=1`) sert temporairement le dossier du fichier sur 127.0.0.1, puis ferme le serveur. Les autres origines restent bloquées par défaut.

Exemple pour un environnement où Chromium est déjà installé à cet emplacement :

```bash
DG_BROWSER_EXECUTABLE=/usr/bin/chromium DG_RENDER_SERVE_LOCAL=1 python3 scripts/validate_all.py --require-browser
```

Un fichier de règles est un fichier de `agent/`, `design/`, `gouvernance/` ou `maintenance/` qui porte au moins un titre à code. Hors de son en-tête (titre et phrase d’introduction), chacune de ses lignes doit être servie par une route ou compilée dans le noyau : `validate_structure.py` refuse toute autre ligne (garde ATT-01). Les sections de maintenance de `maintenance/` se lisent par leur fichier ; ailleurs, un texte destiné aux personnes se place entre `<!-- orientation:début -->` et `<!-- orientation:fin -->`.

Les chemins d’exemple entre accents graves portent le préfixe `exemple:` ; les chemins opérationnels doivent se résoudre vers un fichier livré ou une route. Une référence destinée à une seule distribution se marque sur sa ligne par le commentaire HTML « références:github » ou « références:local » : son chemin doit être déclaré dans le manifeste de cette distribution. Les contrôles ignorent les blocs d’exemple, mais vérifient les liens Markdown.

Les tests JavaScript sur DOM simulés utilisent un runtime Node déjà disponible ; son absence laisse cette partie `NOT-VERIFIED`. `python3 scripts/test_check_render.py --skip-browser` exécute seulement les tests synthétiques et les DOM simulés, sans ouvrir de page ni installer de dépendance.

La projection machine comprend aussi les contrats de production : `DOMAIN_FRAME`, `RESEARCH_BRIEF` et les contrats de direction créative, de réalité UI/UX et d’évaluation. Ils sont illustrés dans `gouvernance/schemas/examples/` et contrôlés par `gouvernance/outils/validate_contracts.py`.

| Commande | Fonction |
|---|---|
| `python3 scripts/validate_design_governance.py` | Contrôle l’inventaire, les liens Markdown relatifs, le vocabulaire structuré et les conventions du paquet. |
| `python3 gouvernance/outils/validate_run_card.py` | Exécute la suite intégrée de validation des projections et des fixtures `RUN_CARD`. |
| `python3 gouvernance/outils/validate_run_card.py chemin/run.json` | Valide un fichier JSON ciblé et échoue s’il est absent, malformé ou sémantiquement invalide. |
| `python3 gouvernance/outils/validate_contracts.py --type production_contracts chemin/contrat.json` | Valide un contrat ciblé, y compris hors du paquet ; sans `--type`, la famille est détectée par les clés racines. |
| `python3 scripts/validate_reading_map.py` | Vérifie la carte de lecture, ses propriétaires, ses locators et sa frontière non normative. |
| `python3 scripts/read_route.py --tronc MODE [--fichier CHEMIN]` | Affiche le tronc de la ligne d’un mode, ou l’écrit avec la ligne du mode en tête dans un fichier lu une fois (routes lues à chaque run de ce mode), sa taille, sa marge et le respect du budget de 40 000 caractères ; rend le code 1 si le budget est dépassé. Une marge sous 10 % est signalée au mainteneur par `validate_structure.py`, pas à l’agent. |
| `DG_JOURNAL=run.jsonl python3 scripts/read_route.py …`, puis `python3 scripts/journal_mobilisation.py run.jsonl` | Journal de mobilisation : la variable `DG_JOURNAL` fait noter au lecteur de routes, à `check_render.py`, à `planche.py`, à `regard.py` et à `parcours.py` ce qu’ils ont servi ; le second script en tire une fiche de mobilisation. Sans la variable, rien n’est écrit ; un journal impossible à écrire ne bloque aucun outil. Une route servie n’est pas une route lue. |
| (même fiche) | Contenu : routes servies et destination de leur sortie, appels, résultats du parcours, tronc non servi comparé au tronc noté au run, run DIRECTION sans planche ni regard, rendu sans ligne de mode. Indices de lecture : un filtre vu dans la commande de l’appel (« … \| head ») est noté comme un indice, seulement s’il peut couper la sortie ; une route écrite dans un fichier (`--fichier`, redirection) est notée « lue hors journal », hors des manques. |
| `python3 scripts/parcours.py verifier page.html --foyer SÉL --action SÉL [--refs DOSSIER]` | Parcours par défaut : recette (à 1440, 768 et 390 px), regard, captures, signaux de finition, planche de mouvement et poids de la page en une fiche `parcours.md`, à côté de la page ; `mouvement page.html --action SÉL` produit la planche seule. |
| `python3 scripts/parcours.py COMMANDE …` | Outils de la boucle : `captures page.html --version v2` capture une version de la boucle ; `critique page.html --brief "…"` prépare un regard séparé ; `typo page.html --corriger` pose les espaces du français. |
| (même commande) | Matériaux : `polices "Famille:400,700i"` télécharge des polices ouvertes et écrit leur feuille ; `icones NOM…` télécharge des icônes et leur licence ; `references --url ADRESSE --commons "requête"` rassemble des références avec leur provenance, et mesure les pages capturées ; `identite signe.svg` pose un signe de marque sur une planche d’épreuve. |
| `python3 scripts/read_route.py --connexions` | Affiche le sommaire des connexions situées ; ajouter un identifiant comme `C03` pour lire condition, contributions, limites et sources résolues. |
| `python3 scripts/test_audit_regressions.py` | Exécute les régressions de navigation, de capacités et de conditions de façade ; ne mesure ni la compréhension utilisateur ni la qualité esthétique. |
| `python3 scripts/validate_all.py` | Exécute les contrôles documentaires, machine, CLI, fixtures négatives, compilation et reproductibilité des distributions. |
| `python3 scripts/validate_all.py --lecture-seule` | Exécute les mêmes contrôles sans construire ni remplacer les distributions : `dist/`, `.build/` et les archives ne sont pas touchés (le runner le vérifie). Des caches Python et des copies temporaires de test peuvent être écrits ailleurs. Build et reproductibilité restent `NOT-VERIFIED`. |
| `python3 scripts/validate_all.py --skip-browser` | Exécute les mêmes contrôles sans lancer les tests de pages, déclarés `NOT-VERIFIED`. Le build l’emploie pour valider l’export Local, dont le code vient d’être testé dans le navigateur ; incompatible avec `--require-browser`. |

Les chemins `exemple: chemin/run.json` et `exemple: chemin/contrat.json` sont des exemples à remplacer par ceux de vos fichiers. Pour exécuter les contrôles intégrés du paquet :

```bash
python3 scripts/validate_design_governance.py
python3 gouvernance/outils/validate_run_card.py
python3 scripts/validate_all.py
```

Ces contrôles vérifient la forme du paquet, de ses projections et de ses distributions, ainsi que la liste close des conditions de façade ; une divergence hors de cette liste n’est pas détectée. Ce qu’ils ne prouvent pas est décrit dans [la fiche de version](versions.md#ce-qui-est-vérifié-ce-qui-ne-lest-pas) ; ce qu’une `RUN_CARD` validée atteste, dans la frontière de validation d’`ACTION/RUN_CARD`.

## Résolution des routes

Un code de route (`SAVOIR/TYPE`) se lit avec `python3 scripts/read_route.py CODE`. Le lecteur cherche, dans les fichiers de règles, le titre unique qui commence par ce code ; pour un sous-code (`SAVOIR/CRAFT/CFT-03`), le sous-titre qui commence par sa dernière partie, dans la section parente (`## CFT-03 — …`). Aucune table ni aucun registre ne relie un code à son fichier : déplacer une section revient à déplacer son texte avec son titre, et un code porté par deux titres est refusé comme ambigu. Les guides citent les sections par des liens : après un déplacement, la validation nomme chaque lien qui vise encore l’ancien fichier ; il suffit d’y remplacer le nom du fichier. En lecture manuelle, cherchez le code au début d’un titre. Un renvoi qui ne résout pas doit être déclaré obsolète, conceptuel ou `NOT-VERIFIED` ; il ne doit jamais être traité comme une instruction active par supposition.

| Code | Propriétaire |
|---|---|
| `DIRECTION/*`, `ACTION/*`, `SAVOIR/*`, `BIBLIOTHEQUE/*` | La section dont le titre commence par ce code, dans un fichier de règles. |
| `CHANGELOG` | Fiche `maintenance/versions.md` (état courant) ; les règles de cycle de vie sont dans `maintenance/evolution.md`. |
| `RUN_CARD` | `gouvernance/schemas/run_card.schema.json`, exemple et validateur |

`RUN_CARD` est un **adaptateur machine**, pas un locator Markdown résolvable par `scripts/read_route.py`. Pour l’inspecter ou le valider, utiliser le schéma, l’exemple et `gouvernance/outils/validate_run_card.py` ; ne pas l’invoquer comme une route documentaire.

## Ajouter ou modifier une règle

1. **Titre à code.** La règle vit sous un titre qui commence par son code, comme `SAVOIR/TYPE` ; une sous-route est un sous-titre qui commence par la dernière partie de son code, comme `CONTROLES` pour `ACTION/GATE-A/CONTROLES`. Le lecteur la retrouve par ce code, quel que soit le fichier.
2. **Manifeste.** Un nouveau fichier entre dans `scripts/package_manifest.json`, listes `github` et `local` ; un fichier absent du manifeste n’est pas livré.
3. **Noyau.** Une règle lue à chaque demande s’encadre des marqueurs `noyau:début ID` et `noyau:fin ID`, en commentaire HTML, et son identifiant s’ajoute au registre `NOYAU` de `scripts/build_core.py`. `python3 scripts/build_core.py` recompile la skill sous le budget de 31 500 octets.
4. **Plancher.** Une obligation étiquetée `[REQUIS PAR LE MODULE — scope]` reçoit son plancher dans `PLANCHERS` de `scripts/validate_structure.py` : un bloc du noyau, une route du tronc des modes concernés, ou une ligne du noyau qui porte l’étiquette et nomme sa route, laquelle garde le texte complet.
5. **Guides.** Les guides renvoient à la règle par un lien vers son titre, sans la recopier ; un code en capitales cité a sa ligne au glossaire.
6. **Validation.** `python3 scripts/validate_all.py --require-browser`, ou la préparation de livraison décrite plus haut ; une règle qui change un comportement reçoit un test, et la mutation qui la casse doit le faire échouer.

Suite : [ce que contient la version](versions.md) et [l’évolution du système](evolution.md). Retour au [README](../README.md).
