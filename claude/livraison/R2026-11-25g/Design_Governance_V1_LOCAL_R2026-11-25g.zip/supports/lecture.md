# Lire peu, au bon moment.

V1.5.0 expérimentale. Vue dérivée : les sections propriétaires font foi.

Vue de lecture : les sections propriétaires font foi.

## 01 · Toujours lu

**Le noyau**. Les règles de chaque demande, une ligne par obligation, l’index de toutes les sections.


[Section propriétaire](../SKILL.md).

## 02 · Classer

**Le mode et le risque**. Une ligne de départ : mode, décision, risque, prochaine preuve et condition d’arrêt.


[Section propriétaire](../agent/chemins.md).

## 03 · Lire une fois

**Le tronc du mode**. Les sections que ce mode demande à chaque fois, écrites dans un fichier lu en entier.


[Section propriétaire](../agent/chemins.md).

## 04 · Au signal

**Les sections utiles**. Une section se lit quand son signal apparaît, par son code, plutôt que de mémoire.


[Section propriétaire](../guides/reference.md).

## 05 · Mesurer

**Les outils de la boucle**. Capturer, mesurer, comparer. Ils ne décident rien à la place de l’agent.


[Section propriétaire](../scripts/README.md).

## 06 · Sans outils

**Dire ce qui n’est pas vu**. Sans exécution de code, les règles restent dues ; ce qui demande une capture est non vérifié.


[Section propriétaire](../guides/1-utiliser.md).

## Un budget pour chaque lecture

**Un budget pour chaque lecture**. Le noyau tient en 31 500 octets au plus, le tronc d’un mode en 40 000 caractères. Un ajout se compense, il ne s’empile pas.


[Section propriétaire](../agent/chemins.md).

## La section fait foi

**La section fait foi**. Une ligne du noyau nomme sa section ; le texte complet y reste servi : l’obligation entière reste lisible.


[Section propriétaire](../SKILL.md).

## Un seul agent suffit

**Un seul agent suffit**. Aucune consigne ne suppose un second agent. Un regard séparé reste facultatif, si l’environnement le permet.


[Section propriétaire](../agent/chemins.md).

## Ce qui n’a pas été vu se déclare.

**Ce qui n’a pas été vu se déclare.** Une capture manquante ne devient jamais une réussite : l’agent nomme le contrôle qui manque et la prochaine preuve.

