# Référence

_Page générée par `scripts/reference.py` depuis les sources ; ne pas la modifier à la main. Après un changement d’outil ou de route : `python3 scripts/reference.py`._

Pour chercher un sujet plutôt qu’une commande : le [glossaire](glossaire.md) et le [niveau 2](2-comprendre.md).

## Commandes

### `read_route.py`

```text
usage: read_route.py [-h] [--trouver TERME] [--complet] [--tout] [--sommaire [LOCATOR]] [--guides]
                     [--connexions [Cxx]] [--mode {LITE,ITER,STANDARD,DIRECTION,SYSTÈME}]
                     [--tronc {LITE,ITER,STANDARD,DIRECTION,SYSTÈME}] [--etape NOM]
                     [--fichier CHEMIN]
                     [locator]

Charge un locator, trouve la route d’un terme ou expose les connexions situées.

positional arguments:
  locator               locator, par exemple DIRECTION/START ou SAVOIR/CRAFT/CFT-01

options:
  -h, --help            show this help message and exit
  --trouver TERME       routes classées où le terme ou ses alias apparaissent (mots entiers, casse
                        et accents ignorés)
  --complet             avec un locator : affiche aussi les blocs déjà compilés dans le noyau de
                        la skill
  --tout                avec --trouver : toutes les routes trouvées, pas seulement les premières
  --sommaire [LOCATOR]  liste des routes avec leur rôle, ou table des matières d’une route
  --guides              ajouter les documents d’orientation (guides, README racine, références de
                        la skill) à une recherche --trouver
  --connexions [Cxx]    sommaire des connexions situées, ou entrée Cxx
  --mode {LITE,ITER,STANDARD,DIRECTION,SYSTÈME}
                        ligne du mode déjà classé dans DIRECTION/CHARGE, sans charger les autres
                        modes ; SYSTEME accepte l’écriture sans accent
  --tronc {LITE,ITER,STANDARD,DIRECTION,SYSTÈME}
                        routes du tronc de la ligne du mode (lues à chaque run), servies à la
                        suite, avec leur taille ; code 1 au-delà de 40000 caractères
  --etape NOM           étape de la ligne DIRECTION (ESQUISSES, CONSTRUCTION) : ses routes servies
                        à la suite, au moment qu'elle nomme ; code 1 au-delà de 40000 caractères
  --fichier CHEMIN      avec --tronc ou --etape : écrit la lecture dans ce fichier, à lire une
                        seule fois, et n'affiche que ses routes et leur taille
```

### `parcours.py`

```text
usage: parcours.py [-h]
                   {captures,polices,finition,mouvement,verifier,references,critique,recette,tirage,chantier,leviers,typo,identite,icones,trace} ...

Parcours par défaut : captures, polices, signaux de finition, vérification.

positional arguments:
  {captures,polices,finition,mouvement,verifier,references,critique,recette,tirage,chantier,leviers,typo,identite,icones,trace}
    captures            premier écran, page entière et @2x à chaque largeur ; foyer agrandi
    polices             télécharge des polices ouvertes en woff2 et écrit polices.css
    finition            signaux mesurables de finition, chacun avec sa question et son geste
    mouvement           planche de mouvement : entrée image par image, défilement, survol,
                        mouvement réduit
    verifier            recette, regard, captures, finition, mouvement et planche en une passe ;
                        écrit parcours.md
    references          rassemble des références : sites donnés (premier écran, page entière,
                        sections, mesures), collections et banques sur demande, provenance relevée
    critique            prépare un regard séparé : images seules et consigne pour un agent neuf
    recette             affiche une recette de procédé (sans nom : la liste)
    tirage              tire au sort deux pistes du sujet et une dimension de registre, pour une
                        esquisse
    chantier            le démarrage en un appel : dossiers, tirage, leviers des pôles donnés,
                        gabarit de trace
    leviers             avant le build : leviers et piège des pôles de caractère choisis, ordre de
                        composition
    typo                espaces insécables du français et points de suspension, dans le texte
                        visible
    identite            planche d'épreuve d'un signe : échelle, noir, gris, inversé, sur photo,
                        avatar, onglet, en-tête, retourné ; signaux mesurés
    icones              télécharge des icônes Lucide (licence ISC) dans icones/, avec la licence
    trace               contrôle la forme de la trace légère : six lignes nommées, dans l'ordre ;
                        longueur et geste envisagé signalés

options:
  -h, --help            show this help message and exit
```

#### `parcours.py captures`

```text
usage: parcours.py captures [-h] [--largeurs LARGEURS] [--foyer FOYER] [--sortie SORTIE]
                            [--version VERSION] [--pleine] [--separees] [--contre CONTRE]
                            page

positional arguments:
  page

options:
  -h, --help           show this help message and exit
  --largeurs LARGEURS  largeurs en px, séparées par des virgules (défaut 1440,390)
  --foyer FOYER        sélecteur CSS de l'objet de preuve, capturé agrandi
  --sortie SORTIE      dossier (défaut : parcours-NOM à côté de la page)
  --version VERSION    capture rapide de la boucle : premiers écrans côte à côte en une image,
                       VERSION.png (v2.png)
  --pleine             avec --version : page entière sous le même nom (captures à livrer)
  --separees           avec --version : une image par largeur au lieu d'une planche
  --contre CONTRE      avec --version : l'esquisse retenue sur la même planche, au même cadrage ;
                       l'idée doit s'y lire aussi vite
```

#### `parcours.py polices`

```text
usage: parcours.py polices [-h] [--source {fontshare}] [--catalogue] [--sortie SORTIE]
                           [--integrer] [--etendu]
                           [specs ...]

positional arguments:
  specs                 "Famille:400,700i" ; graisses séparées par des virgules, i pour italique

options:
  -h, --help            show this help message and exit
  --source {fontshare}  chercher seulement dans Fontshare (sinon : Fontsource, Google Fonts, puis
                        Fontshare)
  --catalogue           liste les familles de Fontshare par catégorie, avec leur licence, pour
                        chercher hors des polices les plus vues
  --sortie SORTIE       dossier qui reçoit fonts/ et polices.css
  --integrer            intègre les fichiers en data: dans polices.css (page autonome)
  --etendu              ajoute le sous-ensemble latin-ext
```

#### `parcours.py finition`

```text
usage: parcours.py finition [-h] [--largeurs LARGEURS] page

positional arguments:
  page

options:
  -h, --help           show this help message and exit
  --largeurs LARGEURS  largeurs en px, séparées par des virgules (défaut 1440,390)
```

#### `parcours.py mouvement`

```text
usage: parcours.py mouvement [-h] [--largeur LARGEUR] [--action ACTION] [--sortie SORTIE] page

positional arguments:
  page

options:
  -h, --help         show this help message and exit
  --largeur LARGEUR  largeur en px (défaut 1440)
  --action ACTION    sélecteur CSS de l'action principale (son survol, et quand elle devient
                     visible)
  --sortie SORTIE    dossier (défaut : parcours-NOM à côté de la page)
```

#### `parcours.py verifier`

```text
usage: parcours.py verifier [-h] [--foyer FOYER] [--action ACTION] [--assert ASSERT_]
                            [--refs REFS] [--largeurs LARGEURS] [--mobile] [--sortie SORTIE]
                            [--complet]
                            page

positional arguments:
  page

options:
  -h, --help           show this help message and exit
  --foyer FOYER        sélecteur CSS de l'objet de preuve
  --action ACTION      sélecteur CSS de l'action principale, exigée dans le premier écran
  --assert ASSERT_     assertion transmise à check_render.py (répétable)
  --refs REFS          dossier de `references` : planche contre références et, pour les sites
                       mesurés, mesures de la page à côté des leurs
  --largeurs LARGEURS  largeurs en px, séparées par des virgules (défaut 1440,390) ; la recette de
                       rendu y ajoute 768 px
  --mobile             390 px seulement, recette comprise
  --sortie SORTIE      dossier (défaut : parcours-NOM à côté de la page)
  --complet            réaffiche toute la fiche, même quand rien n'a changé depuis l'appel
                       précédent
```

#### `parcours.py references`

```text
usage: parcours.py references [-h] [--url URL] [--commons COMMONS] [--openverse OPENVERSE]
                              [--aic AIC] [--polyhaven POLYHAVEN] [--pexels PEXELS]
                              [--pixabay PIXABAY] [--unsplash UNSPLASH]
                              [--fichier ADRESSE PAGE LICENCE] [--nombre NOMBRE] [--integrable]
                              [--sortie SORTIE]

options:
  -h, --help            show this help message and exit
  --url URL             adresse d'un site à capturer (répétable), trouvée avec l'outil de
                        recherche de l'environnement
  --commons COMMONS     requête dans Wikimedia Commons (répétable) ; les mots du lieu d'abord
  --openverse OPENVERSE
                        requête dans Openverse (répétable)
  --aic AIC             requête dans l'Art Institute of Chicago, domaine public seulement
                        (répétable)
  --polyhaven POLYHAVEN
                        requête dans Poly Haven, CC0 : textures et panoramas de lumière ; « hdri:
                        » ou « texture: » en tête restreint (répétable)
  --pexels PEXELS       requête dans Pexels ; clé PEXELS_API_KEY dans l'environnement (répétable)
  --pixabay PIXABAY     requête dans Pixabay ; « illustration: » ou « vector: » en tête ; clé
                        PIXABAY_API_KEY (répétable)
  --unsplash UNSPLASH   requête dans Unsplash ; clé UNSPLASH_ACCESS_KEY dans l'environnement
                        (répétable)
  --fichier ADRESSE PAGE LICENCE
                        fichier trouvé ailleurs, avec la page où sa licence a été lue et cette
                        licence (répétable)
  --nombre NOMBRE       images par requête (défaut 3)
  --integrable          seulement les images dont la licence permet usage commercial et recadrage
                        (ni NC ni ND)
  --sortie SORTIE       dossier (défaut : references)
```

#### `parcours.py critique`

```text
usage: parcours.py critique [-h] --brief BRIEF [--refs REFS] [--sortie SORTIE] page

positional arguments:
  page

options:
  -h, --help       show this help message and exit
  --brief BRIEF    la demande de la personne, telle quelle
  --refs REFS      dossier d'images de référence : ajoute la planche contre références
  --sortie SORTIE  dossier (défaut : critique-NOM à côté de la page)
```

#### `parcours.py recette`

```text
usage: parcours.py recette [-h] [nom]

positional arguments:
  nom

options:
  -h, --help  show this help message and exit
```

#### `parcours.py tirage`

```text
usage: parcours.py tirage [-h]

options:
  -h, --help  show this help message and exit
```

#### `parcours.py chantier`

```text
usage: parcours.py chantier [-h] [--dossier DOSSIER] [--poles POLES]

options:
  -h, --help         show this help message and exit
  --dossier DOSSIER  dossier du projet (défaut : le dossier courant)
  --poles POLES      un ou deux pôles de caractère, un par paire : « tension,précision »
```

#### `parcours.py leviers`

```text
usage: parcours.py leviers [-h] poles

positional arguments:
  poles       un ou deux pôles, un par paire, séparés par une virgule : « tension,précision »

options:
  -h, --help  show this help message and exit
```

#### `parcours.py typo`

```text
usage: parcours.py typo [-h] [--corriger] page

positional arguments:
  page

options:
  -h, --help  show this help message and exit
  --corriger  écrit les corrections dans la page
```

#### `parcours.py identite`

```text
usage: parcours.py identite [-h] [--marque-verbale VERBALE] [--photo PHOTO] [--sortie SORTIE]
                            signe

positional arguments:
  signe                 le signe, en SVG de préférence

options:
  -h, --help            show this help message and exit
  --marque-verbale VERBALE
                        la marque verbale (SVG), montrée dans les en-têtes
  --photo PHOTO         une photo ou une matière du sujet, sur laquelle poser le signe
  --sortie SORTIE       dossier (défaut : identite-NOM à côté du signe)
```

#### `parcours.py icones`

```text
usage: parcours.py icones [-h] [--sortie SORTIE] noms [noms ...]

positional arguments:
  noms             noms Lucide : arrow-right, check, clock…

options:
  -h, --help       show this help message and exit
  --sortie SORTIE
```

#### `parcours.py trace`

```text
usage: parcours.py trace [-h] fichier

positional arguments:
  fichier     fichier de trace, ou fichier livré dont l'en-tête porte la trace

options:
  -h, --help  show this help message and exit
```

### `check_render.py`

```text
usage: check_render.py [-h] [--widths WIDTHS] [--proof PROOF] [--click CLICK] [--wait-ms WAIT_MS]
                       [--wait-after-ms WAIT_AFTER_MS] [--assert EXPRESSION]
                       [--in-frame SÉLECTEUR[@CADRE]] [--tab-stops TAB_STOPS] [--allow-external]
                       [--json JSON] [--limites] [--captures DOSSIER] [--baseline JSON]
                       [--browser-executable CHEMIN] [--serve-local]
                       page

Recette AUTOMATED optionnelle d'un rendu HTML (ACTION/GATE-A).

positional arguments:
  page                  chemin d'un fichier HTML ou URL

options:
  -h, --help            show this help message and exit
  --widths WIDTHS       largeurs en px, séparées par des virgules
  --proof PROOF         sélecteur CSS de l'objet de preuve déclaré par l'auteur
  --click CLICK         sélecteur à cliquer avant la mesure (répétable)
  --wait-ms WAIT_MS     attente après chargement (animations d'entrée)
  --wait-after-ms WAIT_AFTER_MS
                        attente après les clics, pour observer l'état qui compte (chargement,
                        animation, résultat)
  --assert EXPRESSION   expression JavaScript qui doit valoir true à l'état observé (répétable) :
                        recoupe un texte calculé avec ses valeurs ; RETURN sinon
  --in-frame SÉLECTEUR[@CADRE]
                        chaque élément visible du sélecteur doit avoir son centre dans le cadre
                        (la fenêtre si @CADRE est omis), à l'état observé (répétable) ; RETURN
                        sinon
  --tab-stops TAB_STOPS
                        nombre maximal de tabulations observées
  --allow-external      laisser passer les requêtes vers d'autres origines
  --json JSON           écrit les résultats et la provenance dans ce fichier
  --limites             affiche le détail des limites de la recette (sinon une ligne)
  --captures DOSSIER    écrit une capture pleine page par largeur (capture-<largeur>px.png), à
                        l'état observé ; n'écrase rien
  --baseline JSON       comparer à une mesure --json antérieure du même périmètre (défauts
                        introduits, préexistants ou disparus)
  --browser-executable CHEMIN
                        Chromium installé à utiliser explicitement (ou DG_BROWSER_EXECUTABLE) ;
                        sinon navigateur Playwright
  --serve-local         servir le fichier et ses ressources sur 127.0.0.1 pour cette mesure (ou
                        DG_RENDER_SERVE_LOCAL=1)
```

### `planche.py`

```text
usage: planche.py [-h] [--etiquettes ETIQUETTES] [--colonnes COLONNES] [--bureau BUREAU]
                  [--mobile MOBILE] [--bureau-seul]
                  sortie pages [pages ...]

Planche de premiers écrans, bureau et mobile (ou bureau seul), côte à côte.

positional arguments:
  sortie                image PNG à écrire
  pages                 pages HTML ; la première sert de référence (la modale)

options:
  -h, --help            show this help message and exit
  --etiquettes ETIQUETTES
                        libellés séparés par des virgules, dans l'ordre des pages
  --colonnes COLONNES
  --bureau BUREAU       largeur x hauteur du premier écran bureau
  --mobile MOBILE       largeur x hauteur du premier écran mobile
  --bureau-seul         comparer les esquisses au bureau seulement, pour un produit d’abord au
                        bureau ; le mobile se construit sur la direction gardée
```

### `regard.py`

```text
usage: regard.py [-h] [--foyer FOYER] [--largeurs LARGEURS] [--hauteur HAUTEUR] [--sortie SORTIE]
                 [--attention ATTENTION] [--antecedent ANTECEDENT]
                 page

Fiche de regard d'un rendu HTML (signaux, pas verdicts).

positional arguments:
  page

options:
  -h, --help            show this help message and exit
  --foyer FOYER         sélecteur CSS du foyer déclaré
  --largeurs LARGEURS
  --hauteur HAUTEUR
  --sortie SORTIE       dossier de la fiche ; par défaut regard-NOM, à côté de la page
  --attention ATTENTION
                        classique | onnx:CHEMIN/model.onnx
  --antecedent ANTECEDENT
                        rendu HTML précédent à comparer (paire typographique, teinte dominante,
                        registre)
```

## Sections servies par le lecteur

85 sections, chacune lue par son code : `python3 scripts/read_route.py CODE`.

### DIRECTION

| Code | Sujet |
|---|---|
| `DIRECTION/ANCHOR-RESERVE` | réserve ANCHOR-GENERATED en enjeu identitaire élevé |
| `DIRECTION/ASSET-ROUTE` | décider la route de production |
| `DIRECTION/CADRES` | correspondance des cadres |
| `DIRECTION/CAPACITY` | cadrage de médium et de capacité |
| `DIRECTION/CHARGE` | classer, puis charger |
| `DIRECTION/CREATIVE-BOOT` | activer la boucle avant le premier pixel |
| `DIRECTION/DIRECTION-ATELIER` | module officiel de direction située |
| `DIRECTION/DIVERGENCE` | direction divergente, déclenchement |
| `DIRECTION/DOMAIN-FRAME` | adapter le design au domaine |
| `DIRECTION/DOUBLE-LOOP` | créer puis apprendre |
| `DIRECTION/EXTERNAL-START` | activation portable sur brief vague |
| `DIRECTION/FAST-PATH` | renvoi vers l’exécution courte |
| `DIRECTION/FIRST-OBJECT` | compiler le brief et produire le premier objet |
| `DIRECTION/GROUNDING` | grounding contestable |
| `DIRECTION/LECTURE-INSTRUMENTEE` | lecture instrumentée d’un run |
| `DIRECTION/REUSE` | réutilisation située |
| `DIRECTION/SERVICE-BOUNDARY` | ne pas confondre relation et contrat |
| `DIRECTION/STANDARD` | les cinq règles absolues |
| `DIRECTION/START` | classer avant d’agir |
| `DIRECTION/VISUAL_TARGET` | rendre la direction pilotable |

### ACTION

| Code | Sujet |
|---|---|
| `ACTION/ANTI-SLOP` | conséquence au contrôle d'un motif générique |
| `ACTION/ATELIER-EDITION` | opération observable |
| `ACTION/AUTHORITY` | portée d’action et reprise |
| `ACTION/CLOSE-EXIT-CHECK` | test de sortie canonique |
| `ACTION/CLOSE-PACKAGE` | paquet de clôture |
| `ACTION/FAST-PATH` | preuve minimale sans rituel |
| `ACTION/FIRST-RENDER` | qualité initiale attendue |
| `ACTION/GATE-A` | plancher objectivable |
| `ACTION/GATE-B` | jugement contextualisé et risques |
| `ACTION/GATE-C` | craft sur rendu réel |
| `ACTION/HANDOFF` | sortie minimale commune |
| `ACTION/MAINTENANCE` | recette documentaire |
| `ACTION/OVERRIDE` | FAIL-ASSUMED et péremption |
| `ACTION/PIPELINE-DIRECTION` | direction vérifiable |
| `ACTION/POLICIES` | contraste et inspection |
| `ACTION/PRECONDITION` | mode, capacité et preuve |
| `ACTION/RECETTE-RENDU` | recette de rendu check_render.py |
| `ACTION/ROUTING` | prérequis de jugement et de structure |
| `ACTION/RUN` | routes d’exécution |
| `ACTION/RUN-DIRECTION` | exécution du mode DIRECTION |
| `ACTION/RUN-ITER` | exécution du mode ITER |
| `ACTION/RUN-LITE` | exécution du mode LITE |
| `ACTION/RUN-STANDARD` | exécution du mode STANDARD |
| `ACTION/RUN-SYSTEM` | exécution du mode SYSTÈME |
| `ACTION/RUN_CARD` | carte de run minimale |
| `ACTION/STATUS` | états, issues et verdicts |
| `ACTION/STRUCTURED-PROOF` | contrats de décision et leur preuve |
| `ACTION/UI-UX-REALITY` | construire l’interface et la tâche ensemble |
| `ACTION/VISUAL_PROOF` | rendre la direction vérifiable |

### SAVOIR

| Code | Sujet |
|---|---|
| `SAVOIR/CONTEXT` | accessibilité, contexte et robustesse |
| `SAVOIR/CRAFT` | anti-slop, composition et expression |
| `SAVOIR/DESIGN-ATLAS` | familles et responsabilités |
| `SAVOIR/FRAME` | fondations et cadrage |
| `SAVOIR/IDENTITY` | signe, déclinaisons et épreuves |
| `SAVOIR/INTEGRITY` | limites, délégation et critique |
| `SAVOIR/JUGEMENT-COURT` | juger sans produire un dossier |
| `SAVOIR/READ` | comment utiliser cette bibliothèque |
| `SAVOIR/ROUTING` | routes stables |
| `SAVOIR/SOURCE` | ancre et sourcing visuel |
| `SAVOIR/STATE` | craft, composants et états |
| `SAVOIR/STYLE` | profils contrôlés et dials |
| `SAVOIR/SYSTEM` | jetons de design et composants |
| `SAVOIR/TECH` | techniques, tests et stack |
| `SAVOIR/TOOLS` | claims, tendances et calibration |
| `SAVOIR/TYPE` | typographie et données |
| `SAVOIR/TYPE-VOIX` | trouver, apparier et comparer des voix |

### BIBLIOTHEQUE

| Code | Sujet |
|---|---|
| `BIBLIOTHEQUE/AVANT-SELECTION` | vérifier avant de sélectionner |
| `BIBLIOTHEQUE/COMPAT` | combiner avec une raison |
| `BIBLIOTHEQUE/COMPONENTS` | couches et dépendances |
| `BIBLIOTHEQUE/CONTRACTS` | contrat commun de route |
| `BIBLIOTHEQUE/DERIVE` | inventer sans fabriquer un menu |
| `BIBLIOTHEQUE/EVOLUTION` | promotion et dépréciation |
| `BIBLIOTHEQUE/GATE` | contrôle de module structurel complémentaire |
| `BIBLIOTHEQUE/GRID` | comment le regard circule |
| `BIBLIOTHEQUE/MICRO` | unités denses |
| `BIBLIOTHEQUE/MODIFIER` | comportements transversaux |
| `BIBLIOTHEQUE/OBJECT` | quelle preuve devient tangible |
| `BIBLIOTHEQUE/READ` | responsabilités et convention de route |
| `BIBLIOTHEQUE/SCENE` | comment la promesse devient une surface |
| `BIBLIOTHEQUE/SECTIONS` | sections ordinaires d’une page |
| `BIBLIOTHEQUE/SELECT` | choisir avant de composer |
| `BIBLIOTHEQUE/SEQUENCE` | comment la page s’enchaîne |
| `BIBLIOTHEQUE/SIGNATURE` | rendre l’écart vérifiable |
| `BIBLIOTHEQUE/SUPPORT` | où la surface vit |
| `BIBLIOTHEQUE/TENSION` | diverger avant de sélectionner |
