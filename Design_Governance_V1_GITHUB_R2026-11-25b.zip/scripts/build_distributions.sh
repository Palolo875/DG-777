#!/usr/bin/env bash
set -euo pipefail

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
DIST="$ROOT/dist"
WORK="$ROOT/.build"
BACKUP="$ROOT/.dist.previous"

ARCHIVES_BACKUP="$ROOT/.archives.previous"
ZIPS=(Design_Governance_V1_GITHUB.zip Design_Governance_V1_LOCAL.zip)
LOCK="$ROOT/.distribution.lock"
RUN=""
if ! mkdir "$LOCK" 2>/dev/null; then
  echo "BUILD FAILED — verrou de construction présent ($LOCK) ; ne pas lancer deux builds simultanément" >&2
  if [[ -f "$LOCK/owner.txt" ]]; then cat "$LOCK/owner.txt" >&2; fi
  echo "Diagnostic et reprise manuelle : maintenance/README.md, section Reprendre une préparation interrompue" >&2
  exit 1
fi
cleanup() {
  if [[ -n "$RUN" ]]; then rm -rf "$RUN"; fi
  rm -f "$LOCK/owner.txt"
  rmdir "$LOCK"
}
trap cleanup EXIT
printf 'pid=%s\nstarted_utc=%s\nroot=%s\n' "$$" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$ROOT" > "$LOCK/owner.txt"

# Même contrôle sur la source canonique avant staging, puis sur chaque projection.
python3 "$ROOT/scripts/build_core.py" --check

# Une sauvegarde d’archives laissée par une restauration incomplète n’est ni restaurée à
# l’aveugle ni supprimée (impossible de savoir quelles archives en place sont neuves).
if [[ -e "$ARCHIVES_BACKUP" ]]; then
  echo "BUILD FAILED — sauvegarde d’archives $ARCHIVES_BACKUP présente : résolution manuelle requise (aucune suppression)" >&2
  exit 1
fi
# Une sauvegarde laissée par un échec précédent est restaurée, jamais supprimée.
if [[ -e "$BACKUP" ]]; then
  if [[ -e "$DIST" ]]; then
    echo "BUILD FAILED — sauvegarde $BACKUP et $DIST présents ensemble : résolution manuelle requise (aucune suppression)" >&2
    exit 1
  fi
  mv "$BACKUP" "$DIST"
  echo "dist antérieur restauré depuis la sauvegarde d’un échec précédent"
fi
mkdir -p "$WORK"
RUN=$(mktemp -d "$WORK/distributions.XXXXXX")
STAGE="$RUN/dist"
ARCHIVES="$RUN/archives"
mkdir -p "$STAGE/github" "$STAGE/local" "$ARCHIVES"

# Les deux distributions sont copiées depuis le manifeste (`scripts/package_manifest.json`), sa liste
# « github » puis sa liste « local » : ajouter un fichier au paquet, c’est l’ajouter au manifeste.
# Un fichier absent du manifeste n’entre pas ; un fichier listé mais absent fait échouer le build.
python3 - "$ROOT" "$STAGE" <<'PY'
import json
import shutil
import sys
from pathlib import Path

root, stage = Path(sys.argv[1]), Path(sys.argv[2])
manifest = json.loads((root / "scripts" / "package_manifest.json").read_text(encoding="utf-8"))
for kind in ("github", "local"):
    for relative in manifest[kind]:
        source = root / relative
        if not source.is_file():
            raise SystemExit(f"BUILD FAILED — fichier du manifeste ({kind}) absent de la source : {relative}")
        target = stage / kind / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target, follow_symlinks=False)
    print(f"COPIE {kind.upper()} — {len(manifest[kind])} fichiers du manifeste")
PY

# README du Local : les passages balisés `github:début ID` / `github:fin ID` (installation par
# dépôt, CI, outils de construction) sont remplacés par leur variante locale ; la distribution
# GitHub garde ces balises, invisibles au rendu. Un passage balisé sans variante, ou une variante
# sans passage, fait échouer le build.
python3 - "$STAGE/local/README.md" <<'PY'
import re
import sys
from pathlib import Path

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
LOCAL = {
    "installation": """Copiez ce dossier dans le dossier de skills de votre agent, sous ce nom ; par exemple, pour Claude Code dans le projet :

```bash
mkdir -p .claude/skills
cp -R chemin/vers/ce/dossier .claude/skills/design-governance-practice
```

| Agent | Dossier du projet | Dossier personnel |
|---|---|---|
| Claude Code | `.claude/skills/` | `~/.claude/skills/` |
| Codex | `.agents/skills/` | `~/.agents/skills/` |
| Cursor, Gemini CLI, GitHub Copilot | `.agents/skills/` | `~/.cursor/skills/`, `~/.gemini/skills/`, `~/.copilot/skills/` |

Pour mettre à jour, remplacez le dossier installé par le nouvel export complet, sans fusionner les deux versions.""",
    "titre-contenu": "## Ce que contient le paquet",
    "outils": "Lecteur de routes, recette de rendu, planche de comparaison, commande de regard, parcours par défaut (une passe : recette, regard, captures, signaux de finition, planche de mouvement, regard séparé), journal de mobilisation, compilation du noyau et contrôles du paquet ; chaque commande est décrite dans [la validation](maintenance/README.md#validation).",
    "limite-ci": "Les contrôles inclus (`python3 scripts/validate_all.py`, voir les [notes de version](RELEASE_NOTES.md#contrôles-inclus)) attestent la cohérence du paquet, pas cette efficacité.",
}
pattern = re.compile(r"<!-- github:début ([a-z-]+) -->\n?(.*?)\n?<!-- github:fin \1 -->", re.S)
found = pattern.findall(text)
ids = [i for i, _ in found]
if len(ids) != len(set(ids)) or set(ids) != set(LOCAL):
    raise SystemExit(f"BUILD FAILED — README Local : passages balisés {sorted(ids)} ≠ variantes {sorted(LOCAL)}")
text = pattern.sub(lambda m: LOCAL[m.group(1)], text)
if "github:" in text:
    raise SystemExit("BUILD FAILED — README Local : balise github restante")
path.write_text(text, encoding="utf-8")
print(f"README LOCAL — {len(LOCAL)} passages remplacés par leur variante locale")
PY

# Vérification des deux distributions avant archivage. Sous DG_BUILD_REPRODUCTIBILITE (posée par validate_all.py
# pour son second build seulement), ces contrôles sont sautés : ils ont déjà passé sur le même contenu au premier
# build, et le second ne sert qu’à comparer les archives. Le contrôle des membres d’archive tourne toujours.
if [[ -n "${DG_BUILD_REPRODUCTIBILITE:-}" ]]; then
  echo "CONTRÔLES DES DISTRIBUTIONS SAUTÉS — build de reproductibilité (contrôles passés au build précédent, même contenu)"
else
python3 "$STAGE/github/scripts/validate_design_governance.py"
python3 "$STAGE/github/gouvernance/outils/validate_run_card.py"
python3 "$STAGE/github/gouvernance/outils/validate_contracts.py"
python3 "$STAGE/github/scripts/validate_reading_map.py"
python3 "$STAGE/github/scripts/validate_structure.py"
python3 "$STAGE/github/scripts/validate_supports.py"

# Valider les chemins relatifs du Local indépendamment, sans exiger la structure GitHub.
python3 - "$STAGE/local" <<'PY'
from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
import json
manifest = json.loads((root / "scripts" / "package_manifest.json").read_text(encoding="utf-8"))
expected = manifest["local"]
for relative in expected:
    if not (root / relative).is_file():
        raise SystemExit(f"Local export missing: {relative}")
for path in root.rglob("*.md"):
    text = path.read_text(encoding="utf-8")
    for target in re.findall(r"\]\(([^)]+)\)", text):
        target = target.split("#", 1)[0]
        if not target or target.startswith(("http://", "https://", "mailto:")):
            continue
        if not (path.parent / target).exists():
            raise SystemExit(f"Broken Local link: {path} -> {target}")
    # Chemins `.md` cités entre accents graves (avec un dossier), depuis la racine ou le fichier.
    # Un chemin entre accents graves ; pas la suite « ](… » d'un lien Markdown placé après un nom entre accents graves.
    for target in re.findall(r"`([^`\s\[\]()]+/[^`\s()]*\.md)(?:#[^`\s]*)?`", text):
        if not ((root / target).exists() or (path.parent / target).exists()):
            raise SystemExit(f"Broken Local path: {path} -> {target}")
print(f"LOCAL EXPORT PASSED — {len(expected)} fichiers attendus et liens contrôlés")
PY
python3 "$STAGE/local/scripts/validate_design_governance.py"
python3 "$STAGE/local/gouvernance/outils/validate_run_card.py"
python3 "$STAGE/local/gouvernance/outils/validate_contracts.py"
python3 "$STAGE/local/scripts/validate_reading_map.py"
python3 "$STAGE/local/scripts/validate_structure.py"
# Les tests de pages ont déjà tourné sur ce même code avant le build : l’export Local les déclare NOT-VERIFIED ici.
# L'export Local reprend les fichiers de la source, dont validate_all.py vient de passer tous les tests : on vérifie
# qu'ils sont identiques octet pour octet (README à part, qui reçoit ses variantes locales), puis on ne relance que
# l'essentiel (validations, RUN_CARD, CLI) au lieu de toute la suite.
python3 "$ROOT/scripts/validate_all.py" --identite-locale "$STAGE/local"
python3 "$STAGE/local/scripts/validate_all.py" --essentiel
fi

# Archives déterministes du contenu, sans répertoire de travail caché.
# Le build nettoie aussi les caches éventuels avant de copier les sources.
find "$STAGE/github" "$STAGE/local" -type d -name '__pycache__' -prune -exec rm -rf {} +
# Date des fichiers archivés : celle du dernier commit, identique d'un build à l'autre pour un même commit ;
# hors dépôt git, une date fixe (2026-01-01), déclarée ici, plutôt que l'origine du calendrier (1970).
if [[ -z "${SOURCE_DATE_EPOCH:-}" ]]; then
  SOURCE_DATE_EPOCH=$(git -C "$ROOT" log -1 --format=%ct 2>/dev/null || true)
  SOURCE_DATE_EPOCH="${SOURCE_DATE_EPOCH:-1767225600}"
fi
find "$STAGE/github" "$STAGE/local" -exec touch -h -d "@$SOURCE_DATE_EPOCH" {} +
# Archives créées dans le répertoire de travail, à partir d’un fichier absent.
(
  cd "$STAGE/github"
  LC_ALL=C find . -type f -print | sort | zip -X -q "$ARCHIVES/Design_Governance_V1_GITHUB.zip" -@
)
(
  cd "$STAGE/local"
  LC_ALL=C find . -type f -print | sort | zip -X -q "$ARCHIVES/Design_Governance_V1_LOCAL.zip" -@
)

# Membres de chaque archive = liste du manifeste, à l’identique, avant publication.
python3 - "$ROOT/scripts/package_manifest.json" "$ARCHIVES" <<'PY'
import json
import sys
import zipfile
from pathlib import Path

manifest = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
archives = Path(sys.argv[2])
for kind, name in (("github", "Design_Governance_V1_GITHUB.zip"), ("local", "Design_Governance_V1_LOCAL.zip")):
    with zipfile.ZipFile(archives / name) as archive:
        members = [info.filename for info in archive.infolist() if not info.is_dir()]
    expected = manifest[kind]
    if len(members) != len(set(members)) or set(members) != set(expected) or len(members) != len(expected):
        extra = sorted(set(members) - set(expected))
        missing = sorted(set(expected) - set(members))
        raise SystemExit(f"BUILD FAILED — membres de l’archive ≠ manifeste ({kind}) : en plus {extra} ; manquants {missing}")
print("ARCHIVE MEMBERS PASSED — membres = manifeste (GitHub et Local)")
PY

# Publier uniquement après validations et archivage réussis.
# Promotion transactionnelle ; en cas d’échec, la sauvegarde est restaurée avant tout nettoyage.
# La transaction couvre dist ET les deux archives ; un échec à n’importe quelle étape remet
# l’ensemble antérieur (dist et archives), puis une relance normale repart d’un état propre.
saved=" " published=" " dist_promoted=0
rollback() {
  local ok=1 name
  for name in "${ZIPS[@]}"; do
    if [[ "$saved" == *" $name "* ]]; then
      mv -f "$ARCHIVES_BACKUP/$name" "$ROOT/$name" || ok=0
    elif [[ "$published" == *" $name "* ]]; then
      rm -f "$ROOT/$name" || ok=0  # aucune archive antérieure : l’archive neuve est retirée
    fi
  done
  if (( dist_promoted )); then
    if [[ -e "$BACKUP" ]]; then
      { rm -rf "$DIST" && mv "$BACKUP" "$DIST"; } || ok=0
    else
      rm -rf "$DIST" || ok=0  # aucun dist antérieur : le dist neuf est retiré
    fi
  elif [[ -e "$BACKUP" && ! -e "$DIST" ]]; then
    mv "$BACKUP" "$DIST" || ok=0
  fi
  if (( ok )); then
    rmdir "$ARCHIVES_BACKUP" 2>/dev/null || true
    echo "BUILD FAILED — $1 ; dist et archives antérieurs restaurés" >&2
  else
    echo "BUILD FAILED — $1 ; restauration incomplète : sauvegardes conservées ($BACKUP, $ARCHIVES_BACKUP), résolution manuelle requise" >&2
  fi
  exit 1
}
mkdir "$ARCHIVES_BACKUP"
for name in "${ZIPS[@]}"; do
  if [[ -e "$ROOT/$name" ]]; then
    mv "$ROOT/$name" "$ARCHIVES_BACKUP/$name" || rollback "sauvegarde de $name impossible"
    saved+="$name "
  fi
done
if [[ -e "$DIST" ]]; then
  mv "$DIST" "$BACKUP" || rollback "sauvegarde de dist impossible"
fi
mv "$STAGE" "$DIST" || rollback "promotion de dist impossible"
dist_promoted=1
for name in "${ZIPS[@]}"; do
  mv -f "$ARCHIVES/$name" "$ROOT/$name" || rollback "publication de $name impossible"
  published+="$name "
done
rm -rf "$BACKUP" "$RUN" "$ARCHIVES_BACKUP"

printf 'Generated:\n  %s\n  %s\n' \
  "$ROOT/Design_Governance_V1_GITHUB.zip" \
  "$ROOT/Design_Governance_V1_LOCAL.zip"
