#!/usr/bin/env python3
"""Planches de principes : un mécanisme par planche, en avant/après sur un même contenu neutre.

Chaque planche montre un mécanisme déjà écrit dans le savoir, jamais un style à reprendre : le contenu est neutre
(barres grises à la place du texte courant, titres génériques) et seule la variable du mécanisme change d'un panneau
à l'autre. Police : Manrope, livrée avec le paquet (`supports/fonts/`).

Usage : python3 scripts/principes.py [--sortie design/principes]   (Playwright, Chromium et Pillow requis)
"""
from __future__ import annotations

import argparse
import base64
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POLICE = ROOT / "supports" / "fonts" / "manrope.ttf"
L, H = 1600, 900

BASE = """
@font-face{font-family:M;src:url(data:font/ttf;base64,__FONT__) format('truetype');font-weight:200 800}
*{box-sizing:border-box}
body{margin:0;width:1600px;height:900px;background:#efefec;font-family:M,sans-serif;color:#1d1d1b;
 font-feature-settings:'pnum'}
.tete{position:absolute;left:64px;top:40px;right:64px;display:flex;justify-content:space-between;align-items:baseline}
.tete h1{margin:0;font-size:30px;font-weight:700;letter-spacing:-.01em}
.tete .code{font-size:17px;color:#55554f;font-weight:500}
.q{position:absolute;left:64px;top:86px;font-size:18px;color:#3a3a36;font-weight:500}
.p{position:absolute;top:140px;width:712px;height:620px}
.p.a{left:64px}.p.b{left:824px}
.etiquette{font-size:15px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#55554f;margin:0 0 12px}
.cadre{background:#fff;height:540px;position:relative;overflow:hidden;border:1px solid #d9d9d4}
.leg{position:absolute;top:782px;width:712px;font-size:19px;line-height:1.35;font-weight:500}
.leg.a{left:64px}.leg.b{left:824px}
.bar{height:10px;border-radius:5px;background:currentColor;opacity:.28;margin:9px 0}
"""


def page(titre: str, code: str, question: str, gauche: tuple[str, str, str], droite: tuple[str, str, str], css: str) -> str:
    fonte = base64.b64encode(POLICE.read_bytes()).decode()
    (ea, ca, la), (eb, cb, lb) = gauche, droite
    return (f"<!doctype html><html lang='fr'><meta charset='utf-8'><style>{BASE.replace('__FONT__', fonte)}{css}</style><body>"
            f"<div class='tete'><h1>{titre}</h1><span class='code'>{code}</span></div><div class='q'>{question}</div>"
            f"<div class='p a'><p class='etiquette'>{ea}</p><div class='cadre'>{ca}</div></div>"
            f"<div class='p b'><p class='etiquette'>{eb}</p><div class='cadre'>{cb}</div></div>"
            f"<div class='leg a'>{la}</div><div class='leg b'>{lb}</div></body></html>")


def bars(n: int, w=(92, 84, 60)) -> str:
    return "".join(f"<div class='bar' style='width:{w[i % len(w)]}%'></div>" for i in range(n))


# ---------------------------------------------------------------- 1. Fonds voisins
def fonds_voisins() -> str:
    css = """.bandes{height:330px;display:flex;flex-direction:column}.bandes>div{flex:1;padding:22px 34px}
.bandes h2{margin:0 0 4px;font-size:22px;font-weight:700}
.note{height:34px;padding:9px 34px 0;font-size:13px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#55554f}
.gris{height:176px;display:flex;flex-direction:column;filter:grayscale(1)}.gris>div{flex:1}"""
    def panneau(fonds, textes):
        haut = "".join(f"<div style='background:{f};color:{t}'><h2>Section</h2>{bars(1)}</div>" for f, t in zip(fonds, textes))
        bas = "".join(f"<div style='background:{f}'></div>" for f in fonds)
        return f"<div class='bandes'>{haut}</div><div class='note'>Les mêmes fonds, en niveaux de gris</div><div class='gris'>{bas}</div>"
    teinte = ["oklch(0.82 0.07 250)", "oklch(0.82 0.07 150)", "oklch(0.82 0.07 40)"]
    valeur = ["oklch(0.97 0.01 250)", "oklch(0.86 0.035 250)", "oklch(0.32 0.04 250)"]
    return page("Fonds voisins", "SAVOIR/CRAFT/CFT-05 — Relations de couleur",
                "Deux fonds de section voisins se distinguent-ils encore sans leur teinte ?",
                ("Teinte seule", panneau(teinte, ["#1d1d1b"] * 3),
                 "Trois teintes à luminosité égale : en niveaux de gris, les sections se confondent."),
                ("Écart de luminosité", panneau(valeur, ["#1d1d1b", "#1d1d1b", "#f2f2ee"]),
                 "Une teinte, trois luminosités : en niveaux de gris, chaque section reste distincte."), css)


# ---------------------------------------------------------------- 2. Accent de foyer
def accent() -> str:
    css = """.ui{padding:40px 44px}.ui h2{margin:0 0 14px;font-size:30px;font-weight:700}
.ligne{display:flex;gap:14px;align-items:center;margin:0 0 18px}.pastille{font-size:14px;font-weight:700;padding:5px 12px;border-radius:999px}
.lien{font-size:17px;font-weight:600;text-decoration:underline;text-underline-offset:4px}
.ico{width:22px;height:22px;border-radius:6px}.btn{display:inline-block;margin-top:26px;padding:15px 26px;border-radius:10px;font-size:18px;font-weight:700}
.sec{display:inline-block;margin:26px 0 0 18px;font-size:18px;font-weight:600}"""
    acc = "oklch(0.55 0.19 30)"
    def ui(partout: bool):
        c = acc if partout else "#1d1d1b"
        pas = f"background:{acc};color:#fff" if partout else "background:#ececE7;color:#3a3a36"
        ico = acc if partout else "#c9c9c3"
        return (f"<div class='ui'><div class='ligne'><span class='pastille' style='{pas}'>Nouveau</span>"
                f"<span class='pastille' style='{pas}'>Offre</span></div>"
                f"<h2 style='color:{c if partout else '#1d1d1b'}'>Titre de l’écran</h2>{bars(3)}"
                + "".join(f"<div class='ligne'><span class='ico' style='background:{ico}'></span><span class='lien' style='color:{c}'>Lien secondaire</span></div>" for _ in range(3))
                + f"<span class='btn' style='background:{acc};color:#fff'>Action principale</span>"
                + f"<span class='sec' style='color:{c}'>Autre action</span></div>")
    return page("Accent de foyer", "SAVOIR/CRAFT/CFT-05 — Relations de couleur",
                "L’accent désigne-t-il encore quelque chose ?",
                ("Accent partout", ui(True), "Titre, pastilles, icônes, liens et bouton en accent : rien n’est désigné."),
                ("Accent sur l’action seule", ui(False), "Les neutres portent le reste : l’œil va d’abord à l’action principale."), css)


# ---------------------------------------------------------------- 3. Masse visuelle
def masse() -> str:
    css = """.sc{position:relative;height:100%;padding:44px}.chiffre{font-size:120px;font-weight:800;letter-spacing:-.03em;line-height:1}
.unite{font-size:22px;font-weight:600;color:#55554f;margin-top:6px}.deco{position:absolute;border-radius:50%}
.lab{font-size:16px;font-weight:600;color:#55554f;margin-bottom:10px}"""
    gauche = ("<div class='sc'><div class='lab'>Objet de preuve</div><div class='chiffre' style='font-size:56px'>38</div>"
              "<div class='unite' style='font-size:16px'>places ce soir</div>" + bars(2) +
              "<div class='deco' style='width:400px;height:400px;right:-60px;top:110px;background:#2b2b28'></div>"
              "<div class='deco' style='width:150px;height:150px;right:60px;top:40px;background:#8e8e86'></div></div>")
    droite = ("<div class='sc'><div class='lab'>Objet de preuve</div><div class='chiffre'>38</div>"
              "<div class='unite'>places ce soir</div><div style='width:60%'>" + bars(2) + "</div>"
              "<div class='deco' style='width:180px;height:180px;right:40px;top:300px;background:#e4e4de'></div></div>")
    return page("Masse visuelle", "SAVOIR/STATE — Masse visuelle",
                "Qu’est-ce qui pèse le plus sur l’image : la preuve ou le décor ?",
                ("Le décor pèse le plus", gauche, "Deux formes sombres et grandes attirent l’œil ; le chiffre qui prouve passe après."),
                ("La preuve pèse le plus", droite, "Le chiffre prend l’échelle et le contraste ; le décor recule, clair et petit."), css)


# ---------------------------------------------------------------- 4. Grand titre réglé
def grand_titre() -> str:
    css = """.t{padding:56px 44px 0;font-size:92px;font-weight:700;margin:0}"""
    texte = "Un titre sur deux lignes"
    return page("Grand titre réglé", "SAVOIR/TYPE — Réglage d’un grand texte",
                "Le titre se lit-il comme un seul bloc ?",
                ("Réglages du texte courant", f"<h2 class='t' style='line-height:1.5;letter-spacing:.01em'>{texte}</h2>",
                 "Interligne 1,5 et approche du corps, à 92 px : les deux lignes se séparent."),
                ("Réglé pour sa taille", f"<h2 class='t' style='line-height:1.0;letter-spacing:-.025em'>{texte}</h2>",
                 "Interligne près de 1, approche resserrée : les deux lignes forment un bloc."), css)


# ---------------------------------------------------------------- 5. Cohérence de rayon
def rayons() -> str:
    css = """.zone{height:100%;display:flex;align-items:center;justify-content:center;gap:40px}
.carte{width:300px;height:380px;background:#dcdcd6;padding:18px;border-radius:30px}.img{height:100%;background:#5e5e57}
.zoom{width:220px;height:220px;overflow:hidden;border:1px solid #c9c9c3;position:relative;background:#fff}
.zoom .carte{transform:scale(3.2);transform-origin:0 0;position:absolute;left:0;top:0}"""
    def zone(r_int):
        c = f"<div class='carte'><div class='img' style='border-radius:{r_int}px'></div></div>"
        return f"<div class='zone'>{c}<div class='zoom'>{c}</div></div>"
    return page("Cohérence de rayon", "SAVOIR/STATE — Cohérence de rayon",
                "Le cadre et son contenu emboîté sont-ils concentriques ?",
                ("Même rayon dedans et dehors", zone(30), "Rayon intérieur égal au rayon extérieur (30 px) : l’écart s’épaissit dans le coin."),
                ("Rayon intérieur = extérieur − marge", zone(12), "30 − 18 = 12 px : l’écart reste égal tout autour du coin."), css)


# ---------------------------------------------------------------- 6. Chiffres
def chiffres() -> str:
    css = """table{margin:44px;border-collapse:collapse;font-size:30px;font-weight:600}td{padding:10px 0;border-bottom:1px solid #e4e4de}
td.l{width:300px;font-weight:500;color:#3a3a36;font-size:22px}"""
    lignes = [("Janvier", "1 240,50 €"), ("Février", "87,00 €"), ("Mars", "19 990,00 €"), ("Avril", "311,10 €")]
    def table(tab: bool):
        st = "font-feature-settings:'tnum';text-align:right;width:260px" if tab else "font-feature-settings:'pnum';text-align:left;width:260px"
        return "<table>" + "".join(f"<tr><td class='l'>{m}</td><td style=\"{st}\">{v}</td></tr>" for m, v in lignes) + "</table>"
    return page("Chiffres", "SAVOIR/STATE — Chiffres",
                "Une colonne de montants se compare-t-elle d’un coup d’œil ?",
                ("Chiffres proportionnels, alignés à gauche", table(False), "Les virgules et les unités ne s’alignent pas : comparer demande de lire chaque ligne."),
                ("Chiffres tabulaires, alignés à droite", table(True), "Mêmes largeurs, virgules sur un axe : l’ordre de grandeur se voit sans lire."), css)


PLANCHES = {"fonds-voisins": fonds_voisins, "accent-de-foyer": accent, "masse-visuelle": masse,
            "grand-titre": grand_titre, "rayons": rayons, "chiffres": chiffres}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Planches de principes, en PNG.")
    ap.add_argument("--sortie", default=str(ROOT / "design" / "principes"))
    a = ap.parse_args(argv)
    sortie = Path(a.sortie)
    sortie.mkdir(parents=True, exist_ok=True)
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        page_ = b.new_page(viewport={"width": L, "height": H}, device_scale_factor=1)
        for nom, f in PLANCHES.items():
            page_.set_content(f())
            page_.wait_for_timeout(150)
            png = sortie / f"{nom}.png"
            page_.screenshot(path=str(png))
            # 128 couleurs sans tramage : aplats et texte gardés nets, environ quatre fois moins lourd.
            from PIL import Image
            Image.open(png).convert("RGB").quantize(colors=128, method=Image.Quantize.MEDIANCUT,
                                                    dither=Image.Dither.NONE).save(png, optimize=True)
            print(sortie / f"{nom}.png")
        b.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
